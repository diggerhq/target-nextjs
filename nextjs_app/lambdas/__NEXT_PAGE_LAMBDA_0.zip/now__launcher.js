"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// The Next.js builder can emit the project in a subdirectory depending on how
// many folder levels of `node_modules` are traced. To ensure `process.cwd()`
// returns the proper path, we change the directory to the folder with the
// launcher. This mimics `yarn workspace run` behavior.
process.chdir(__dirname);
if (!process.env.NODE_ENV) {
    const region = process.env.VERCEL_REGION || process.env.NOW_REGION;
    process.env.NODE_ENV = region === 'dev1' ? 'development' : 'production';
}
const http_1 = require("http");
const now__bridge_1 = require("./now__bridge");
// eslint-disable-next-line
let page = {};

              const url = require('url');

              function stripLocalePath(pathname) { return pathname }

              page = function(req, res) {
                try {
                  const pages = {
                    '/_error': () => require('./.next/serverless/pages/_error.js'),
'/blog': () => require('./.next/serverless/pages/blog.js'),
'/blog/[slug]': () => require('./.next/serverless/pages/blog/[slug].js'),
'/data-input': () => require('./.next/serverless/pages/data-input.js'),
'/forgot-password': () => require('./.next/serverless/pages/forgot-password.js'),
'/history': () => require('./.next/serverless/pages/history.js'),
'/history/[id]': () => require('./.next/serverless/pages/history/[id].js'),
'/history/[id]/compensate': () => require('./.next/serverless/pages/history/[id]/compensate.js'),
'/history/[id]/compensate/[project_id]': () => require('./.next/serverless/pages/history/[id]/compensate/[project_id].js'),
'/history/[id]/compensate/[project_id]/checkout': () => require('./.next/serverless/pages/history/[id]/compensate/[project_id]/checkout.js'),
'/history/[id]/compensate/[project_id]/payment': () => require('./.next/serverless/pages/history/[id]/compensate/[project_id]/payment.js'),
'/history/annual/[id]': () => require('./.next/serverless/pages/history/annual/[id].js'),
'/history/annual/[id]/edit': () => require('./.next/serverless/pages/history/annual/[id]/edit.js'),
'/history/annual/new': () => require('./.next/serverless/pages/history/annual/new.js'),
'/index': () => require('./.next/serverless/pages/index.js'),
'/login': () => require('./.next/serverless/pages/login.js'),
'/measurements': () => require('./.next/serverless/pages/measurements.js'),
'/measurements/[id]': () => require('./.next/serverless/pages/measurements/[id].js'),
'/measurements/[id]/business-travel': () => require('./.next/serverless/pages/measurements/[id]/business-travel.js'),
'/measurements/[id]/details': () => require('./.next/serverless/pages/measurements/[id]/details.js'),
'/measurements/[id]/expenses': () => require('./.next/serverless/pages/measurements/[id]/expenses.js'),
'/measurements/[id]/offices': () => require('./.next/serverless/pages/measurements/[id]/offices.js'),
'/measurements/[id]/result': () => require('./.next/serverless/pages/measurements/[id]/result.js'),
'/measurements/[id]/review': () => require('./.next/serverless/pages/measurements/[id]/review.js'),
'/measurements/[id]/vehicles': () => require('./.next/serverless/pages/measurements/[id]/vehicles.js'),
'/offers': () => require('./.next/serverless/pages/offers.js'),
'/offers/[slug]': () => require('./.next/serverless/pages/offers/[slug].js'),
'/offset': () => require('./.next/serverless/pages/offset.js'),
'/offset/projects/[slug]': () => require('./.next/serverless/pages/offset/projects/[slug].js'),
'/offset/projects/[slug]/payment': () => require('./.next/serverless/pages/offset/projects/[slug]/payment.js'),
'/onboard/change-password': () => require('./.next/serverless/pages/onboard/change-password.js'),
'/onboard/subscribe': () => require('./.next/serverless/pages/onboard/subscribe.js'),
'/onboarded': () => require('./.next/serverless/pages/onboarded.js'),
'/policy': () => require('./.next/serverless/pages/policy.js'),
'/reset-password': () => require('./.next/serverless/pages/reset-password.js'),
'/settings/admin': () => require('./.next/serverless/pages/settings/admin.js'),
'/settings/admin/billing': () => require('./.next/serverless/pages/settings/admin/billing.js'),
'/settings/admin/manage-team': () => require('./.next/serverless/pages/settings/admin/manage-team.js'),
'/settings/admin/offset-history': () => require('./.next/serverless/pages/settings/admin/offset-history.js'),
'/settings/admin/organisation-details': () => require('./.next/serverless/pages/settings/admin/organisation-details.js'),
'/settings/admin/password': () => require('./.next/serverless/pages/settings/admin/password.js'),
'/settings/admin/profile': () => require('./.next/serverless/pages/settings/admin/profile.js'),
'/settings/personal': () => require('./.next/serverless/pages/settings/personal.js'),
'/verify': () => require('./.next/serverless/pages/verify.js')
                    
                  }
                  let toRender = req.headers['x-nextjs-page']

                  if (!toRender) {
                    try {
                      const { pathname } = url.parse(req.url)
                      toRender = stripLocalePath(pathname).replace(/\/$/, '') || '/index'
                    } catch (_) {
                      // handle failing to parse url
                      res.statusCode = 400
                      return res.end('Bad Request')
                    }
                  }

                  let currentPage = pages[toRender]

                  if (
                    toRender &&
                    !currentPage
                  ) {
                    if (toRender.includes('/_next/data')) {
                      toRender = toRender
                        .replace(new RegExp('/_next/data/lDoX7RBEQ31kzKIJJbkVC/'), '/')
                        .replace(/\.json$/, '')

                      toRender = stripLocalePath(toRender) || '/index'
                      currentPage = pages[toRender]
                    }

                    if (!currentPage) {
                      // for prerendered dynamic routes (/blog/post-1) we need to
                      // find the match since it won't match the page directly
                      const dynamicRoutes = [{"src":"^/api/features/(?<slug>[^/]+?)(?:/)?$","dest":"/api/features/[slug]?slug=$slug"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)(?:/)?$","dest":"/api/organisations/[organisation_id]?organisation_id=$organisation_id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/create\\-link(?:/)?$","dest":"/api/organisations/[organisation_id]/create-link?organisation_id=$organisation_id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/data\\-collection(?:/)?$","dest":"/api/organisations/[organisation_id]/data-collection?organisation_id=$organisation_id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/data\\-collection/measurements/(?<measurement_id>[^/]+?)(?:/)?$","dest":"/api/organisations/[organisation_id]/data-collection/measurements/[measurement_id]?organisation_id=$organisation_id&measurement_id=$measurement_id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/data\\-collection/measurements/(?<measurement_id>[^/]+?)/office(?:/)?$","dest":"/api/organisations/[organisation_id]/data-collection/measurements/[measurement_id]/office?organisation_id=$organisation_id&measurement_id=$measurement_id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/data\\-collection/measurements/(?<measurement_id>[^/]+?)/office/(?<office_id>[^/]+?)(?:/)?$","dest":"/api/organisations/[organisation_id]/data-collection/measurements/[measurement_id]/office/[office_id]?organisation_id=$organisation_id&measurement_id=$measurement_id&office_id=$office_id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/email\\-link(?:/)?$","dest":"/api/organisations/[organisation_id]/email-link?organisation_id=$organisation_id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/invite\\-link(?:/)?$","dest":"/api/organisations/[organisation_id]/invite-link?organisation_id=$organisation_id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/invites(?:/)?$","dest":"/api/organisations/[organisation_id]/invites?organisation_id=$organisation_id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/invites/(?<id>[^/]+?)(?:/)?$","dest":"/api/organisations/[organisation_id]/invites/[id]?organisation_id=$organisation_id&id=$id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/invoices(?:/)?$","dest":"/api/organisations/[organisation_id]/invoices?organisation_id=$organisation_id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/invoices/(?<invoice_id>[^/]+?)(?:/)?$","dest":"/api/organisations/[organisation_id]/invoices/[invoice_id]?organisation_id=$organisation_id&invoice_id=$invoice_id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/measurements(?:/)?$","dest":"/api/organisations/[organisation_id]/measurements?organisation_id=$organisation_id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/measurements/(?<measurement_id>[^/]+?)(?:/)?$","dest":"/api/organisations/[organisation_id]/measurements/[measurement_id]?organisation_id=$organisation_id&measurement_id=$measurement_id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/measurements/(?<measurement_id>[^/]+?)/business\\-travel(?:/)?$","dest":"/api/organisations/[organisation_id]/measurements/[measurement_id]/business-travel?organisation_id=$organisation_id&measurement_id=$measurement_id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/measurements/(?<measurement_id>[^/]+?)/business\\-travel/batch(?:/)?$","dest":"/api/organisations/[organisation_id]/measurements/[measurement_id]/business-travel/batch?organisation_id=$organisation_id&measurement_id=$measurement_id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/measurements/(?<measurement_id>[^/]+?)/business\\-travel/(?<id>[^/]+?)(?:/)?$","dest":"/api/organisations/[organisation_id]/measurements/[measurement_id]/business-travel/[id]?organisation_id=$organisation_id&measurement_id=$measurement_id&id=$id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/measurements/(?<measurement_id>[^/]+?)/commutes(?:/)?$","dest":"/api/organisations/[organisation_id]/measurements/[measurement_id]/commutes?organisation_id=$organisation_id&measurement_id=$measurement_id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/measurements/(?<measurement_id>[^/]+?)/commutes/batch(?:/)?$","dest":"/api/organisations/[organisation_id]/measurements/[measurement_id]/commutes/batch?organisation_id=$organisation_id&measurement_id=$measurement_id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/measurements/(?<measurement_id>[^/]+?)/commutes/(?<id>[^/]+?)(?:/)?$","dest":"/api/organisations/[organisation_id]/measurements/[measurement_id]/commutes/[id]?organisation_id=$organisation_id&measurement_id=$measurement_id&id=$id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/measurements/(?<measurement_id>[^/]+?)/compensate(?:/)?$","dest":"/api/organisations/[organisation_id]/measurements/[measurement_id]/compensate?organisation_id=$organisation_id&measurement_id=$measurement_id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/measurements/(?<measurement_id>[^/]+?)/compensate/(?<invoice_id>[^/]+?)(?:/)?$","dest":"/api/organisations/[organisation_id]/measurements/[measurement_id]/compensate/[invoice_id]?organisation_id=$organisation_id&measurement_id=$measurement_id&invoice_id=$invoice_id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/measurements/(?<measurement_id>[^/]+?)/expenses(?:/)?$","dest":"/api/organisations/[organisation_id]/measurements/[measurement_id]/expenses?organisation_id=$organisation_id&measurement_id=$measurement_id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/measurements/(?<measurement_id>[^/]+?)/expenses/(?<id>[^/]+?)(?:/)?$","dest":"/api/organisations/[organisation_id]/measurements/[measurement_id]/expenses/[id]?organisation_id=$organisation_id&measurement_id=$measurement_id&id=$id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/measurements/(?<measurement_id>[^/]+?)/measurement\\-result(?:/)?$","dest":"/api/organisations/[organisation_id]/measurements/[measurement_id]/measurement-result?organisation_id=$organisation_id&measurement_id=$measurement_id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/measurements/(?<measurement_id>[^/]+?)/offices(?:/)?$","dest":"/api/organisations/[organisation_id]/measurements/[measurement_id]/offices?organisation_id=$organisation_id&measurement_id=$measurement_id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/measurements/(?<measurement_id>[^/]+?)/utilities(?:/)?$","dest":"/api/organisations/[organisation_id]/measurements/[measurement_id]/utilities?organisation_id=$organisation_id&measurement_id=$measurement_id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/measurements/(?<measurement_id>[^/]+?)/utilities/(?<id>[^/]+?)(?:/)?$","dest":"/api/organisations/[organisation_id]/measurements/[measurement_id]/utilities/[id]?organisation_id=$organisation_id&measurement_id=$measurement_id&id=$id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/measurements/(?<measurement_id>[^/]+?)/vehicle\\-usage(?:/)?$","dest":"/api/organisations/[organisation_id]/measurements/[measurement_id]/vehicle-usage?organisation_id=$organisation_id&measurement_id=$measurement_id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/measurements/(?<measurement_id>[^/]+?)/vehicle\\-usage/batch(?:/)?$","dest":"/api/organisations/[organisation_id]/measurements/[measurement_id]/vehicle-usage/batch?organisation_id=$organisation_id&measurement_id=$measurement_id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/measurements/(?<measurement_id>[^/]+?)/vehicle\\-usage/(?<id>[^/]+?)(?:/)?$","dest":"/api/organisations/[organisation_id]/measurements/[measurement_id]/vehicle-usage/[id]?organisation_id=$organisation_id&measurement_id=$measurement_id&id=$id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/measurements/(?<measurement_id>[^/]+?)/waste(?:/)?$","dest":"/api/organisations/[organisation_id]/measurements/[measurement_id]/waste?organisation_id=$organisation_id&measurement_id=$measurement_id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/measurements/(?<measurement_id>[^/]+?)/waste/(?<id>[^/]+?)(?:/)?$","dest":"/api/organisations/[organisation_id]/measurements/[measurement_id]/waste/[id]?organisation_id=$organisation_id&measurement_id=$measurement_id&id=$id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/offices(?:/)?$","dest":"/api/organisations/[organisation_id]/offices?organisation_id=$organisation_id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/offices/(?<office_id>[^/]+?)(?:/)?$","dest":"/api/organisations/[organisation_id]/offices/[office_id]?organisation_id=$organisation_id&office_id=$office_id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/payment\\-methods(?:/)?$","dest":"/api/organisations/[organisation_id]/payment-methods?organisation_id=$organisation_id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/payment\\-methods/(?<payment_method_id>[^/]+?)(?:/)?$","dest":"/api/organisations/[organisation_id]/payment-methods/[payment_method_id]?organisation_id=$organisation_id&payment_method_id=$payment_method_id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/policies(?:/)?$","dest":"/api/organisations/[organisation_id]/policies?organisation_id=$organisation_id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/subscriptions(?:/)?$","dest":"/api/organisations/[organisation_id]/subscriptions?organisation_id=$organisation_id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/subscriptions/setup\\-intent(?:/)?$","dest":"/api/organisations/[organisation_id]/subscriptions/setup-intent?organisation_id=$organisation_id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/users/admin(?:/)?$","dest":"/api/organisations/[organisation_id]/users/admin?organisation_id=$organisation_id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/users/(?<id>[^/]+?)(?:/)?$","dest":"/api/organisations/[organisation_id]/users/[id]?organisation_id=$organisation_id&id=$id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/vehicles(?:/)?$","dest":"/api/organisations/[organisation_id]/vehicles?organisation_id=$organisation_id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/vehicles/batch(?:/)?$","dest":"/api/organisations/[organisation_id]/vehicles/batch?organisation_id=$organisation_id"},{"src":"^/api/organisations/(?<organisation_id>[^/]+?)/vehicles/(?<vehicle_id>[^/]+?)(?:/)?$","dest":"/api/organisations/[organisation_id]/vehicles/[vehicle_id]?organisation_id=$organisation_id&vehicle_id=$vehicle_id"},{"src":"^/api/payment\\-intent/(?<id>[^/]+?)(?:/)?$","dest":"/api/payment-intent/[id]?id=$id"},{"src":"^/api/projects/(?<slug>[^/]+?)(?:/)?$","dest":"/api/projects/[slug]?slug=$slug"},{"src":"^/api/reduce/(?<slug>[^/]+?)(?:/)?$","dest":"/api/reduce/[slug]?slug=$slug"},{"src":"^/api/users/(?<id>[^/]+?)(?:/)?$","dest":"/api/users/[id]?id=$id"},{"src":"^/api/users/(?<id>[^/]+?)/interests(?:/)?$","dest":"/api/users/[id]/interests?id=$id"},{"src":"^/api/users/(?<id>[^/]+?)/reduction\\-categories(?:/)?$","dest":"/api/users/[id]/reduction-categories?id=$id"},{"src":"^/blog/(?<slug>[^/]+?)(?:/)?$","dest":"/blog/[slug]?slug=$slug"},{"src":"^/history/annual/(?<id>[^/]+?)(?:/)?$","dest":"/history/annual/[id]?id=$id"},{"src":"^/history/annual/(?<id>[^/]+?)/edit(?:/)?$","dest":"/history/annual/[id]/edit?id=$id"},{"src":"^/history/(?<id>[^/]+?)(?:/)?$","dest":"/history/[id]?id=$id"},{"src":"^/history/(?<id>[^/]+?)/compensate(?:/)?$","dest":"/history/[id]/compensate?id=$id"},{"src":"^/history/(?<id>[^/]+?)/compensate/(?<project_id>[^/]+?)(?:/)?$","dest":"/history/[id]/compensate/[project_id]?id=$id&project_id=$project_id"},{"src":"^/history/(?<id>[^/]+?)/compensate/(?<project_id>[^/]+?)/checkout(?:/)?$","dest":"/history/[id]/compensate/[project_id]/checkout?id=$id&project_id=$project_id"},{"src":"^/history/(?<id>[^/]+?)/compensate/(?<project_id>[^/]+?)/payment(?:/)?$","dest":"/history/[id]/compensate/[project_id]/payment?id=$id&project_id=$project_id"},{"src":"^/measurements/(?<id>[^/]+?)(?:/)?$","dest":"/measurements/[id]?id=$id"},{"src":"^/measurements/(?<id>[^/]+?)/business\\-travel(?:/)?$","dest":"/measurements/[id]/business-travel?id=$id"},{"src":"^/measurements/(?<id>[^/]+?)/details(?:/)?$","dest":"/measurements/[id]/details?id=$id"},{"src":"^/measurements/(?<id>[^/]+?)/expenses(?:/)?$","dest":"/measurements/[id]/expenses?id=$id"},{"src":"^/measurements/(?<id>[^/]+?)/offices(?:/)?$","dest":"/measurements/[id]/offices?id=$id"},{"src":"^/measurements/(?<id>[^/]+?)/result(?:/)?$","dest":"/measurements/[id]/result?id=$id"},{"src":"^/measurements/(?<id>[^/]+?)/review(?:/)?$","dest":"/measurements/[id]/review?id=$id"},{"src":"^/measurements/(?<id>[^/]+?)/vehicles(?:/)?$","dest":"/measurements/[id]/vehicles?id=$id"},{"src":"^/offers/(?<slug>[^/]+?)(?:/)?$","dest":"/offers/[slug]?slug=$slug"},{"src":"^/offset/projects/(?<slug>[^/]+?)(?:/)?$","dest":"/offset/projects/[slug]?slug=$slug"},{"src":"^/offset/projects/(?<slug>[^/]+?)/payment(?:/)?$","dest":"/offset/projects/[slug]/payment?slug=$slug"}]

                      for (const route of dynamicRoutes) {
                        const matcher = new RegExp(route.src)

                        if (matcher.test(toRender)) {
                          toRender = url.parse(route.dest).pathname
                          currentPage = pages[toRender]
                          break
                        }
                      }
                    }
                  }

                  if (!currentPage) {
                    console.error(
                      "Failed to find matching page for", {toRender, header: req.headers['x-nextjs-page'], url: req.url }, "in lambda"
                    )
                    console.error('pages in lambda', Object.keys(pages))
                    res.statusCode = 500
                    return res.end('internal server error')
                  }

                  const mod = currentPage()
                  const method = mod.render || mod.default || mod

                  return method(req, res)
                } catch (err) {
                  console.error('Unhandled error during request:', err)
                  throw err
                }
              }
              
// page.render is for React rendering
// page.default is for /api rendering
// page is for module.exports in /api
const server = new http_1.Server(page.render || page.default || page);
const bridge = new now__bridge_1.Bridge(server);
bridge.listen();
exports.launcher = bridge.launcher;
