"use strict";
(() => {
var exports = {};
exports.id = 3816;
exports.ids = [3816];
exports.modules = {

/***/ 72629:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(61908);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(45641);
/* harmony import */ var _button_Button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(59067);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(87491);
/* harmony import */ var _form_PasswordInput__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(20661);
/* harmony import */ var _contexts_auth__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(58368);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(91073);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(11098);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(75609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_1__, react_hook_form__WEBPACK_IMPORTED_MODULE_4__, _form_PasswordInput__WEBPACK_IMPORTED_MODULE_7__]);
([_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_1__, react_hook_form__WEBPACK_IMPORTED_MODULE_4__, _form_PasswordInput__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }











var Inhabit = function Inhabit(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("g", {
      clipPath: "url(#clip0_4478_114974)",
      fill: "#000",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("path", {
        d: "M52.654 25.875c-.502-.089-1.01-.15-1.505-.27a4.648 4.648 0 0 1-1.9-.873 3.743 3.743 0 0 1-1.326-2.47c-.188-1.266.075-2.405.931-3.369a6.394 6.394 0 0 1 2.133-1.483c1.233-.58 2.543-.902 3.855-1.213 1.419-.34 2.85-.63 4.266-.985a7.014 7.014 0 0 0 1.538-.58c.903-.469 1.118-1.033.913-2.057-.313-1.545-1.26-2.433-2.724-2.765-1.466-.353-3-.28-4.428.21-1.459.508-2.471 1.545-3.224 2.884-.059.106-.117.214-.18.32-.187.344-.285.377-.633.184-.458-.251-.908-.516-1.361-.773l-.617-.357c-.358-.205-.4-.352-.189-.703 1.353-2.239 3.226-3.77 5.733-4.452a11.573 11.573 0 0 1 3.388-.442 10.26 10.26 0 0 1 3.847.792c1.946.847 3.025 2.395 3.358 4.506.065.447.097.899.096 1.352.019 2.142.024 4.285.036 6.43 0 .668 0 1.338.01 2.006a.884.884 0 0 0 .178.564.844.844 0 0 0 .49.317 2.17 2.17 0 0 0 1.138-.016c.376-.127.534 0 .536.41v1.873c0 .386-.128.55-.484.65-1.129.312-2.258.364-3.367-.07a2.277 2.277 0 0 1-.821-.539 2.35 2.35 0 0 1-.528-.84 5.532 5.532 0 0 1-.377-2.1c.014-1.04 0-2.082-.028-3.133-.12.269-.237.537-.36.806-.752 1.647-1.693 3.146-3.07 4.318a7.523 7.523 0 0 1-4.33 1.84.689.689 0 0 0-.109.028h-.885zm8.948-11.376c-.335.245-.683.47-1.043.676-.368.192-.757.34-1.159.442-1.287.33-2.605.62-3.905.924-.941.216-1.883.448-2.73.929-.916.511-1.505 1.243-1.612 2.346-.132 1.352.446 2.358 1.65 2.795a6.488 6.488 0 0 0 4.425.029c1.861-.637 3.043-1.995 3.802-3.8.585-1.395.687-2.858.565-4.34h.007zM0 1.814a.55.55 0 0 1 .222-.224c.093-.05.2-.072.305-.062h2.07c.052 0 .105.003.156.01.36.048.401.086.44.453.011.124.015.247.012.371v22.23c.004.177-.003.354-.02.53a.324.324 0 0 1-.096.219.308.308 0 0 1-.217.09c-.216.011-.433 0-.65 0-.519 0-1.036.02-1.554.029-.25 0-.504.021-.67-.23L0 1.814zM72.618 19.497c.012 1.667.025 3.423.036 5.18.005.085.005.17 0 .253-.024.358-.178.52-.529.526-.284 0-.564-.023-.856-.025h-1.485a.28.28 0 0 1-.23-.075.295.295 0 0 1-.094-.229 3.577 3.577 0 0 1-.017-.347V.792.56c0-.421.098-.516.51-.518h2.122c.402 0 .564.15.58.564.012.33 0 .663 0 .995v10.986a.352.352 0 0 0 .061.218c.064-.164.14-.326.189-.494a8.065 8.065 0 0 1 1.805-3.218 6.741 6.741 0 0 1 3.961-2.184c2.36-.377 4.517.17 6.4 1.707 1.191.966 1.95 2.271 2.446 3.733.489 1.462.677 3.012.554 4.553a11.165 11.165 0 0 1-.785 3.639c-1.18 2.78-3.2 4.53-6.142 5.046-1.859.327-3.645.052-5.28-.965-1.266-.788-2.084-1.96-2.636-3.344-.235-.612-.425-1.245-.61-1.78zm6.198-9.757c-.521.062-1.048.09-1.562.193-2.07.404-3.504 1.61-4.278 3.627-.504 1.314-.564 2.666-.352 4.045.352 2.368 1.645 3.936 3.83 4.735a7.282 7.282 0 0 0 3.576.288c1.809-.259 3.2-1.159 4.08-2.822.882-1.662 1.028-3.463.68-5.297a5.753 5.753 0 0 0-.841-2.169 5.593 5.593 0 0 0-1.623-1.636c-1.063-.71-2.27-.914-3.51-.964zM31.266 13.338c.17-.535.329-1.072.513-1.6a8.413 8.413 0 0 1 1.866-3.163 5.922 5.922 0 0 1 3.798-1.827c1.45-.139 2.866.014 4.172.705 1.849.978 2.946 2.565 3.266 4.66.116.933.163 1.872.141 2.81.017 3.325.01 6.647.011 9.97 0 .447-.135.58-.564.569h-1.894c-.516 0-.68-.145-.68-.678v-9.945a7.481 7.481 0 0 0-.29-2.19c-.507-1.688-1.629-2.677-3.312-2.994a7.176 7.176 0 0 0-2.911 0c-1.267.282-2.214 1.033-2.936 2.113a7.113 7.113 0 0 0-1.226 4.056v9.182c-.03.3-.116.398-.412.407-.404.014-.81 0-1.214 0-.346 0-.69.03-1.037.027-.42 0-.555-.144-.555-.579V.641c0-.485.115-.599.587-.599h2.07c.435 0 .565.126.565.58v12.71l.042.006zM10.368 13.28c.245-.685.465-1.383.736-2.059.642-1.593 1.645-2.88 3.14-3.721a6.231 6.231 0 0 1 2.89-.798 8.136 8.136 0 0 1 3.147.49c1.946.73 3.138 2.183 3.644 4.211.197.775.303 1.571.318 2.372.047 3.538.041 7.076.055 10.623 0 .177.009.355 0 .53-.02.348-.166.51-.503.532-.201.011-.405-.023-.606-.021-.502 0-.998.01-1.489.029-.564.019-.72-.134-.72-.706V14.72a6.844 6.844 0 0 0-.377-2.36 4.005 4.005 0 0 0-1.122-1.723 3.858 3.858 0 0 0-1.812-.915 6.96 6.96 0 0 0-3.085-.056c-1.525.324-2.616 1.222-3.34 2.617a8.343 8.343 0 0 0-.942 3.886v8.558c0 .64-.188.772-.815.734-.514-.037-1.035-.01-1.553 0-.097 0-.188.015-.293.011-.41-.017-.565-.193-.565-.602V7.729c.003-.108.013-.215.03-.322a.3.3 0 0 1 .09-.196.286.286 0 0 1 .194-.082c.307-.02.616-.033.923-.037h1.4c.46 0 .627.15.625.614 0 .91-.023 1.82-.028 2.727v2.865l.058-.018zM103.283 15.337v4.603c-.003.518.116 1.029.344 1.49.39.799 1.032 1.177 1.882 1.237a4.415 4.415 0 0 0 1.969-.307l.105-.037c.307-.096.428 0 .424.323 0 .53-.017 1.064-.021 1.595 0 .193 0 .4.013.6a.468.468 0 0 1-.065.335.446.446 0 0 1-.272.197c-1.389.402-2.787.533-4.208.174-1.613-.408-2.554-1.476-2.947-3.1a12.055 12.055 0 0 1-.307-2.704c-.011-.81.032-1.619.03-2.428 0-1.379-.026-2.758-.034-4.137v-2.544c0-.473-.047-.523-.521-.525h-2.596c-.476 0-.6-.18-.574-.676.03-.58.029-1.159 0-1.738-.018-.443.108-.624.537-.624h2.663c.406 0 .493-.08.493-.497V2.48a1.09 1.09 0 0 1 .134-.595c.101-.181.25-.328.431-.423.694-.415 1.368-.867 2.059-1.292a.418.418 0 0 1 .346-.046c.071.034.119.202.119.31v6.06c0 .486.09.579.564.579h3.589c.463 0 .586.172.565.641-.026.58-.026 1.17 0 1.756.024.463-.094.635-.538.635h-3.62c-.47 0-.564.1-.564.58V15.336zM94.248 16.253v8.498c0 .58-.156.728-.732.718-.638-.01-1.276 0-1.914 0-.55 0-.717-.152-.717-.722V7.791c0-.626.077-.703.69-.703h2.031c.509 0 .635.132.635.66l.007 8.505zM90.562 2.057a2.059 2.059 0 0 1 .141-.797c.1-.253.248-.482.436-.675.188-.192.413-.343.66-.444.247-.1.51-.148.777-.141.265-.003.528.049.774.151.246.103.47.255.658.446a2.107 2.107 0 0 1 .594 1.465c0 .562-.216 1.1-.602 1.499-.386.398-.91.623-1.456.626a1.965 1.965 0 0 1-.777-.17 2.008 2.008 0 0 1-.65-.467 2.068 2.068 0 0 1-.425-.69 2.109 2.109 0 0 1-.13-.803z"
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("defs", {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("clipPath", {
        id: "clip0_4478_114974",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("path", {
          fill: "#fff",
          d: "M0 0h108v25.875H0z"
        })
      })
    })]
  }));
};

Inhabit.defaultProps = {
  width: "108",
  height: "26",
  viewBox: "0 0 108 26",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};






const StyledLogo = styled_components__WEBPACK_IMPORTED_MODULE_12___default()(Inhabit).withConfig({
  displayName: "ChangePassword__StyledLogo",
  componentId: "sc-1u2k8j6-0"
})(["width:8.5rem;cursor:pointer;margin:1rem auto;", " ", ""], _theme__WEBPACK_IMPORTED_MODULE_10__/* .media.mobileModern */ .BC.mobileModern`
    margin: 2rem auto;
  `, _theme__WEBPACK_IMPORTED_MODULE_10__/* .media.tablet */ .BC.tablet`
    margin: 0.5rem auto 2rem;
  `);
const schema = yup__WEBPACK_IMPORTED_MODULE_13__.object().shape({
  password: yup__WEBPACK_IMPORTED_MODULE_13__.string().required("No password provided.").min(8, "Password is too short - should be 8 chars minimum."),
  confirm_password: yup__WEBPACK_IMPORTED_MODULE_13__.string().oneOf([yup__WEBPACK_IMPORTED_MODULE_13__.ref("password"), null], "Passwords must match")
});
const ChangePasswordContainer = styled_components__WEBPACK_IMPORTED_MODULE_12___default().div.withConfig({
  displayName: "ChangePassword__ChangePasswordContainer",
  componentId: "sc-1u2k8j6-1"
})(["background:", ";padding:1.5rem;width:100%;position:relative;display:flex;flex-direction:column;align-items:flex-start;", ""], p => p.theme.colors.white, _theme__WEBPACK_IMPORTED_MODULE_10__/* .media.tablet */ .BC.tablet`
    max-width: 30rem;
    padding: 1.5rem 3rem;
    border-radius: 4px;
  `);
const HeadingContainer = styled_components__WEBPACK_IMPORTED_MODULE_12___default().div.withConfig({
  displayName: "ChangePassword__HeadingContainer",
  componentId: "sc-1u2k8j6-2"
})(["margin-bottom:2rem;display:flex;justify-content:center;"]);
const FormGroup = styled_components__WEBPACK_IMPORTED_MODULE_12___default().div.withConfig({
  displayName: "ChangePassword__FormGroup",
  componentId: "sc-1u2k8j6-3"
})(["z-index:1;margin-bottom:1.875rem;", ""], _theme__WEBPACK_IMPORTED_MODULE_10__/* .media.tabletLarge */ .BC.tabletLarge`
    display: flex;

    &>div{
      width:100%;
    }
  `);
const ButtonContainer = styled_components__WEBPACK_IMPORTED_MODULE_12___default().div.withConfig({
  displayName: "ChangePassword__ButtonContainer",
  componentId: "sc-1u2k8j6-4"
})(["margin:2rem auto;display:flex;justify-content:center;"]);
const Form = styled_components__WEBPACK_IMPORTED_MODULE_12___default().form.withConfig({
  displayName: "ChangePassword__Form",
  componentId: "sc-1u2k8j6-5"
})(["width:100%;"]);

const ChangePassword = () => {
  const {
    user,
    setUser
  } = (0,_contexts_auth__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
  const methods = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_4__.useForm)({
    resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_1__.yupResolver)(schema),
    defaultValues: {
      password: "",
      confirm_password: ""
    }
  });
  const {
    handleSubmit,
    formState: {
      isSubmitting
    }
  } = methods;

  const onSubmit = async ({
    password
  }) => {
    try {
      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_2___default().patch(`/api/create-password`, {
        password
      }, {
        headers: {
          Authorization: `Bearer ${router.query.token}`
        }
      });
      setUser(_objectSpread(_objectSpread({}, user), data));
      router.push("/");
    } catch (error) {
      if (error.response && error.response.data && error.response.data.errors === "jwt expired") {
        (0,_utils_logger__WEBPACK_IMPORTED_MODULE_11__/* .logError */ .H)(new Error("Reset token expired, please use forgot password link on the login page to request a new password"));
      } else {
        (0,_utils_logger__WEBPACK_IMPORTED_MODULE_11__/* .logError */ .H)(error);
      }
    }
  };

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(ChangePasswordContainer, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(StyledLogo, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(HeadingContainer, {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .ZP, {
        size: "boldBody",
        color: "black",
        children: "Create your password"
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_4__.FormProvider, _objectSpread(_objectSpread({}, methods), {}, {
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(Form, {
        onSubmit: handleSubmit(onSubmit),
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(FormGroup, {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_form_PasswordInput__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
            label: "New Password",
            name: "password",
            type: "password"
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(FormGroup, {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_form_PasswordInput__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
            label: "Confirm Password",
            name: "confirm_password",
            type: "password"
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(ButtonContainer, {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP, {
            loading: isSubmitting,
            children: "Create"
          })
        })]
      })
    }))]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ChangePassword);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 65812:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_common_Page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(97598);
/* harmony import */ var _components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(60805);
/* harmony import */ var _components_onboard_ChangePassword__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(72629);
/* harmony import */ var _contexts_auth__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(58368);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_2__, _components_onboard_ChangePassword__WEBPACK_IMPORTED_MODULE_3__]);
([_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_2__, _components_onboard_ChangePassword__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const ForgotPasswordContainer = styled_components__WEBPACK_IMPORTED_MODULE_6___default().div.withConfig({
  displayName: "change-password__ForgotPasswordContainer",
  componentId: "sc-18f05wl-0"
})(["width:100%;min-height:calc(100vh - ", ");display:flex;justify-content:center;align-items:center;flex-direction:column;overflow:scroll;background:", ";", ""], _components_common_Page__WEBPACK_IMPORTED_MODULE_1__/* .NAVBAR_OFFSET */ .v2, p => p.theme.colors.backgroundGrey, _theme__WEBPACK_IMPORTED_MODULE_5__/* .media.tablet */ .BC.tablet`
    max-height: calc(100vh - ${_components_common_Page__WEBPACK_IMPORTED_MODULE_1__/* .NAVBAR_OFFSET */ .v2});
  `);

const ForgotPassword = () => {
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_0__.useRouter)();
  const {
    user
  } = (0,_contexts_auth__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)();

  if (!(user !== null && user !== void 0 && user.password_change_required)) {
    router.push("/");
  }

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(styled_components__WEBPACK_IMPORTED_MODULE_6__.ThemeProvider, {
    theme: _theme__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP,
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(ForgotPasswordContainer, {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_components_onboard_ChangePassword__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)(ForgotPassword));
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 74261:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "unstable_getStaticParams": () => (/* binding */ unstable_getStaticParams),
/* harmony export */   "unstable_getStaticProps": () => (/* binding */ unstable_getStaticProps),
/* harmony export */   "unstable_getStaticPaths": () => (/* binding */ unstable_getStaticPaths),
/* harmony export */   "unstable_getServerProps": () => (/* binding */ unstable_getServerProps),
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "_app": () => (/* binding */ _app),
/* harmony export */   "renderReqToHTML": () => (/* binding */ renderReqToHTML),
/* harmony export */   "render": () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(70607);
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59450);
/* harmony import */ var private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97020);
/* harmony import */ var private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(73978);
/* harmony import */ var next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99436);

      
      
      
      

      
      const { processEnv } = __webpack_require__(85360)
      processEnv([{"path":".env","contents":"API_HOST=https://api.inhabit.eco\nNEXT_PUBLIC_CALENDLY_URL=https://calendly.com/inhabit-meet/inhabit-measurement-tutorial\nNEXT_PUBLIC_FLAGS_ENVIRONMENT_KEY=flags_pub_289425705564897805\nNEXT_PUBLIC_GOOGLE_ANALYTICS=G-1CBB78XFQ4\nNEXT_PUBLIC_INTERCOM_APP_ID=bw9p6mfd\nNEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_bQDaTEuYc10x3BZt9YcGj2cE00Gzwm4gDD\nSTRIPE_PUBLISHABLE_KEY=pk_live_bQDaTEuYc10x3BZt9YcGj2cE00Gzwm4gDD\n\n"}])
    
      
      const runtimeConfig = {}
      ;

      const documentModule = __webpack_require__(9968)

      const appMod = __webpack_require__(13724)
      let App = appMod.default || appMod.then && appMod.then(mod => mod.default);

      const compMod = __webpack_require__(65812)

      const Component = compMod.default || compMod.then && compMod.then(mod => mod.default)
      /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Component);
      const getStaticProps = compMod['getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['getStaticProp' + 's'])
      const getStaticPaths = compMod['getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['getStaticPath' + 's'])
      const getServerSideProps = compMod['getServerSideProp' + 's'] || compMod.then && compMod.then(mod => mod['getServerSideProp' + 's'])

      // kept for detecting legacy exports
      const unstable_getStaticParams = compMod['unstable_getStaticParam' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticParam' + 's'])
      const unstable_getStaticProps = compMod['unstable_getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticProp' + 's'])
      const unstable_getStaticPaths = compMod['unstable_getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticPath' + 's'])
      const unstable_getServerProps = compMod['unstable_getServerProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getServerProp' + 's'])

      let config = compMod['confi' + 'g'] || (compMod.then && compMod.then(mod => mod['confi' + 'g'])) || {}
      const _app = App

      const combinedRewrites = Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)
        ? private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg
        : []

      if (!Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)) {
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.beforeFiles */ .Dg.beforeFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.afterFiles */ .Dg.afterFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.fallback */ .Dg.fallback)
      }

      const { renderReqToHTML, render } = (0,next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__/* .getPageHandler */ .u)({
        pageModule: compMod,
        pageComponent: Component,
        pageConfig: config,
        appModule: App,
        documentModule: documentModule,
        errorModule: __webpack_require__(99651),
        notFoundModule: undefined,
        pageGetStaticProps: getStaticProps,
        pageGetStaticPaths: getStaticPaths,
        pageGetServerSideProps: getServerSideProps,

        assetPrefix: "",
        canonicalBase: "",
        generateEtags: true,
        poweredByHeader: true,
        reactRoot: false,

        runtimeConfig,
        buildManifest: private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__,
        reactLoadableManifest: private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__,

        rewrites: combinedRewrites,
        i18n: undefined,
        page: "/onboard/change-password",
        buildId: "lDoX7RBEQ31kzKIJJbkVC",
        escapedBuildId: "lDoX7RBEQ31kzKIJJbkVC",
        basePath: "",
        pageIsDynamic: false,
        encodedPreviewProps: {previewModeId:"89cdc9f6073608262d43eab6d636f3f4",previewModeSigningKey:"74c7e36a2414a3f7b0ebcc67250f915f156686e1610b45a21ae9358d5b7c6c5a",previewModeEncryptionKey:"8a4c97ad9e5cf12d5a140689be08539ea52d8b27a416c2b8ae67db636b45841b"}
      })
      
    

/***/ }),

/***/ 94970:
/***/ ((module) => {

module.exports = require("@happykit/flags/client");

/***/ }),

/***/ 46411:
/***/ ((module) => {

module.exports = require("@happykit/flags/config");

/***/ }),

/***/ 48095:
/***/ ((module) => {

module.exports = require("@happykit/flags/server");

/***/ }),

/***/ 83218:
/***/ ((module) => {

module.exports = require("@hookform/error-message");

/***/ }),

/***/ 48308:
/***/ ((module) => {

module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ 85360:
/***/ ((module) => {

module.exports = require("@next/env");

/***/ }),

/***/ 64515:
/***/ ((module) => {

module.exports = require("@stripe/react-stripe-js");

/***/ }),

/***/ 20943:
/***/ ((module) => {

module.exports = require("@stripe/stripe-js");

/***/ }),

/***/ 52167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 1043:
/***/ ((module) => {

module.exports = require("lodash.get");

/***/ }),

/***/ 51650:
/***/ ((module) => {

module.exports = require("lodash.uniqby");

/***/ }),

/***/ 54426:
/***/ ((module) => {

module.exports = require("next/dist/compiled/chalk");

/***/ }),

/***/ 40252:
/***/ ((module) => {

module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 19371:
/***/ ((module) => {

module.exports = require("next/dist/compiled/node-fetch");

/***/ }),

/***/ 97999:
/***/ ((module) => {

module.exports = require("next/dist/compiled/path-to-regexp");

/***/ }),

/***/ 60600:
/***/ ((module) => {

module.exports = require("next/dist/server/accept-header.js");

/***/ }),

/***/ 52155:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils/index.js");

/***/ }),

/***/ 90730:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils/node.js");

/***/ }),

/***/ 60562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 94140:
/***/ ((module) => {

module.exports = require("next/dist/server/get-page-files.js");

/***/ }),

/***/ 89716:
/***/ ((module) => {

module.exports = require("next/dist/server/htmlescape.js");

/***/ }),

/***/ 25071:
/***/ ((module) => {

module.exports = require("next/dist/server/render-result.js");

/***/ }),

/***/ 33100:
/***/ ((module) => {

module.exports = require("next/dist/server/render.js");

/***/ }),

/***/ 92779:
/***/ ((module) => {

module.exports = require("next/dist/server/request-meta.js");

/***/ }),

/***/ 79502:
/***/ ((module) => {

module.exports = require("next/dist/server/send-payload.js");

/***/ }),

/***/ 76368:
/***/ ((module) => {

module.exports = require("next/dist/server/utils.js");

/***/ }),

/***/ 56724:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 27664:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/escape-regexp.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 94957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 82374:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-locale-cookie.js");

/***/ }),

/***/ 34014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 78524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 78020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 29565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 64365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 95714:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-route-from-asset-path.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 91292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 25753:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-match.js");

/***/ }),

/***/ 99521:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/prepare-destination.js");

/***/ }),

/***/ 80979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 36052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 84226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 95566:
/***/ ((module) => {

module.exports = require("next/error");

/***/ }),

/***/ 40968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 71853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 59819:
/***/ ((module) => {

module.exports = require("querystring");

/***/ }),

/***/ 16689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 25716:
/***/ ((module) => {

module.exports = require("react-hotjar");

/***/ }),

/***/ 16666:
/***/ ((module) => {

module.exports = require("react-responsive");

/***/ }),

/***/ 1187:
/***/ ((module) => {

module.exports = require("react-toastify");

/***/ }),

/***/ 20997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 57518:
/***/ ((module) => {

module.exports = require("styled-components");

/***/ }),

/***/ 24535:
/***/ ((module) => {

module.exports = require("styled-normalize");

/***/ }),

/***/ 6153:
/***/ ((module) => {

module.exports = require("universal-cookie");

/***/ }),

/***/ 84269:
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ 75609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 61908:
/***/ ((module) => {

module.exports = import("@hookform/resolvers/yup");;

/***/ }),

/***/ 45641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [4357,9703,6114,9067,8183,9899,805,661], () => (__webpack_exec__(74261)));
module.exports = __webpack_exports__;

})();