"use strict";
(() => {
var exports = {};
exports.id = 7003;
exports.ids = [7003];
exports.modules = {

/***/ 22873:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(87491);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);



const Button = styled_components__WEBPACK_IMPORTED_MODULE_1___default().button.withConfig({
  displayName: "TextButton__Button",
  componentId: "sc-10zi0dq-0"
})(["cursor:pointer;display:flex;align-items:center;justify-content:center;border:none;border-radius:10px;background:inherit;span{text-decoration:underline;}"]);

const TextButton = ({
  onClick,
  children,
  size = "small"
}) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(Button, {
  onClick: onClick,
  type: "button",
  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .ZP, {
    size: size,
    color: "blue",
    children: children
  })
});

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TextButton);

/***/ }),

/***/ 9274:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _hookform_error_message__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(83218);
/* harmony import */ var _hookform_error_message__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_hookform_error_message__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(45641);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(87491);
/* harmony import */ var _Error__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(26428);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_1__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
const _excluded = ["id", "value", "name"],
      _excluded2 = ["id"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }









const Fill = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
  displayName: "CardRadioButtons__Fill",
  componentId: "sc-116wqt2-0"
})(["background:", ";width:0;height:0;border-radius:100%;position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);transition:width 0.2s ease-in,height 0.2s ease-in;pointer-events:none;z-index:1;&::before{content:\"\";opacity:0;width:calc(20px - 4px);position:absolute;height:calc(20px - 4px);top:50%;left:50%;transform:translate(-50%,-50%);border:1px solid ", ";border-radius:100%;}"], props => props.fillColor ? props.fillColor : props.theme.colors.blue, props => props.borderActive ? props.borderActive : props.theme.colors.blue);
const Input = styled_components__WEBPACK_IMPORTED_MODULE_4___default().input.withConfig({
  displayName: "CardRadioButtons__Input",
  componentId: "sc-116wqt2-1"
})(["opacity:0;z-index:2;position:absolute;top:0;width:100%;height:100%;margin:0;cursor:pointer;&:focus{outline:none;}&:checked{& ~ ", "{width:calc(100% - 8px);height:calc(100% - 8px);transition:width 0.2s ease-out,height 0.2s ease-out;&::before{opacity:1;transition:opacity 1s ease;}}}"], Fill);
const InputContainer = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
  displayName: "CardRadioButtons__InputContainer",
  componentId: "sc-116wqt2-2"
})(["margin:5px;cursor:pointer;width:", "px;min-width:", "px;max-width:", "px;height:", "px;position:relative;margin-right:20px;label{margin-left:25px;}&::before{content:\"\";border-radius:100%;border:1px solid ", ";background:", ";width:100%;height:100%;position:absolute;top:0;box-sizing:border-box;pointer-events:none;z-index:0;}"], props => props.size ? props.size : 20, props => props.size ? props.size : 20, props => props.size ? props.size : 20, props => props.size ? props.size : 20, props => props.borderColor ? props.borderColor : "#DDD", props => props.backgroundColor ? props.backgroundColor : "#FAFAFA");
const RadioButtonsContainer = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
  displayName: "CardRadioButtons__RadioButtonsContainer",
  componentId: "sc-116wqt2-3"
})(["display:flex;flex-direction:column;align-items:flex-start;width:100%;& > *:not(:first-child){margin-top:0.5rem;}"]);
const Container = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
  displayName: "CardRadioButtons__Container",
  componentId: "sc-116wqt2-4"
})(["display:flex;align-items:center;justify-content:flex-start;background:", ";width:100%;border-radius:4px;padding:14px 28px;"], p => p.theme.colors.white);
const Column = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
  displayName: "CardRadioButtons__Column",
  componentId: "sc-116wqt2-5"
})(["margin-right:50px;width:", ";"], p => p.width);
const Label = styled_components__WEBPACK_IMPORTED_MODULE_4___default().label.withConfig({
  displayName: "CardRadioButtons__Label",
  componentId: "sc-116wqt2-6"
})(["display:flex;width:100%;"]);
const ColumnsContainer = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
  displayName: "CardRadioButtons__ColumnsContainer",
  componentId: "sc-116wqt2-7"
})(["display:flex;width:100%;"]);

const RadioButton = _ref => {
  let {
    id,
    value,
    name
  } = _ref,
      rest = _objectWithoutProperties(_ref, _excluded);

  const {
    register,
    watch
  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_1__.useFormContext)();
  const currentValue = watch(name);
  const columns = Object.keys(rest);
  const widths = {
    cardholder: "30%",
    last4: "25%",
    expiry_date: "10%"
  };
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(Label, {
    htmlFor: id,
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(Container, {
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(InputContainer, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(Input, _objectSpread(_objectSpread({
          type: "radio"
        }, register(name)), {}, {
          "data-cy": `${name}`,
          id: id,
          value: value,
          defaultChecked: value === currentValue
        })), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(Fill, {})]
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(ColumnsContainer, {
        children: columns.map(key => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(Column, {
          width: widths[key] || "10%",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
            children: rest[key]
          })
        }, key))
      })]
    })
  });
};

const RadioButtons = ({
  options,
  name
}) => {
  const {
    formState: {
      errors
    }
  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_1__.useFormContext)();
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.Fragment, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(RadioButtonsContainer, {
      children: options.map(_ref2 => {
        let {
          id
        } = _ref2,
            rest = _objectWithoutProperties(_ref2, _excluded2);

        return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(RadioButton, _objectSpread({}, _objectSpread({
          id,
          name
        }, rest)), id);
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_hookform_error_message__WEBPACK_IMPORTED_MODULE_0__.ErrorMessage, {
      errors: errors,
      name: name,
      as: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_Error__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RadioButtons);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1805:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _stripe_react_stripe_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(64515);
/* harmony import */ var _stripe_react_stripe_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_stripe_react_stripe_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(45641);
/* harmony import */ var _components_button_Button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(59067);
/* harmony import */ var _components_button_TextButton__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(22873);
/* harmony import */ var _components_common_CardSection__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(48580);
/* harmony import */ var _components_common_Divider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6459);
/* harmony import */ var _components_common_LoadingLarge__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(49899);
/* harmony import */ var _components_common_Page__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(97598);
/* harmony import */ var _components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(60805);
/* harmony import */ var _components_common_Text__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(87491);
/* harmony import */ var _components_ContentContainer__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(16067);
/* harmony import */ var _components_form_CardRadioButtons__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(9274);
/* harmony import */ var _components_form_Input__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(18183);
/* harmony import */ var _components_measurement_utils_charts__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(19343);
/* harmony import */ var _contexts_auth__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(58368);
/* harmony import */ var _contexts_cart__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(44989);
/* harmony import */ var _contexts_measurements__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(85238);
/* harmony import */ var _contexts_project__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(98605);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(11098);
/* harmony import */ var _utils_numbers__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(86702);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_4__, _components_common_CardSection__WEBPACK_IMPORTED_MODULE_7__, _components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_11__, _components_form_CardRadioButtons__WEBPACK_IMPORTED_MODULE_14__, _components_form_Input__WEBPACK_IMPORTED_MODULE_15__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_4__, _components_common_CardSection__WEBPACK_IMPORTED_MODULE_7__, _components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_11__, _components_form_CardRadioButtons__WEBPACK_IMPORTED_MODULE_14__, _components_form_Input__WEBPACK_IMPORTED_MODULE_15__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
























var PoweredByStripe = function PoweredByStripe(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx("defs", {
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxs)("style", {
        children: [".cls-1", `{`, "fill:#635bff", `}`]
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx("title", {
      children: "Powered by Stripe - blurple"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx("path", {
      className: "cls-1",
      d: "M146 0H3.73A3.73 3.73 0 0 0 0 3.73v26.54A3.73 3.73 0 0 0 3.73 34H146a4 4 0 0 0 4-4V4a4 4 0 0 0-4-4zm3 30a3 3 0 0 1-3 3H3.73A2.74 2.74 0 0 1 1 30.27V3.73A2.74 2.74 0 0 1 3.73 1H146a3 3 0 0 1 3 3z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx("path", {
      className: "cls-1",
      d: "M17.07 11.24h-4.3V22h1.92v-4.16h2.38c2.4 0 3.9-1.16 3.9-3.3s-1.5-3.3-3.9-3.3zm-.1 5h-2.28v-3.3H17c1.38 0 2.11.59 2.11 1.65s-.76 1.6-2.11 1.6zM25.1 14a3.77 3.77 0 0 0-3.8 4.09 3.81 3.81 0 1 0 7.59 0A3.76 3.76 0 0 0 25.1 14zm0 6.67c-1.22 0-2-1-2-2.58s.76-2.58 2-2.58 2 1 2 2.58-.79 2.57-2 2.57zM36.78 19.35l-1.41-5.22h-1.48l-1.4 5.22-1.42-5.22h-1.85l2.37 7.88h1.56l1.44-5.16 1.44 5.16h1.56l2.37-7.88h-1.78l-1.4 5.22zM44 14a3.83 3.83 0 0 0-3.75 4.09 3.79 3.79 0 0 0 3.83 4.09A3.47 3.47 0 0 0 47.49 20L46 19.38a1.78 1.78 0 0 1-1.83 1.26A2.12 2.12 0 0 1 42 18.47h5.52v-.6C47.54 15.71 46.32 14 44 14zm-1.93 3.13A1.92 1.92 0 0 1 44 15.5a1.56 1.56 0 0 1 1.69 1.62zM50.69 15.3v-1.17h-1.8V22h1.8v-4.13a1.89 1.89 0 0 1 2-2 4.68 4.68 0 0 1 .66 0v-1.8h-.51a2.29 2.29 0 0 0-2.15 1.23zM57.48 14a3.83 3.83 0 0 0-3.75 4.09 3.79 3.79 0 0 0 3.83 4.09A3.47 3.47 0 0 0 60.93 20l-1.54-.59a1.78 1.78 0 0 1-1.83 1.26 2.12 2.12 0 0 1-2.1-2.17H61v-.6c0-2.19-1.24-3.9-3.52-3.9zm-1.93 3.13a1.92 1.92 0 0 1 1.92-1.62 1.56 1.56 0 0 1 1.69 1.62zM67.56 15a2.85 2.85 0 0 0-2.26-1c-2.21 0-3.47 1.85-3.47 4.09s1.26 4.09 3.47 4.09a2.82 2.82 0 0 0 2.26-1V22h1.8V11.24h-1.8zm0 3.35a2 2 0 0 1-2 2.28c-1.31 0-2-1-2-2.52s.7-2.52 2-2.52c1.11 0 2 .81 2 2.29zM79.31 14A2.88 2.88 0 0 0 77 15v-3.76h-1.8V22H77v-.83a2.86 2.86 0 0 0 2.27 1c2.2 0 3.46-1.86 3.46-4.09S81.51 14 79.31 14zM79 20.6a2 2 0 0 1-2-2.28v-.47c0-1.48.84-2.29 2-2.29 1.3 0 2 1 2 2.52s-.75 2.52-2 2.52zM86.93 19.66L85 14.13h-1.9l2.9 7.59-.3.74a1 1 0 0 1-1.14.79 4.12 4.12 0 0 1-.6 0v1.51a4.62 4.62 0 0 0 .73.05 2.67 2.67 0 0 0 2.78-2l3.24-8.62h-1.89zM125 12.43a3 3 0 0 0-2.13.87l-.14-.69h-2.39v12.92l2.72-.59v-3.13a3 3 0 0 0 1.93.7c1.94 0 3.72-1.59 3.72-5.11 0-3.22-1.8-4.97-3.71-4.97zm-.65 7.63a1.61 1.61 0 0 1-1.28-.52v-4.11a1.64 1.64 0 0 1 1.3-.55c1 0 1.68 1.13 1.68 2.58s-.69 2.6-1.7 2.6zM133.73 12.43c-2.62 0-4.21 2.26-4.21 5.11 0 3.37 1.88 5.08 4.56 5.08a6.12 6.12 0 0 0 3-.73v-2.25a5.79 5.79 0 0 1-2.7.62c-1.08 0-2-.39-2.14-1.7h5.38v-1c.09-2.87-1.27-5.13-3.89-5.13zm-1.47 4.07c0-1.26.77-1.79 1.45-1.79s1.4.53 1.4 1.79zM113 13.36l-.17-.82h-2.32v9.71h2.68v-6.58a1.87 1.87 0 0 1 2.05-.58v-2.55a1.8 1.8 0 0 0-2.24.82zM99.46 15.46c0-.44.36-.61.93-.61a5.9 5.9 0 0 1 2.7.72v-2.63a7 7 0 0 0-2.7-.51c-2.21 0-3.68 1.18-3.68 3.16 0 3.1 4.14 2.6 4.14 3.93 0 .52-.44.69-1 .69a6.78 6.78 0 0 1-3-.9V22a7.38 7.38 0 0 0 3 .64c2.26 0 3.82-1.15 3.82-3.16-.05-3.36-4.21-2.76-4.21-4.02zM107.28 10.24l-2.65.58v8.93a2.77 2.77 0 0 0 2.82 2.87 4.16 4.16 0 0 0 1.91-.37V20c-.35.15-2.06.66-2.06-1v-4h2.06v-2.34h-2.06zM116.25 11.7l2.73-.57V8.97l-2.73.57v2.16zM116.25 12.61h2.73v9.64h-2.73z"
    })]
  }));
};

PoweredByStripe.defaultProps = {
  id: "Layer_1",
  'data-name': "Layer 1",
  xmlns: "http://www.w3.org/2000/svg",
  viewBox: "0 0 150 34"
};





const Container = styled_components__WEBPACK_IMPORTED_MODULE_23___default().div.withConfig({
  displayName: "checkout__Container",
  componentId: "sc-1c6t2y9-0"
})(["display:flex;width:100%;"]);
const ProjectsContainer = styled_components__WEBPACK_IMPORTED_MODULE_23___default().div.withConfig({
  displayName: "checkout__ProjectsContainer",
  componentId: "sc-1c6t2y9-1"
})(["max-width:760px;width:760px;margin-right:40px;"]);
const AddCardContainer = styled_components__WEBPACK_IMPORTED_MODULE_23___default().div.withConfig({
  displayName: "checkout__AddCardContainer",
  componentId: "sc-1c6t2y9-2"
})(["background-color:", ";padding:20px 28px;display:flex;align-items:center;margin-top:0.5rem;border-radius:4px;"], p => p.theme.colors.white);
const ProjectsAmountContainer = styled_components__WEBPACK_IMPORTED_MODULE_23___default().div.withConfig({
  displayName: "checkout__ProjectsAmountContainer",
  componentId: "sc-1c6t2y9-3"
})(["max-width:420px;width:420px;"]);
const ProjectTechnologyRow = styled_components__WEBPACK_IMPORTED_MODULE_23___default().div.withConfig({
  displayName: "checkout__ProjectTechnologyRow",
  componentId: "sc-1c6t2y9-4"
})(["display:flex;justify-content:space-between;align-items:center;margin-bottom:0.5rem;"]);
const ButtonContainer = styled_components__WEBPACK_IMPORTED_MODULE_23___default().div.withConfig({
  displayName: "checkout__ButtonContainer",
  componentId: "sc-1c6t2y9-5"
})(["margin-top:2rem;display:flex;justify-content:flex-end;"]);
const TextButtonContainer = styled_components__WEBPACK_IMPORTED_MODULE_23___default().div.withConfig({
  displayName: "checkout__TextButtonContainer",
  componentId: "sc-1c6t2y9-6"
})(["display:flex;"]);
const ProjectDescription = styled_components__WEBPACK_IMPORTED_MODULE_23___default().div.withConfig({
  displayName: "checkout__ProjectDescription",
  componentId: "sc-1c6t2y9-7"
})(["background:", ";padding:16px 24px;display:flex;flex-direction:column;"], p => p.theme.colors.white);
const FormGroup = styled_components__WEBPACK_IMPORTED_MODULE_23___default().div.withConfig({
  displayName: "checkout__FormGroup",
  componentId: "sc-1c6t2y9-8"
})(["margin-bottom:1.25rem;width:100%;"]);
const TextContainer = styled_components__WEBPACK_IMPORTED_MODULE_23___default().div.withConfig({
  displayName: "checkout__TextContainer",
  componentId: "sc-1c6t2y9-9"
})(["display:flex;align-items:center;margin-bottom:10px;"]);
const CardContainer = styled_components__WEBPACK_IMPORTED_MODULE_23___default().form.withConfig({
  displayName: "checkout__CardContainer",
  componentId: "sc-1c6t2y9-10"
})(["display:flex;flex-direction:column;"]);
const PoweredByStripeIcon = styled_components__WEBPACK_IMPORTED_MODULE_23___default()(PoweredByStripe).withConfig({
  displayName: "checkout__PoweredByStripeIcon",
  componentId: "sc-1c6t2y9-11"
})(["margin:1rem 0 0;width:8rem;"]);

function Project() {
  var _options$, _createTotalMeasureme, _methods$formState;

  const {
    loading,
    setSelectedProject,
    selectedProject,
    getSelectedProject
  } = (0,_contexts_project__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z)();
  const {
    getSelectedMeasurement,
    selectedMeasurement,
    setSelectedMeasurement,
    loading: measurementLeading
  } = (0,_contexts_measurements__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z)({
    defaultSelectedMeasurement: true
  });
  const defaultValues = {
    add_new_card: false,
    payment_method: options === null || options === void 0 ? void 0 : (_options$ = options[0]) === null || _options$ === void 0 ? void 0 : _options$.id
  };
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
  const stripe = (0,_stripe_react_stripe_js__WEBPACK_IMPORTED_MODULE_1__.useStripe)();
  const elements = (0,_stripe_react_stripe_js__WEBPACK_IMPORTED_MODULE_1__.useElements)();
  const methods = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_4__.useForm)({
    defaultValues
  });
  const {
    organisation
  } = (0,_contexts_auth__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z)();
  const {
    0: paymentMethods,
    1: setPaymentMethods
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
  const {
    0: paymentMethodLoading,
    1: setPaymentMethodLoading
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    0: checkoutLoading,
    1: setCheckoutLoading
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    handleSubmit
  } = methods;
  const {
    getPaymentMethod
  } = (0,_contexts_cart__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .C)();
  const options = paymentMethods.map(card => ({
    id: card.id,
    value: card.id,
    last4: `**** **** **** ${card.last4}`,
    expiry_date: card.expiry_date,
    cardholder: card.name
  }));

  const onSubmit = async ({
    payment_method
  }) => {
    try {
      setCheckoutLoading(true);
      await getPaymentMethod(payment_method);
      router.push(`/history/${selectedMeasurement === null || selectedMeasurement === void 0 ? void 0 : selectedMeasurement.id}/compensate/${selectedProject.id}/payment`);
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_21__/* .logError */ .H)(error);
    } finally {
      setCheckoutLoading(false);
    }
  };

  const onSubmitNewCard = async ({
    name
  }) => {
    try {
      const cardElement = elements.getElement(_stripe_react_stripe_js__WEBPACK_IMPORTED_MODULE_1__.CardElement);
      const {
        paymentMethod,
        error
      } = await stripe.createPaymentMethod({
        type: "card",
        card: cardElement,
        billing_details: {
          name
        }
      });

      if (error) {
        throw error;
      } else {
        await axios__WEBPACK_IMPORTED_MODULE_2___default().post(`/api/organisations/${organisation.id}/payment-methods`, paymentMethod);
        await getPaymentMethods();
        methods.setValue("add_new_card", false);
      }
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_21__/* .logError */ .H)(error);
    }
  };

  const getPaymentMethods = async () => {
    try {
      setPaymentMethodLoading(true);
      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_2___default().get(`/api/organisations/${organisation.id}/payment-methods`);
      setPaymentMethods(data);
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_21__/* .logError */ .H)(error);
    } finally {
      setPaymentMethodLoading(false);
    }
  };

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    router.query.project_id && getSelectedProject(router.query.project_id);
    return () => setSelectedProject(null);
  }, [router.query]);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    getSelectedMeasurement();
    getPaymentMethods();
    return () => setSelectedMeasurement(null);
  }, []);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    var _paymentMethods$;

    methods.setValue("payment_method", paymentMethods === null || paymentMethods === void 0 ? void 0 : (_paymentMethods$ = paymentMethods[0]) === null || _paymentMethods$ === void 0 ? void 0 : _paymentMethods$.id);
  }, [paymentMethods]);
  const addNewCard = methods.watch("add_new_card");
  const payment_method = methods.watch("payment_method");
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    var _selectedMeasurement$;

    (selectedMeasurement === null || selectedMeasurement === void 0 ? void 0 : (_selectedMeasurement$ = selectedMeasurement.offsets) === null || _selectedMeasurement$ === void 0 ? void 0 : _selectedMeasurement$.length) && router.replace(`/history${selectedMeasurement.time_period === 12 && "/annual"}/${selectedMeasurement === null || selectedMeasurement === void 0 ? void 0 : selectedMeasurement.id}`);
  }, [selectedMeasurement]);
  const tonnes = (0,_utils_numbers__WEBPACK_IMPORTED_MODULE_22__/* .convertKgToTonnesValue */ .mC)((_createTotalMeasureme = (0,_components_measurement_utils_charts__WEBPACK_IMPORTED_MODULE_24__/* .createTotalMeasurementResults */ .d)(selectedMeasurement)) === null || _createTotalMeasureme === void 0 ? void 0 : _createTotalMeasureme.total);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_components_common_Page__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .ZP, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxs)(_components_ContentContainer__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
      iconBorder: false,
      title: "Payment Method",
      fullWidth: true,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_components_common_LoadingLarge__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
        loading: loading || paymentMethodLoading || measurementLeading
      }), selectedProject && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxs)(Container, {
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxs)(ProjectsContainer, {
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxs)(react_hook_form__WEBPACK_IMPORTED_MODULE_4__.FormProvider, _objectSpread(_objectSpread({}, methods), {}, {
            children: [addNewCard ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxs)(ProjectDescription, {
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(TextContainer, {
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .ZP, {
                  size: "subtitle1",
                  children: "New card"
                })
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxs)(react_hook_form__WEBPACK_IMPORTED_MODULE_4__.FormProvider, _objectSpread(_objectSpread({}, methods), {}, {
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(FormGroup, {
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_components_form_Input__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                    name: "name",
                    id: "name",
                    label: "Name:",
                    width: "400px"
                  })
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_components_common_CardSection__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                  width: "400px"
                })]
              })), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(PoweredByStripeIcon, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(ButtonContainer, {
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_components_button_Button__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP, {
                  onClick: handleSubmit(onSubmitNewCard),
                  loading: methods === null || methods === void 0 ? void 0 : (_methods$formState = methods.formState) === null || _methods$formState === void 0 ? void 0 : _methods$formState.isSubmitting,
                  type: "button",
                  children: "Save"
                })
              })]
            }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(CardContainer, {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_components_form_CardRadioButtons__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                options: options,
                name: "payment_method"
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(AddCardContainer, {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(TextButtonContainer, {
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_components_button_TextButton__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                  onClick: () => methods.setValue("add_new_card", !addNewCard),
                  children: addNewCard ? "Use existing card" : "Add card"
                })
              })
            })]
          })), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(ButtonContainer, {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_components_button_Button__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP, {
              onClick: handleSubmit(onSubmit),
              loading: checkoutLoading,
              disabled: addNewCard || !payment_method,
              type: "button",
              children: "Confirm"
            })
          })]
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(ProjectsAmountContainer, {
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxs)(ProjectDescription, {
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(TextContainer, {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .ZP, {
                size: "subtitle1",
                align: "left",
                children: selectedProject.name
              })
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxs)(ProjectTechnologyRow, {
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .ZP, {
                size: "tiny",
                fontWeight: 500,
                children: "Project price"
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxs)(_components_common_Text__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .ZP, {
                size: "tiny",
                fontWeight: 500,
                children: [(0,_utils_numbers__WEBPACK_IMPORTED_MODULE_22__/* .formatCurrency */ .xG)((selectedProject.average_price_per_tonne_pennies_gbp / 100).toFixed(2)), "/tonne"]
              })]
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxs)(ProjectTechnologyRow, {
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .ZP, {
                size: "tiny",
                fontWeight: 500,
                children: "Tonnes"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .ZP, {
                size: "tiny",
                fontWeight: 500,
                children: Math.ceil(tonnes)
              })]
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_components_common_Divider__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
              color: "black"
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxs)(ProjectTechnologyRow, {
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .ZP, {
                size: "subtitle1",
                fontWeight: 500,
                children: "Subtotal"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .ZP, {
                size: "subtitle1",
                fontWeight: 500,
                children: (0,_utils_numbers__WEBPACK_IMPORTED_MODULE_22__/* .formatCurrency */ .xG)((selectedProject.average_price_per_tonne_pennies_gbp / 100 * tonnes).toFixed(2))
              })]
            })]
          })
        })]
      })]
    })
  });
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z)(Project));
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 86702:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "mC": () => (/* binding */ convertKgToTonnesValue),
/* harmony export */   "xG": () => (/* binding */ formatCurrency)
/* harmony export */ });
/* unused harmony export formatter */
const convertKgToTonnesValue = value => !value ? 0 : Math.ceil(value / 1000);
const formatter = new Intl.NumberFormat("en-GB", {
  style: "currency",
  currency: "GBP",
  // These options are needed to round to whole numbers if that's what you want.
  minimumFractionDigits: 2,
  // (this suffices for whole numbers, but will print 2500.10 as $2,500.1)
  maximumFractionDigits: 2 // (causes 2500.99 to be printed as $2,501)

});
const formatCurrency = formatter.format;

/***/ }),

/***/ 66792:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "unstable_getStaticParams": () => (/* binding */ unstable_getStaticParams),
/* harmony export */   "unstable_getStaticProps": () => (/* binding */ unstable_getStaticProps),
/* harmony export */   "unstable_getStaticPaths": () => (/* binding */ unstable_getStaticPaths),
/* harmony export */   "unstable_getServerProps": () => (/* binding */ unstable_getServerProps),
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "_app": () => (/* binding */ _app),
/* harmony export */   "renderReqToHTML": () => (/* binding */ renderReqToHTML),
/* harmony export */   "render": () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(70607);
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59450);
/* harmony import */ var private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97020);
/* harmony import */ var private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(73978);
/* harmony import */ var next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99436);

      
      
      
      

      
      const { processEnv } = __webpack_require__(85360)
      processEnv([{"path":".env","contents":"API_HOST=https://api.inhabit.eco\nNEXT_PUBLIC_CALENDLY_URL=https://calendly.com/inhabit-meet/inhabit-measurement-tutorial\nNEXT_PUBLIC_FLAGS_ENVIRONMENT_KEY=flags_pub_289425705564897805\nNEXT_PUBLIC_GOOGLE_ANALYTICS=G-1CBB78XFQ4\nNEXT_PUBLIC_INTERCOM_APP_ID=bw9p6mfd\nNEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_bQDaTEuYc10x3BZt9YcGj2cE00Gzwm4gDD\nSTRIPE_PUBLISHABLE_KEY=pk_live_bQDaTEuYc10x3BZt9YcGj2cE00Gzwm4gDD\n\n"}])
    
      
      const runtimeConfig = {}
      ;

      const documentModule = __webpack_require__(9968)

      const appMod = __webpack_require__(13724)
      let App = appMod.default || appMod.then && appMod.then(mod => mod.default);

      const compMod = __webpack_require__(1805)

      const Component = compMod.default || compMod.then && compMod.then(mod => mod.default)
      /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Component);
      const getStaticProps = compMod['getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['getStaticProp' + 's'])
      const getStaticPaths = compMod['getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['getStaticPath' + 's'])
      const getServerSideProps = compMod['getServerSideProp' + 's'] || compMod.then && compMod.then(mod => mod['getServerSideProp' + 's'])

      // kept for detecting legacy exports
      const unstable_getStaticParams = compMod['unstable_getStaticParam' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticParam' + 's'])
      const unstable_getStaticProps = compMod['unstable_getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticProp' + 's'])
      const unstable_getStaticPaths = compMod['unstable_getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticPath' + 's'])
      const unstable_getServerProps = compMod['unstable_getServerProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getServerProp' + 's'])

      let config = compMod['confi' + 'g'] || (compMod.then && compMod.then(mod => mod['confi' + 'g'])) || {}
      const _app = App

      const combinedRewrites = Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)
        ? private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg
        : []

      if (!Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)) {
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.beforeFiles */ .Dg.beforeFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.afterFiles */ .Dg.afterFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.fallback */ .Dg.fallback)
      }

      const { renderReqToHTML, render } = (0,next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__/* .getPageHandler */ .u)({
        pageModule: compMod,
        pageComponent: Component,
        pageConfig: config,
        appModule: App,
        documentModule: documentModule,
        errorModule: __webpack_require__(99651),
        notFoundModule: undefined,
        pageGetStaticProps: getStaticProps,
        pageGetStaticPaths: getStaticPaths,
        pageGetServerSideProps: getServerSideProps,

        assetPrefix: "",
        canonicalBase: "",
        generateEtags: true,
        poweredByHeader: true,
        reactRoot: false,

        runtimeConfig,
        buildManifest: private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__,
        reactLoadableManifest: private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__,

        rewrites: combinedRewrites,
        i18n: undefined,
        page: "/history/[id]/compensate/[project_id]/checkout",
        buildId: "lDoX7RBEQ31kzKIJJbkVC",
        escapedBuildId: "lDoX7RBEQ31kzKIJJbkVC",
        basePath: "",
        pageIsDynamic: true,
        encodedPreviewProps: {previewModeId:"89cdc9f6073608262d43eab6d636f3f4",previewModeSigningKey:"74c7e36a2414a3f7b0ebcc67250f915f156686e1610b45a21ae9358d5b7c6c5a",previewModeEncryptionKey:"8a4c97ad9e5cf12d5a140689be08539ea52d8b27a416c2b8ae67db636b45841b"}
      })
      
    

/***/ }),

/***/ 94970:
/***/ ((module) => {

module.exports = require("@happykit/flags/client");

/***/ }),

/***/ 46411:
/***/ ((module) => {

module.exports = require("@happykit/flags/config");

/***/ }),

/***/ 48095:
/***/ ((module) => {

module.exports = require("@happykit/flags/server");

/***/ }),

/***/ 83218:
/***/ ((module) => {

module.exports = require("@hookform/error-message");

/***/ }),

/***/ 48308:
/***/ ((module) => {

module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ 85360:
/***/ ((module) => {

module.exports = require("@next/env");

/***/ }),

/***/ 64515:
/***/ ((module) => {

module.exports = require("@stripe/react-stripe-js");

/***/ }),

/***/ 20943:
/***/ ((module) => {

module.exports = require("@stripe/stripe-js");

/***/ }),

/***/ 52167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 1043:
/***/ ((module) => {

module.exports = require("lodash.get");

/***/ }),

/***/ 51650:
/***/ ((module) => {

module.exports = require("lodash.uniqby");

/***/ }),

/***/ 54426:
/***/ ((module) => {

module.exports = require("next/dist/compiled/chalk");

/***/ }),

/***/ 40252:
/***/ ((module) => {

module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 19371:
/***/ ((module) => {

module.exports = require("next/dist/compiled/node-fetch");

/***/ }),

/***/ 97999:
/***/ ((module) => {

module.exports = require("next/dist/compiled/path-to-regexp");

/***/ }),

/***/ 60600:
/***/ ((module) => {

module.exports = require("next/dist/server/accept-header.js");

/***/ }),

/***/ 52155:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils/index.js");

/***/ }),

/***/ 90730:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils/node.js");

/***/ }),

/***/ 60562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 94140:
/***/ ((module) => {

module.exports = require("next/dist/server/get-page-files.js");

/***/ }),

/***/ 89716:
/***/ ((module) => {

module.exports = require("next/dist/server/htmlescape.js");

/***/ }),

/***/ 25071:
/***/ ((module) => {

module.exports = require("next/dist/server/render-result.js");

/***/ }),

/***/ 33100:
/***/ ((module) => {

module.exports = require("next/dist/server/render.js");

/***/ }),

/***/ 92779:
/***/ ((module) => {

module.exports = require("next/dist/server/request-meta.js");

/***/ }),

/***/ 79502:
/***/ ((module) => {

module.exports = require("next/dist/server/send-payload.js");

/***/ }),

/***/ 76368:
/***/ ((module) => {

module.exports = require("next/dist/server/utils.js");

/***/ }),

/***/ 56724:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 27664:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/escape-regexp.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 94957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 82374:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-locale-cookie.js");

/***/ }),

/***/ 34014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 78524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 78020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 29565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 64365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 95714:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-route-from-asset-path.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 91292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 25753:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-match.js");

/***/ }),

/***/ 99521:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/prepare-destination.js");

/***/ }),

/***/ 80979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 36052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 84226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 95566:
/***/ ((module) => {

module.exports = require("next/error");

/***/ }),

/***/ 40968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 71853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 59819:
/***/ ((module) => {

module.exports = require("querystring");

/***/ }),

/***/ 16689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 25716:
/***/ ((module) => {

module.exports = require("react-hotjar");

/***/ }),

/***/ 16666:
/***/ ((module) => {

module.exports = require("react-responsive");

/***/ }),

/***/ 1187:
/***/ ((module) => {

module.exports = require("react-toastify");

/***/ }),

/***/ 20997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 57518:
/***/ ((module) => {

module.exports = require("styled-components");

/***/ }),

/***/ 24535:
/***/ ((module) => {

module.exports = require("styled-normalize");

/***/ }),

/***/ 6153:
/***/ ((module) => {

module.exports = require("universal-cookie");

/***/ }),

/***/ 84269:
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ 75609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 61908:
/***/ ((module) => {

module.exports = import("@hookform/resolvers/yup");;

/***/ }),

/***/ 45641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [4357,9703,6114,9067,8183,9899,805,6067,9343], () => (__webpack_exec__(66792)));
module.exports = __webpack_exports__;

})();