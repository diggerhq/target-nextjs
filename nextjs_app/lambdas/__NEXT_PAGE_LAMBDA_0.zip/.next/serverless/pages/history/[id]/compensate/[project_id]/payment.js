"use strict";
(() => {
var exports = {};
exports.id = 6343;
exports.ids = [6343];
exports.modules = {

/***/ 18549:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Text__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(87491);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);
const _excluded = ["id", "value", "name", "currentValue"],
      _excluded2 = ["id"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }






const Fill = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "CardRadioButtons__Fill",
  componentId: "sc-1o2chwi-0"
})(["background:", ";width:0;height:0;border-radius:100%;position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);transition:width 0.2s ease-in,height 0.2s ease-in;pointer-events:none;z-index:1;&::before{content:\"\";opacity:0;width:calc(20px - 4px);position:absolute;height:calc(20px - 4px);top:50%;left:50%;transform:translate(-50%,-50%);border:1px solid ", ";border-radius:100%;}"], props => props.fillColor ? props.fillColor : props.theme.colors.blue, props => props.borderActive ? props.borderActive : props.theme.colors.blue);
const Input = styled_components__WEBPACK_IMPORTED_MODULE_1___default().input.withConfig({
  displayName: "CardRadioButtons__Input",
  componentId: "sc-1o2chwi-1"
})(["opacity:0;z-index:2;position:absolute;top:0;width:100%;height:100%;margin:0;cursor:pointer;&:focus{outline:none;}&:checked{& ~ ", "{width:calc(100% - 8px);height:calc(100% - 8px);transition:width 0.2s ease-out,height 0.2s ease-out;&::before{opacity:1;transition:opacity 1s ease;}}}"], Fill);
const InputContainer = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "CardRadioButtons__InputContainer",
  componentId: "sc-1o2chwi-2"
})(["margin:5px;cursor:pointer;width:", "px;height:", "px;position:relative;margin-right:20px;label{margin-left:25px;}&::before{content:\"\";border-radius:100%;border:1px solid ", ";background:", ";width:100%;height:100%;position:absolute;top:0;box-sizing:border-box;pointer-events:none;z-index:0;}"], props => props.size ? props.size : 20, props => props.size ? props.size : 20, props => props.borderColor ? props.borderColor : "#DDD", props => props.backgroundColor ? props.backgroundColor : "#FAFAFA");
const RadioButtonsContainer = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "CardRadioButtons__RadioButtonsContainer",
  componentId: "sc-1o2chwi-3"
})(["display:flex;flex-direction:column;align-items:flex-start;width:100%;& > *:not(:first-child){margin-top:0.5rem;}"]);
const Container = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "CardRadioButtons__Container",
  componentId: "sc-1o2chwi-4"
})(["display:flex;align-items:center;justify-content:flex-start;background:", ";width:100%;border-radius:4px;padding:14px 28px;"], p => p.theme.colors.white);
const Column = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "CardRadioButtons__Column",
  componentId: "sc-1o2chwi-5"
})(["margin-right:75px;"]);
const Label = styled_components__WEBPACK_IMPORTED_MODULE_1___default().label.withConfig({
  displayName: "CardRadioButtons__Label",
  componentId: "sc-1o2chwi-6"
})(["display:flex;"]);

const RadioButton = _ref => {
  let {
    id,
    value,
    name,
    currentValue
  } = _ref,
      rest = _objectWithoutProperties(_ref, _excluded);

  const columns = Object.keys(rest);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(Container, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(InputContainer, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(Input, {
        type: "radio",
        "data-cy": `${name}`,
        id: id,
        value: value,
        defaultChecked: value === currentValue
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(Fill, {})]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(Label, {
      htmlFor: id,
      children: columns.map(key => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(Column, {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_Text__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .ZP, {
          children: rest[key]
        })
      }, key))
    })]
  });
};

const RadioButtons = ({
  options,
  name,
  currentValue
}) => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(RadioButtonsContainer, {
      children: options.map(_ref2 => {
        let {
          id
        } = _ref2,
            rest = _objectWithoutProperties(_ref2, _excluded2);

        return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(RadioButton, _objectSpread({}, _objectSpread({
          id,
          name,
          currentValue
        }, rest)), id);
      })
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RadioButtons);

/***/ }),

/***/ 55280:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _stripe_react_stripe_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(64515);
/* harmony import */ var _stripe_react_stripe_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_stripe_react_stripe_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var lodash_get__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1043);
/* harmony import */ var lodash_get__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lodash_get__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1187);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _components_button_Button__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(59067);
/* harmony import */ var _components_common_CardRadioButtons__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(18549);
/* harmony import */ var _components_common_Divider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6459);
/* harmony import */ var _components_common_LoadingLarge__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(49899);
/* harmony import */ var _components_common_Page__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(97598);
/* harmony import */ var _components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(60805);
/* harmony import */ var _components_common_Text__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(87491);
/* harmony import */ var _components_common_TextLink__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(33843);
/* harmony import */ var _components_common_Tooltip__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(39891);
/* harmony import */ var _components_ContentContainer__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(16067);
/* harmony import */ var _components_measurement_utils_charts__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(19343);
/* harmony import */ var _contexts_auth__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(58368);
/* harmony import */ var _contexts_cart__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(44989);
/* harmony import */ var _contexts_measurements__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(85238);
/* harmony import */ var _contexts_project__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(98605);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(11098);
/* harmony import */ var _utils_numbers__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(86702);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_11__]);
_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_11__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



























const ProjectsContainer = styled_components__WEBPACK_IMPORTED_MODULE_22___default().div.withConfig({
  displayName: "payment__ProjectsContainer",
  componentId: "lukw9u-0"
})(["max-width:760px;width:760px;margin-right:40px;"]);
const ConfirmContainer = styled_components__WEBPACK_IMPORTED_MODULE_22___default().div.withConfig({
  displayName: "payment__ConfirmContainer",
  componentId: "lukw9u-1"
})(["max-width:760px;width:760px;background:", ";padding:16px 24px;display:flex;flex-direction:column;"], p => p.theme.colors.white);
const ProjectTechnologyRow = styled_components__WEBPACK_IMPORTED_MODULE_22___default().div.withConfig({
  displayName: "payment__ProjectTechnologyRow",
  componentId: "lukw9u-2"
})(["display:flex;justify-content:space-between;align-items:center;margin-bottom:0.5rem;"]);
const CardContainer = styled_components__WEBPACK_IMPORTED_MODULE_22___default().form.withConfig({
  displayName: "payment__CardContainer",
  componentId: "lukw9u-3"
})(["display:flex;flex-direction:column;"]);
const ConfirmationRow = styled_components__WEBPACK_IMPORTED_MODULE_22___default().div.withConfig({
  displayName: "payment__ConfirmationRow",
  componentId: "lukw9u-4"
})(["display:flex;justify-content:space-between;align-items:center;"]);
const ProjectActions = styled_components__WEBPACK_IMPORTED_MODULE_22___default().div.withConfig({
  displayName: "payment__ProjectActions",
  componentId: "lukw9u-5"
})(["display:flex;justify-content:flex-end;align-items:center;margin-top:1rem;text-align:right;"]);
const ButtonContainer = styled_components__WEBPACK_IMPORTED_MODULE_22___default().div.withConfig({
  displayName: "payment__ButtonContainer",
  componentId: "lukw9u-6"
})(["margin-left:1.25rem;"]);
const TextContainer = styled_components__WEBPACK_IMPORTED_MODULE_22___default().div.withConfig({
  displayName: "payment__TextContainer",
  componentId: "lukw9u-7"
})(["display:flex;align-items:center;margin:1.25rem 0;"]);

function Project() {
  var _ref, _createTotalMeasureme, _invoice$metadata$ton, _invoice$metadata, _invoice$lines, _invoice$lines$data;

  const {
    loading,
    setSelectedProject,
    selectedProject,
    getSelectedProject
  } = (0,_contexts_project__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z)();
  const {
    measurements,
    getSelectedMeasurement,
    selectedMeasurement,
    setSelectedMeasurement,
    loading: measurementLeading
  } = (0,_contexts_measurements__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z)({
    defaultSelectedMeasurement: true
  });
  const {
    organisation
  } = (0,_contexts_auth__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z)();
  const {
    0: invoice,
    1: setInvoice
  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)();
  const {
    0: submitLoading,
    1: setSubmitLoading
  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
  const {
    0: invoiceLoading,
    1: setInvoiceLoading
  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
  const stripe = (0,_stripe_react_stripe_js__WEBPACK_IMPORTED_MODULE_0__.useStripe)();
  const {
    loading: paymentMethodLoading,
    paymentMethod,
    getPaymentMethod
  } = (0,_contexts_cart__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .C)();
  const options = paymentMethod ? (_ref = [paymentMethod]) === null || _ref === void 0 ? void 0 : _ref.map(card => ({
    id: card.id,
    value: card.id,
    last4: `**** **** **** ${card.last4}`,
    expiry_date: card.expiry_date,
    cardholder: card.name
  })) : [];
  const tonnes = (0,_utils_numbers__WEBPACK_IMPORTED_MODULE_21__/* .convertKgToTonnesValue */ .mC)((_createTotalMeasureme = (0,_components_measurement_utils_charts__WEBPACK_IMPORTED_MODULE_24__/* .createTotalMeasurementResults */ .d)(selectedMeasurement)) === null || _createTotalMeasureme === void 0 ? void 0 : _createTotalMeasureme.total);

  const getInvoice = async () => {
    try {
      setInvoiceLoading(true);
      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`/api/organisations/${organisation.id}/measurements/${selectedMeasurement === null || selectedMeasurement === void 0 ? void 0 : selectedMeasurement.id}/compensate/${invoice.id}`);
      setInvoice(data);
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_20__/* .logError */ .H)(error);
    } finally {
      setInvoiceLoading(false);
    }
  };

  const createInvoice = async () => {
    try {
      setInvoiceLoading(true);
      const compensateData = {
        payment_method: paymentMethod.id,
        tonnes,
        project_id: selectedProject.id
      };
      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_1___default().post(`/api/organisations/${organisation.id}/measurements/${selectedMeasurement === null || selectedMeasurement === void 0 ? void 0 : selectedMeasurement.id}/compensate`, compensateData);
      setInvoice(data);
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_20__/* .logError */ .H)(error);
    } finally {
      setInvoiceLoading(false);
    }
  };

  const cancelInvoice = async () => {
    try {
      setInvoiceLoading(true);
      console.log("CALLED");

      if ((invoice === null || invoice === void 0 ? void 0 : invoice.status) === "paid") {
        return;
      }

      await axios__WEBPACK_IMPORTED_MODULE_1___default()["delete"](`/api/organisations/${organisation.id}/measurements/${selectedMeasurement === null || selectedMeasurement === void 0 ? void 0 : selectedMeasurement.id}/compensate/${invoice === null || invoice === void 0 ? void 0 : invoice.id}`);
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_20__/* .logError */ .H)(error);
    } finally {
      setInvoiceLoading(false);
    }
  };

  const handleClick = async () => {
    try {
      setSubmitLoading(true);
      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_1___default().patch(`/api/organisations/${organisation.id}/measurements/${selectedMeasurement === null || selectedMeasurement === void 0 ? void 0 : selectedMeasurement.id}/compensate/${invoice === null || invoice === void 0 ? void 0 : invoice.id}`);
      const {
        payment_intent
      } = data;
      const {
        paymentIntent: newPaymentIntent,
        error
      } = await stripe.confirmCardPayment(payment_intent.client_secret, {
        payment_method: payment_intent.payment_method
      });

      if (error) {
        throw error;
      }

      if (newPaymentIntent) {
        checkSubscription(newPaymentIntent, newPaymentIntent.payment_method);
      }
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_20__/* .logError */ .H)(error);
    } finally {
      setSubmitLoading(false);
    }
  };

  const handleSuccess = async paymentIntent => {
    await getInvoice();
    setSubmitLoading(false);
  };

  const checkSubscription = (paymentIntent, paymentMethod) => {
    if (paymentIntent) {
      switch (paymentIntent.status) {
        case "succeeded":
          handleSuccess(paymentIntent);
          break;

        case "requires_payment_method":
          (0,_utils_logger__WEBPACK_IMPORTED_MODULE_20__/* .logError */ .H)({
            message: lodash_get__WEBPACK_IMPORTED_MODULE_2___default()(paymentIntent, "last_payment_error.message", "Could no make the payment please check your card and try again")
          });
          break;

        case "requires_action":
          authenticateCard(paymentIntent, paymentMethod);
          break;

        default:
          react_toastify__WEBPACK_IMPORTED_MODULE_5__.toast.info("Something seems to have gone wrong please get in contact with us");
          break;
      }
    }
  };

  const authenticateCard = async (paymentIntent, paymentMethod) => {
    const {
      paymentIntent: newPaymentIntent,
      error
    } = await stripe.confirmCardPayment(paymentIntent.client_secret, {
      payment_method: paymentMethod
    });

    if (error) {
      throw error;
    } else {
      checkSubscription(newPaymentIntent, paymentMethod);
    }
  };

  (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(() => {
    router.query.project_id && getSelectedProject(router.query.project_id);
    return () => setSelectedProject(null);
  }, [router.query]);
  (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(() => {
    paymentMethod && selectedMeasurement && selectedProject && !invoice && !invoiceLoading && createInvoice();
  }, [selectedMeasurement, selectedProject, paymentMethod, invoice]);
  (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(() => {
    getSelectedMeasurement();
    return () => setSelectedMeasurement(null);
  }, []);
  (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(() => {
    (invoice === null || invoice === void 0 ? void 0 : invoice.default_payment_method) && getPaymentMethod(invoice === null || invoice === void 0 ? void 0 : invoice.default_payment_method);
  }, [invoice]);
  (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(() => {
    selectedMeasurement && selectedProject && !paymentMethod && router.replace(`/history/${selectedMeasurement === null || selectedMeasurement === void 0 ? void 0 : selectedMeasurement.id}/compensate/${selectedProject.id}/checkout`);
  }, [selectedMeasurement, selectedProject, paymentMethod]);
  const paid = (invoice === null || invoice === void 0 ? void 0 : invoice.status) === "paid";
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(_components_common_Page__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .ZP, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsxs)(_components_ContentContainer__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
      iconBorder: false,
      title: paid ? "Confirmed" : "Payment",
      fullWidth: true,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(_components_common_LoadingLarge__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
        loading: loading || paymentMethodLoading || invoiceLoading
      }), selectedProject && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsxs)(ProjectsContainer, {
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsxs)(ConfirmContainer, {
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsxs)(ConfirmationRow, {
            children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsxs)(_components_common_Text__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .ZP, {
              size: "tiny",
              children: [paid ? "Compensated" : "Amount", " (tCO2e):"]
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .ZP, {
              size: "tiny",
              children: (_invoice$metadata$ton = invoice === null || invoice === void 0 ? void 0 : (_invoice$metadata = invoice.metadata) === null || _invoice$metadata === void 0 ? void 0 : _invoice$metadata.tonnes) !== null && _invoice$metadata$ton !== void 0 ? _invoice$metadata$ton : "--.--"
            })]
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsxs)(ConfirmationRow, {
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .ZP, {
              size: "tiny",
              fontWeight: 500,
              children: "Project price"
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsxs)(_components_common_Text__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .ZP, {
              size: "tiny",
              fontWeight: 500,
              children: [(0,_utils_numbers__WEBPACK_IMPORTED_MODULE_21__/* .formatCurrency */ .xG)((selectedProject === null || selectedProject === void 0 ? void 0 : selectedProject.average_price_per_tonne_pennies_gbp) / 100), "/tonnes"]
            })]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx("br", {}), invoice === null || invoice === void 0 ? void 0 : (_invoice$lines = invoice.lines) === null || _invoice$lines === void 0 ? void 0 : (_invoice$lines$data = _invoice$lines.data) === null || _invoice$lines$data === void 0 ? void 0 : _invoice$lines$data.map(invoiceItem => {
            var _invoiceItem$metadata, _invoiceItem$metadata2;

            return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsxs)(ConfirmationRow, {
              children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsxs)(_components_common_Text__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .ZP, {
                size: "tiny",
                fontWeight: 500,
                children: [invoiceItem === null || invoiceItem === void 0 ? void 0 : invoiceItem.description, " ", (invoiceItem === null || invoiceItem === void 0 ? void 0 : (_invoiceItem$metadata = invoiceItem.metadata) === null || _invoiceItem$metadata === void 0 ? void 0 : _invoiceItem$metadata.tooltip) && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(_components_common_Tooltip__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                  content: invoiceItem === null || invoiceItem === void 0 ? void 0 : (_invoiceItem$metadata2 = invoiceItem.metadata) === null || _invoiceItem$metadata2 === void 0 ? void 0 : _invoiceItem$metadata2.tooltip,
                  direction: "right"
                })]
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .ZP, {
                size: "tiny",
                fontWeight: 500,
                children: (0,_utils_numbers__WEBPACK_IMPORTED_MODULE_21__/* .formatCurrency */ .xG)(((invoiceItem === null || invoiceItem === void 0 ? void 0 : invoiceItem.amount) / 100).toFixed(2))
              })]
            }, invoiceItem.id);
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(_components_common_Divider__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
            color: "black"
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsxs)(ProjectTechnologyRow, {
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .ZP, {
              size: "subtitle1",
              fontWeight: 500,
              children: "Total Price"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .ZP, {
              size: "subtitle1",
              fontWeight: 500,
              children: invoice !== null && invoice !== void 0 && invoice.total ? (0,_utils_numbers__WEBPACK_IMPORTED_MODULE_21__/* .formatCurrency */ .xG)(((invoice === null || invoice === void 0 ? void 0 : invoice.total) / 100).toFixed(2)) : "£--.--"
            })]
          })]
        }), !paid && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.Fragment, {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(TextContainer, {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .ZP, {
              size: "subtitle1",
              children: "Payment Method"
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(CardContainer, {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(_components_common_CardRadioButtons__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
              options: options,
              name: "payment_method",
              currentValue: paymentMethod === null || paymentMethod === void 0 ? void 0 : paymentMethod.id
            })
          })]
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsxs)(ProjectActions, {
          children: [!paid && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx("div", {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx("div", {
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsxs)(_components_common_Text__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .ZP, {
                align: "right",
                size: "tiny",
                children: ["By clicking Pay, you agree to the", " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(_components_common_TextLink__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                  external: true,
                  href: "https://inhabit.eco/terms-and-conditions",
                  target: "_blank",
                  children: "terms and conditions"
                }), "."]
              })
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(ButtonContainer, {
            children: paid ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(_components_button_Button__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .ZP, {
              onClick: () => router.push("/history"),
              children: "Back to history"
            }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(_components_button_Button__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .ZP, {
              loading: submitLoading,
              disabled: !invoice,
              onClick: handleClick,
              children: "Pay"
            })
          })]
        })]
      })]
    })
  });
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z)(Project));
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 86702:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "mC": () => (/* binding */ convertKgToTonnesValue),
/* harmony export */   "xG": () => (/* binding */ formatCurrency)
/* harmony export */ });
/* unused harmony export formatter */
const convertKgToTonnesValue = value => !value ? 0 : Math.ceil(value / 1000);
const formatter = new Intl.NumberFormat("en-GB", {
  style: "currency",
  currency: "GBP",
  // These options are needed to round to whole numbers if that's what you want.
  minimumFractionDigits: 2,
  // (this suffices for whole numbers, but will print 2500.10 as $2,500.1)
  maximumFractionDigits: 2 // (causes 2500.99 to be printed as $2,501)

});
const formatCurrency = formatter.format;

/***/ }),

/***/ 58300:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "unstable_getStaticParams": () => (/* binding */ unstable_getStaticParams),
/* harmony export */   "unstable_getStaticProps": () => (/* binding */ unstable_getStaticProps),
/* harmony export */   "unstable_getStaticPaths": () => (/* binding */ unstable_getStaticPaths),
/* harmony export */   "unstable_getServerProps": () => (/* binding */ unstable_getServerProps),
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "_app": () => (/* binding */ _app),
/* harmony export */   "renderReqToHTML": () => (/* binding */ renderReqToHTML),
/* harmony export */   "render": () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(70607);
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59450);
/* harmony import */ var private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97020);
/* harmony import */ var private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(73978);
/* harmony import */ var next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99436);

      
      
      
      

      
      const { processEnv } = __webpack_require__(85360)
      processEnv([{"path":".env","contents":"API_HOST=https://api.inhabit.eco\nNEXT_PUBLIC_CALENDLY_URL=https://calendly.com/inhabit-meet/inhabit-measurement-tutorial\nNEXT_PUBLIC_FLAGS_ENVIRONMENT_KEY=flags_pub_289425705564897805\nNEXT_PUBLIC_GOOGLE_ANALYTICS=G-1CBB78XFQ4\nNEXT_PUBLIC_INTERCOM_APP_ID=bw9p6mfd\nNEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_bQDaTEuYc10x3BZt9YcGj2cE00Gzwm4gDD\nSTRIPE_PUBLISHABLE_KEY=pk_live_bQDaTEuYc10x3BZt9YcGj2cE00Gzwm4gDD\n\n"}])
    
      
      const runtimeConfig = {}
      ;

      const documentModule = __webpack_require__(9968)

      const appMod = __webpack_require__(13724)
      let App = appMod.default || appMod.then && appMod.then(mod => mod.default);

      const compMod = __webpack_require__(55280)

      const Component = compMod.default || compMod.then && compMod.then(mod => mod.default)
      /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Component);
      const getStaticProps = compMod['getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['getStaticProp' + 's'])
      const getStaticPaths = compMod['getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['getStaticPath' + 's'])
      const getServerSideProps = compMod['getServerSideProp' + 's'] || compMod.then && compMod.then(mod => mod['getServerSideProp' + 's'])

      // kept for detecting legacy exports
      const unstable_getStaticParams = compMod['unstable_getStaticParam' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticParam' + 's'])
      const unstable_getStaticProps = compMod['unstable_getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticProp' + 's'])
      const unstable_getStaticPaths = compMod['unstable_getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticPath' + 's'])
      const unstable_getServerProps = compMod['unstable_getServerProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getServerProp' + 's'])

      let config = compMod['confi' + 'g'] || (compMod.then && compMod.then(mod => mod['confi' + 'g'])) || {}
      const _app = App

      const combinedRewrites = Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)
        ? private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg
        : []

      if (!Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)) {
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.beforeFiles */ .Dg.beforeFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.afterFiles */ .Dg.afterFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.fallback */ .Dg.fallback)
      }

      const { renderReqToHTML, render } = (0,next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__/* .getPageHandler */ .u)({
        pageModule: compMod,
        pageComponent: Component,
        pageConfig: config,
        appModule: App,
        documentModule: documentModule,
        errorModule: __webpack_require__(99651),
        notFoundModule: undefined,
        pageGetStaticProps: getStaticProps,
        pageGetStaticPaths: getStaticPaths,
        pageGetServerSideProps: getServerSideProps,

        assetPrefix: "",
        canonicalBase: "",
        generateEtags: true,
        poweredByHeader: true,
        reactRoot: false,

        runtimeConfig,
        buildManifest: private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__,
        reactLoadableManifest: private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__,

        rewrites: combinedRewrites,
        i18n: undefined,
        page: "/history/[id]/compensate/[project_id]/payment",
        buildId: "lDoX7RBEQ31kzKIJJbkVC",
        escapedBuildId: "lDoX7RBEQ31kzKIJJbkVC",
        basePath: "",
        pageIsDynamic: true,
        encodedPreviewProps: {previewModeId:"89cdc9f6073608262d43eab6d636f3f4",previewModeSigningKey:"74c7e36a2414a3f7b0ebcc67250f915f156686e1610b45a21ae9358d5b7c6c5a",previewModeEncryptionKey:"8a4c97ad9e5cf12d5a140689be08539ea52d8b27a416c2b8ae67db636b45841b"}
      })
      
    

/***/ }),

/***/ 94970:
/***/ ((module) => {

module.exports = require("@happykit/flags/client");

/***/ }),

/***/ 46411:
/***/ ((module) => {

module.exports = require("@happykit/flags/config");

/***/ }),

/***/ 48095:
/***/ ((module) => {

module.exports = require("@happykit/flags/server");

/***/ }),

/***/ 83218:
/***/ ((module) => {

module.exports = require("@hookform/error-message");

/***/ }),

/***/ 48308:
/***/ ((module) => {

module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ 85360:
/***/ ((module) => {

module.exports = require("@next/env");

/***/ }),

/***/ 64515:
/***/ ((module) => {

module.exports = require("@stripe/react-stripe-js");

/***/ }),

/***/ 20943:
/***/ ((module) => {

module.exports = require("@stripe/stripe-js");

/***/ }),

/***/ 52167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 1043:
/***/ ((module) => {

module.exports = require("lodash.get");

/***/ }),

/***/ 51650:
/***/ ((module) => {

module.exports = require("lodash.uniqby");

/***/ }),

/***/ 54426:
/***/ ((module) => {

module.exports = require("next/dist/compiled/chalk");

/***/ }),

/***/ 40252:
/***/ ((module) => {

module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 19371:
/***/ ((module) => {

module.exports = require("next/dist/compiled/node-fetch");

/***/ }),

/***/ 97999:
/***/ ((module) => {

module.exports = require("next/dist/compiled/path-to-regexp");

/***/ }),

/***/ 60600:
/***/ ((module) => {

module.exports = require("next/dist/server/accept-header.js");

/***/ }),

/***/ 52155:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils/index.js");

/***/ }),

/***/ 90730:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils/node.js");

/***/ }),

/***/ 60562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 94140:
/***/ ((module) => {

module.exports = require("next/dist/server/get-page-files.js");

/***/ }),

/***/ 89716:
/***/ ((module) => {

module.exports = require("next/dist/server/htmlescape.js");

/***/ }),

/***/ 25071:
/***/ ((module) => {

module.exports = require("next/dist/server/render-result.js");

/***/ }),

/***/ 33100:
/***/ ((module) => {

module.exports = require("next/dist/server/render.js");

/***/ }),

/***/ 92779:
/***/ ((module) => {

module.exports = require("next/dist/server/request-meta.js");

/***/ }),

/***/ 79502:
/***/ ((module) => {

module.exports = require("next/dist/server/send-payload.js");

/***/ }),

/***/ 76368:
/***/ ((module) => {

module.exports = require("next/dist/server/utils.js");

/***/ }),

/***/ 56724:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 27664:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/escape-regexp.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 94957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 82374:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-locale-cookie.js");

/***/ }),

/***/ 34014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 78524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 78020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 29565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 64365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 95714:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-route-from-asset-path.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 91292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 25753:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-match.js");

/***/ }),

/***/ 99521:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/prepare-destination.js");

/***/ }),

/***/ 80979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 36052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 84226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 95566:
/***/ ((module) => {

module.exports = require("next/error");

/***/ }),

/***/ 40968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 71853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 59819:
/***/ ((module) => {

module.exports = require("querystring");

/***/ }),

/***/ 16689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 25716:
/***/ ((module) => {

module.exports = require("react-hotjar");

/***/ }),

/***/ 16666:
/***/ ((module) => {

module.exports = require("react-responsive");

/***/ }),

/***/ 1187:
/***/ ((module) => {

module.exports = require("react-toastify");

/***/ }),

/***/ 20997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 57518:
/***/ ((module) => {

module.exports = require("styled-components");

/***/ }),

/***/ 24535:
/***/ ((module) => {

module.exports = require("styled-normalize");

/***/ }),

/***/ 6153:
/***/ ((module) => {

module.exports = require("universal-cookie");

/***/ }),

/***/ 84269:
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ 75609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 61908:
/***/ ((module) => {

module.exports = import("@hookform/resolvers/yup");;

/***/ }),

/***/ 45641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [4357,9703,6114,9067,8183,9899,805,6067,9891,9343,3843], () => (__webpack_exec__(58300)));
module.exports = __webpack_exports__;

})();