"use strict";
(() => {
var exports = {};
exports.id = 5350;
exports.ids = [5350];
exports.modules = {

/***/ 39671:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(41664);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_button_Button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(59067);
/* harmony import */ var _components_common_LoadingLarge__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(49899);
/* harmony import */ var _components_common_Page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(97598);
/* harmony import */ var _components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(60805);
/* harmony import */ var _components_common_Text__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(87491);
/* harmony import */ var _components_ContentContainer__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(16067);
/* harmony import */ var _components_measurement_utils_charts__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(19343);
/* harmony import */ var _contexts_config__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(33742);
/* harmony import */ var _contexts_measurements__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(85238);
/* harmony import */ var _contexts_project__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(98605);
/* harmony import */ var _utils_numbers__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(86702);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(91073);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_6__]);
_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
















var AvoidanceIcon = function AvoidanceIcon(props) {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx("path", {
      d: "M14.77 0L8 6.77 1.23 0 0 1.23 6.77 8 0 14.77 1.23 16 8 9.23 14.77 16 16 14.77 9.23 8 16 1.23 14.77 0z",
      fill: "#fff"
    })
  }));
};

AvoidanceIcon.defaultProps = {
  width: "16",
  height: "16",
  viewBox: "0 0 16 16",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var RemovalIcon = function RemovalIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)("g", {
      clipPath: "url(#clip0_6239_86351)",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx("path", {
        d: "M14.608 7.13L8.87 12.866V2H7.13v10.867L1.394 7.13.176 8.375 8 16.2l7.825-7.825-1.217-1.246z",
        fill: "#fff"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx("path", {
        stroke: "#fff",
        strokeWidth: "1.5",
        d: "M0 1.25h16"
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx("defs", {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx("clipPath", {
        id: "clip0_6239_86351",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx("path", {
          fill: "#fff",
          d: "M0 0h16v16H0z"
        })
      })
    })]
  }));
};

RemovalIcon.defaultProps = {
  width: "16",
  height: "16",
  viewBox: "0 0 16 16",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};






const createColor = ({
  color,
  theme
}) => theme.colors[color] || theme.colors.darkYellow;

const ProjectsContainer = styled_components__WEBPACK_IMPORTED_MODULE_14___default().div.withConfig({
  displayName: "compensate__ProjectsContainer",
  componentId: "vvo47w-0"
})(["display:flex;flex-wrap:wrap;"]);
const ProjectCard = styled_components__WEBPACK_IMPORTED_MODULE_14___default().div.withConfig({
  displayName: "compensate__ProjectCard",
  componentId: "vvo47w-1"
})(["max-width:360px;min-height:390px;max-height:390px;margin-bottom:40px;cursor:pointer;&:not(:nth-child(2n)){margin-right:40px;}", ""], _theme__WEBPACK_IMPORTED_MODULE_15__/* .media.wideScreen */ .BC.wideScreen`
    &:not(:nth-child(2n)) {
      margin-right: initial;
    }
  
    &:not(:nth-child(3n)) {
      margin-right: 40px;
    }
`);
const ProjectImage = styled_components__WEBPACK_IMPORTED_MODULE_14___default().img.withConfig({
  displayName: "compensate__ProjectImage",
  componentId: "vvo47w-2"
})(["width:360px;height:200px;object-fit:cover;"]);
const ProjectMechanism = styled_components__WEBPACK_IMPORTED_MODULE_14___default().div.withConfig({
  displayName: "compensate__ProjectMechanism",
  componentId: "vvo47w-3"
})(["text-transform:capitalize;margin-right:1rem;background:", ";display:flex;padding:4px 10px;border-radius:10px;svg{margin-right:6px;}"], createColor);
const ProjectTechnology = styled_components__WEBPACK_IMPORTED_MODULE_14___default().div.withConfig({
  displayName: "compensate__ProjectTechnology",
  componentId: "vvo47w-4"
})(["text-transform:capitalize;margin-right:1rem;border:1px solid ", ";display:flex;padding:4px 10px;border-radius:10px;svg{margin-right:6px;}"], p => p.theme.colors.darkBlue);
const ProjectDescription = styled_components__WEBPACK_IMPORTED_MODULE_14___default().div.withConfig({
  displayName: "compensate__ProjectDescription",
  componentId: "vvo47w-5"
})(["background:", ";padding:16px 24px;height:190px;display:flex;flex-direction:column;"], p => p.theme.colors.white);
const ProjectType = styled_components__WEBPACK_IMPORTED_MODULE_14___default().div.withConfig({
  displayName: "compensate__ProjectType",
  componentId: "vvo47w-6"
})(["display:flex;margin-top:auto;margin-bottom:1.25rem;align-items:flex-end;"]);
const ProjectActions = styled_components__WEBPACK_IMPORTED_MODULE_14___default().div.withConfig({
  displayName: "compensate__ProjectActions",
  componentId: "vvo47w-7"
})(["background:", ";display:flex;justify-content:space-between;align-items:center;"], p => p.theme.colors.white);

function Projects() {
  const {
    loading,
    projects,
    getProjects,
    nextPage,
    setNextPage,
    hasNextPage
  } = (0,_contexts_project__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z)();
  const {
    pageContainer
  } = (0,_contexts_config__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)();
  const {
    measurements,
    getSelectedMeasurement,
    selectedMeasurement,
    setSelectedMeasurement,
    loading: measurementLeading
  } = (0,_contexts_measurements__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)({
    defaultSelectedMeasurement: true
  });
  const loader = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
  const handleObserver = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(entries => {
    const target = entries[0];

    if (target.isIntersecting) {
      setNextPage(prev => prev + 1);
    }
  }, []);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    const option = {
      root: document.querySelector("#scrollArea"),
      rootMargin: "0px",
      threshold: 1.0
    };
    const observer = new IntersectionObserver(handleObserver, option);
    if (loader.current) observer.observe(loader.current);
  }, [handleObserver, loader.current]);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    var _createTotalMeasureme;

    nextPage && selectedMeasurement && getProjects({
      page: nextPage,
      minimum_available_mass: (0,_utils_numbers__WEBPACK_IMPORTED_MODULE_13__/* .convertKgToTonnesValue */ .mC)((_createTotalMeasureme = (0,_components_measurement_utils_charts__WEBPACK_IMPORTED_MODULE_16__/* .createTotalMeasurementResults */ .d)(selectedMeasurement)) === null || _createTotalMeasureme === void 0 ? void 0 : _createTotalMeasureme.total) * 1000000
    });
  }, [nextPage, selectedMeasurement]);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    getSelectedMeasurement();
    return () => setSelectedMeasurement(null);
  }, []);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    var _selectedMeasurement$;

    (selectedMeasurement === null || selectedMeasurement === void 0 ? void 0 : (_selectedMeasurement$ = selectedMeasurement.offsets) === null || _selectedMeasurement$ === void 0 ? void 0 : _selectedMeasurement$.length) && router.replace(`/history${selectedMeasurement.time_period === 12 && "/annual"}/${selectedMeasurement === null || selectedMeasurement === void 0 ? void 0 : selectedMeasurement.id}`);
  }, [selectedMeasurement]);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_common_Page__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_components_ContentContainer__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
      iconBorder: false,
      title: "Projects",
      fullWidth: true,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_common_LoadingLarge__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
        loading: loading || measurementLeading
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(ProjectsContainer, {
        children: projects.map(project => {
          var _project$photos, _project$photos$, _project$technology_t;

          return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
            as: `/history/${selectedMeasurement === null || selectedMeasurement === void 0 ? void 0 : selectedMeasurement.id}/compensate/${project.id}`,
            href: "/history/[id]/compensate/[project_id]",
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(ProjectCard, {
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(ProjectImage, {
                src: (_project$photos = project.photos) === null || _project$photos === void 0 ? void 0 : (_project$photos$ = _project$photos[0]) === null || _project$photos$ === void 0 ? void 0 : _project$photos$.url
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(ProjectDescription, {
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx("div", {
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
                    size: "subtitle1",
                    children: project.name
                  })
                }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(ProjectType, {
                  children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(ProjectMechanism, {
                    color: project.mechanism === "removal" ? "darkGreen" : "darkYellow",
                    children: [project.mechanism === "removal" && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(RemovalIcon, {}), project.mechanism === "avoidance" && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(AvoidanceIcon, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
                      size: "tiny",
                      color: "white",
                      children: project.mechanism
                    }), " "]
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(ProjectTechnology, {
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
                      size: "tiny",
                      color: "darkBlue",
                      children: project === null || project === void 0 ? void 0 : (_project$technology_t = project.technology_type) === null || _project$technology_t === void 0 ? void 0 : _project$technology_t.name
                    })
                  })]
                }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(ProjectActions, {
                  children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_components_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
                    children: ["\xA3", (project.average_price_per_tonne_pennies_gbp / 100).toFixed(2).toLocaleString(), "/tonne"]
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_button_Button__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP, {
                    secondary: true,
                    as: `/history/${selectedMeasurement === null || selectedMeasurement === void 0 ? void 0 : selectedMeasurement.id}/compensate/${project.id}`,
                    href: "/history/[id]/compensate/[project_id]",
                    children: "More info"
                  })]
                })]
              })]
            }, project.id)
          }, project.id);
        })
      }), !!projects.length && hasNextPage && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx("div", {
        ref: loader,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_button_Button__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP, {
          secondary: true,
          loading: loading,
          onClick: () => setNextPage(prev => prev + 1),
          children: "Load more"
        })
      })]
    })
  });
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)(Projects));
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 86702:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "mC": () => (/* binding */ convertKgToTonnesValue),
/* harmony export */   "xG": () => (/* binding */ formatCurrency)
/* harmony export */ });
/* unused harmony export formatter */
const convertKgToTonnesValue = value => !value ? 0 : Math.ceil(value / 1000);
const formatter = new Intl.NumberFormat("en-GB", {
  style: "currency",
  currency: "GBP",
  // These options are needed to round to whole numbers if that's what you want.
  minimumFractionDigits: 2,
  // (this suffices for whole numbers, but will print 2500.10 as $2,500.1)
  maximumFractionDigits: 2 // (causes 2500.99 to be printed as $2,501)

});
const formatCurrency = formatter.format;

/***/ }),

/***/ 95031:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "unstable_getStaticParams": () => (/* binding */ unstable_getStaticParams),
/* harmony export */   "unstable_getStaticProps": () => (/* binding */ unstable_getStaticProps),
/* harmony export */   "unstable_getStaticPaths": () => (/* binding */ unstable_getStaticPaths),
/* harmony export */   "unstable_getServerProps": () => (/* binding */ unstable_getServerProps),
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "_app": () => (/* binding */ _app),
/* harmony export */   "renderReqToHTML": () => (/* binding */ renderReqToHTML),
/* harmony export */   "render": () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(70607);
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59450);
/* harmony import */ var private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97020);
/* harmony import */ var private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(73978);
/* harmony import */ var next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99436);

      
      
      
      

      
      const { processEnv } = __webpack_require__(85360)
      processEnv([{"path":".env","contents":"API_HOST=https://api.inhabit.eco\nNEXT_PUBLIC_CALENDLY_URL=https://calendly.com/inhabit-meet/inhabit-measurement-tutorial\nNEXT_PUBLIC_FLAGS_ENVIRONMENT_KEY=flags_pub_289425705564897805\nNEXT_PUBLIC_GOOGLE_ANALYTICS=G-1CBB78XFQ4\nNEXT_PUBLIC_INTERCOM_APP_ID=bw9p6mfd\nNEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_bQDaTEuYc10x3BZt9YcGj2cE00Gzwm4gDD\nSTRIPE_PUBLISHABLE_KEY=pk_live_bQDaTEuYc10x3BZt9YcGj2cE00Gzwm4gDD\n\n"}])
    
      
      const runtimeConfig = {}
      ;

      const documentModule = __webpack_require__(9968)

      const appMod = __webpack_require__(13724)
      let App = appMod.default || appMod.then && appMod.then(mod => mod.default);

      const compMod = __webpack_require__(39671)

      const Component = compMod.default || compMod.then && compMod.then(mod => mod.default)
      /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Component);
      const getStaticProps = compMod['getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['getStaticProp' + 's'])
      const getStaticPaths = compMod['getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['getStaticPath' + 's'])
      const getServerSideProps = compMod['getServerSideProp' + 's'] || compMod.then && compMod.then(mod => mod['getServerSideProp' + 's'])

      // kept for detecting legacy exports
      const unstable_getStaticParams = compMod['unstable_getStaticParam' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticParam' + 's'])
      const unstable_getStaticProps = compMod['unstable_getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticProp' + 's'])
      const unstable_getStaticPaths = compMod['unstable_getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticPath' + 's'])
      const unstable_getServerProps = compMod['unstable_getServerProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getServerProp' + 's'])

      let config = compMod['confi' + 'g'] || (compMod.then && compMod.then(mod => mod['confi' + 'g'])) || {}
      const _app = App

      const combinedRewrites = Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)
        ? private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg
        : []

      if (!Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)) {
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.beforeFiles */ .Dg.beforeFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.afterFiles */ .Dg.afterFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.fallback */ .Dg.fallback)
      }

      const { renderReqToHTML, render } = (0,next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__/* .getPageHandler */ .u)({
        pageModule: compMod,
        pageComponent: Component,
        pageConfig: config,
        appModule: App,
        documentModule: documentModule,
        errorModule: __webpack_require__(99651),
        notFoundModule: undefined,
        pageGetStaticProps: getStaticProps,
        pageGetStaticPaths: getStaticPaths,
        pageGetServerSideProps: getServerSideProps,

        assetPrefix: "",
        canonicalBase: "",
        generateEtags: true,
        poweredByHeader: true,
        reactRoot: false,

        runtimeConfig,
        buildManifest: private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__,
        reactLoadableManifest: private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__,

        rewrites: combinedRewrites,
        i18n: undefined,
        page: "/history/[id]/compensate",
        buildId: "lDoX7RBEQ31kzKIJJbkVC",
        escapedBuildId: "lDoX7RBEQ31kzKIJJbkVC",
        basePath: "",
        pageIsDynamic: true,
        encodedPreviewProps: {previewModeId:"89cdc9f6073608262d43eab6d636f3f4",previewModeSigningKey:"74c7e36a2414a3f7b0ebcc67250f915f156686e1610b45a21ae9358d5b7c6c5a",previewModeEncryptionKey:"8a4c97ad9e5cf12d5a140689be08539ea52d8b27a416c2b8ae67db636b45841b"}
      })
      
    

/***/ }),

/***/ 94970:
/***/ ((module) => {

module.exports = require("@happykit/flags/client");

/***/ }),

/***/ 46411:
/***/ ((module) => {

module.exports = require("@happykit/flags/config");

/***/ }),

/***/ 48095:
/***/ ((module) => {

module.exports = require("@happykit/flags/server");

/***/ }),

/***/ 83218:
/***/ ((module) => {

module.exports = require("@hookform/error-message");

/***/ }),

/***/ 48308:
/***/ ((module) => {

module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ 85360:
/***/ ((module) => {

module.exports = require("@next/env");

/***/ }),

/***/ 64515:
/***/ ((module) => {

module.exports = require("@stripe/react-stripe-js");

/***/ }),

/***/ 20943:
/***/ ((module) => {

module.exports = require("@stripe/stripe-js");

/***/ }),

/***/ 52167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 1043:
/***/ ((module) => {

module.exports = require("lodash.get");

/***/ }),

/***/ 51650:
/***/ ((module) => {

module.exports = require("lodash.uniqby");

/***/ }),

/***/ 54426:
/***/ ((module) => {

module.exports = require("next/dist/compiled/chalk");

/***/ }),

/***/ 40252:
/***/ ((module) => {

module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 19371:
/***/ ((module) => {

module.exports = require("next/dist/compiled/node-fetch");

/***/ }),

/***/ 97999:
/***/ ((module) => {

module.exports = require("next/dist/compiled/path-to-regexp");

/***/ }),

/***/ 60600:
/***/ ((module) => {

module.exports = require("next/dist/server/accept-header.js");

/***/ }),

/***/ 52155:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils/index.js");

/***/ }),

/***/ 90730:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils/node.js");

/***/ }),

/***/ 60562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 94140:
/***/ ((module) => {

module.exports = require("next/dist/server/get-page-files.js");

/***/ }),

/***/ 89716:
/***/ ((module) => {

module.exports = require("next/dist/server/htmlescape.js");

/***/ }),

/***/ 25071:
/***/ ((module) => {

module.exports = require("next/dist/server/render-result.js");

/***/ }),

/***/ 33100:
/***/ ((module) => {

module.exports = require("next/dist/server/render.js");

/***/ }),

/***/ 92779:
/***/ ((module) => {

module.exports = require("next/dist/server/request-meta.js");

/***/ }),

/***/ 79502:
/***/ ((module) => {

module.exports = require("next/dist/server/send-payload.js");

/***/ }),

/***/ 76368:
/***/ ((module) => {

module.exports = require("next/dist/server/utils.js");

/***/ }),

/***/ 56724:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 27664:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/escape-regexp.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 94957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 82374:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-locale-cookie.js");

/***/ }),

/***/ 34014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 78524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 78020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 29565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 64365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 95714:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-route-from-asset-path.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 91292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 25753:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-match.js");

/***/ }),

/***/ 99521:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/prepare-destination.js");

/***/ }),

/***/ 80979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 36052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 84226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 95566:
/***/ ((module) => {

module.exports = require("next/error");

/***/ }),

/***/ 40968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 71853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 59819:
/***/ ((module) => {

module.exports = require("querystring");

/***/ }),

/***/ 16689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 25716:
/***/ ((module) => {

module.exports = require("react-hotjar");

/***/ }),

/***/ 16666:
/***/ ((module) => {

module.exports = require("react-responsive");

/***/ }),

/***/ 1187:
/***/ ((module) => {

module.exports = require("react-toastify");

/***/ }),

/***/ 20997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 57518:
/***/ ((module) => {

module.exports = require("styled-components");

/***/ }),

/***/ 24535:
/***/ ((module) => {

module.exports = require("styled-normalize");

/***/ }),

/***/ 6153:
/***/ ((module) => {

module.exports = require("universal-cookie");

/***/ }),

/***/ 84269:
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ 75609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 61908:
/***/ ((module) => {

module.exports = import("@hookform/resolvers/yup");;

/***/ }),

/***/ 45641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [4357,9703,6114,9067,8183,9899,805,6067,9343], () => (__webpack_exec__(95031)));
module.exports = __webpack_exports__;

})();