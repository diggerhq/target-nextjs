"use strict";
(() => {
var exports = {};
exports.id = 5405;
exports.ids = [5405];
exports.modules = {

/***/ 71055:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(87491);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _button_Button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(59067);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




var BecomeCarbonNeutralIcon = function BecomeCarbonNeutralIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      opacity: ".5",
      d: "M0 17h272v279a4 4 0 0 1-4 4H4a4 4 0 0 1-4-4V17z",
      fill: "#C6DED0"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("rect", {
      x: ".5",
      y: ".5",
      width: "271",
      height: "299",
      rx: "3.5",
      stroke: "#76B591"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      stroke: "#76B591",
      d: "M0 16.5h272"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("circle", {
      cx: "13",
      cy: "9",
      r: "3",
      fill: "#76B591"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("circle", {
      cx: "22",
      cy: "9",
      r: "2.5",
      stroke: "#76B591"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("circle", {
      cx: "31",
      cy: "9",
      r: "2.5",
      stroke: "#76B591"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("rect", {
      x: "10.25",
      y: "25.25",
      width: "99.5",
      height: "79.5",
      rx: "3.75",
      fill: "#fff",
      stroke: "#76B591",
      strokeWidth: ".5"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("rect", {
      x: "10.25",
      y: "189.25",
      width: "99.5",
      height: "59.5",
      rx: "3.75",
      fill: "#fff",
      stroke: "#76B591",
      strokeWidth: ".5"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#76B591",
      d: "M18 196h40v4H18zM18 238h8v4h-8zM28 238h8v4h-8zM83 238h20v4H83z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      d: "M62.919 64.294a2.043 2.043 0 1 0 0-4.087 2.043 2.043 0 0 0 0 4.087zm0-2.919a.875.875 0 1 1 0 1.75.875.875 0 0 1 0-1.75z",
      fill: "#C6DED0"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      d: "M66.419 55.25H53.58a2.338 2.338 0 0 0-2.331 2.331V70.42a2.338 2.338 0 0 0 2.331 2.331H66.42a2.338 2.338 0 0 0 2.331-2.331V57.58a2.338 2.338 0 0 0-2.331-2.331zM53.58 56.419H66.42a1.169 1.169 0 0 1 1.169 1.169v10.675l-1.175-1.25a1.794 1.794 0 0 0-2.5 0l-2.263 2.362-3.781-3.944a1.738 1.738 0 0 0-1.25-.537 1.736 1.736 0 0 0-1.25.537l-2.95 3.044V57.581a1.169 1.169 0 0 1 1.162-1.162zm-1.162 14v-.257l3.75-3.893a.584.584 0 0 1 .419-.181.574.574 0 0 1 .418.18l5.1 5.32h-8.525a1.169 1.169 0 0 1-1.162-1.17zm14 1.169h-2.706l-1.288-1.338 2.3-2.394a.625.625 0 0 1 .844 0l2.019 2.1v.469a1.169 1.169 0 0 1-1.17 1.156v.007z",
      fill: "#C6DED0"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      d: "M19.915 215.66h-.76l.16 1.52-1.24-.89-.37.67 1.39.56-1.39.58.39.68 1.21-.89-.15 1.51h.75l-.16-1.51 1.21.88.38-.67-1.4-.57 1.39-.58-.36-.65-1.22.88.17-1.52zm4.863 0h-.76l.16 1.52-1.24-.89-.37.67 1.39.56-1.39.58.39.68 1.21-.89-.15 1.51h.75l-.16-1.51 1.21.88.38-.67-1.4-.57 1.39-.58-.36-.65-1.22.88.17-1.52zm4.863 0h-.76l.16 1.52-1.24-.89-.37.67 1.39.56-1.39.58.39.68 1.21-.89-.15 1.51h.75l-.16-1.51 1.21.88.38-.67-1.4-.57 1.39-.58-.36-.65-1.22.88.17-1.52zm4.864 0h-.76l.16 1.52-1.24-.89-.37.67 1.39.56-1.39.58.39.68 1.21-.89-.15 1.51h.75l-.16-1.51 1.21.88.38-.67-1.4-.57 1.39-.58-.36-.65-1.22.88.17-1.52zm7.529 0h-.76l.16 1.52-1.24-.89-.37.67 1.39.56-1.39.58.39.68 1.21-.89-.15 1.51h.75l-.16-1.51 1.21.88.38-.67-1.4-.57 1.39-.58-.36-.65-1.22.88.17-1.52zm4.863 0h-.76l.16 1.52-1.24-.89-.37.67 1.39.56-1.39.58.39.68 1.21-.89-.15 1.51h.75l-.16-1.51 1.21.88.38-.67-1.4-.57 1.39-.58-.36-.65-1.22.88.17-1.52zm4.863 0H51l.16 1.52-1.24-.89-.37.67 1.39.56-1.39.58.39.68 1.21-.89-.15 1.51h.75l-.16-1.51 1.21.88.38-.67-1.4-.57 1.39-.58-.36-.65-1.22.88.17-1.52zm4.864 0h-.76l.16 1.52-1.24-.89-.37.67 1.39.56-1.39.58.39.68 1.21-.89-.15 1.51h.75l-.16-1.51 1.21.88.38-.67-1.4-.57 1.39-.58-.36-.65-1.22.88.17-1.52zm7.529 0h-.76l.16 1.52-1.24-.89-.37.67 1.39.56-1.39.58.39.68 1.21-.89-.15 1.51h.75l-.16-1.51 1.21.88.38-.67-1.4-.57 1.39-.58-.36-.65-1.22.88.17-1.52zm4.863 0h-.76l.16 1.52-1.24-.89-.37.67 1.39.56-1.39.58.39.68 1.21-.89-.15 1.51h.75l-.16-1.51 1.21.88.38-.67-1.4-.57 1.39-.58-.36-.65-1.22.88.17-1.52zm4.864 0h-.76l.16 1.52-1.24-.89-.37.67 1.39.56-1.39.58.39.68 1.21-.89-.15 1.51h.75l-.16-1.51 1.21.88.38-.67-1.4-.57 1.39-.58-.36-.65-1.22.88.17-1.52zm4.863 0h-.76l.16 1.52-1.24-.89-.37.67 1.39.56-1.39.58.39.68 1.21-.89-.15 1.51h.75l-.16-1.51 1.21.88.38-.67-1.4-.57 1.39-.58-.36-.65-1.22.88.17-1.52zm7.53 0h-.76l.16 1.52-1.24-.89-.37.67 1.39.56-1.39.58.39.68 1.21-.89-.15 1.51h.75l-.16-1.51 1.21.88.38-.67-1.4-.57 1.39-.58-.36-.65-1.22.88.17-1.52zm4.862 0h-.76l.16 1.52-1.24-.89-.37.67 1.39.56-1.39.58.39.68 1.21-.89-.15 1.51h.75l-.16-1.51 1.21.88.38-.67-1.4-.57 1.39-.58-.36-.65-1.22.88.17-1.52zm4.864 0h-.76l.16 1.52-1.24-.89-.37.67 1.39.56-1.39.58.39.68 1.21-.89-.15 1.51h.75l-.16-1.51 1.21.88.38-.67-1.4-.57 1.39-.58-.36-.65-1.22.88.17-1.52zm4.863 0h-.76l.16 1.52-1.24-.89-.37.67 1.39.56-1.39.58.39.68 1.21-.89-.15 1.51h.75l-.16-1.51 1.21.88.38-.67-1.4-.57 1.39-.58-.36-.65-1.22.88.17-1.52z",
      fill: "#76B591"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#8CBCA1",
      d: "M118 45h145v4H118zM118 53h145v4H118zM118 61h145v4H118zM118 69h52v4h-52zM118 85h145v4H118zM118 93h145v4H118zM118 101h145v4H118zM118 109h52v4h-52z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#C6DED0",
      d: "M118 125h117v2H118zM118 131h117v2H118zM118 137h87v2h-87zM118 151h117v2H118zM118 157h117v2H118zM118 163h87v2h-87z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#8CBCA1",
      d: "M243 191h20v8h-20z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      d: "M235.884 193.936c0 .448.104.784.216 1.088h-.728v.512h.904c.04.16.072.32.072.496 0 .728-.264 1.128-.664 1.568l.128.416h3.568v-.608h-2.912c.376-.408.568-.848.568-1.376 0-.168-.032-.336-.072-.496h1.392v-.512h-1.552c-.112-.328-.224-.664-.224-1.056 0-.784.48-1.104 1.048-1.104.704 0 1.04.448 1.056 1.048h.672c-.04-.896-.576-1.664-1.728-1.664-1.032 0-1.744.656-1.744 1.688z",
      fill: "#76B591"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#8CBCA1",
      d: "M118 193h40v4h-40zM243 203h20v8h-20z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      d: "M235.884 205.936c0 .448.104.784.216 1.088h-.728v.512h.904c.04.16.072.32.072.496 0 .728-.264 1.128-.664 1.568l.128.416h3.568v-.608h-2.912c.376-.408.568-.848.568-1.376 0-.168-.032-.336-.072-.496h1.392v-.512h-1.552c-.112-.328-.224-.664-.224-1.056 0-.784.48-1.104 1.048-1.104.704 0 1.04.448 1.056 1.048h.672c-.04-.896-.576-1.664-1.728-1.664-1.032 0-1.744.656-1.744 1.688z",
      fill: "#76B591"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#8CBCA1",
      d: "M118 205h40v4h-40zM235 228h28v12h-28z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      d: "M226.575 231.904c0 .672.156 1.176.324 1.632h-1.092v.768h1.356c.06.24.108.48.108.744 0 1.092-.396 1.692-.996 2.352l.192.624h5.352v-.912h-4.368c.564-.612.852-1.272.852-2.064 0-.252-.048-.504-.108-.744h2.088v-.768h-2.328c-.168-.492-.336-.996-.336-1.584 0-1.176.72-1.656 1.572-1.656 1.056 0 1.56.672 1.584 1.572h1.008c-.06-1.344-.864-2.496-2.592-2.496-1.548 0-2.616.984-2.616 2.532z",
      fill: "#76B591"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#8CBCA1",
      d: "M118 230h28v6h-28z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#76B591",
      d: "M118 25h48v8h-48z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      stroke: "#C6DED0",
      d: "M118 218.5h145M10 176.5h253M10 260.5h253"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("rect", {
      x: "222.25",
      y: "273.25",
      width: "39.5",
      height: "11.5",
      rx: "1.75",
      fill: "#76B591",
      stroke: "#76B591",
      strokeWidth: ".5"
    })]
  }));
};

BecomeCarbonNeutralIcon.defaultProps = {
  width: "272",
  height: "300",
  viewBox: "0 0 272 300",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var ArrowIcon = function ArrowIcon(props) {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      d: "M57.937 31.406c-6.281 3.188-11.531 7.5-15.938 13.125-1.031 1.313-6.375 1.782-5.062 0 3.844-5.062 8.531-9.187 13.875-12.468-16.031-.188-32.063-.282-48.188-.376-3.656 0 .281-2.812 2.156-2.812 15.47.094 30.844.188 46.22.375-4.688-4.313-9.188-8.813-13.594-13.406-1.313-1.406 3.843-3.375 5.062-2.063 5.25 5.531 10.688 10.781 16.313 15.938.656.562-.375 1.406-.844 1.687z",
      fill: "#7D8078"
    })
  }));
};

ArrowIcon.defaultProps = {
  width: "60",
  height: "60",
  viewBox: "0 0 60 60",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var EnterDataIcon = function EnterDataIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      opacity: ".5",
      d: "M0 17h272v279a4 4 0 0 1-4 4H4a4 4 0 0 1-4-4V17z",
      fill: "#C4CFDB"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("rect", {
      x: ".5",
      y: ".5",
      width: "271",
      height: "299",
      rx: "3.5",
      stroke: "#7495B1"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      stroke: "#7495B1",
      d: "M0 16.5h272M59.5 25v268"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#7495B1",
      d: "M10 28h40v4H10z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#899FB7",
      d: "M10 35h28v2H10z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#7495B1",
      d: "M10 53h40v4H10z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#899FB7",
      d: "M10 60h28v2H10z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      stroke: "#7495B1",
      d: "M10 44.5h49"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("circle", {
      cx: "13",
      cy: "9",
      r: "3",
      fill: "#7495B1"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("circle", {
      cx: "22",
      cy: "9",
      r: "2.5",
      stroke: "#7495B1"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("circle", {
      cx: "31",
      cy: "9",
      r: "2.5",
      stroke: "#7495B1"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("rect", {
      x: "69.25",
      y: "25.25",
      width: "192.5",
      height: "79.5",
      rx: "3.75",
      fill: "#fff",
      stroke: "#899FB7",
      strokeWidth: ".5"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("rect", {
      x: "222.25",
      y: "273.25",
      width: "39.5",
      height: "11.5",
      rx: "1.75",
      fill: "#7495B1",
      stroke: "#7495B1",
      strokeWidth: ".5"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("rect", {
      x: "69.25",
      y: "113.25",
      width: "192.5",
      height: "63.5",
      rx: "3.75",
      fill: "#fff",
      stroke: "#899FB7",
      strokeWidth: ".5"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("rect", {
      x: "69.25",
      y: "185.25",
      width: "192.5",
      height: "79.5",
      rx: "3.75",
      fill: "#fff",
      stroke: "#899FB7",
      strokeWidth: ".5"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("g", {
      clipPath: "url(#clip0_4478_85098)",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
        d: "M180.999 235.319a.306.306 0 0 1-.098.241l-2.167 2.191a.314.314 0 0 1-.469 0l-2.173-2.204a.33.33 0 0 1-.008-.448c.126-.131.316-.133.458-.003l.036.036 1.875 1.902c.057.058.044.056.098.001l1.901-1.929a.318.318 0 0 1 .331-.091.301.301 0 0 1 .216.304z",
        fill: "#7495B1"
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#7495B1",
      d: "M80 232h20v8H80z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("g", {
      clipPath: "url(#clip1_4478_85098)",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
        d: "M180.999 249.319a.306.306 0 0 1-.098.241l-2.167 2.191a.314.314 0 0 1-.469 0l-2.173-2.204a.33.33 0 0 1-.008-.448c.126-.131.316-.133.458-.003l.036.036 1.875 1.902c.057.058.044.056.098.001l1.901-1.929a.318.318 0 0 1 .331-.091.301.301 0 0 1 .216.304z",
        fill: "#7495B1"
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#7495B1",
      d: "M80 246h20v8H80zM108 246h20v8h-20z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("rect", {
      x: "136.25",
      y: "246.25",
      width: "47.5",
      height: "7.5",
      rx: "1.75",
      stroke: "#7495B1",
      strokeWidth: ".5"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("rect", {
      x: "208",
      y: "246",
      width: "16",
      height: "8",
      rx: "4",
      fill: "#7495B1"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("circle", {
      cx: "220",
      cy: "250",
      r: "3.5",
      fill: "#fff",
      stroke: "#7495B1"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#7495B1",
      d: "M108 232h20v8h-20z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("rect", {
      x: "136.25",
      y: "232.25",
      width: "47.5",
      height: "7.5",
      rx: "1.75",
      stroke: "#7495B1",
      strokeWidth: ".5"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#7495B1",
      stroke: "#7495B1",
      strokeWidth: "2",
      d: "M193 233h6.28v6H193z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      d: "M200.998 232.464c.012.112-.045.206-.12.294l-1.069 1.24-2.881 3.34c-.215.25-.43.501-.644.753-.191.224-.587.227-.779.005l-1.94-2.253c-.12-.14-.167-.293-.083-.463a.52.52 0 0 1 .462-.293.457.457 0 0 1 .386.169c.505.583 1.009 1.167 1.512 1.752.049.057.049.057.099 0l4.033-4.676c.046-.053.091-.108.138-.16a.486.486 0 0 1 .499-.156c.186.04.406.23.387.448z",
      fill: "#fff"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("rect", {
      x: "208",
      y: "232",
      width: "16",
      height: "8",
      rx: "4",
      fill: "#C4CFDB"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("circle", {
      cx: "212",
      cy: "236",
      r: "3.5",
      fill: "#fff",
      stroke: "#C4CFDB"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#7495B1",
      d: "M80 195h20v8H80zM108 195h20v8h-20z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("rect", {
      x: "136.25",
      y: "195.25",
      width: "47.5",
      height: "7.5",
      rx: "1.75",
      stroke: "#7495B1",
      strokeWidth: ".5"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#7495B1",
      stroke: "#7495B1",
      strokeWidth: "2",
      d: "M193 196h6.28v6H193z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      d: "M200.998 195.464c.012.112-.045.206-.12.294l-1.069 1.24-2.881 3.34c-.215.25-.43.501-.644.753-.191.224-.587.227-.779.005l-1.94-2.253c-.12-.14-.167-.293-.083-.463a.52.52 0 0 1 .462-.293.457.457 0 0 1 .386.169c.505.583 1.009 1.167 1.512 1.752.049.057.049.057.099 0l4.033-4.676c.046-.053.091-.108.138-.16a.486.486 0 0 1 .499-.156c.186.04.406.23.387.448z",
      fill: "#fff"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("g", {
      clipPath: "url(#clip2_4478_85098)",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
        d: "M180.999 198.319a.306.306 0 0 1-.098.241l-2.167 2.191a.314.314 0 0 1-.469 0l-2.173-2.204a.33.33 0 0 1-.008-.448c.126-.131.316-.133.458-.003l.036.036 1.875 1.902c.057.058.044.056.098.001l1.901-1.929a.318.318 0 0 1 .331-.091.301.301 0 0 1 .216.304z",
        fill: "#7495B1"
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("g", {
      clipPath: "url(#clip3_4478_85098)",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
        d: "M180.999 210.319a.306.306 0 0 1-.098.241l-2.167 2.191a.314.314 0 0 1-.469 0l-2.173-2.204a.33.33 0 0 1-.008-.448c.126-.131.316-.133.458-.003l.036.036 1.875 1.902c.057.058.044.056.098.001l1.901-1.929a.318.318 0 0 1 .331-.091.301.301 0 0 1 .216.304z",
        fill: "#7495B1"
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#C4CFDB",
      d: "M80 124h60v4H80z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#7495B1",
      d: "M80 41h60v8H80z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#C4CFDB",
      d: "M80 35h24v4H80z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#7495B1",
      d: "M80 63h40v8H80z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#C4CFDB",
      d: "M80 57h24v4H80z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#7495B1",
      d: "M80 85h100v8H80z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("rect", {
      x: "146.25",
      y: "122.25",
      width: "23.5",
      height: "7.5",
      rx: "1.75",
      fill: "#7495B1",
      stroke: "#7495B1",
      strokeWidth: ".5"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("rect", {
      x: "174.25",
      y: "122.25",
      width: "23.5",
      height: "7.5",
      rx: "1.75",
      stroke: "#7495B1",
      strokeWidth: ".5"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("rect", {
      x: "202.25",
      y: "122.25",
      width: "23.5",
      height: "7.5",
      rx: "1.75",
      stroke: "#7495B1",
      strokeWidth: ".5"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#C4CFDB",
      d: "M80 136h60v4H80z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("rect", {
      x: "146.25",
      y: "134.25",
      width: "23.5",
      height: "7.5",
      rx: "1.75",
      stroke: "#7495B1",
      strokeWidth: ".5"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("rect", {
      x: "174.25",
      y: "134.25",
      width: "23.5",
      height: "7.5",
      rx: "1.75",
      stroke: "#7495B1",
      strokeWidth: ".5"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#C4CFDB",
      d: "M80 148h60v4H80zM80 160h60v4H80z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("rect", {
      x: "146.25",
      y: "158.25",
      width: "23.5",
      height: "7.5",
      rx: "1.75",
      fill: "#7495B1",
      stroke: "#7495B1",
      strokeWidth: ".5"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("rect", {
      x: "174.25",
      y: "158.25",
      width: "23.5",
      height: "7.5",
      rx: "1.75",
      stroke: "#7495B1",
      strokeWidth: ".5"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("rect", {
      x: "146.25",
      y: "146.25",
      width: "23.5",
      height: "7.5",
      rx: "1.75",
      stroke: "#7495B1",
      strokeWidth: ".5"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("rect", {
      x: "174.25",
      y: "146.25",
      width: "23.5",
      height: "7.5",
      rx: "1.75",
      fill: "#7495B1",
      stroke: "#7495B1",
      strokeWidth: ".5"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("rect", {
      x: "202.25",
      y: "134.25",
      width: "23.5",
      height: "7.5",
      rx: "1.75",
      fill: "#7495B1",
      stroke: "#7495B1",
      strokeWidth: ".5"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#C4CFDB",
      d: "M80 79h24v4H80z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#7495B1",
      d: "M146 41h60v8h-60z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#C4CFDB",
      d: "M146 35h24v4h-24z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      stroke: "#7495B1",
      d: "M192.5 246.5h7.28v7h-7.28z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("rect", {
      x: "208",
      y: "195",
      width: "16",
      height: "8",
      rx: "4",
      fill: "#7495B1"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("circle", {
      cx: "220",
      cy: "199",
      r: "3.5",
      fill: "#fff",
      stroke: "#7495B1"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#7495B1",
      d: "M80 207h20v8H80zM108 207h20v8h-20z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("rect", {
      x: "136.25",
      y: "207.25",
      width: "47.5",
      height: "7.5",
      rx: "1.75",
      stroke: "#7495B1",
      strokeWidth: ".5"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#7495B1",
      stroke: "#7495B1",
      strokeWidth: "2",
      d: "M193 208h6.28v6H193z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      d: "M200.998 207.464c.012.112-.045.206-.12.294l-1.069 1.24-2.881 3.34c-.215.25-.43.501-.644.753-.191.224-.587.227-.779.005l-1.94-2.253c-.12-.14-.167-.293-.083-.463a.52.52 0 0 1 .462-.293.457.457 0 0 1 .386.169c.505.583 1.009 1.167 1.512 1.752.049.057.049.057.099 0l4.033-4.676c.046-.053.091-.108.138-.16a.486.486 0 0 1 .499-.156c.186.04.406.23.387.448z",
      fill: "#fff"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("rect", {
      x: "208",
      y: "207",
      width: "16",
      height: "8",
      rx: "4",
      fill: "#C4CFDB"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("circle", {
      cx: "212",
      cy: "211",
      r: "3.5",
      fill: "#fff",
      stroke: "#C4CFDB"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("g", {
      clipPath: "url(#clip4_4478_85098)",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
        d: "M180.999 222.319a.306.306 0 0 1-.098.241l-2.167 2.191a.314.314 0 0 1-.469 0l-2.173-2.204a.33.33 0 0 1-.008-.448c.126-.131.316-.133.458-.003l.036.036 1.875 1.902c.057.058.044.056.098.001l1.901-1.929a.318.318 0 0 1 .331-.091.301.301 0 0 1 .216.304z",
        fill: "#7495B1"
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#7495B1",
      d: "M80 219h20v8H80zM108 219h20v8h-20z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("rect", {
      x: "136.25",
      y: "219.25",
      width: "47.5",
      height: "7.5",
      rx: "1.75",
      stroke: "#7495B1",
      strokeWidth: ".5"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      stroke: "#7495B1",
      d: "M192.5 219.5h7.28v7h-7.28z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("rect", {
      x: "208",
      y: "219",
      width: "16",
      height: "8",
      rx: "4",
      fill: "#C4CFDB"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("circle", {
      cx: "212",
      cy: "223",
      r: "3.5",
      fill: "#fff",
      stroke: "#C4CFDB"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("defs", {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("clipPath", {
        id: "clip0_4478_85098",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
          fill: "#fff",
          transform: "rotate(-90 206.929 30.928)",
          d: "M0 0h2.857v5H0z"
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("clipPath", {
        id: "clip1_4478_85098",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
          fill: "#fff",
          transform: "rotate(-90 213.929 37.928)",
          d: "M0 0h2.857v5H0z"
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("clipPath", {
        id: "clip2_4478_85098",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
          fill: "#fff",
          transform: "rotate(-90 188.429 12.428)",
          d: "M0 0h2.857v5H0z"
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("clipPath", {
        id: "clip3_4478_85098",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
          fill: "#fff",
          transform: "rotate(-90 194.429 18.428)",
          d: "M0 0h2.857v5H0z"
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("clipPath", {
        id: "clip4_4478_85098",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
          fill: "#fff",
          transform: "rotate(-90 200.429 24.428)",
          d: "M0 0h2.857v5H0z"
        })
      })]
    })]
  }));
};

EnterDataIcon.defaultProps = {
  width: "272",
  height: "300",
  viewBox: "0 0 272 300",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var SeeResultsIcon = function SeeResultsIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      opacity: ".5",
      d: "M0 17h272v279a4 4 0 0 1-4 4H4a4 4 0 0 1-4-4V17z",
      fill: "#F8E4AD"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("rect", {
      x: ".5",
      y: ".5",
      width: "271",
      height: "299",
      rx: "3.5",
      stroke: "#EEBC32"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      stroke: "#EEBC32",
      d: "M0 16.5h272"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("circle", {
      cx: "13",
      cy: "9",
      r: "3",
      fill: "#EEBC32"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("circle", {
      cx: "22",
      cy: "9",
      r: "2.5",
      stroke: "#EEBC32"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("circle", {
      cx: "31",
      cy: "9",
      r: "2.5",
      stroke: "#EEBC32"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("rect", {
      x: "10.25",
      y: "25.25",
      width: "79.5",
      height: "27.5",
      rx: "3.75",
      fill: "#fff",
      stroke: "#EEBC32",
      strokeWidth: ".5"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("rect", {
      x: "10.25",
      y: "59.25",
      width: "79.5",
      height: "111.5",
      rx: "3.75",
      fill: "#fff",
      stroke: "#EEBC32",
      strokeWidth: ".5"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("rect", {
      x: "10.25",
      y: "177.25",
      width: "121.5",
      height: "111.5",
      rx: "3.75",
      fill: "#fff",
      stroke: "#EEBC32",
      strokeWidth: ".5"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#EEBC32",
      d: "M16 184h24v8H16z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      stroke: "#F8E4AD",
      strokeWidth: ".2",
      d: "M126 233.1H16"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#EEBC32",
      d: "M19 233v-31h6v31zM33 233v-23h6v23zM47 233v-17h6v17zM61 233v-14h6v14zM75 233v-9h6v9zM89 233v-7h6v7zM103 233v-5h6v5zM117 233v-5h6v5z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#F8E4AD",
      d: "M19 233v46h6v-46zM33 233v34h6v-34zM47 233v25h6v-25zM61 233v21h6v-21zM75 233v13h6v-13zM89 233v10h6v-10zM103 233v7h6v-7zM117 233v7h6v-7z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("rect", {
      x: "140.25",
      y: "177.25",
      width: "121.5",
      height: "111.5",
      rx: "3.75",
      fill: "#fff",
      stroke: "#EEBC32",
      strokeWidth: ".5"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      stroke: "#F8E4AD",
      strokeWidth: ".2",
      d: "M256 270.1H146"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      d: "M146 270.1h110V261l-20-14-24.5-7-12-10-18-7.5-13-13.5-22.5-4v65.1z",
      fill: "#EEBC32"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      d: "M146 270.1h110V261l-20-9-23.5-5-13.5-1.5-6.5-5-12-6-12-12-11.5-4-11 5v46.6z",
      fill: "#F1C95B"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      d: "M146 270.1h110v-4.6l-20.5-2.5-23-1-13-3.5-12-3-10-10.5-11-8.5-11-3.5-9.5-1.5v38.6z",
      fill: "#F8E4AD",
      stroke: "#F8E4AD",
      strokeWidth: ".2"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#EEBC32",
      d: "M146 184h24v8h-24z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("rect", {
      x: "96.25",
      y: "59.25",
      width: "165.5",
      height: "111.5",
      rx: "3.75",
      fill: "#fff",
      stroke: "#EEBC32",
      strokeWidth: ".5"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#EEBC32",
      d: "M103 66h24v8h-24z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      stroke: "#F8E4AD",
      strokeWidth: ".2",
      d: "M141.1 82v79M163.1 82v79M185.1 82v79M207.1 82v79M229.1 82v79M251.1 82v79"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#F8E4AD",
      d: "M103 84h28v4h-28zM103 94h28v4h-28zM103 104h28v4h-28zM103 114h28v4h-28zM103 124h28v4h-28zM103 134h28v4h-28z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#EEBC32",
      d: "M141 83h75v6h-75zM141 93h55v6h-55zM141 103h101v6H141zM141 113h25v6h-25zM141 123h33v6h-33zM141 133h64v6h-64z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#F8E4AD",
      d: "M103 145h28v4h-28zM103 155h28v4h-28z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#EEBC32",
      d: "M141 144h55v6h-55zM141 154h86v6h-86zM16 66h24v8H16zM16 32h16v8H16z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#F8E4AD",
      d: "M16 43h24v4H16z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      d: "M50.25 25.25H86A3.75 3.75 0 0 1 89.75 29v20A3.75 3.75 0 0 1 86 52.75H50.25v-27.5z",
      fill: "#EEBC32",
      stroke: "#EEBC32",
      strokeWidth: ".5"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("g", {
      clipPath: "url(#clip0_4478_85106)",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
        fillRule: "evenodd",
        clipRule: "evenodd",
        d: "M56.833 36.89l3.166 3.167 3.167-3.166.472.47L59.998 41l-3.638-3.638.472-.471z",
        fill: "#fff"
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("rect", {
      x: "96.25",
      y: "25.25",
      width: "79.5",
      height: "27.5",
      rx: "3.75",
      fill: "#fff",
      stroke: "#EEBC32",
      strokeWidth: ".5"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#EEBC32",
      d: "M144 32h12v8h-12z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#F8E4AD",
      d: "M144 43h20v4h-20z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#EEBC32",
      d: "M103 32h12v8h-12z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#F8E4AD",
      d: "M103 43h20v4h-20z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#fff",
      d: "M68 32h12v8H68z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#F8E4AD",
      d: "M68 43h16v4H68z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("rect", {
      x: "182.25",
      y: "25.25",
      width: "79.5",
      height: "27.5",
      rx: "3.75",
      fill: "#fff",
      stroke: "#EEBC32",
      strokeWidth: ".5"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      d: "M50 143c-12.703 0-23-10.297-23-23a22.93 22.93 0 0 1 6.592-16.118",
      stroke: "#F1C95B",
      strokeWidth: "12"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      d: "M50 143c12.703 0 23-10.297 23-23S62.703 97 50 97",
      stroke: "#EEBC32",
      strokeWidth: "12"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      d: "M50 97a22.932 22.932 0 0 0-16.408 6.882",
      stroke: "#F8E4AD",
      strokeWidth: "12"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      stroke: "#F1C95B",
      strokeWidth: ".5",
      d: "M136.25 28v23M222.25 28v23"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#EEBC32",
      d: "M189 32h12v8h-12zM230 32h12v8h-12z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#F8E4AD",
      d: "M230 43h20v4h-20zM189 43h20v4h-20z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("defs", {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("clipPath", {
        id: "clip0_4478_85106",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
          fill: "#fff",
          transform: "rotate(180 32 21.5)",
          d: "M0 0h8v8H0z"
        })
      })
    })]
  }));
};

SeeResultsIcon.defaultProps = {
  width: "272",
  height: "300",
  viewBox: "0 0 272 300",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};






const Container = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
  displayName: "OnboardingGuide__Container",
  componentId: "dogs2n-0"
})(["background:", ";border-radius:8px;padding:2rem 3rem;display:flex;align-items:center;flex-direction:column;", ""], p => p.theme.colors.white, _theme__WEBPACK_IMPORTED_MODULE_3__/* .media.tablet */ .BC.tablet`
    flex-direction: row;
  `);
const StyledArrowIcon = styled_components__WEBPACK_IMPORTED_MODULE_4___default()(ArrowIcon).withConfig({
  displayName: "OnboardingGuide__StyledArrowIcon",
  componentId: "dogs2n-1"
})(["margin:2.5rem auto;transform:rotate(90deg);", ""], _theme__WEBPACK_IMPORTED_MODULE_3__/* .media.tablet */ .BC.tablet`
    margin: auto 2.5rem;
    transform: rotate(0deg);
  `);
const SectionContainer = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
  displayName: "OnboardingGuide__SectionContainer",
  componentId: "dogs2n-2"
})(["display:flex;flex-direction:column;align-items:center;"]);
const TextContainer = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
  displayName: "OnboardingGuide__TextContainer",
  componentId: "dogs2n-3"
})(["margin-bottom:15px;"]);
const HeadingContainer = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
  displayName: "OnboardingGuide__HeadingContainer",
  componentId: "dogs2n-4"
})(["margin:1.5rem 0 0.75rem;"]);
const ButtonContainer = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
  displayName: "OnboardingGuide__ButtonContainer",
  componentId: "dogs2n-5"
})(["margin:2rem 0;"]);

const OnboardingGuide = () => {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(HeadingContainer, {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
        children: "Enter your data and visualise your carbon footprint in a matter of minutes."
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(ButtonContainer, {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP, {
        href: "/history/annual/new",
        children: "Get started"
      })
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(Container, {
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(SectionContainer, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(TextContainer, {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
            children: "Enter your data."
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(EnterDataIcon, {})]
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(StyledArrowIcon, {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(SectionContainer, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(TextContainer, {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
            children: "See your results."
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(SeeResultsIcon, {})]
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(StyledArrowIcon, {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(SectionContainer, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(TextContainer, {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
            children: "Become carbon neutral."
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(BecomeCarbonNeutralIcon, {})]
      })]
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (OnboardingGuide);

/***/ }),

/***/ 764:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_common_LoadingLarge__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(49899);
/* harmony import */ var _components_common_Page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97598);
/* harmony import */ var _components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(60805);
/* harmony import */ var _components_ContentContainer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(16067);
/* harmony import */ var _components_dashboard_OnboardingGuide__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(71055);
/* harmony import */ var _components_history_HistoryResults__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(51041);
/* harmony import */ var _contexts_auth__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(58368);
/* harmony import */ var _contexts_measurements__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(85238);
/* harmony import */ var _contexts_project__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(98605);
/* harmony import */ var _contexts_reductionPartners__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(55100);
/* harmony import */ var _utils_custom_hooks_useLoading__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(68037);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_3__]);
_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
















function Dashboard() {
  const {
    organisation
  } = (0,_contexts_auth__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
  const {
    loading,
    setLoading,
    progress,
    setProgress
  } = (0,_utils_custom_hooks_useLoading__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z)();
  const {
    getReductionPartners
  } = (0,_contexts_reductionPartners__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)();
  const {
    annualMeasurementsWithResults,
    loading: loadingMeasurements,
    getMeasurements,
    measurements
  } = (0,_contexts_measurements__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
  const {
    getProjects
  } = (0,_contexts_project__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)();
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    setLoading(true);
    getProjects();
    getReductionPartners();
    getMeasurements();
    setLoading(false);
  }, []);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_common_Page__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_components_ContentContainer__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
      iconBorder: false,
      title: organisation.name,
      fullWidth: true,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_common_LoadingLarge__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        loading: loading,
        text: "Getting dashboard...",
        progress: progress,
        setProgress: setProgress
      }), loadingMeasurements ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_common_LoadingLarge__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        loading: loadingMeasurements,
        text: "Loading measurements...",
        progress: progress,
        setProgress: setProgress
      }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.Fragment, {
        children: annualMeasurementsWithResults.length ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.Fragment, {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_history_HistoryResults__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
            measurement: annualMeasurementsWithResults[0],
            edit: false
          })
        }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_dashboard_OnboardingGuide__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
      })]
    })
  });
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)(Dashboard));
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 87852:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "unstable_getStaticParams": () => (/* binding */ unstable_getStaticParams),
/* harmony export */   "unstable_getStaticProps": () => (/* binding */ unstable_getStaticProps),
/* harmony export */   "unstable_getStaticPaths": () => (/* binding */ unstable_getStaticPaths),
/* harmony export */   "unstable_getServerProps": () => (/* binding */ unstable_getServerProps),
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "_app": () => (/* binding */ _app),
/* harmony export */   "renderReqToHTML": () => (/* binding */ renderReqToHTML),
/* harmony export */   "render": () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(70607);
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59450);
/* harmony import */ var private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97020);
/* harmony import */ var private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(73978);
/* harmony import */ var next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99436);

      
      
      
      

      
      const { processEnv } = __webpack_require__(85360)
      processEnv([{"path":".env","contents":"API_HOST=https://api.inhabit.eco\nNEXT_PUBLIC_CALENDLY_URL=https://calendly.com/inhabit-meet/inhabit-measurement-tutorial\nNEXT_PUBLIC_FLAGS_ENVIRONMENT_KEY=flags_pub_289425705564897805\nNEXT_PUBLIC_GOOGLE_ANALYTICS=G-1CBB78XFQ4\nNEXT_PUBLIC_INTERCOM_APP_ID=bw9p6mfd\nNEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_bQDaTEuYc10x3BZt9YcGj2cE00Gzwm4gDD\nSTRIPE_PUBLISHABLE_KEY=pk_live_bQDaTEuYc10x3BZt9YcGj2cE00Gzwm4gDD\n\n"}])
    
      
      const runtimeConfig = {}
      ;

      const documentModule = __webpack_require__(9968)

      const appMod = __webpack_require__(13724)
      let App = appMod.default || appMod.then && appMod.then(mod => mod.default);

      const compMod = __webpack_require__(764)

      const Component = compMod.default || compMod.then && compMod.then(mod => mod.default)
      /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Component);
      const getStaticProps = compMod['getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['getStaticProp' + 's'])
      const getStaticPaths = compMod['getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['getStaticPath' + 's'])
      const getServerSideProps = compMod['getServerSideProp' + 's'] || compMod.then && compMod.then(mod => mod['getServerSideProp' + 's'])

      // kept for detecting legacy exports
      const unstable_getStaticParams = compMod['unstable_getStaticParam' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticParam' + 's'])
      const unstable_getStaticProps = compMod['unstable_getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticProp' + 's'])
      const unstable_getStaticPaths = compMod['unstable_getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticPath' + 's'])
      const unstable_getServerProps = compMod['unstable_getServerProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getServerProp' + 's'])

      let config = compMod['confi' + 'g'] || (compMod.then && compMod.then(mod => mod['confi' + 'g'])) || {}
      const _app = App

      const combinedRewrites = Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)
        ? private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg
        : []

      if (!Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)) {
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.beforeFiles */ .Dg.beforeFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.afterFiles */ .Dg.afterFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.fallback */ .Dg.fallback)
      }

      const { renderReqToHTML, render } = (0,next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__/* .getPageHandler */ .u)({
        pageModule: compMod,
        pageComponent: Component,
        pageConfig: config,
        appModule: App,
        documentModule: documentModule,
        errorModule: __webpack_require__(99651),
        notFoundModule: undefined,
        pageGetStaticProps: getStaticProps,
        pageGetStaticPaths: getStaticPaths,
        pageGetServerSideProps: getServerSideProps,

        assetPrefix: "",
        canonicalBase: "",
        generateEtags: true,
        poweredByHeader: true,
        reactRoot: false,

        runtimeConfig,
        buildManifest: private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__,
        reactLoadableManifest: private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__,

        rewrites: combinedRewrites,
        i18n: undefined,
        page: "/",
        buildId: "lDoX7RBEQ31kzKIJJbkVC",
        escapedBuildId: "lDoX7RBEQ31kzKIJJbkVC",
        basePath: "",
        pageIsDynamic: false,
        encodedPreviewProps: {previewModeId:"89cdc9f6073608262d43eab6d636f3f4",previewModeSigningKey:"74c7e36a2414a3f7b0ebcc67250f915f156686e1610b45a21ae9358d5b7c6c5a",previewModeEncryptionKey:"8a4c97ad9e5cf12d5a140689be08539ea52d8b27a416c2b8ae67db636b45841b"}
      })
      
    

/***/ }),

/***/ 94970:
/***/ ((module) => {

module.exports = require("@happykit/flags/client");

/***/ }),

/***/ 46411:
/***/ ((module) => {

module.exports = require("@happykit/flags/config");

/***/ }),

/***/ 48095:
/***/ ((module) => {

module.exports = require("@happykit/flags/server");

/***/ }),

/***/ 83218:
/***/ ((module) => {

module.exports = require("@hookform/error-message");

/***/ }),

/***/ 48308:
/***/ ((module) => {

module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ 85360:
/***/ ((module) => {

module.exports = require("@next/env");

/***/ }),

/***/ 64515:
/***/ ((module) => {

module.exports = require("@stripe/react-stripe-js");

/***/ }),

/***/ 20943:
/***/ ((module) => {

module.exports = require("@stripe/stripe-js");

/***/ }),

/***/ 52167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 74146:
/***/ ((module) => {

module.exports = require("date-fns");

/***/ }),

/***/ 1043:
/***/ ((module) => {

module.exports = require("lodash.get");

/***/ }),

/***/ 51650:
/***/ ((module) => {

module.exports = require("lodash.uniqby");

/***/ }),

/***/ 54426:
/***/ ((module) => {

module.exports = require("next/dist/compiled/chalk");

/***/ }),

/***/ 40252:
/***/ ((module) => {

module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 19371:
/***/ ((module) => {

module.exports = require("next/dist/compiled/node-fetch");

/***/ }),

/***/ 97999:
/***/ ((module) => {

module.exports = require("next/dist/compiled/path-to-regexp");

/***/ }),

/***/ 60600:
/***/ ((module) => {

module.exports = require("next/dist/server/accept-header.js");

/***/ }),

/***/ 52155:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils/index.js");

/***/ }),

/***/ 90730:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils/node.js");

/***/ }),

/***/ 60562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 94140:
/***/ ((module) => {

module.exports = require("next/dist/server/get-page-files.js");

/***/ }),

/***/ 89716:
/***/ ((module) => {

module.exports = require("next/dist/server/htmlescape.js");

/***/ }),

/***/ 25071:
/***/ ((module) => {

module.exports = require("next/dist/server/render-result.js");

/***/ }),

/***/ 33100:
/***/ ((module) => {

module.exports = require("next/dist/server/render.js");

/***/ }),

/***/ 92779:
/***/ ((module) => {

module.exports = require("next/dist/server/request-meta.js");

/***/ }),

/***/ 79502:
/***/ ((module) => {

module.exports = require("next/dist/server/send-payload.js");

/***/ }),

/***/ 76368:
/***/ ((module) => {

module.exports = require("next/dist/server/utils.js");

/***/ }),

/***/ 56724:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 27664:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/escape-regexp.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 94957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 82374:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-locale-cookie.js");

/***/ }),

/***/ 34014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 78524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 78020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 29565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 64365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 95714:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-route-from-asset-path.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 91292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 25753:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-match.js");

/***/ }),

/***/ 99521:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/prepare-destination.js");

/***/ }),

/***/ 80979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 36052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 84226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 95566:
/***/ ((module) => {

module.exports = require("next/error");

/***/ }),

/***/ 40968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 71853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 59819:
/***/ ((module) => {

module.exports = require("querystring");

/***/ }),

/***/ 16689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 25716:
/***/ ((module) => {

module.exports = require("react-hotjar");

/***/ }),

/***/ 16666:
/***/ ((module) => {

module.exports = require("react-responsive");

/***/ }),

/***/ 61929:
/***/ ((module) => {

module.exports = require("react-select");

/***/ }),

/***/ 1187:
/***/ ((module) => {

module.exports = require("react-toastify");

/***/ }),

/***/ 20997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 36157:
/***/ ((module) => {

module.exports = require("recharts");

/***/ }),

/***/ 57518:
/***/ ((module) => {

module.exports = require("styled-components");

/***/ }),

/***/ 24535:
/***/ ((module) => {

module.exports = require("styled-normalize");

/***/ }),

/***/ 6153:
/***/ ((module) => {

module.exports = require("universal-cookie");

/***/ }),

/***/ 84269:
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ 75609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 61908:
/***/ ((module) => {

module.exports = import("@hookform/resolvers/yup");;

/***/ }),

/***/ 45641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [4357,9703,6114,9067,8183,9899,805,6067,1233,9343,1217,1041], () => (__webpack_exec__(87852)));
module.exports = __webpack_exports__;

})();