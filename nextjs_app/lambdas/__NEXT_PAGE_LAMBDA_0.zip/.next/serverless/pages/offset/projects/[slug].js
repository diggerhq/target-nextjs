"use strict";
(() => {
var exports = {};
exports.id = 6940;
exports.ids = [6940];
exports.modules = {

/***/ 37928:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const BreadcrumbLink = styled_components__WEBPACK_IMPORTED_MODULE_0___default().a.withConfig({
  displayName: "BreadcrumbLink",
  componentId: "sc-1fywp6v-0"
})(["cursor:pointer;text-decoration:none;"]);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BreadcrumbLink);

/***/ }),

/***/ 20406:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(41664);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(16666);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_responsive__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_common_BreadcrumbLink__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(37928);
/* harmony import */ var _components_common_LoadingLarge__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(49899);
/* harmony import */ var _components_common_Page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(97598);
/* harmony import */ var _components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(60805);
/* harmony import */ var _components_common_Text__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(87491);
/* harmony import */ var _components_ContentContainer__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(16067);
/* harmony import */ var _contexts_auth__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(58368);
/* harmony import */ var _contexts_project__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(98605);
/* harmony import */ var _lib_projects__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(27898);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(72994);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_7__]);
_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_7__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



















const Container = styled_components__WEBPACK_IMPORTED_MODULE_15___default().div.withConfig({
  displayName: "slug__Container",
  componentId: "sc-186qxtb-0"
})(["display:flex;flex-direction:column;p{", "}h3{", "}", ""], p => p.theme.body, p => p.theme.h3, _theme__WEBPACK_IMPORTED_MODULE_14__/* .media.tabletLarge */ .BC.tabletLarge`
    flex-direction: row;

  `);
const Content = styled_components__WEBPACK_IMPORTED_MODULE_15___default().div.withConfig({
  displayName: "slug__Content",
  componentId: "sc-186qxtb-1"
})(["padding-bottom:2rem;margin-bottom:2rem;border-bottom:1px solid black;h3{", "}"], p => p.theme.h3);
const InnerContainer = styled_components__WEBPACK_IMPORTED_MODULE_15___default().div.withConfig({
  displayName: "slug__InnerContainer",
  componentId: "sc-186qxtb-2"
})([""]);
const LeftContainer = styled_components__WEBPACK_IMPORTED_MODULE_15___default()(InnerContainer).withConfig({
  displayName: "slug__LeftContainer",
  componentId: "sc-186qxtb-3"
})(["", ""], _theme__WEBPACK_IMPORTED_MODULE_14__/* .media.tabletLarge */ .BC.tabletLarge`
    margin-right: 3rem;
  `);
const RightContainer = styled_components__WEBPACK_IMPORTED_MODULE_15___default()(InnerContainer).withConfig({
  displayName: "slug__RightContainer",
  componentId: "sc-186qxtb-4"
})([""]);
const ImageContainer = styled_components__WEBPACK_IMPORTED_MODULE_15___default().div.withConfig({
  displayName: "slug__ImageContainer",
  componentId: "sc-186qxtb-5"
})(["width:100%;height:100%;", ""], _theme__WEBPACK_IMPORTED_MODULE_14__/* .media.tabletLarge */ .BC.tabletLarge`
    width: 21rem;
    height: 15rem;
  `);
const Image = styled_components__WEBPACK_IMPORTED_MODULE_15___default().img.withConfig({
  displayName: "slug__Image",
  componentId: "sc-186qxtb-6"
})(["width:100%;height:100%;", ""], _styles__WEBPACK_IMPORTED_MODULE_13__/* .borderRadius */ .E);
const FactContainer = styled_components__WEBPACK_IMPORTED_MODULE_15___default().div.withConfig({
  displayName: "slug__FactContainer",
  componentId: "sc-186qxtb-7"
})(["width:100%;height:100%;", " background-color:", ";display:flex;align-items:center;margin-top:1.25rem;padding:0.5rem 1.5rem;", ""], _styles__WEBPACK_IMPORTED_MODULE_13__/* .borderRadius */ .E, p => p.theme.colors.white, _theme__WEBPACK_IMPORTED_MODULE_14__/* .media.tabletLarge */ .BC.tabletLarge`
  padding: 0 1.5rem;
  width: 21rem;
  height: 4.25rem;
  `);
const FactContent = styled_components__WEBPACK_IMPORTED_MODULE_15___default().div.withConfig({
  displayName: "slug__FactContent",
  componentId: "sc-186qxtb-8"
})(["display:flex;flex-direction:column;justify-content:flex-start;align-items:flex-start;"]);
const FactIcon = styled_components__WEBPACK_IMPORTED_MODULE_15___default().div.withConfig({
  displayName: "slug__FactIcon",
  componentId: "sc-186qxtb-9"
})(["margin-right:1rem;& > svg{height:2rem;width:2rem;", "}"], _theme__WEBPACK_IMPORTED_MODULE_14__/* .media.desktop */ .BC.desktop`
  height: 3rem;
  width: 3rem;
  `);
const SDGListContainer = styled_components__WEBPACK_IMPORTED_MODULE_15___default().div.withConfig({
  displayName: "slug__SDGListContainer",
  componentId: "sc-186qxtb-10"
})(["display:flex;align-items:flex-start;flex-direction:column;"]);
const SDGContainer = styled_components__WEBPACK_IMPORTED_MODULE_15___default().div.withConfig({
  displayName: "slug__SDGContainer",
  componentId: "sc-186qxtb-11"
})(["display:flex;margin-top:1.25rem;align-items:flex-start;"]);
const SDGLogo = styled_components__WEBPACK_IMPORTED_MODULE_15___default().img.withConfig({
  displayName: "slug__SDGLogo",
  componentId: "sc-186qxtb-12"
})(["margin-right:2rem;border-radius:10px;width:4.5rem;", ""], _theme__WEBPACK_IMPORTED_MODULE_14__/* .media.tabletLarge */ .BC.tabletLarge`
    width: 6rem;
  `);
const SDGDescription = styled_components__WEBPACK_IMPORTED_MODULE_15___default().div.withConfig({
  displayName: "slug__SDGDescription",
  componentId: "sc-186qxtb-13"
})([""]);

const renderStandardText = standard => {
  switch (standard) {
    case "gold_standard":
      return "Gold Standard";
      break;

    case "redd":
      return "REDD+";
      break;

    default:
      break;
  }
};

const renderTypeText = type => {
  switch (type) {
    case "wind_power":
      return "Wind Power";
      break;

    case "bio_gas":
      return "Biogas";
      break;

    case "biodiversity_conservation":
      return "Biodiversity Conservation";
      break;

    default:
      break;
  }
};

const SDGs = [{
  id: 1,
  description: "Providing clean, readily available, affordable energy for businesses and households in the province. Fulfiling an important precondition to the areas economic development."
}, {
  id: 3,
  description: "Decreasing air pollution from fossul fuel based energy capture, and increasing the health of the local community."
}, {
  id: 7,
  description: "Providing renewable, clean wind power and reducing the country’s costly dependency on fossil fuels. Closing supply gaps and promoting the establishment of a sustainable, climate-friendly energy sector."
}, {
  id: 8,
  description: "Local employees have been specifically trained in site construction, operation and maintenance, work safety and fire protection. Improving the conditions for production and the profits of Pakistani companies."
}, {
  id: 9,
  description: "The PoA is a component of an increasingly robust and diversified renweable energy infrastructure in Pakistan. Creating necessary conditions for sustainable industrialisation."
}, {
  id: 13,
  description: "The overall purpose of the Zorlu Enerji project is the reduction of GHG emissions. Replacing fossil-based grids with clean wind power."
}];

const OffsetProject = () => {
  const {
    user,
    organisation,
    isAdmin
  } = (0,_contexts_auth__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)();
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
  const {
    selectedProject,
    getSelectedProject,
    loading,
    progress,
    setProgress,
    setSelectedProject
  } = (0,_contexts_project__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z)();
  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(() => {
    if (router.query.slug) {
      getSelectedProject();
    }

    return () => setSelectedProject(null);
  }, [router.query]);
  const isTabletLarge = (0,react_responsive__WEBPACK_IMPORTED_MODULE_3__.useMediaQuery)({
    query: `(min-width: ${_theme__WEBPACK_IMPORTED_MODULE_14__/* .sizes.tabletLarge */ .J7.tabletLarge}px)`
  });
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_components_common_Page__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .ZP, {
    children: !selectedProject ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_components_common_LoadingLarge__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
      loading: loading,
      text: "Getting Project...",
      progress: progress,
      setProgress: setProgress
    }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_components_ContentContainer__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
      title: selectedProject.title,
      breadcrumb: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.Fragment, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(next_link__WEBPACK_IMPORTED_MODULE_0__["default"], {
          href: "/offset",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_components_common_BreadcrumbLink__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)(_components_common_Text__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .ZP, {
              size: "breadcrumb",
              align: "left",
              color: "placeholderGrey",
              children: ["Offset ", ">"]
            })
          })
        }), " ", selectedProject.title]
      }),
      cta: isAdmin({
        user,
        organisation
      }) && "Offset carbon",
      onClick: () => router.push("/offset/projects/[slug]/payment", `/offset/projects/${selectedProject.slug}/payment`),
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)(Container, {
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)(LeftContainer, {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(ImageContainer, {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(Image, {
              src: selectedProject.image
            })
          }), selectedProject.type && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)(FactContainer, {
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(FactIcon, {
              children: (0,_lib_projects__WEBPACK_IMPORTED_MODULE_12__/* .renderTypeIcon */ .L)(selectedProject.type)
            }), " ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)(FactContent, {
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .ZP, {
                size: isTabletLarge ? "body" : "small",
                children: "Type:"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .ZP, {
                size: isTabletLarge ? "breadcrumb" : "smallBold",
                align: "left",
                children: renderTypeText(selectedProject.type)
              })]
            })]
          }), selectedProject.standard && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)(FactContainer, {
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(FactIcon, {
              children: (0,_lib_projects__WEBPACK_IMPORTED_MODULE_12__/* .renderStandardIcon */ .G)(selectedProject.standard)
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)(FactContent, {
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .ZP, {
                size: isTabletLarge ? "body" : "small",
                children: "Carbon Credit Standard:"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .ZP, {
                size: isTabletLarge ? "breadcrumb" : "smallBold",
                children: renderStandardText(selectedProject.standard)
              })]
            })]
          }), selectedProject.facts && selectedProject.facts.map(({
            label,
            value
          }) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(FactContainer, {
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)(FactContent, {
              children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)(_components_common_Text__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .ZP, {
                size: isTabletLarge ? "body" : "small",
                children: [label, ":"]
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .ZP, {
                size: isTabletLarge ? "breadcrumb" : "smallBold",
                children: value
              })]
            })
          }))]
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)(RightContainer, {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(Content, {
            dangerouslySetInnerHTML: {
              __html: selectedProject.long_description
            }
          }), selectedProject.further_description && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.Fragment, {
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .ZP, {
              size: "h4",
              children: "Further Background"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(Content, {
              dangerouslySetInnerHTML: {
                __html: selectedProject.further_description
              }
            })]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .ZP, {
            size: "h4",
            children: "Project Contribution To UN SDG Goals"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx("br", {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)(_components_common_Text__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .ZP, {
            children: ["The ", selectedProject.title, " Project contributes to local sustainable development via a variety of registered SDG\u2019s. Generating positive impact across a range of economic, social, environmental and technological growth categories."]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(SDGListContainer, {
            children: SDGs.filter(({
              id
            }) => selectedProject.sustainability_development_goals.includes(id)).map(({
              id,
              description
            }) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)(SDGContainer, {
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(SDGLogo, {
                src: `https://inhabit-images.s3.eu-west-2.amazonaws.com/assets/sdg_logos/sdg_${id}.png`,
                alt: `Sustainability development goal ${id}`
              }, id), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(SDGDescription, {
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .ZP, {
                  children: description
                })
              })]
            }))
          })]
        })]
      })
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)(OffsetProject));
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4546:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "unstable_getStaticParams": () => (/* binding */ unstable_getStaticParams),
/* harmony export */   "unstable_getStaticProps": () => (/* binding */ unstable_getStaticProps),
/* harmony export */   "unstable_getStaticPaths": () => (/* binding */ unstable_getStaticPaths),
/* harmony export */   "unstable_getServerProps": () => (/* binding */ unstable_getServerProps),
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "_app": () => (/* binding */ _app),
/* harmony export */   "renderReqToHTML": () => (/* binding */ renderReqToHTML),
/* harmony export */   "render": () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(70607);
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59450);
/* harmony import */ var private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97020);
/* harmony import */ var private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(73978);
/* harmony import */ var next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99436);

      
      
      
      

      
      const { processEnv } = __webpack_require__(85360)
      processEnv([{"path":".env","contents":"API_HOST=https://api.inhabit.eco\nNEXT_PUBLIC_CALENDLY_URL=https://calendly.com/inhabit-meet/inhabit-measurement-tutorial\nNEXT_PUBLIC_FLAGS_ENVIRONMENT_KEY=flags_pub_289425705564897805\nNEXT_PUBLIC_GOOGLE_ANALYTICS=G-1CBB78XFQ4\nNEXT_PUBLIC_INTERCOM_APP_ID=bw9p6mfd\nNEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_bQDaTEuYc10x3BZt9YcGj2cE00Gzwm4gDD\nSTRIPE_PUBLISHABLE_KEY=pk_live_bQDaTEuYc10x3BZt9YcGj2cE00Gzwm4gDD\n\n"}])
    
      
      const runtimeConfig = {}
      ;

      const documentModule = __webpack_require__(9968)

      const appMod = __webpack_require__(13724)
      let App = appMod.default || appMod.then && appMod.then(mod => mod.default);

      const compMod = __webpack_require__(20406)

      const Component = compMod.default || compMod.then && compMod.then(mod => mod.default)
      /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Component);
      const getStaticProps = compMod['getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['getStaticProp' + 's'])
      const getStaticPaths = compMod['getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['getStaticPath' + 's'])
      const getServerSideProps = compMod['getServerSideProp' + 's'] || compMod.then && compMod.then(mod => mod['getServerSideProp' + 's'])

      // kept for detecting legacy exports
      const unstable_getStaticParams = compMod['unstable_getStaticParam' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticParam' + 's'])
      const unstable_getStaticProps = compMod['unstable_getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticProp' + 's'])
      const unstable_getStaticPaths = compMod['unstable_getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticPath' + 's'])
      const unstable_getServerProps = compMod['unstable_getServerProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getServerProp' + 's'])

      let config = compMod['confi' + 'g'] || (compMod.then && compMod.then(mod => mod['confi' + 'g'])) || {}
      const _app = App

      const combinedRewrites = Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)
        ? private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg
        : []

      if (!Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)) {
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.beforeFiles */ .Dg.beforeFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.afterFiles */ .Dg.afterFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.fallback */ .Dg.fallback)
      }

      const { renderReqToHTML, render } = (0,next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__/* .getPageHandler */ .u)({
        pageModule: compMod,
        pageComponent: Component,
        pageConfig: config,
        appModule: App,
        documentModule: documentModule,
        errorModule: __webpack_require__(99651),
        notFoundModule: undefined,
        pageGetStaticProps: getStaticProps,
        pageGetStaticPaths: getStaticPaths,
        pageGetServerSideProps: getServerSideProps,

        assetPrefix: "",
        canonicalBase: "",
        generateEtags: true,
        poweredByHeader: true,
        reactRoot: false,

        runtimeConfig,
        buildManifest: private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__,
        reactLoadableManifest: private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__,

        rewrites: combinedRewrites,
        i18n: undefined,
        page: "/offset/projects/[slug]",
        buildId: "lDoX7RBEQ31kzKIJJbkVC",
        escapedBuildId: "lDoX7RBEQ31kzKIJJbkVC",
        basePath: "",
        pageIsDynamic: true,
        encodedPreviewProps: {previewModeId:"89cdc9f6073608262d43eab6d636f3f4",previewModeSigningKey:"74c7e36a2414a3f7b0ebcc67250f915f156686e1610b45a21ae9358d5b7c6c5a",previewModeEncryptionKey:"8a4c97ad9e5cf12d5a140689be08539ea52d8b27a416c2b8ae67db636b45841b"}
      })
      
    

/***/ }),

/***/ 94970:
/***/ ((module) => {

module.exports = require("@happykit/flags/client");

/***/ }),

/***/ 46411:
/***/ ((module) => {

module.exports = require("@happykit/flags/config");

/***/ }),

/***/ 48095:
/***/ ((module) => {

module.exports = require("@happykit/flags/server");

/***/ }),

/***/ 83218:
/***/ ((module) => {

module.exports = require("@hookform/error-message");

/***/ }),

/***/ 48308:
/***/ ((module) => {

module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ 85360:
/***/ ((module) => {

module.exports = require("@next/env");

/***/ }),

/***/ 64515:
/***/ ((module) => {

module.exports = require("@stripe/react-stripe-js");

/***/ }),

/***/ 20943:
/***/ ((module) => {

module.exports = require("@stripe/stripe-js");

/***/ }),

/***/ 52167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 1043:
/***/ ((module) => {

module.exports = require("lodash.get");

/***/ }),

/***/ 51650:
/***/ ((module) => {

module.exports = require("lodash.uniqby");

/***/ }),

/***/ 54426:
/***/ ((module) => {

module.exports = require("next/dist/compiled/chalk");

/***/ }),

/***/ 40252:
/***/ ((module) => {

module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 19371:
/***/ ((module) => {

module.exports = require("next/dist/compiled/node-fetch");

/***/ }),

/***/ 97999:
/***/ ((module) => {

module.exports = require("next/dist/compiled/path-to-regexp");

/***/ }),

/***/ 60600:
/***/ ((module) => {

module.exports = require("next/dist/server/accept-header.js");

/***/ }),

/***/ 52155:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils/index.js");

/***/ }),

/***/ 90730:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils/node.js");

/***/ }),

/***/ 60562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 94140:
/***/ ((module) => {

module.exports = require("next/dist/server/get-page-files.js");

/***/ }),

/***/ 89716:
/***/ ((module) => {

module.exports = require("next/dist/server/htmlescape.js");

/***/ }),

/***/ 25071:
/***/ ((module) => {

module.exports = require("next/dist/server/render-result.js");

/***/ }),

/***/ 33100:
/***/ ((module) => {

module.exports = require("next/dist/server/render.js");

/***/ }),

/***/ 92779:
/***/ ((module) => {

module.exports = require("next/dist/server/request-meta.js");

/***/ }),

/***/ 79502:
/***/ ((module) => {

module.exports = require("next/dist/server/send-payload.js");

/***/ }),

/***/ 76368:
/***/ ((module) => {

module.exports = require("next/dist/server/utils.js");

/***/ }),

/***/ 56724:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 27664:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/escape-regexp.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 94957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 82374:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-locale-cookie.js");

/***/ }),

/***/ 34014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 78524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 78020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 29565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 64365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 95714:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-route-from-asset-path.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 91292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 25753:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-match.js");

/***/ }),

/***/ 99521:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/prepare-destination.js");

/***/ }),

/***/ 80979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 36052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 84226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 95566:
/***/ ((module) => {

module.exports = require("next/error");

/***/ }),

/***/ 40968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 71853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 59819:
/***/ ((module) => {

module.exports = require("querystring");

/***/ }),

/***/ 16689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 25716:
/***/ ((module) => {

module.exports = require("react-hotjar");

/***/ }),

/***/ 16666:
/***/ ((module) => {

module.exports = require("react-responsive");

/***/ }),

/***/ 1187:
/***/ ((module) => {

module.exports = require("react-toastify");

/***/ }),

/***/ 20997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 57518:
/***/ ((module) => {

module.exports = require("styled-components");

/***/ }),

/***/ 24535:
/***/ ((module) => {

module.exports = require("styled-normalize");

/***/ }),

/***/ 6153:
/***/ ((module) => {

module.exports = require("universal-cookie");

/***/ }),

/***/ 84269:
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ 75609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 61908:
/***/ ((module) => {

module.exports = import("@hookform/resolvers/yup");;

/***/ }),

/***/ 45641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [4357,9703,6114,9067,8183,9899,805,6067,7898], () => (__webpack_exec__(4546)));
module.exports = __webpack_exports__;

})();