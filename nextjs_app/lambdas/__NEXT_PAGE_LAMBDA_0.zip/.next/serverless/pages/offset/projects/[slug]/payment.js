"use strict";
(() => {
var exports = {};
exports.id = 3182;
exports.ids = [3182];
exports.modules = {

/***/ 45839:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Text__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(87491);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




var CardChipIcon = function CardChipIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      d: "M12.506.006h9.5c1.466 0 2.622.944 2.922 2.37.044.207.067.418.068.63.004 3.82.004 7.64 0 11.46-.003 1.47-1.012 2.673-2.435 2.923a4.676 4.676 0 0 1-.804.06c-6.17.003-12.34.005-18.511.005-1.235 0-2.234-.418-2.877-1.517A2.65 2.65 0 0 1 0 14.585V2.856C.002 1.354 1.275.05 2.782.014 3.867-.01 4.952.006 6.04.006h6.467zm0 6.936H1.51c-.182 0-.306 0-.305.25.008 2.448 0 4.897.007 7.346a1.69 1.69 0 0 0 .507 1.21c.41.42.93.513 1.482.513h18.365c.188 0 .374-.024.56-.034.911-.051 1.658-.812 1.644-1.868-.03-2.35-.01-4.702-.01-7.052 0-.364 0-.364-.358-.364H12.505v-.001zm-.016-3.905h10.525c.18 0 .36-.006.538 0 .165.008.217-.067.207-.22a1.65 1.65 0 0 0-.306-.865c-.402-.572-.984-.741-1.644-.741H5.41c-.775 0-1.55-.007-2.325 0-1.017.012-1.68.547-1.847 1.472-.06.337-.048.35.287.35l10.965.004zm-.008 1.209H1.76a1.974 1.974 0 0 1-.245 0c-.229-.029-.327.051-.31.296.02.268.005.538.006.807 0 .385 0 .385.382.385H23.38c.049-.002.098-.002.147 0 .187.022.24-.07.235-.244-.008-.294 0-.587 0-.881 0-.362 0-.363-.36-.363h-10.92z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      d: "M21.143 11.399v1.958c0 .444-.231.68-.678.682-1.265.005-2.53.005-3.794 0-.453 0-.696-.247-.697-.7a870.154 870.154 0 0 1 0-3.892c0-.416.195-.64.606-.686.22-.02.44-.026.66-.02 1.003-.002 2.006-.002 3.01 0 .13-.002.26.009.389.03.315.056.5.273.503.596.004.678 0 1.355 0 2.032zm-1.208-.013h.01c0-.391-.003-.783 0-1.174.003-.159-.042-.24-.22-.24-.765.005-1.532.005-2.298 0-.156 0-.22.06-.219.216.004.79.004 1.58 0 2.371 0 .167.062.231.23.23.759-.005 1.516-.005 2.274 0 .174 0 .228-.067.225-.232-.007-.389-.002-.78-.002-1.17zM8.534 10.852H4.619a1.349 1.349 0 0 1-.411-.043.601.601 0 0 1-.433-.562.604.604 0 0 1 .429-.589 1.29 1.29 0 0 1 .385-.045h7.9c.13-.004.26.012.385.048a.615.615 0 0 1 .423.571.61.61 0 0 1-.42.573 1.302 1.302 0 0 1-.41.048H8.534zM7.39 12.541c.977 0 1.956-.003 2.934 0 .386 0 .662.264.657.607-.005.335-.273.582-.648.598-.082.003-.163 0-.244 0h-4.11c-.53 0-1.059 0-1.589-.003a.588.588 0 0 1-.552-.34.57.57 0 0 1 .044-.604c.135-.202.338-.263.573-.263.978.007 1.956.005 2.934.005z"
    })]
  }));
};

CardChipIcon.defaultProps = {
  viewBox: "0 0 25 18",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};



const Card = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
  displayName: "BankCard__Card",
  componentId: "sc-1w3nvrq-0"
})(["background:", ";border-radius:10px;width:12rem;height:7.5rem;padding:18px;"], p => p.theme.colors.progressYellow);
const StyledCardChipIcon = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(CardChipIcon).withConfig({
  displayName: "BankCard__StyledCardChipIcon",
  componentId: "sc-1w3nvrq-1"
})(["width:1.5rem;height:1.125rem;fill:", ";"], p => p.theme.colors.black);
const CardRow = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
  displayName: "BankCard__CardRow",
  componentId: "sc-1w3nvrq-2"
})(["display:flex;justify-content:space-between;align-items:center;"]);

const BankCard = ({
  name,
  last4,
  expiryDate
}) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(Card, {
  children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(CardRow, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_Text__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
      size: "tiny",
      children: name || "Name"
    }), " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(StyledCardChipIcon, {})]
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(CardRow, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(_Text__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
      size: "tinyBold",
      children: ["**** **** **** ", last4 || 1234]
    })
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(CardRow, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_Text__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
      size: "minisculeBold",
      children: expiryDate || "01/01"
    })
  })]
});

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BankCard);

/***/ }),

/***/ 37928:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const BreadcrumbLink = styled_components__WEBPACK_IMPORTED_MODULE_0___default().a.withConfig({
  displayName: "BreadcrumbLink",
  componentId: "sc-1fywp6v-0"
})(["cursor:pointer;text-decoration:none;"]);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BreadcrumbLink);

/***/ }),

/***/ 45131:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _stripe_react_stripe_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(64515);
/* harmony import */ var _stripe_react_stripe_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_stripe_react_stripe_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Input__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18183);
/* harmony import */ var _Label__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(54251);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Input__WEBPACK_IMPORTED_MODULE_1__]);
_Input__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }








const FormContainer = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
  displayName: "CardSection__FormContainer",
  componentId: "sc-2or8ni-0"
})(["width:100%;.StripeElement{", " margin-top:0.5rem;padding:0.875rem 0.75rem;pointer-events:none;iframe{pointer-events:auto;}}.StripeElement--focus{outline:none;border:2px solid #2e68f1;box-shadow:0 1px 3px 0 #cfd7df;}.StripeElement--invalid{border-color:#fa755a;}.StripeElement--webkit-autofill{background-color:#fefde5 !important;}"], _Input__WEBPACK_IMPORTED_MODULE_1__/* .inputStyles */ .T);
const CARD_ELEMENT_OPTIONS = {
  style: {
    base: {
      color: _theme__WEBPACK_IMPORTED_MODULE_3__/* ["default"].colors.black */ .ZP.colors.black,
      fontFamily: '"Poppins", Helvetica, sans-serif',
      fontSmoothing: "antialiased",
      borderRadius: "20px",
      fontWeight: 600,
      fontSize: "16px",
      "::placeholder": {
        color: _theme__WEBPACK_IMPORTED_MODULE_3__/* ["default"].colors.placeholderGrey */ .ZP.colors.placeholderGrey,
        fontWeight: 600
      }
    },
    invalid: {
      color: "#fa755a",
      iconColor: "#fa755a"
    }
  }
};

const CARD_NUMBER_OPTIONS = _objectSpread(_objectSpread({}, CARD_ELEMENT_OPTIONS), {}, {
  placeholder: "0000 0000 0000 0000"
});

const CVC_OPTIONS = _objectSpread(_objectSpread({}, CARD_ELEMENT_OPTIONS), {}, {
  placeholder: "123"
});

function CardSection() {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(FormContainer, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(_Label__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
      children: ["Card number:", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_stripe_react_stripe_js__WEBPACK_IMPORTED_MODULE_0__.CardNumberElement, {
        options: CARD_NUMBER_OPTIONS
      })]
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(_Label__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
      children: ["Expiry date:", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_stripe_react_stripe_js__WEBPACK_IMPORTED_MODULE_0__.CardExpiryElement, {
        options: CARD_ELEMENT_OPTIONS
      })]
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(_Label__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
      children: ["CVC:", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_stripe_react_stripe_js__WEBPACK_IMPORTED_MODULE_0__.CardCvcElement, {
        options: CVC_OPTIONS
      })]
    })]
  });
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CardSection);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 54251:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export labelStyles */
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const labelStyles = (0,styled_components__WEBPACK_IMPORTED_MODULE_0__.css)(["color:", ";font-weight:", ";font-size:", ";"], p => p.color ? p.color : p.theme.colors.label, p => p.fontWeight || p.theme.body.weight, p => p.theme.tiny.size);
const Label = styled_components__WEBPACK_IMPORTED_MODULE_0___default().label.withConfig({
  displayName: "Label",
  componentId: "l08cxq-0"
})(["", " margin:", ";", ""], labelStyles, p => p.margin || " 0 0.125rem 0.1rem", p => p.block && "display:block;");
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Label);

/***/ }),

/***/ 23310:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(61908);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(74146);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(date_fns__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(45641);
/* harmony import */ var _common_ConfirmationModal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(65487);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(87491);
/* harmony import */ var _form_PasswordInput__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(20661);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(91073);
/* harmony import */ var _utils_cookies__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1420);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(11098);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(75609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_1__, react_hook_form__WEBPACK_IMPORTED_MODULE_4__, _form_PasswordInput__WEBPACK_IMPORTED_MODULE_7__]);
([_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_1__, react_hook_form__WEBPACK_IMPORTED_MODULE_4__, _form_PasswordInput__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }










var CardChipIcon = function CardChipIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("path", {
      d: "M12.506.006h9.5c1.466 0 2.622.944 2.922 2.37.044.207.067.418.068.63.004 3.82.004 7.64 0 11.46-.003 1.47-1.012 2.673-2.435 2.923a4.676 4.676 0 0 1-.804.06c-6.17.003-12.34.005-18.511.005-1.235 0-2.234-.418-2.877-1.517A2.65 2.65 0 0 1 0 14.585V2.856C.002 1.354 1.275.05 2.782.014 3.867-.01 4.952.006 6.04.006h6.467zm0 6.936H1.51c-.182 0-.306 0-.305.25.008 2.448 0 4.897.007 7.346a1.69 1.69 0 0 0 .507 1.21c.41.42.93.513 1.482.513h18.365c.188 0 .374-.024.56-.034.911-.051 1.658-.812 1.644-1.868-.03-2.35-.01-4.702-.01-7.052 0-.364 0-.364-.358-.364H12.505v-.001zm-.016-3.905h10.525c.18 0 .36-.006.538 0 .165.008.217-.067.207-.22a1.65 1.65 0 0 0-.306-.865c-.402-.572-.984-.741-1.644-.741H5.41c-.775 0-1.55-.007-2.325 0-1.017.012-1.68.547-1.847 1.472-.06.337-.048.35.287.35l10.965.004zm-.008 1.209H1.76a1.974 1.974 0 0 1-.245 0c-.229-.029-.327.051-.31.296.02.268.005.538.006.807 0 .385 0 .385.382.385H23.38c.049-.002.098-.002.147 0 .187.022.24-.07.235-.244-.008-.294 0-.587 0-.881 0-.362 0-.363-.36-.363h-10.92z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("path", {
      d: "M21.143 11.399v1.958c0 .444-.231.68-.678.682-1.265.005-2.53.005-3.794 0-.453 0-.696-.247-.697-.7a870.154 870.154 0 0 1 0-3.892c0-.416.195-.64.606-.686.22-.02.44-.026.66-.02 1.003-.002 2.006-.002 3.01 0 .13-.002.26.009.389.03.315.056.5.273.503.596.004.678 0 1.355 0 2.032zm-1.208-.013h.01c0-.391-.003-.783 0-1.174.003-.159-.042-.24-.22-.24-.765.005-1.532.005-2.298 0-.156 0-.22.06-.219.216.004.79.004 1.58 0 2.371 0 .167.062.231.23.23.759-.005 1.516-.005 2.274 0 .174 0 .228-.067.225-.232-.007-.389-.002-.78-.002-1.17zM8.534 10.852H4.619a1.349 1.349 0 0 1-.411-.043.601.601 0 0 1-.433-.562.604.604 0 0 1 .429-.589 1.29 1.29 0 0 1 .385-.045h7.9c.13-.004.26.012.385.048a.615.615 0 0 1 .423.571.61.61 0 0 1-.42.573 1.302 1.302 0 0 1-.41.048H8.534zM7.39 12.541c.977 0 1.956-.003 2.934 0 .386 0 .662.264.657.607-.005.335-.273.582-.648.598-.082.003-.163 0-.244 0h-4.11c-.53 0-1.059 0-1.589-.003a.588.588 0 0 1-.552-.34.57.57 0 0 1 .044-.604c.135-.202.338-.263.573-.263.978.007 1.956.005 2.934.005z"
    })]
  }));
};

CardChipIcon.defaultProps = {
  viewBox: "0 0 25 18",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};







const schema = yup__WEBPACK_IMPORTED_MODULE_13__.object().shape({
  password: yup__WEBPACK_IMPORTED_MODULE_13__.string().required("Please enter your password").min(8, "Please enter a valid password")
});
const TitleContainer = styled_components__WEBPACK_IMPORTED_MODULE_12___default().div.withConfig({
  displayName: "ConfirmPayment__TitleContainer",
  componentId: "sc-1lql97v-0"
})(["display:flex;flex-direction:column;align-items:center;justify-content:center;"]);
const ButtonContainer = styled_components__WEBPACK_IMPORTED_MODULE_12___default().div.withConfig({
  displayName: "ConfirmPayment__ButtonContainer",
  componentId: "sc-1lql97v-1"
})(["margin-top:2rem;display:flex;justify-content:flex-end;width:100%;& > button:not(:first-of-type){margin-left:0.5rem;}", ""], _theme__WEBPACK_IMPORTED_MODULE_9__/* .media.tabletLarge */ .BC.tabletLarge`
    margin-top: auto;
    margin-left: -40%;
    width: 147%;

    & > button {
        width: 8rem;
  }
  `);
const BodyContainer = styled_components__WEBPACK_IMPORTED_MODULE_12___default()(TitleContainer).withConfig({
  displayName: "ConfirmPayment__BodyContainer",
  componentId: "sc-1lql97v-2"
})(["padding:0 10%;", ""], _theme__WEBPACK_IMPORTED_MODULE_9__/* .media.tablet */ .BC.tablet`
    padding: 0 19%;
  `);
const TextContainer = styled_components__WEBPACK_IMPORTED_MODULE_12___default()(TitleContainer).withConfig({
  displayName: "ConfirmPayment__TextContainer",
  componentId: "sc-1lql97v-3"
})(["margin-bottom:0.875rem;"]);
const Form = styled_components__WEBPACK_IMPORTED_MODULE_12___default().form.withConfig({
  displayName: "ConfirmPayment__Form",
  componentId: "sc-1lql97v-4"
})(["width:100%;height:100%;display:flex;justify-content:space-between;align-items:flex-end;flex-direction:column;"]);
const FormGroup = styled_components__WEBPACK_IMPORTED_MODULE_12___default().div.withConfig({
  displayName: "ConfirmPayment__FormGroup",
  componentId: "sc-1lql97v-5"
})(["width:100%;display:flex;flex-direction:column;align-items:center;"]);
const StyledCardChipIcon = styled_components__WEBPACK_IMPORTED_MODULE_12___default()(CardChipIcon).withConfig({
  displayName: "ConfirmPayment__StyledCardChipIcon",
  componentId: "sc-1lql97v-6"
})(["width:1.5rem;height:1.125rem;& > *{fill:", ";}"], p => p.theme.colors.blue);

const ConfirmPayment = ({
  showConfirmationModal,
  setShowConfirmationModal,
  onConfirm,
  loading,
  setLoading
}) => {
  const methods = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_4__.useForm)({
    resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_1__.yupResolver)(schema),
    mode: "onBlur",
    reValidateMode: "onChange",
    defaultValues: {
      password: ""
    }
  });
  const {
    handleSubmit,
    setError
  } = methods;

  const onSubmit = async values => {
    try {
      setLoading(true);
      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_2___default().post(`/api/payment-token`, values);
      const {
        token
      } = data;
      (0,_utils_cookies__WEBPACK_IMPORTED_MODULE_10__/* .setCookies */ .lE)("inhabit_payment_token", token, {
        expires: (0,date_fns__WEBPACK_IMPORTED_MODULE_3__.addMinutes)(new Date(), 10)
      });
      await onConfirm();
      setShowConfirmationModal(false);
    } catch (error) {
      if (error.response && error.response.status === 401) {
        setError("password", {
          message: error.response.data.errors
        });
      } else {
        (0,_utils_logger__WEBPACK_IMPORTED_MODULE_11__/* .logError */ .H)(error);
      }

      setLoading(false);
    }
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_common_ConfirmationModal__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
    open: showConfirmationModal,
    onClose: () => setShowConfirmationModal(!showConfirmationModal),
    onConfirm: handleSubmit(onSubmit),
    cancelText: "Go back",
    confirmText: "Pay",
    confirmClose: true,
    title: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(TitleContainer, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(StyledCardChipIcon, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .ZP, {
        size: "modalTitle",
        color: "blue",
        children: "Enter password to pay"
      })]
    }),
    body: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(BodyContainer, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(TextContainer, {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .ZP, {
          size: "tiny",
          children: "Please enter your password process payment."
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_4__.FormProvider, _objectSpread(_objectSpread({}, methods), {}, {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(Form, {
          onSubmit: handleSubmit(onSubmit),
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(FormGroup, {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_form_PasswordInput__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
              width: "90%",
              name: "password",
              isRequired: true,
              type: "password",
              placeholder: "Enter password..."
            })
          })
        })
      }))]
    }),
    loading: loading
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ConfirmPayment);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 46384:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61908);
/* harmony import */ var _stripe_react_stripe_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(64515);
/* harmony import */ var _stripe_react_stripe_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_stripe_react_stripe_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var lodash_get__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1043);
/* harmony import */ var lodash_get__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(lodash_get__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(41664);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(45641);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(16666);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_responsive__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1187);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_button_Button__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(59067);
/* harmony import */ var _components_common_BankCard__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(45839);
/* harmony import */ var _components_common_BreadcrumbLink__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(37928);
/* harmony import */ var _components_common_FormToastContainer__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(41593);
/* harmony import */ var _components_common_LoadingLarge__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(49899);
/* harmony import */ var _components_common_Page__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(97598);
/* harmony import */ var _components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(60805);
/* harmony import */ var _components_common_Text__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(87491);
/* harmony import */ var _components_ContentContainer__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(16067);
/* harmony import */ var _components_form_CardSection__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(45131);
/* harmony import */ var _components_form_Input__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(18183);
/* harmony import */ var _components_offset_ConfirmPayment__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(23310);
/* harmony import */ var _components_offset_ProjectItem__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(21731);
/* harmony import */ var _contexts_auth__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(58368);
/* harmony import */ var _contexts_project__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(98605);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(72994);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(91073);
/* harmony import */ var _utils_cookies__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(1420);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(11098);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_29___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_29__);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(75609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_30___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_30__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__, react_hook_form__WEBPACK_IMPORTED_MODULE_7__, _components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_16__, _components_form_CardSection__WEBPACK_IMPORTED_MODULE_19__, _components_form_Input__WEBPACK_IMPORTED_MODULE_20__, _components_offset_ConfirmPayment__WEBPACK_IMPORTED_MODULE_21__]);
([_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__, react_hook_form__WEBPACK_IMPORTED_MODULE_7__, _components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_16__, _components_form_CardSection__WEBPACK_IMPORTED_MODULE_19__, _components_form_Input__WEBPACK_IMPORTED_MODULE_20__, _components_offset_ConfirmPayment__WEBPACK_IMPORTED_MODULE_21__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



































const CONTAINER_ID = "offset-payment";
const schema = yup__WEBPACK_IMPORTED_MODULE_30__.object().shape({
  offset_units: yup__WEBPACK_IMPORTED_MODULE_30__.number().required("Please enter amount to offset").min(1, "Please enter at least 1 offset").typeError("Please enter amount to offset")
});
const Container = styled_components__WEBPACK_IMPORTED_MODULE_29___default().div.withConfig({
  displayName: "payment__Container",
  componentId: "ytjam5-0"
})(["display:flex;flex-direction:column;p{", "}h3{", "}", ""], p => p.theme.body, p => p.theme.h3, _theme__WEBPACK_IMPORTED_MODULE_26__/* .media.tabletLarge */ .BC.tabletLarge`
    flex-direction: row;
    align-items: flex-start;

  `);
const ButtonContainer = styled_components__WEBPACK_IMPORTED_MODULE_29___default().div.withConfig({
  displayName: "payment__ButtonContainer",
  componentId: "ytjam5-1"
})(["margin-top:2rem;display:flex;justify-content:flex-end;width:100%;", " & > button:not(:first-of-type){margin-left:0.5rem;}", ""], _theme__WEBPACK_IMPORTED_MODULE_26__/* .media.tabletLarge */ .BC.tabletLarge`
    margin-top: 2rem;
  `, p => p.extended && `
    ${_theme__WEBPACK_IMPORTED_MODULE_26__/* .media.tabletLarge */ .BC.tabletLarge`
    margin-left: -40%;
    width: 147%;

    & > button {
        width: 8rem;
  }
  `}`);
const InnerContainer = styled_components__WEBPACK_IMPORTED_MODULE_29___default().div.withConfig({
  displayName: "payment__InnerContainer",
  componentId: "ytjam5-2"
})(["background:", ";", " height:auto;"], p => p.theme.colors.white, _styles__WEBPACK_IMPORTED_MODULE_25__/* .borderRadius */ .E);
const LeftContainer = styled_components__WEBPACK_IMPORTED_MODULE_29___default()(InnerContainer).withConfig({
  displayName: "payment__LeftContainer",
  componentId: "ytjam5-3"
})(["margin:0 0 3rem 0;", ""], _theme__WEBPACK_IMPORTED_MODULE_26__/* .media.tabletLarge */ .BC.tabletLarge`
    margin: 0 3rem 0 0;
  `);
const RightContainer = styled_components__WEBPACK_IMPORTED_MODULE_29___default()(InnerContainer).withConfig({
  displayName: "payment__RightContainer",
  componentId: "ytjam5-4"
})(["width:100%;max-width:36rem;"]);
const FormContainer = styled_components__WEBPACK_IMPORTED_MODULE_29___default().div.withConfig({
  displayName: "payment__FormContainer",
  componentId: "ytjam5-5"
})(["width:100%;height:100%;padding:3.25rem 1.5rem;display:flex;flex-direction:column;align-items:center;", " ", " ", ""], _theme__WEBPACK_IMPORTED_MODULE_26__/* .media.tablet */ .BC.tablet`
    flex-direction: row;
  `, _theme__WEBPACK_IMPORTED_MODULE_26__/* .media.tabletLarge */ .BC.tabletLarge`
   flex-direction: column;
  `, _theme__WEBPACK_IMPORTED_MODULE_26__/* .media.desktop */ .BC.desktop`
    flex-direction: row;
    align-items: stretch;
  `);
const InnerFormerContainer = styled_components__WEBPACK_IMPORTED_MODULE_29___default().div.withConfig({
  displayName: "payment__InnerFormerContainer",
  componentId: "ytjam5-6"
})(["width:100%;display:flex;flex-direction:column;align-items:center;&:first-of-type{margin-bottom:3rem;}", ""], _theme__WEBPACK_IMPORTED_MODULE_26__/* .media.tabletLarge */ .BC.tabletLarge`
    align-items: unset;

${p => p.last && `&:not(:first-of-type) {
    width: 57.5%;
    margin-left: 3rem;
    max-width: 240px;
  }`}
  
  
  `);
const Form = styled_components__WEBPACK_IMPORTED_MODULE_29___default().form.withConfig({
  displayName: "payment__Form",
  componentId: "ytjam5-7"
})(["width:100%;height:100%;display:flex;justify-content:space-between;align-items:flex-end;flex-direction:column;", ""], p => p.maxWidth && `
    ${_theme__WEBPACK_IMPORTED_MODULE_26__/* .media.tabletLarge */ .BC.tabletLarge`
      max-width: 240px;
   `}
   `);
const FormGroup = styled_components__WEBPACK_IMPORTED_MODULE_29___default().div.withConfig({
  displayName: "payment__FormGroup",
  componentId: "ytjam5-8"
})(["width:100%;display:flex;flex-direction:column;align-items:stretch;"]);
const TextContainer = styled_components__WEBPACK_IMPORTED_MODULE_29___default().div.withConfig({
  displayName: "payment__TextContainer",
  componentId: "ytjam5-9"
})(["display:flex;flex-direction:column;align-items:center;", " ", ""], p => p.border && "padding-bottom: 1.25rem; margin-bottom: 1.25rem; border-bottom: 1px solid #BBBBBB;", _theme__WEBPACK_IMPORTED_MODULE_26__/* .media.tabletLarge */ .BC.tabletLarge`
    align-items: flex-start;
   `);
const SideTextContainer = styled_components__WEBPACK_IMPORTED_MODULE_29___default().div.withConfig({
  displayName: "payment__SideTextContainer",
  componentId: "ytjam5-10"
})(["width:100%;"]);
const TonnesDropdownFormGroup = styled_components__WEBPACK_IMPORTED_MODULE_29___default()(FormGroup).withConfig({
  displayName: "payment__TonnesDropdownFormGroup",
  componentId: "ytjam5-11"
})(["display:flex;width:100%;align-items:center;flex-direction:row;& > ", ":first-of-type{width:70%;}& > ", ":last-of-type{width:30%;}"], SideTextContainer, SideTextContainer);
const UpdateButtonContainer = styled_components__WEBPACK_IMPORTED_MODULE_29___default().div.withConfig({
  displayName: "payment__UpdateButtonContainer",
  componentId: "ytjam5-12"
})(["display:flex;margin:0.5rem 0;width:12rem;justify-content:center;", ""], _theme__WEBPACK_IMPORTED_MODULE_26__/* .media.tabletLarge */ .BC.tabletLarge`
    justify-content: flex-end;
  `);

const OffsetPayment = () => {
  const {
    0: submitting,
    1: setSubmitting
  } = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(false);
  const {
    0: updateLoading,
    1: setUpdateLoading
  } = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(false);
  const {
    0: paid,
    1: setPaid
  } = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(false);
  const {
    0: tonnes,
    1: setTonnes
  } = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(1);
  const {
    0: polling,
    1: setPolling
  } = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(false);
  const {
    0: showConfirmationModal,
    1: setShowConfirmationModal
  } = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(false);
  const {
    0: updating,
    1: setUpdating
  } = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(false);
  const stripe = (0,_stripe_react_stripe_js__WEBPACK_IMPORTED_MODULE_1__.useStripe)();
  const elements = (0,_stripe_react_stripe_js__WEBPACK_IMPORTED_MODULE_1__.useElements)();
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)();
  const {
    user,
    organisation,
    setOrganisation
  } = (0,_contexts_auth__WEBPACK_IMPORTED_MODULE_23__/* ["default"] */ .Z)();
  const {
    selectedProject,
    getSelectedProject,
    loading,
    progress,
    setProgress,
    setSelectedProject,
    setLoading
  } = (0,_contexts_project__WEBPACK_IMPORTED_MODULE_24__/* ["default"] */ .Z)();
  const methods = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_7__.useForm)({
    resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__.yupResolver)(schema),
    mode: "onBlur",
    reValidateMode: "onChange",
    defaultValues: {
      offset_units: null
    }
  });
  const {
    handleSubmit
  } = methods;
  const last4 = lodash_get__WEBPACK_IMPORTED_MODULE_3___default()(organisation, "card.last4", null);
  const expiryDate = lodash_get__WEBPACK_IMPORTED_MODULE_3___default()(organisation, "card.expiry_date", null);
  const name = lodash_get__WEBPACK_IMPORTED_MODULE_3___default()(organisation, "name", null);
  const offset_units = methods.watch("offset_units");
  (0,react__WEBPACK_IMPORTED_MODULE_6__.useEffect)(() => {
    if (router.query.slug) {
      getSelectedProject();
    }

    return () => setSelectedProject(null);
  }, [router.query]);
  const isTabletLarge = (0,react_responsive__WEBPACK_IMPORTED_MODULE_8__.useMediaQuery)({
    query: `(min-width: ${_theme__WEBPACK_IMPORTED_MODULE_26__/* .sizes.tabletLarge */ .J7.tabletLarge}px)`
  });

  const handleSubmitCard = async event => {
    try {
      setUpdateLoading(true);
      event.preventDefault();

      if (!stripe || !elements) {
        return;
      }

      const {
        data: {
          client_secret,
          organisation
        }
      } = await axios__WEBPACK_IMPORTED_MODULE_2___default().post(`/api/organisations/${user.organisation_id}/subscriptions/setup-intent`);
      const cardElement = elements.getElement(_stripe_react_stripe_js__WEBPACK_IMPORTED_MODULE_1__.CardNumberElement);
      const {
        setupIntent,
        error
      } = await stripe.confirmCardSetup(client_secret, {
        payment_method: {
          card: cardElement
        }
      });

      if (error) {
        console.error(error);
        throw error;
      } else {
        const paymentMethodId = setupIntent.payment_method;
        const isSubscribed = organisation.stripe_account && organisation.stripe_account.subscription_id && organisation.subscription.status === "active";
        const {
          data: {
            organisation: subscribedOrganisation,
            paymentIntent
          }
        } = await axios__WEBPACK_IMPORTED_MODULE_2___default()({
          url: `/api/organisations/${user.organisation_id}/subscriptions`,
          method: isSubscribed ? "PATCH" : "POST",
          data: {
            paymentMethodId
          }
        });
        checkSubscription(paymentIntent, subscribedOrganisation, paymentMethodId);
      }
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_28__/* .logError */ .H)(error, CONTAINER_ID);
      setUpdateLoading(false);
    }
  };

  const handleSuccess = organisation => {
    setOrganisation(organisation);
    setUpdating(false);
    setUpdateLoading(false);
    react_toastify__WEBPACK_IMPORTED_MODULE_9__.toast.success("Payment details updated!", {
      containerId: CONTAINER_ID
    });
  };

  const checkSubscription = (paymentIntent, organisation, paymentMethod) => {
    if (organisation && organisation.subscription.status === "active") {
      handleSuccess(organisation);
    } else if (paymentIntent) {
      switch (paymentIntent.status) {
        case "succeeded":
          handleSuccess(organisation);
          break;

        case "requires_payment_method":
          (0,_utils_logger__WEBPACK_IMPORTED_MODULE_28__/* .logError */ .H)({
            message: lodash_get__WEBPACK_IMPORTED_MODULE_3___default()(paymentIntent, "last_payment_error.message", "Could no make the payment please check your card and try again")
          }, CONTAINER_ID);
          break;

        case "requires_action":
          authenticateCard(paymentIntent, paymentMethod);
          break;

        default:
          react_toastify__WEBPACK_IMPORTED_MODULE_9__.toast.info("Something seems to have gone wrong please get in contact with us");
          break;
      }
    }
  };

  const authenticateCard = async (paymentIntent, paymentMethod) => {
    const {
      paymentIntent: newPaymentIntent,
      error
    } = await stripe.confirmCardPayment(paymentIntent.client_secret, {
      payment_method: paymentMethod
    });
    const {
      data: organisation
    } = await axios__WEBPACK_IMPORTED_MODULE_2___default().get(`/api/organisations/${user.organisation_id}`);

    if (error) {
      throw error;
    } else {
      checkSubscription(newPaymentIntent, organisation, paymentMethod);
    }
  };

  const onSubmit = async values => {
    try {
      const token = (0,_utils_cookies__WEBPACK_IMPORTED_MODULE_27__/* .getCookie */ .ej)("inhabit_payment_token");

      if (!token) {
        setShowConfirmationModal(true);
        return;
      }

      setSubmitting(true);
      setShowConfirmationModal(false);
      setLoading(true);
      setTonnes(offset_units);
      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_2___default().post("/api/offset", _objectSpread(_objectSpread({}, values), {}, {
        project_id: selectedProject.id
      }), {
        onUploadProgress: progressEvent => {
          setProgress(Math.floor(progressEvent.loaded * 50 / progressEvent.total));
        }
      });
      const {
        error,
        paymentIntent
      } = await stripe.confirmCardPayment(data.client_secret);

      if (error) {
        throw error;
      } else {
        setPolling(true);
        let id = setInterval(pollForConfirmation, 3000);
        let totalProgress = 50;

        async function pollForConfirmation() {
          try {
            if (paid) {
              return;
            }

            setProgress(totalProgress + 10);
            const {
              data
            } = await axios__WEBPACK_IMPORTED_MODULE_2___default().get(`/api/payment-intent/${paymentIntent.id}`, {
              onDownloadProgress: progressEvent => {
                setProgress(Math.floor(totalProgress + progressEvent.loaded * 50 / progressEvent.total));
              }
            });

            if (data.success) {
              const {
                data
              } = await axios__WEBPACK_IMPORTED_MODULE_2___default().get(`/api/organisations/${organisation.id}`);
              setPaid(true);
              setPolling(false);
              setOrganisation(data);
              clearInterval(id);
              setSubmitting(false);
              setLoading(false);
              react_toastify__WEBPACK_IMPORTED_MODULE_9__.toast.success("Thank you for offsetting", {
                toastId: "offset-thanks",
                containerId: CONTAINER_ID
              });
            }
          } catch (error) {
            (0,_utils_logger__WEBPACK_IMPORTED_MODULE_28__/* .logError */ .H)(error, CONTAINER_ID);
            setPolling(false);
            setSubmitting(false);
            setLoading(false);
          }
        }
      }
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_28__/* .logError */ .H)(error, CONTAINER_ID);
      setLoading(false);
      setSubmitting(false);
      setPolling(false);
    }
  };

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsxs)(_components_common_Page__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .ZP, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsx(_components_offset_ConfirmPayment__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .Z, {
      showConfirmationModal: showConfirmationModal,
      setShowConfirmationModal: setShowConfirmationModal,
      onConfirm: handleSubmit(onSubmit),
      loading: submitting,
      setLoading: setSubmitting
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsxs)(_components_ContentContainer__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {
      title: paid ? "Success!" : "Offset payment",
      description: paid ? "Thank you, your payment was successful and your ozffset has been confirmed. Your carbon offset will be added to your dashboard. Please see details below." : "Simply choose the amount of carbon to offset and confirm. Funding environmental projects is an amazing way to make a positive contribution.",
      breadcrumb: selectedProject && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.Fragment, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsx(next_link__WEBPACK_IMPORTED_MODULE_4__["default"], {
          href: "/offset",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsx(_components_common_BreadcrumbLink__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .ZP, {
              size: "breadcrumb",
              align: "left",
              color: "placeholderGrey",
              children: "Offset"
            })
          })
        }), " ", ">", " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsx(next_link__WEBPACK_IMPORTED_MODULE_4__["default"], {
          href: "/offset/projects/[slug]",
          as: `/offset/projects/${selectedProject.slug}`,
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsxs)(_components_common_BreadcrumbLink__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .ZP, {
              size: "breadcrumb",
              align: "left",
              color: "placeholderGrey",
              children: selectedProject.title
            }), " "]
          })
        }), " ", " > ", " Payment"]
      }),
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsx(_components_common_FormToastContainer__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
        containerId: CONTAINER_ID,
        maxWidth: "82.5%"
      }), loading || !selectedProject ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsx(_components_common_LoadingLarge__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
        loading: loading,
        text: submitting ? "Payment in progress..." : "Getting Project...",
        progress: progress,
        setProgress: setProgress
      }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.Fragment, {
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsxs)(Container, {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsx(LeftContainer, {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsx(_components_offset_ProjectItem__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .Z, {
              project: selectedProject,
              rotate: true
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsx(RightContainer, {
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsxs)(FormContainer, {
              children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsxs)(InnerFormerContainer, {
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsx(_components_common_BankCard__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                  name,
                  last4,
                  expiryDate
                }), !updating && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsx(UpdateButtonContainer, {
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsx(_components_button_Button__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .ZP, {
                    small: true,
                    onClick: () => setUpdating(!updating),
                    children: "Update"
                  })
                })]
              }), updating ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsx(InnerFormerContainer, {
                flex: true,
                last: true,
                children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsxs)(Form, {
                  onSubmit: handleSubmitCard,
                  maxWidth: true,
                  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsx(_components_form_CardSection__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z, {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsxs)(ButtonContainer, {
                    extended: true,
                    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsxs)(_components_button_Button__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .ZP, {
                      secondary: true,
                      type: "button",
                      loading: updateLoading,
                      onClick: () => setUpdating(!updating),
                      minWidth: "8rem",
                      children: ["Discard ", isTabletLarge && "Changes"]
                    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsxs)(_components_button_Button__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .ZP, {
                      loading: updateLoading,
                      minWidth: "8rem",
                      children: ["Save ", isTabletLarge && "Changes"]
                    })]
                  })]
                })
              }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsx(InnerFormerContainer, {
                children: paid ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.Fragment, {
                  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsx(TextContainer, {
                    border: true,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsx("div", {
                      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .ZP, {
                        size: "cardTitle",
                        children: "Offset Details "
                      })
                    })
                  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsxs)(TonnesDropdownFormGroup, {
                    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsx(SideTextContainer, {
                      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .ZP, {
                        size: "smallBold",
                        children: "Carbon (tonnes):"
                      })
                    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsx(SideTextContainer, {
                      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .ZP, {
                        size: "smallBold",
                        children: tonnes
                      })
                    })]
                  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsxs)(TonnesDropdownFormGroup, {
                    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsx(SideTextContainer, {
                      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .ZP, {
                        size: "smallBold",
                        children: "Price:"
                      })
                    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsx(SideTextContainer, {
                      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsxs)(_components_common_Text__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .ZP, {
                        size: "smallBold",
                        children: ["\xA3", (selectedProject.price * parseInt(tonnes)).toFixed(2) || 0]
                      })
                    })]
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsx(ButtonContainer, {
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsx(_components_button_Button__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .ZP, {
                      href: "/offset",
                      children: "Back to Offset"
                    })
                  })]
                }) : polling ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsx(_components_common_LoadingLarge__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                  loading: loading || polling,
                  text: "Checking Offset...",
                  progress: progress,
                  setProgress: setProgress
                }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_7__.FormProvider, _objectSpread(_objectSpread({}, methods), {}, {
                  children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsxs)(Form, {
                    onSubmit: handleSubmit(onSubmit),
                    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsxs)(FormGroup, {
                      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsx(_components_form_Input__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {
                        name: "offset_units",
                        isRequired: true,
                        type: "number",
                        label: "Amount of carbon (tonnes)",
                        placeholder: "Enter amount..."
                      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsxs)(TextContainer, {
                        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsx("div", {
                          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .ZP, {
                            children: "Price: "
                          })
                        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsx("div", {
                          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsxs)(_components_common_Text__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .ZP, {
                            size: "h4",
                            children: ["\xA3", (parseFloat(selectedProject.price || 0) * parseInt(offset_units || 0)).toFixed(2)]
                          })
                        })]
                      })]
                    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsx(ButtonContainer, {
                      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_31__.jsx(_components_button_Button__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .ZP, {
                        fullWidth: true,
                        loading: submitting,
                        width: "100%",
                        children: "Pay"
                      })
                    })]
                  })
                }))
              })]
            })
          })]
        })
      })]
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z)(OffsetPayment, true));
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 88126:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "unstable_getStaticParams": () => (/* binding */ unstable_getStaticParams),
/* harmony export */   "unstable_getStaticProps": () => (/* binding */ unstable_getStaticProps),
/* harmony export */   "unstable_getStaticPaths": () => (/* binding */ unstable_getStaticPaths),
/* harmony export */   "unstable_getServerProps": () => (/* binding */ unstable_getServerProps),
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "_app": () => (/* binding */ _app),
/* harmony export */   "renderReqToHTML": () => (/* binding */ renderReqToHTML),
/* harmony export */   "render": () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(70607);
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59450);
/* harmony import */ var private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97020);
/* harmony import */ var private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(73978);
/* harmony import */ var next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99436);

      
      
      
      

      
      const { processEnv } = __webpack_require__(85360)
      processEnv([{"path":".env","contents":"API_HOST=https://api.inhabit.eco\nNEXT_PUBLIC_CALENDLY_URL=https://calendly.com/inhabit-meet/inhabit-measurement-tutorial\nNEXT_PUBLIC_FLAGS_ENVIRONMENT_KEY=flags_pub_289425705564897805\nNEXT_PUBLIC_GOOGLE_ANALYTICS=G-1CBB78XFQ4\nNEXT_PUBLIC_INTERCOM_APP_ID=bw9p6mfd\nNEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_bQDaTEuYc10x3BZt9YcGj2cE00Gzwm4gDD\nSTRIPE_PUBLISHABLE_KEY=pk_live_bQDaTEuYc10x3BZt9YcGj2cE00Gzwm4gDD\n\n"}])
    
      
      const runtimeConfig = {}
      ;

      const documentModule = __webpack_require__(9968)

      const appMod = __webpack_require__(13724)
      let App = appMod.default || appMod.then && appMod.then(mod => mod.default);

      const compMod = __webpack_require__(46384)

      const Component = compMod.default || compMod.then && compMod.then(mod => mod.default)
      /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Component);
      const getStaticProps = compMod['getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['getStaticProp' + 's'])
      const getStaticPaths = compMod['getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['getStaticPath' + 's'])
      const getServerSideProps = compMod['getServerSideProp' + 's'] || compMod.then && compMod.then(mod => mod['getServerSideProp' + 's'])

      // kept for detecting legacy exports
      const unstable_getStaticParams = compMod['unstable_getStaticParam' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticParam' + 's'])
      const unstable_getStaticProps = compMod['unstable_getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticProp' + 's'])
      const unstable_getStaticPaths = compMod['unstable_getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticPath' + 's'])
      const unstable_getServerProps = compMod['unstable_getServerProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getServerProp' + 's'])

      let config = compMod['confi' + 'g'] || (compMod.then && compMod.then(mod => mod['confi' + 'g'])) || {}
      const _app = App

      const combinedRewrites = Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)
        ? private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg
        : []

      if (!Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)) {
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.beforeFiles */ .Dg.beforeFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.afterFiles */ .Dg.afterFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.fallback */ .Dg.fallback)
      }

      const { renderReqToHTML, render } = (0,next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__/* .getPageHandler */ .u)({
        pageModule: compMod,
        pageComponent: Component,
        pageConfig: config,
        appModule: App,
        documentModule: documentModule,
        errorModule: __webpack_require__(99651),
        notFoundModule: undefined,
        pageGetStaticProps: getStaticProps,
        pageGetStaticPaths: getStaticPaths,
        pageGetServerSideProps: getServerSideProps,

        assetPrefix: "",
        canonicalBase: "",
        generateEtags: true,
        poweredByHeader: true,
        reactRoot: false,

        runtimeConfig,
        buildManifest: private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__,
        reactLoadableManifest: private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__,

        rewrites: combinedRewrites,
        i18n: undefined,
        page: "/offset/projects/[slug]/payment",
        buildId: "lDoX7RBEQ31kzKIJJbkVC",
        escapedBuildId: "lDoX7RBEQ31kzKIJJbkVC",
        basePath: "",
        pageIsDynamic: true,
        encodedPreviewProps: {previewModeId:"89cdc9f6073608262d43eab6d636f3f4",previewModeSigningKey:"74c7e36a2414a3f7b0ebcc67250f915f156686e1610b45a21ae9358d5b7c6c5a",previewModeEncryptionKey:"8a4c97ad9e5cf12d5a140689be08539ea52d8b27a416c2b8ae67db636b45841b"}
      })
      
    

/***/ }),

/***/ 94970:
/***/ ((module) => {

module.exports = require("@happykit/flags/client");

/***/ }),

/***/ 46411:
/***/ ((module) => {

module.exports = require("@happykit/flags/config");

/***/ }),

/***/ 48095:
/***/ ((module) => {

module.exports = require("@happykit/flags/server");

/***/ }),

/***/ 83218:
/***/ ((module) => {

module.exports = require("@hookform/error-message");

/***/ }),

/***/ 48308:
/***/ ((module) => {

module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ 85360:
/***/ ((module) => {

module.exports = require("@next/env");

/***/ }),

/***/ 64515:
/***/ ((module) => {

module.exports = require("@stripe/react-stripe-js");

/***/ }),

/***/ 20943:
/***/ ((module) => {

module.exports = require("@stripe/stripe-js");

/***/ }),

/***/ 52167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 74146:
/***/ ((module) => {

module.exports = require("date-fns");

/***/ }),

/***/ 1043:
/***/ ((module) => {

module.exports = require("lodash.get");

/***/ }),

/***/ 51650:
/***/ ((module) => {

module.exports = require("lodash.uniqby");

/***/ }),

/***/ 54426:
/***/ ((module) => {

module.exports = require("next/dist/compiled/chalk");

/***/ }),

/***/ 40252:
/***/ ((module) => {

module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 19371:
/***/ ((module) => {

module.exports = require("next/dist/compiled/node-fetch");

/***/ }),

/***/ 97999:
/***/ ((module) => {

module.exports = require("next/dist/compiled/path-to-regexp");

/***/ }),

/***/ 60600:
/***/ ((module) => {

module.exports = require("next/dist/server/accept-header.js");

/***/ }),

/***/ 52155:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils/index.js");

/***/ }),

/***/ 90730:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils/node.js");

/***/ }),

/***/ 60562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 94140:
/***/ ((module) => {

module.exports = require("next/dist/server/get-page-files.js");

/***/ }),

/***/ 89716:
/***/ ((module) => {

module.exports = require("next/dist/server/htmlescape.js");

/***/ }),

/***/ 25071:
/***/ ((module) => {

module.exports = require("next/dist/server/render-result.js");

/***/ }),

/***/ 33100:
/***/ ((module) => {

module.exports = require("next/dist/server/render.js");

/***/ }),

/***/ 92779:
/***/ ((module) => {

module.exports = require("next/dist/server/request-meta.js");

/***/ }),

/***/ 79502:
/***/ ((module) => {

module.exports = require("next/dist/server/send-payload.js");

/***/ }),

/***/ 76368:
/***/ ((module) => {

module.exports = require("next/dist/server/utils.js");

/***/ }),

/***/ 56724:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 27664:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/escape-regexp.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 94957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 82374:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-locale-cookie.js");

/***/ }),

/***/ 34014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 78524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 78020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 29565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 64365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 95714:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-route-from-asset-path.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 91292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 25753:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-match.js");

/***/ }),

/***/ 99521:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/prepare-destination.js");

/***/ }),

/***/ 80979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 36052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 84226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 95566:
/***/ ((module) => {

module.exports = require("next/error");

/***/ }),

/***/ 40968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 71853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 59819:
/***/ ((module) => {

module.exports = require("querystring");

/***/ }),

/***/ 16689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 25716:
/***/ ((module) => {

module.exports = require("react-hotjar");

/***/ }),

/***/ 16666:
/***/ ((module) => {

module.exports = require("react-responsive");

/***/ }),

/***/ 1187:
/***/ ((module) => {

module.exports = require("react-toastify");

/***/ }),

/***/ 20997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 57518:
/***/ ((module) => {

module.exports = require("styled-components");

/***/ }),

/***/ 24535:
/***/ ((module) => {

module.exports = require("styled-normalize");

/***/ }),

/***/ 6153:
/***/ ((module) => {

module.exports = require("universal-cookie");

/***/ }),

/***/ 84269:
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ 75609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 61908:
/***/ ((module) => {

module.exports = import("@hookform/resolvers/yup");;

/***/ }),

/***/ 45641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [4357,9703,6114,9067,8183,9899,805,6067,1593,661,7898,1731], () => (__webpack_exec__(88126)));
module.exports = __webpack_exports__;

})();