"use strict";
(() => {
var exports = {};
exports.id = 6434;
exports.ids = [6434];
exports.modules = {

/***/ 24214:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61908);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(45641);
/* harmony import */ var _button_Button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(59067);
/* harmony import */ var _common_Divider__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6459);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(87491);
/* harmony import */ var _BusinessTravel__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(31558);
/* harmony import */ var _BusinessTravel_BusinessTravelView__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(12105);
/* harmony import */ var _common_DataInputContainer__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(64493);
/* harmony import */ var _DataCollectionSchema__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(37960);
/* harmony import */ var _Details__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5024);
/* harmony import */ var _Details_DetailsView__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(45332);
/* harmony import */ var _EmployeeCommutes__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(6137);
/* harmony import */ var _EmployeeCommutes_EmployeeCommutesView__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(31982);
/* harmony import */ var _Utilities__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(42088);
/* harmony import */ var _Utilities_UtilitiesView__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(6778);
/* harmony import */ var _utils_parseFormData__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(29645);
/* harmony import */ var _form_Form__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(89781);
/* harmony import */ var _contexts_auth__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(58368);
/* harmony import */ var _contexts_measurements__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(85238);
/* harmony import */ var _hooks_usePrevious__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(9258);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(11098);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var _DeleteOfficeModal__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(87399);
/* harmony import */ var _Details_DetailsEdit__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(65043);
/* harmony import */ var _Homeworking_HomeworkingView__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(84259);
/* harmony import */ var _Utilities_UtilitiesEdit__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(52069);
/* harmony import */ var _VehicleUsage__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(59663);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__, react_hook_form__WEBPACK_IMPORTED_MODULE_3__, _BusinessTravel__WEBPACK_IMPORTED_MODULE_7__, _Details__WEBPACK_IMPORTED_MODULE_11__, _EmployeeCommutes__WEBPACK_IMPORTED_MODULE_13__, _Utilities__WEBPACK_IMPORTED_MODULE_15__, _Details_DetailsEdit__WEBPACK_IMPORTED_MODULE_24__, _Utilities_UtilitiesEdit__WEBPACK_IMPORTED_MODULE_26__, _VehicleUsage__WEBPACK_IMPORTED_MODULE_27__]);
([_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__, react_hook_form__WEBPACK_IMPORTED_MODULE_3__, _BusinessTravel__WEBPACK_IMPORTED_MODULE_7__, _Details__WEBPACK_IMPORTED_MODULE_11__, _EmployeeCommutes__WEBPACK_IMPORTED_MODULE_13__, _Utilities__WEBPACK_IMPORTED_MODULE_15__, _Details_DetailsEdit__WEBPACK_IMPORTED_MODULE_24__, _Utilities_UtilitiesEdit__WEBPACK_IMPORTED_MODULE_26__, _VehicleUsage__WEBPACK_IMPORTED_MODULE_27__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


































const createColor = ({
  color,
  size,
  theme
}) => theme.colors[color] || size && theme[size].color || theme.colors.transparent;

const MeasurementsSection = styled_components__WEBPACK_IMPORTED_MODULE_22___default().div.withConfig({
  displayName: "DataCollectionForm__MeasurementsSection",
  componentId: "cz8v98-0"
})(["display:flex;flex-direction:column;width:100%;"]);
const TotalFootprint = styled_components__WEBPACK_IMPORTED_MODULE_22___default()(_common_Text__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .ZP).withConfig({
  displayName: "DataCollectionForm__TotalFootprint",
  componentId: "cz8v98-1"
})([""]);
const BottomCTAs = styled_components__WEBPACK_IMPORTED_MODULE_22___default().div.withConfig({
  displayName: "DataCollectionForm__BottomCTAs",
  componentId: "cz8v98-2"
})(["display:flex;width:100%;justify-content:space-between;align-items:center;"]);
const ViewBottomCTAs = styled_components__WEBPACK_IMPORTED_MODULE_22___default()(BottomCTAs).withConfig({
  displayName: "DataCollectionForm__ViewBottomCTAs",
  componentId: "cz8v98-3"
})(["display:flex;width:100%;justify-content:space-between;align-items:center;background-color:", ";padding:1.25rem;border-radius:4px;"], createColor);
const PulseImage = styled_components__WEBPACK_IMPORTED_MODULE_22___default().img.withConfig({
  displayName: "DataCollectionForm__PulseImage",
  componentId: "cz8v98-4"
})(["width:1.5rem;margin-right:0.875rem;"]);
const TexContainer = styled_components__WEBPACK_IMPORTED_MODULE_22___default().div.withConfig({
  displayName: "DataCollectionForm__TexContainer",
  componentId: "cz8v98-5"
})(["display:flex;align-items:center;"]);

const DataCollectionForm = ({
  onDeleteOffice,
  countries,
  office,
  activeOfficeForm,
  setActiveOfficeForm,
  isActive,
  isLastOffice
}) => {
  var _office$details, _office$details2, _office$details3, _office$measurement_r, _office$measurement_r2, _office$details4, _office$details5, _office$details6, _office$details7;

  const {
    organisation
  } = (0,_contexts_auth__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z)();
  const {
    0: showDeleteConfirmationModal,
    1: setShowDeleteConfirmationModal
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
  const {
    0: isEditing,
    1: setIsEditing
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(null);
  const previousOfficeId = (0,_hooks_usePrevious__WEBPACK_IMPORTED_MODULE_20__/* .usePrevious */ .D)(office.id);
  const {
    dataCollectionMeasurement,
    setDataCollectionMeasurement
  } = (0,_contexts_measurements__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z)();

  const formDefaultValues = _objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread({}, (0,_Details_DetailsEdit__WEBPACK_IMPORTED_MODULE_24__/* .createDetailsDefaultValues */ .J)({
    office,
    countries
  })), (0,_Utilities_UtilitiesEdit__WEBPACK_IMPORTED_MODULE_26__/* .createWasteAndUtilitiesDefaultValues */ .D)(office)), (0,_EmployeeCommutes__WEBPACK_IMPORTED_MODULE_13__/* .createEmployeeCommutesDefaultValues */ .s)(office)), (0,_BusinessTravel__WEBPACK_IMPORTED_MODULE_7__/* .createBusinessTravelDefaultValues */ .a)(office)), (0,_VehicleUsage__WEBPACK_IMPORTED_MODULE_27__/* .createVehicleUsageDefaultValues */ .wr)(office));

  const methods = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_3__.useForm)({
    defaultValues: formDefaultValues,
    resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__.yupResolver)(_DataCollectionSchema__WEBPACK_IMPORTED_MODULE_10__/* .schema */ .f),
    context: {
      fullyRemote: office === null || office === void 0 ? void 0 : (_office$details = office.details) === null || _office$details === void 0 ? void 0 : _office$details.fully_remote
    }
  });
  const {
    handleSubmit,
    formState: {
      isSubmitting,
      errors
    }
  } = methods;

  const handleMeasurementsSubmit = async values => {
    const parsedValues = (0,_utils_parseFormData__WEBPACK_IMPORTED_MODULE_29__/* ["default"] */ .Z)(values);

    try {
      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_1___default().patch(`/api/organisations/${organisation.id}/data-collection/measurements/${dataCollectionMeasurement.id}/office/${office.office_id}`, _objectSpread({}, parsedValues));

      const newDataCollectionMeasurement = _objectSpread(_objectSpread({}, dataCollectionMeasurement), data);

      setDataCollectionMeasurement(newDataCollectionMeasurement);
      setIsEditing(null);
      window.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_21__/* .logError */ .H)(error);
    }
  };

  const resetForm = (name = null) => {
    methods.reset(formDefaultValues);
    setIsEditing(name);
  };

  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(() => {
    if (previousOfficeId && previousOfficeId !== office.id) {
      resetForm();
    }
  }, [office]);
  return isActive ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxs)(MeasurementsSection, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_DeleteOfficeModal__WEBPACK_IMPORTED_MODULE_23__/* ["default"] */ .Z, {
      showConfirmationModal: showDeleteConfirmationModal,
      setShowConfirmationModal: setShowDeleteConfirmationModal,
      onConfirm: async () => {
        activeOfficeForm > 0 && setActiveOfficeForm(activeOfficeForm - 1);
        await onDeleteOffice();
      },
      officeName: (office === null || office === void 0 ? void 0 : (_office$details2 = office.details) === null || _office$details2 === void 0 ? void 0 : _office$details2.name) || `Office ${activeOfficeForm + 1}`
    }), office.measurement_result && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_common_DataInputContainer__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxs)(TotalFootprint, {
        size: "sectionTitle",
        align: "left",
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxs)(_common_Text__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .ZP, {
          size: "subtitleBold",
          children: ["Monthly emissions for ", (_office$details3 = office.details) === null || _office$details3 === void 0 ? void 0 : _office$details3.name, ":", " "]
        }), Number((_office$measurement_r = office.measurement_result) === null || _office$measurement_r === void 0 ? void 0 : (_office$measurement_r2 = _office$measurement_r.total) === null || _office$measurement_r2 === void 0 ? void 0 : _office$measurement_r2.toFixed(2)).toLocaleString(), " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .ZP, {
          size: "meta",
          children: "kgCO2e"
        })]
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_form_Form__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
      onSubmit: handleSubmit(handleMeasurementsSubmit),
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_3__.FormProvider, _objectSpread(_objectSpread({}, methods), {}, {
        children: !office.measurement_result ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.Fragment, {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_Details__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
            fullyRemote: office === null || office === void 0 ? void 0 : (_office$details4 = office.details) === null || _office$details4 === void 0 ? void 0 : _office$details4.fully_remote,
            countries: countries,
            isEditing: isEditing === "details",
            isSubmitting: isSubmitting
          }), !office.details.fully_remote && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.Fragment, {
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_Utilities__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
              isEditing: isEditing === "utilities",
              isSubmitting: isSubmitting
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_EmployeeCommutes__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
              isEditing: isEditing === "employeeCommutes",
              isSubmitting: isSubmitting
            })]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_BusinessTravel__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
            office,
            isEditing: isEditing === "businessTravel",
            isSubmitting: isSubmitting
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_VehicleUsage__WEBPACK_IMPORTED_MODULE_27__/* .VehicleUsageEdit */ .$5, {
            office,
            isEditing: isEditing === "vehicleUsage",
            isSubmitting: isSubmitting,
            reset: resetForm
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_common_Divider__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
            margin: "20px 0"
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxs)(BottomCTAs, {
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP, {
              type: "button",
              secondary: true,
              warning: true,
              disabled: isLastOffice,
              loading: false,
              onClick: async () => setShowDeleteConfirmationModal(!showDeleteConfirmationModal),
              children: "Remove office"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP, {
              type: "submit",
              loading: isSubmitting,
              children: "Submit"
            })]
          })]
        }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.Fragment, {
          children: [isEditing === "details" ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_Details__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
            fullyRemote: office === null || office === void 0 ? void 0 : (_office$details5 = office.details) === null || _office$details5 === void 0 ? void 0 : _office$details5.fully_remote,
            countries: countries,
            isEditing: isEditing === "details",
            isSubmitting: isSubmitting,
            reset: resetForm
          }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_Details_DetailsView__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
            result: office.measurement_result,
            fullyRemote: office === null || office === void 0 ? void 0 : (_office$details6 = office.details) === null || _office$details6 === void 0 ? void 0 : _office$details6.fully_remote,
            countries: countries,
            details: office.details,
            isEditing: isEditing === "details",
            reset: resetForm
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_Homeworking_HomeworkingView__WEBPACK_IMPORTED_MODULE_25__/* ["default"] */ .Z, {
            result: office.measurement_result,
            fullyRemote: office === null || office === void 0 ? void 0 : (_office$details7 = office.details) === null || _office$details7 === void 0 ? void 0 : _office$details7.fully_remote,
            countries: countries,
            details: office.details,
            isEditing: isEditing === "details",
            reset: resetForm
          }), !office.details.fully_remote ? isEditing === "utilities" ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_Utilities__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
            isEditing: isEditing === "utilities",
            isSubmitting: isSubmitting,
            reset: resetForm
          }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_Utilities_UtilitiesView__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
            result: office.measurement_result,
            utilities: office.utilities,
            waste: office.waste,
            isEditing: isEditing === "utilities",
            reset: resetForm
          }) : null, !office.details.fully_remote ? isEditing === "employeeCommutes" ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_EmployeeCommutes__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
            isEditing: isEditing === "employeeCommutes",
            isSubmitting: isSubmitting,
            reset: resetForm
          }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_EmployeeCommutes_EmployeeCommutesView__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
            result: office.measurement_result,
            employeeCommutes: office.employee_commutes,
            isEditing: isEditing === "employeeCommutes",
            reset: resetForm
          }) : null, isEditing === "businessTravel" ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_BusinessTravel__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
            office,
            isEditing: isEditing === "businessTravel",
            isSubmitting: isSubmitting,
            reset: resetForm
          }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_BusinessTravel_BusinessTravelView__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
            businessTravel: office.business_travel,
            isEditing: isEditing === "businessTravel",
            reset: resetForm,
            result: office.measurement_result
          }), isEditing === "vehicleUsage" ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_VehicleUsage__WEBPACK_IMPORTED_MODULE_27__/* .VehicleUsageEdit */ .$5, {
            office,
            isEditing: isEditing === "vehicleUsage",
            isSubmitting: isSubmitting,
            reset: resetForm
          }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_VehicleUsage__WEBPACK_IMPORTED_MODULE_27__/* .VehicleUsageView */ .qx, {
            vehicleUsage: office.vehicle_usage,
            isEditing: isEditing === "vehicleUsage",
            reset: resetForm,
            result: office.measurement_result
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxs)(ViewBottomCTAs, {
            color: "paleGreen",
            children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxs)(TexContainer, {
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(PulseImage, {
                src: "/images/pulser-live-green.gif"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .ZP, {
                children: "Your impact data is live."
              })]
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP, {
              href: "/",
              children: "Visualise"
            })]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_common_Divider__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
            margin: "20px 0"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(BottomCTAs, {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP, {
              type: "button",
              secondary: true,
              warning: true,
              disabled: isLastOffice,
              loading: false,
              onClick: async () => setShowDeleteConfirmationModal(!showDeleteConfirmationModal),
              children: "Remove office"
            })
          })]
        })
      }))
    })]
  }) : null;
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DataCollectionForm);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 37960:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "f": () => (/* binding */ schema)
/* harmony export */ });
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(75609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_0__);


function emptyStringToNull(value, originalValue) {
  if (typeof originalValue === "string" && originalValue === "") {
    return null;
  }

  return value;
}

const schema = yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
  details: yup__WEBPACK_IMPORTED_MODULE_0__.object().when("$fullyRemote", {
    is: true,
    then: yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
      name: yup__WEBPACK_IMPORTED_MODULE_0__.string().required("Office name is required"),
      country: yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
        label: yup__WEBPACK_IMPORTED_MODULE_0__.string(),
        value: yup__WEBPACK_IMPORTED_MODULE_0__.string()
      }).required("Country is required").typeError("Please select a country"),
      number_of_staff: yup__WEBPACK_IMPORTED_MODULE_0__.number().required("Number of staff is required").min(1, "There must be a minimum staff of 1").typeError("Please enter number of staff")
    }),
    otherwise: yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
      name: yup__WEBPACK_IMPORTED_MODULE_0__.string().required("Office name is required"),
      size: yup__WEBPACK_IMPORTED_MODULE_0__.number().required("Office size is required").min(1, "There must be a minimum office size of 1").typeError("Please enter office size"),
      country: yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
        label: yup__WEBPACK_IMPORTED_MODULE_0__.string(),
        value: yup__WEBPACK_IMPORTED_MODULE_0__.string()
      }).required("Country is required").typeError("Please select a country"),
      unit: yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
        label: yup__WEBPACK_IMPORTED_MODULE_0__.string(),
        value: yup__WEBPACK_IMPORTED_MODULE_0__.string()
      }).required("Unit is required").nullable(),
      number_of_staff: yup__WEBPACK_IMPORTED_MODULE_0__.number().required("Number of staff is required").min(1, "There must be a minimum staff of 1").typeError("Please enter number of staff"),
      staff_working_from_home_percentage: yup__WEBPACK_IMPORTED_MODULE_0__.string()
    })
  }),
  utilities: yup__WEBPACK_IMPORTED_MODULE_0__.array().of(yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
    known: yup__WEBPACK_IMPORTED_MODULE_0__.string().required(),
    value: yup__WEBPACK_IMPORTED_MODULE_0__.number().when("known", {
      is: "yes",
      then: yup__WEBPACK_IMPORTED_MODULE_0__.number().required("Please enter a value").typeError("Please enter a value")
    }).transform(emptyStringToNull).nullable(true),
    unit: yup__WEBPACK_IMPORTED_MODULE_0__.object().when("known", {
      is: "yes",
      then: yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
        label: yup__WEBPACK_IMPORTED_MODULE_0__.string(),
        value: yup__WEBPACK_IMPORTED_MODULE_0__.string().required()
      })
    }).nullable()
  })),
  waste: yup__WEBPACK_IMPORTED_MODULE_0__.array().of(yup__WEBPACK_IMPORTED_MODULE_0__.lazy((item, options) => {
    var _options$parent, _options$parent$;

    if (options.index > 0 && ((_options$parent = options.parent) === null || _options$parent === void 0 ? void 0 : (_options$parent$ = _options$parent[0]) === null || _options$parent$ === void 0 ? void 0 : _options$parent$.known) === "yes") {
      return yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
        value: yup__WEBPACK_IMPORTED_MODULE_0__.number().required("Please enter a value").typeError("Please enter a value"),
        unit: yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
          label: yup__WEBPACK_IMPORTED_MODULE_0__.string(),
          value: yup__WEBPACK_IMPORTED_MODULE_0__.string().required()
        })
      });
    } else {
      return yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
        known: yup__WEBPACK_IMPORTED_MODULE_0__.string().when("type", {
          is: "landfill",
          then: yup__WEBPACK_IMPORTED_MODULE_0__.string().required()
        }),
        value: yup__WEBPACK_IMPORTED_MODULE_0__.number().when("known", {
          is: "yes",
          then: yup__WEBPACK_IMPORTED_MODULE_0__.number().required("Please enter a value").typeError("Please enter a value")
        }).transform(emptyStringToNull).nullable(),
        unit: yup__WEBPACK_IMPORTED_MODULE_0__.object().when("known", {
          is: "yes",
          then: yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
            label: yup__WEBPACK_IMPORTED_MODULE_0__.string(),
            value: yup__WEBPACK_IMPORTED_MODULE_0__.string().required()
          })
        }).nullable()
      });
    }
  })),
  employee_commutes: yup__WEBPACK_IMPORTED_MODULE_0__.lazy(value => {
    if ((value === null || value === void 0 ? void 0 : value.length) > 1) {
      return yup__WEBPACK_IMPORTED_MODULE_0__.array().of(yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
        name: yup__WEBPACK_IMPORTED_MODULE_0__.string().required("Please enter a name"),
        unit: yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
          label: yup__WEBPACK_IMPORTED_MODULE_0__.string(),
          value: yup__WEBPACK_IMPORTED_MODULE_0__.string().required("Please select a unit of measurement")
        }),
        value: yup__WEBPACK_IMPORTED_MODULE_0__.number().required("Distance is required").min(0.1, "There must be a minimum 1 passenger per trip").typeError("Please enter the distance of the commute one way"),
        mode: yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
          label: yup__WEBPACK_IMPORTED_MODULE_0__.string(),
          value: yup__WEBPACK_IMPORTED_MODULE_0__.string().required()
        }).required("Mode is required").typeError("Please enter the mode of transport")
      }));
    }

    return yup__WEBPACK_IMPORTED_MODULE_0__.array().of(yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
      name: yup__WEBPACK_IMPORTED_MODULE_0__.string().nullable(),
      unit: yup__WEBPACK_IMPORTED_MODULE_0__.object().when("name", {
        is: val => !!val,
        then: yup__WEBPACK_IMPORTED_MODULE_0__.object().required()
      }).shape({
        label: yup__WEBPACK_IMPORTED_MODULE_0__.string(),
        value: yup__WEBPACK_IMPORTED_MODULE_0__.string().required("Please select a unit of measurement")
      }).nullable(),
      value: yup__WEBPACK_IMPORTED_MODULE_0__.number().when("name", {
        is: val => !!val,
        then: yup__WEBPACK_IMPORTED_MODULE_0__.number().required("Distance is required")
      }).min(0.1, "Please enter the distance of the commute one way").typeError("Please enter the distance of the commute one way").nullable(),
      mode: yup__WEBPACK_IMPORTED_MODULE_0__.object().when("value", {
        is: val => !!val,
        then: yup__WEBPACK_IMPORTED_MODULE_0__.object().required("Mode of transport is required")
      }).shape({
        label: yup__WEBPACK_IMPORTED_MODULE_0__.string(),
        value: yup__WEBPACK_IMPORTED_MODULE_0__.string().required()
      }).typeError("Please enter the mode of transport").nullable()
    }));
  }),
  business_travel: yup__WEBPACK_IMPORTED_MODULE_0__.lazy(value => {
    if ((value === null || value === void 0 ? void 0 : value.length) > 1) {
      return yup__WEBPACK_IMPORTED_MODULE_0__.array().of(yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
        from: yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
          label: yup__WEBPACK_IMPORTED_MODULE_0__.string(),
          value: yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
            name: yup__WEBPACK_IMPORTED_MODULE_0__.string().required("Departure city is required"),
            place_id: yup__WEBPACK_IMPORTED_MODULE_0__.string().required("Departure city is required")
          })
        }).required("Departure city is required").typeError("Please enter the departure city").nullable(),
        to: yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
          label: yup__WEBPACK_IMPORTED_MODULE_0__.string(),
          value: yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
            name: yup__WEBPACK_IMPORTED_MODULE_0__.string().required("Destination city is required"),
            place_id: yup__WEBPACK_IMPORTED_MODULE_0__.string().required("Destination city is required")
          })
        }).required("Destination city is required").typeError("Please enter the destination city").nullable(),
        passengers: yup__WEBPACK_IMPORTED_MODULE_0__.number().required("Number of passengers is required").min(1, "There must be a minimum 1 passenger per trip").typeError("Please enter the number of passengers").nullable(),
        mode: yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
          label: yup__WEBPACK_IMPORTED_MODULE_0__.string(),
          value: yup__WEBPACK_IMPORTED_MODULE_0__.string().required()
        }).required("Mode is required").typeError("Please enter the mode of transport").nullable()
      }));
    }

    return yup__WEBPACK_IMPORTED_MODULE_0__.array().of(yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
      from: yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
        label: yup__WEBPACK_IMPORTED_MODULE_0__.string(),
        value: yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
          name: yup__WEBPACK_IMPORTED_MODULE_0__.string(),
          place_id: yup__WEBPACK_IMPORTED_MODULE_0__.string()
        })
      }).nullable().typeError("Please enter the departure city"),
      to: yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
        label: yup__WEBPACK_IMPORTED_MODULE_0__.string(),
        value: yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
          name: yup__WEBPACK_IMPORTED_MODULE_0__.string(),
          place_id: yup__WEBPACK_IMPORTED_MODULE_0__.string()
        })
      }).when("from", {
        is: val => !!val,
        then: yup__WEBPACK_IMPORTED_MODULE_0__.object().required()
      }).typeError("Please enter the destination city").nullable(),
      mode: yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
        label: yup__WEBPACK_IMPORTED_MODULE_0__.string(),
        value: yup__WEBPACK_IMPORTED_MODULE_0__.string()
      }).when("to", {
        is: val => !!val,
        then: yup__WEBPACK_IMPORTED_MODULE_0__.object().required()
      }).typeError("Please enter the mode of transport").nullable(),
      passengers: yup__WEBPACK_IMPORTED_MODULE_0__.number().min(1, "There must be a minimum 1 passenger per trip").when("mode", {
        is: val => !!val,
        then: yup__WEBPACK_IMPORTED_MODULE_0__.number().required()
      }).typeError("Please enter the number of passengers").nullable()
    }));
  }),
  vehicle_usage: yup__WEBPACK_IMPORTED_MODULE_0__.lazy(value => {
    if ((value === null || value === void 0 ? void 0 : value.length) > 1) {
      return yup__WEBPACK_IMPORTED_MODULE_0__.array().of(yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
        registration_number: yup__WEBPACK_IMPORTED_MODULE_0__.string().required("Please enter the vehicle's registration number"),
        unit: yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
          label: yup__WEBPACK_IMPORTED_MODULE_0__.string(),
          value: yup__WEBPACK_IMPORTED_MODULE_0__.string().required("Please select a unit of mileage")
        }),
        value: yup__WEBPACK_IMPORTED_MODULE_0__.number().required("Distance is required").min(0.1, "There must be a minimum 1 passenger per trip").typeError("Please enter the distance of the commute one way"),
        mode: yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
          label: yup__WEBPACK_IMPORTED_MODULE_0__.string(),
          value: yup__WEBPACK_IMPORTED_MODULE_0__.string().required()
        }).required("Mode is required").typeError("Please enter the mode of transport")
      }));
    }

    return yup__WEBPACK_IMPORTED_MODULE_0__.array().of(yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
      registration_number: yup__WEBPACK_IMPORTED_MODULE_0__.string().nullable(),
      unit: yup__WEBPACK_IMPORTED_MODULE_0__.object().when("registration_number", {
        is: val => !!val,
        then: yup__WEBPACK_IMPORTED_MODULE_0__.object().required()
      }).shape({
        label: yup__WEBPACK_IMPORTED_MODULE_0__.string(),
        value: yup__WEBPACK_IMPORTED_MODULE_0__.string().required("Please select a unit of mileage")
      }).nullable(),
      value: yup__WEBPACK_IMPORTED_MODULE_0__.number().when("registration_number", {
        is: val => !!val,
        then: yup__WEBPACK_IMPORTED_MODULE_0__.number().required("Distance is required")
      }).min(0.1, "Please enter the monthly mileage of the vehicle").typeError("Please enter the monthly mileage of the vehicle type").nullable(),
      mode: yup__WEBPACK_IMPORTED_MODULE_0__.object().when("value", {
        is: val => !!val,
        then: yup__WEBPACK_IMPORTED_MODULE_0__.object().required("Please select the type of vehicle")
      }).shape({
        label: yup__WEBPACK_IMPORTED_MODULE_0__.string(),
        value: yup__WEBPACK_IMPORTED_MODULE_0__.string().required()
      }).typeError("Please select the type of vehicle").nullable()
    }));
  })
});

/***/ }),

/***/ 87399:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _common_ConfirmationModal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65487);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(87491);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





var Bin = function Bin(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("g", {
      clipPath: "url(#clip0)",
      fill: "#EC5F59",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("path", {
        d: "M11.768 25c-2.014 0-4.028.003-6.041 0-.49 0-.98-.006-1.467-.049-.847-.073-1.573-.835-1.622-1.719-.126-2.313-.235-4.626-.343-6.94-.16-3.384-.314-6.769-.463-10.154-.017-.38-.173-.516-.522-.489a2.16 2.16 0 0 1-.282 0C.413 5.621-.013 5.213 0 4.667c.013-.561.496-.976 1.115-.971 1.712.012 3.424.021 5.136.027 1.275 0 1.274-.005 1.486-1.298.052-.322.092-.647.176-.96.11-.42.355-.792.696-1.057.341-.264.758-.406 1.187-.403 1.335.007 2.67.026 4.007.04 1.085.01 1.81.64 1.988 1.726.083.51.174 1.019.241 1.53.04.312.18.393.49.393 2.031-.004 4.063.013 6.093.033.615.007.99.375 1 .933.008.583-.375.958-1.01.989-.786.037-.772.041-.81.872-.215 4.512-.434 9.024-.657 13.536-.048 1.032-.083 2.067-.136 3.099-.052 1.007-.8 1.796-1.778 1.804-2.484.02-4.969.007-7.453.007l-.004.033zm.063-1.96c2.163 0 4.326-.022 6.49.016.574.01.772-.193.788-.737.025-.841.087-1.682.125-2.523.202-4.474.401-8.95.598-13.424.033-.73.03-.73-.727-.724-2.389.017-4.776.046-7.164.046-2.538 0-5.077-.018-7.615-.054-.452-.006-.567.127-.545.592.22 4.512.405 9.026.628 13.538.04.823.067 1.645.105 2.467.037.769.084.804.827.804h6.49zm.093-19.338v.008c.377 0 .754.022 1.13-.004 1.061-.074 1.043-.08.887-1.179-.063-.435-.252-.576-.67-.566-.976.023-1.954.005-2.932.008-.22 0-.508-.052-.563.246-.086.46-.273.922-.13 1.4.034.113.194.09.307.089.657-.004 1.314-.003 1.971-.003v.001z"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("path", {
        d: "M8.69 18.497c0 .268.003.536 0 .803-.012.631-.339 1.023-.878 1.059-.553.037-.954-.295-1.014-.916a63.554 63.554 0 0 1-.186-2.86 598.873 598.873 0 0 1-.258-6.133c-.028-.742.278-1.15.84-1.2.6-.055.983.3 1.062 1.056.08.756.118 1.523.154 2.289.093 1.967.174 3.935.26 5.902h.02zM17.265 11.124c-.12 2.598-.242 5.195-.363 7.792-.013.19-.037.38-.072.569-.096.577-.47.9-1 .873-.537-.027-.898-.42-.883-1.046.032-1.357.085-2.715.145-4.07.06-1.337.135-2.673.21-4.008.021-.382.04-.765.096-1.142.087-.57.489-.884 1.022-.844.495.04.835.412.857.959.011.305 0 .612 0 .918h-.012zM10.868 14.807c0-1.51-.01-3.019.005-4.528.007-.665.379-1.043.95-1.034.571.009.932.396.935 1.057.01 2.062.004 4.125.008 6.188 0 .898.005 1.796.02 2.693.013.697-.357 1.165-.95 1.175-.604.012-.97-.419-.97-1.137v-4.414h.002z"
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("defs", {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("clipPath", {
        id: "clip0",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("path", {
          fill: "#fff",
          d: "M0 0h23.611v25H0z"
        })
      })
    })]
  }));
};

Bin.defaultProps = {
  width: "24",
  height: "25",
  viewBox: "0 0 24 25",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var NotifyIcon = function NotifyIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("path", {
      d: "M10.01 0C15.453-.04 20.053 4.48 20 10.09c-.052 5.348-4.374 9.902-10 9.902-5.648 0-10.05-4.6-10-10.087C.052 4.307 4.655-.043 10.01.001zm0 2.022c-4.322-.01-7.804 3.425-7.974 7.637-.183 4.51 3.372 8.232 7.82 8.303 4.559.075 8.005-3.571 8.116-7.756.114-4.396-3.417-8.183-7.964-8.184h.002z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("path", {
      d: "M11.014 8.49v2.6c0 .594-.451 1.06-1.013 1.053-.574-.009-1.018-.464-1.018-1.055-.002-1.74-.002-3.48 0-5.219 0-.58.446-1.035 1.01-1.04.573-.005 1.021.45 1.022 1.042v2.62zM11.015 14.074c.013.424-.167.747-.532.954-.342.195-.689.17-1.026-.033-.39-.235-.577-.785-.437-1.28a1.018 1.018 0 0 1 .996-.745c.476.012.858.324.977.794.026.104.018.206.022.31z"
    })]
  }));
};

NotifyIcon.defaultProps = {
  width: "20",
  height: "20",
  viewBox: "0 0 20 20",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};




const TitleContainer = styled_components__WEBPACK_IMPORTED_MODULE_5___default().div.withConfig({
  displayName: "DeleteOfficeModal__TitleContainer",
  componentId: "sc-1mh4uhj-0"
})(["display:flex;flex-direction:column;align-items:center;justify-content:center;"]);
const BodyContainer = styled_components__WEBPACK_IMPORTED_MODULE_5___default()(TitleContainer).withConfig({
  displayName: "DeleteOfficeModal__BodyContainer",
  componentId: "sc-1mh4uhj-1"
})(["padding:0 1rem;", ""], _theme__WEBPACK_IMPORTED_MODULE_4__/* .media.tablet */ .BC.tablet`
  padding: 0 1.875rem;
`);
const NoUtilityBillsContainer = styled_components__WEBPACK_IMPORTED_MODULE_5___default().div.withConfig({
  displayName: "DeleteOfficeModal__NoUtilityBillsContainer",
  componentId: "sc-1mh4uhj-2"
})(["background:", ";border-radius:4px;padding:0.5rem 1rem;display:flex;justify-content:flex-start;align-items:center;margin-top:0.5rem;& > svg{fill:", ";margin-right:0.25rem;}"], p => p.theme.colors.backgroundYellow, p => p.theme.colors.black);

const DeleteOfficeModal = ({
  showConfirmationModal,
  setShowConfirmationModal,
  onConfirm,
  loading,
  officeName
}) => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_common_ConfirmationModal__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
    open: showConfirmationModal,
    onClose: () => setShowConfirmationModal(!showConfirmationModal),
    onConfirm: onConfirm,
    cancelText: "Go back",
    confirmText: "Remove",
    maxWidth: "32.5rem",
    title: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(TitleContainer, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(Bin, {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(_common_Text__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
        size: "modalTitle",
        color: "error",
        children: ["Remove ", officeName]
      })]
    }),
    body: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(BodyContainer, {
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(NoUtilityBillsContainer, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(NotifyIcon, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
          size: "alert",
          align: "left",
          children: "This deletes all progress on this office and is irreversible."
        })]
      })
    }),
    loading: loading,
    warning: true
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DeleteOfficeModal);

/***/ }),

/***/ 40726:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61908);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(45641);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(16666);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_responsive__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _button_Button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(59067);
/* harmony import */ var _common_InputDropdown__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(31217);
/* harmony import */ var _common_LoadingLarge__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(49899);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(87491);
/* harmony import */ var _common_DataInputContainer__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(64493);
/* harmony import */ var _form_Form__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(89781);
/* harmony import */ var _form_InputDropdown__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(51894);
/* harmony import */ var _contexts_auth__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(58368);
/* harmony import */ var _contexts_measurements__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(85238);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(91073);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(11098);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(75609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _contexts_config__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(33742);
/* harmony import */ var _DataCollectionForm__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(24214);
/* harmony import */ var _SidebarOffices__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(1079);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_21__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__, react_hook_form__WEBPACK_IMPORTED_MODULE_3__, _form_InputDropdown__WEBPACK_IMPORTED_MODULE_11__, _DataCollectionForm__WEBPACK_IMPORTED_MODULE_19__]);
([_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__, react_hook_form__WEBPACK_IMPORTED_MODULE_3__, _form_InputDropdown__WEBPACK_IMPORTED_MODULE_11__, _DataCollectionForm__WEBPACK_IMPORTED_MODULE_19__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

























const createColor = ({
  color,
  size,
  theme
}) => theme.colors[color] || size && theme[size].color || theme.colors.transparent;

const schema = yup__WEBPACK_IMPORTED_MODULE_17__.object().shape({
  number_of_offices: yup__WEBPACK_IMPORTED_MODULE_17__.object().shape({
    label: yup__WEBPACK_IMPORTED_MODULE_17__.string(),
    value: yup__WEBPACK_IMPORTED_MODULE_17__.number()
  }).required("Please select number of offices").typeError("Please select number of offices")
});
const FormGroup = styled_components__WEBPACK_IMPORTED_MODULE_16___default().div.withConfig({
  displayName: "OperationalData__FormGroup",
  componentId: "kwzkpy-0"
})(["display:flex;flex-direction:row;margin-top:20px;& > div{margin-bottom:0px;&:not(:last-child){margin-right:20px;}& > div > div[class$=\"control\"]{margin-bottom:0;}}"]);
const MainContainer = styled_components__WEBPACK_IMPORTED_MODULE_16___default().div.withConfig({
  displayName: "OperationalData__MainContainer",
  componentId: "kwzkpy-1"
})(["display:flex;flex-direction:column;", ""], _theme__WEBPACK_IMPORTED_MODULE_14__/* .media.tablet */ .BC.tablet`
    flex-direction: row;
  `);
const numberOfOffices = [{
  label: "Fully Remote",
  value: 0
}, ...Array.from({
  length: 9
}, (_, i) => ({
  label: i + 1,
  value: i + 1
})), {
  label: "10+",
  value: 10
}];

const OperationalData = ({
  countries
}) => {
  var _dataCollectionMeasur, _dataCollectionMeasur2, _dataCollectionMeasur3;

  const {
    organisation
  } = (0,_contexts_auth__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z)();
  const {
    dataCollectionMeasurement,
    setDataCollectionMeasurement
  } = (0,_contexts_measurements__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z)();
  const {
    pageContainer
  } = (0,_contexts_config__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z)();
  const {
    0: activeOfficeForm,
    1: setActiveOfficeForm
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(0);
  const {
    0: deleteLoading,
    1: setDeleteLoading
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
  const {
    0: resetLoading,
    1: setResetLoading
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
  const methods = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_3__.useForm)({
    defaultValues: {
      number_of_offices: null
    },
    resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__.yupResolver)(schema)
  });
  const isTablet = (0,react_responsive__WEBPACK_IMPORTED_MODULE_4__.useMediaQuery)({
    query: `(min-width: ${_theme__WEBPACK_IMPORTED_MODULE_14__/* .sizes.tablet */ .J7.tablet}px)`
  });
  const {
    handleSubmit,
    formState: {
      isSubmitting
    }
  } = methods;

  const onOfficesSubmit = async ({
    number_of_offices
  }) => {
    try {
      const officesNumber = number_of_offices.value;

      if (dataCollectionMeasurement) {
        const {
          data
        } = await axios__WEBPACK_IMPORTED_MODULE_1___default().post(`/api/organisations/${organisation.id}/data-collection/measurements/${dataCollectionMeasurement.id}/office`, {
          number_of_offices: Number(officesNumber)
        });
        setDataCollectionMeasurement(data);
      } else {
        const {
          data
        } = await axios__WEBPACK_IMPORTED_MODULE_1___default().post(`/api/organisations/${organisation.id}/data-collection`, {
          number_of_offices: Number(officesNumber)
        });
        setDataCollectionMeasurement(data);
      }
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_15__/* .logError */ .H)(error);
    }
  };

  const handleDeleteOffice = async () => {
    try {
      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_1___default()["delete"](`/api/organisations/${organisation.id}/data-collection/measurements/${dataCollectionMeasurement.id}/office/${dataCollectionMeasurement.office_measurements[activeOfficeForm].office_id}`);
      setDataCollectionMeasurement(_objectSpread(_objectSpread({}, dataCollectionMeasurement), data));
    } catch (error) {
      setDeleteLoading(false);
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_15__/* .logError */ .H)(error);
    }
  };

  const handleResetForm = async () => {
    try {
      setResetLoading(true);
      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_1___default()["delete"](`/api/organisations/${organisation.id}/data-collection/measurements/${dataCollectionMeasurement.id}/office`, {
        data: {
          office_ids: dataCollectionMeasurement === null || dataCollectionMeasurement === void 0 ? void 0 : dataCollectionMeasurement.office_measurements.map(office_measurement => office_measurement.office_id)
        }
      });
      setDataCollectionMeasurement(_objectSpread(_objectSpread({}, dataCollectionMeasurement), data));
      setActiveOfficeForm(0);
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_15__/* .logError */ .H)(error);
    }

    setResetLoading(false);
  };

  const isActiveOffice = index => activeOfficeForm === index;

  const optionArray = dataCollectionMeasurement === null || dataCollectionMeasurement === void 0 ? void 0 : (_dataCollectionMeasur = dataCollectionMeasurement.office_measurements) === null || _dataCollectionMeasur === void 0 ? void 0 : _dataCollectionMeasur.map((office, index) => {
    var _office$details;

    return {
      label: ((_office$details = office.details) === null || _office$details === void 0 ? void 0 : _office$details.name) || `Office ${index + 1}`,
      value: index
    };
  });
  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(() => {
    var _pageContainer$curren;

    pageContainer && (pageContainer === null || pageContainer === void 0 ? void 0 : (_pageContainer$curren = pageContainer.current) === null || _pageContainer$curren === void 0 ? void 0 : _pageContainer$curren.scrollTo({
      top: 0,
      behavior: "smooth"
    }));
  }, [activeOfficeForm]);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_21__.jsxs)("div", {
    children: [resetLoading && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_21__.jsx(_common_LoadingLarge__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
      loading: resetLoading
    }), (!dataCollectionMeasurement || (dataCollectionMeasurement === null || dataCollectionMeasurement === void 0 ? void 0 : (_dataCollectionMeasur2 = dataCollectionMeasurement.office_measurements) === null || _dataCollectionMeasur2 === void 0 ? void 0 : _dataCollectionMeasur2.length) < 1) && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_21__.jsxs)(_common_DataInputContainer__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
      width: "50%",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_21__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .ZP, {
        children: "How many offices do you have?"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_21__.jsx(_form_Form__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
        onSubmit: handleSubmit(onOfficesSubmit),
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_21__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_3__.FormProvider, _objectSpread(_objectSpread({}, methods), {}, {
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_21__.jsxs)(FormGroup, {
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_21__.jsx(_form_InputDropdown__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
              id: "number_of_offices",
              placeholder: "Please select...",
              width: "160px",
              hasDefaultValue: false,
              optionArray: numberOfOffices
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_21__.jsx("div", {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_21__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP, {
                type: "submit",
                loading: isSubmitting,
                children: "Start measuring"
              })
            })]
          })
        }))
      })]
    }), dataCollectionMeasurement && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_21__.jsxs)(MainContainer, {
      children: [dataCollectionMeasurement && !!(dataCollectionMeasurement !== null && dataCollectionMeasurement !== void 0 && (_dataCollectionMeasur3 = dataCollectionMeasurement.office_measurements) !== null && _dataCollectionMeasur3 !== void 0 && _dataCollectionMeasur3.length) && (isTablet ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_21__.jsx(_SidebarOffices__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {
        dataCollectionMeasurement,
        activeOfficeForm,
        setActiveOfficeForm,
        isActiveOffice,
        handleResetForm,
        countries
      }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_21__.jsx(_common_InputDropdown__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
        optionArray: optionArray,
        defaultValue: optionArray.find(({
          value
        }) => value === activeOfficeForm) || (optionArray === null || optionArray === void 0 ? void 0 : optionArray[0]),
        onChange: ({
          value
        }) => setActiveOfficeForm(value),
        width: "100%",
        controlMargin: "0 0 1rem 0"
      })), dataCollectionMeasurement && (dataCollectionMeasurement === null || dataCollectionMeasurement === void 0 ? void 0 : dataCollectionMeasurement.office_measurements.map((office, index) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_21__.jsx(_DataCollectionForm__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z, {
        isLastOffice: (dataCollectionMeasurement === null || dataCollectionMeasurement === void 0 ? void 0 : dataCollectionMeasurement.office_measurements.length) <= 1,
        onDeleteOffice: handleDeleteOffice,
        isActive: isActiveOffice(index),
        index,
        isActiveOffice,
        office,
        countries,
        dataCollectionMeasurement,
        activeOfficeForm,
        setActiveOfficeForm
      }, office.id)))]
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (OperationalData);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1079:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _button_Button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(59067);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(87491);
/* harmony import */ var _contexts_auth__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(58368);
/* harmony import */ var _contexts_measurements__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(85238);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(11098);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _ResetFormModal__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(62488);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }









var CircleTickIcon = function CircleTickIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("circle", {
      cx: "12",
      cy: "12",
      r: "11",
      stroke: "#71E69E",
      strokeWidth: "2"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("path", {
      d: "M18.497 7.335c.02.203-.073.372-.198.53L16.532 10.1l-4.764 6.023c-.356.451-.71.904-1.065 1.357-.316.404-.97.41-1.288.009l-3.208-4.062c-.198-.253-.276-.529-.136-.834a.857.857 0 0 1 .763-.529c.262-.018.478.101.64.304.834 1.052 1.667 2.106 2.498 3.16.081.102.082.102.164 0l6.67-8.431c.075-.097.15-.195.228-.29.216-.262.49-.361.824-.28.307.072.672.415.64.807z",
      fill: "#71E69E"
    })]
  }));
};

CircleTickIcon.defaultProps = {
  width: "24",
  height: "24",
  viewBox: "0 0 24 24",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var TabEmptyIcon = function TabEmptyIcon(props) {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("circle", {
      cx: "12",
      cy: "12",
      r: "11",
      stroke: "#BBB",
      strokeWidth: "2"
    })
  }));
};

TabEmptyIcon.defaultProps = {
  width: "24",
  height: "24",
  viewBox: "0 0 24 24",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};





const StyledIcon = styled_components__WEBPACK_IMPORTED_MODULE_8___default()(TabEmptyIcon).withConfig({
  displayName: "SidebarOffices__StyledIcon",
  componentId: "z4clm2-0"
})(["min-height:24px;min-width:24px;margin-right:12px;"]);
const StyledCircleTick = styled_components__WEBPACK_IMPORTED_MODULE_8___default()(CircleTickIcon).withConfig({
  displayName: "SidebarOffices__StyledCircleTick",
  componentId: "z4clm2-1"
})(["min-height:24px;min-width:24px;margin-right:12px;"]);
const SidebarOffices = styled_components__WEBPACK_IMPORTED_MODULE_8___default().div.withConfig({
  displayName: "SidebarOffices",
  componentId: "z4clm2-2"
})(["min-width:265px;max-width:12rem;margin-right:20px;border-right:1px solid ", ";position:relative;"], p => p.theme.colors.secondaryBlue);
const Office = styled_components__WEBPACK_IMPORTED_MODULE_8___default().div.withConfig({
  displayName: "SidebarOffices__Office",
  componentId: "z4clm2-3"
})(["display:flex;flex-direction:row;align-items:flex-start;padding:14px 20px;margin-right:-1px;cursor:pointer;border-right:", ";border-bottom:1px solid ", ";"], p => p.isActive ? `2px solid ${p.theme.colors.blue}` : `1px solid ${p.theme.colors.secondaryBlue}`, p => p.theme.colors.secondaryBlue);
const TextContainer = styled_components__WEBPACK_IMPORTED_MODULE_8___default().div.withConfig({
  displayName: "SidebarOffices__TextContainer",
  componentId: "z4clm2-4"
})(["display:flex;flex-direction:column;& > span:not(:last-child){margin-bottom:0.5rem;}"]);
const ButtonContainer = styled_components__WEBPACK_IMPORTED_MODULE_8___default().div.withConfig({
  displayName: "SidebarOffices__ButtonContainer",
  componentId: "z4clm2-5"
})(["display:flex;width:100%;margin-top:22px;justify-content:center;"]);
const ClearButtonContainer = styled_components__WEBPACK_IMPORTED_MODULE_8___default().div.withConfig({
  displayName: "SidebarOffices__ClearButtonContainer",
  componentId: "z4clm2-6"
})(["position:absolute;bottom:0;left:50%;transform:translate(-50%,0%);"]);

const OfficesSidebar = ({
  isActiveOffice,
  setActiveOfficeForm,
  handleResetForm,
  countries
}) => {
  var _dataCollectionMeasur, _dataCollectionMeasur2;

  const {
    organisation
  } = (0,_contexts_auth__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)();
  const {
    0: showResetConfirmationModal,
    1: setShowResetConfirmationModal
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    dataCollectionMeasurement,
    setDataCollectionMeasurement
  } = (0,_contexts_measurements__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)();

  const handleAddOffice = async () => {
    try {
      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_1___default().post(`/api/organisations/${organisation.id}/data-collection/measurements/${dataCollectionMeasurement.id}/office`);
      setDataCollectionMeasurement(_objectSpread(_objectSpread({}, dataCollectionMeasurement), data));
      setActiveOfficeForm(dataCollectionMeasurement.office_measurements.length);
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_7__/* .logError */ .H)(error);
    }
  };

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(SidebarOffices, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_ResetFormModal__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
      showConfirmationModal: showResetConfirmationModal,
      setShowConfirmationModal: setShowResetConfirmationModal,
      onConfirm: handleResetForm
    }), dataCollectionMeasurement.office_measurements.map((office, index) => {
      var _office$details, _countries$find;

      return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(Office, {
        isActive: isActiveOffice(index),
        onClick: () => setActiveOfficeForm(index),
        children: [!!office.measurement_result ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(StyledCircleTick, {}) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(StyledIcon, {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(TextContainer, {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP, {
            align: "left",
            color: isActiveOffice(index) ? "blue" : "black",
            size: "alert",
            children: ((_office$details = office.details) === null || _office$details === void 0 ? void 0 : _office$details.name) || `Office ${index + 1}`
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP, {
            align: "left",
            color: isActiveOffice(index) ? "blue" : "placeholderGrey",
            size: "meta",
            children: (_countries$find = countries.find(countryObj => {
              var _office$details2;

              return countryObj.value === ((_office$details2 = office.details) === null || _office$details2 === void 0 ? void 0 : _office$details2.country);
            })) === null || _countries$find === void 0 ? void 0 : _countries$find.name
          })]
        })]
      }, index);
    }), !((_dataCollectionMeasur = dataCollectionMeasurement.office_measurements[0]) !== null && _dataCollectionMeasur !== void 0 && (_dataCollectionMeasur2 = _dataCollectionMeasur.details) !== null && _dataCollectionMeasur2 !== void 0 && _dataCollectionMeasur2.fully_remote) && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(ButtonContainer, {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
        type: "button",
        secondary: true,
        loading: false,
        onClick: handleAddOffice,
        children: "Add office"
      })
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(ClearButtonContainer, {
      children: [" ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
        type: "button",
        warning: true,
        secondary: true,
        loading: false,
        onClick: () => setShowResetConfirmationModal(!showResetConfirmationModal),
        children: "Clear and restart"
      })]
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (OfficesSidebar);

/***/ }),

/***/ 90585:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_common_LoadingLarge__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(49899);
/* harmony import */ var _components_common_Page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97598);
/* harmony import */ var _components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(60805);
/* harmony import */ var _components_common_Tab__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(46675);
/* harmony import */ var _components_common_Tabs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5021);
/* harmony import */ var _components_common_Text__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(87491);
/* harmony import */ var _components_ContentContainer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(16067);
/* harmony import */ var _components_data_collection_OperationalData__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(40726);
/* harmony import */ var _contexts_config__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(33742);
/* harmony import */ var _contexts_measurements__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(85238);
/* harmony import */ var _hooks_useWarnOnBeforeUnload__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(65220);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _components_measurement_utils_charts__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(19343);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_3__, _components_data_collection_OperationalData__WEBPACK_IMPORTED_MODULE_8__]);
([_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_3__, _components_data_collection_OperationalData__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }















var CircleTickIcon = function CircleTickIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx("circle", {
      cx: "12",
      cy: "12",
      r: "11",
      stroke: "#71E69E",
      strokeWidth: "2"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx("path", {
      d: "M18.497 7.335c.02.203-.073.372-.198.53L16.532 10.1l-4.764 6.023c-.356.451-.71.904-1.065 1.357-.316.404-.97.41-1.288.009l-3.208-4.062c-.198-.253-.276-.529-.136-.834a.857.857 0 0 1 .763-.529c.262-.018.478.101.64.304.834 1.052 1.667 2.106 2.498 3.16.081.102.082.102.164 0l6.67-8.431c.075-.097.15-.195.228-.29.216-.262.49-.361.824-.28.307.072.672.415.64.807z",
      fill: "#71E69E"
    })]
  }));
};

CircleTickIcon.defaultProps = {
  width: "24",
  height: "24",
  viewBox: "0 0 24 24",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var TabEmptyIcon = function TabEmptyIcon(props) {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx("circle", {
      cx: "12",
      cy: "12",
      r: "11",
      stroke: "#BBB",
      strokeWidth: "2"
    })
  }));
};

TabEmptyIcon.defaultProps = {
  width: "24",
  height: "24",
  viewBox: "0 0 24 24",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};





const StyledCircleTick = styled_components__WEBPACK_IMPORTED_MODULE_13___default()(CircleTickIcon).withConfig({
  displayName: "data-input__StyledCircleTick",
  componentId: "sc-1t4di3x-0"
})(["margin-left:12px;"]);
const StyledIcon = styled_components__WEBPACK_IMPORTED_MODULE_13___default()(TabEmptyIcon).withConfig({
  displayName: "data-input__StyledIcon",
  componentId: "sc-1t4di3x-1"
})(["margin-left:12px;"]);
const SupplyChainContainer = styled_components__WEBPACK_IMPORTED_MODULE_13___default().div.withConfig({
  displayName: "data-input__SupplyChainContainer",
  componentId: "sc-1t4di3x-2"
})(["display:flex;flex-direction:column;justify-content:center;align-items:center;"]);
const Image = styled_components__WEBPACK_IMPORTED_MODULE_13___default().img.withConfig({
  displayName: "data-input__Image",
  componentId: "sc-1t4di3x-3"
})(["width:220px;height:220px;margin:60px 0;"]);
const TotalContainer = styled_components__WEBPACK_IMPORTED_MODULE_13___default().div.withConfig({
  displayName: "data-input__TotalContainer",
  componentId: "sc-1t4di3x-4"
})(["border-top:1px solid ", ";padding:8px 0;align-items:center;justify-content:center;display:flex;"], p => p.theme.colors.secondaryBlue);
const TextContainer = styled_components__WEBPACK_IMPORTED_MODULE_13___default().div.withConfig({
  displayName: "data-input__TextContainer",
  componentId: "sc-1t4di3x-5"
})(["margin-bottom:1rem;"]);
const ButtonContainer = styled_components__WEBPACK_IMPORTED_MODULE_13___default().div.withConfig({
  displayName: "data-input__ButtonContainer",
  componentId: "sc-1t4di3x-6"
})(["margin-top:2rem;"]);

const DataCollection = () => {
  var _dataCollectionMeasur, _dataCollectionMeasur2, _createTotalMeasureme, _dataCollectionMeasur3;

  const {
    countries,
    countriesLoading
  } = (0,_contexts_config__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)();
  (0,_hooks_useWarnOnBeforeUnload__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z)();
  const {
    getDataCollectionMeasurement,
    dataCollectionMeasurement,
    loading
  } = (0,_contexts_measurements__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)();
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    getDataCollectionMeasurement();
  }, []);
  const officesComplete = !!(dataCollectionMeasurement !== null && dataCollectionMeasurement !== void 0 && (_dataCollectionMeasur = dataCollectionMeasurement.office_measurements) !== null && _dataCollectionMeasur !== void 0 && _dataCollectionMeasur.length) && (dataCollectionMeasurement === null || dataCollectionMeasurement === void 0 ? void 0 : (_dataCollectionMeasur2 = dataCollectionMeasurement.office_measurements) === null || _dataCollectionMeasur2 === void 0 ? void 0 : _dataCollectionMeasur2.every(office => !!office.measurement_result));

  const convertkgCO2eTotCO2e = kgCO2e => kgCO2e ? kgCO2e / 1000 : 0;

  const operationalTotal = convertkgCO2eTotCO2e((_createTotalMeasureme = (0,_components_measurement_utils_charts__WEBPACK_IMPORTED_MODULE_14__/* .createTotalMeasurementResults */ .d)(dataCollectionMeasurement)) === null || _createTotalMeasureme === void 0 ? void 0 : _createTotalMeasureme.total);
  const totalCarbonFootprint = parseFloat(operationalTotal);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_common_Page__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_components_ContentContainer__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
      title: "Data Input",
      description: "Add in your operational data and connect your accounting system for a comprehensive analysis of your emissions.",
      cta: (dataCollectionMeasurement === null || dataCollectionMeasurement === void 0 ? void 0 : (_dataCollectionMeasur3 = dataCollectionMeasurement.office_measurements) === null || _dataCollectionMeasur3 === void 0 ? void 0 : _dataCollectionMeasur3.filter(office => !!office.measurement_result).length) && "Visualise",
      href: "/",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_common_LoadingLarge__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        loading: loading || countriesLoading
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(TotalContainer, {
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_components_common_Text__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .ZP, {
          size: "subtitle",
          children: ["Total monthly emissions:", " ", !Number.isNaN(totalCarbonFootprint) ? totalCarbonFootprint === null || totalCarbonFootprint === void 0 ? void 0 : totalCarbonFootprint.toFixed(2) : 0, /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .ZP, {
            size: "meta",
            inherit: true,
            children: " tCO2e"
          })]
        })
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_components_common_Tabs__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_common_Tab__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
          label: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.Fragment, {
            children: ["Operational:", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_components_common_Text__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .ZP, {
              inherit: true,
              margin: "0 0 0 0.15rem",
              children: [" ", ` ${!Number.isNaN(operationalTotal) ? operationalTotal === null || operationalTotal === void 0 ? void 0 : operationalTotal.toFixed(2) : 0} `, " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .ZP, {
                size: "meta",
                inherit: true,
                children: "tCO2e"
              })]
            }), officesComplete ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(StyledCircleTick, {}) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(StyledIcon, {})]
          }),
          id: "operational",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_data_collection_OperationalData__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
            countries: countries
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_common_Tab__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
          label: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.Fragment, {
            children: ["Supply chain ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(StyledIcon, {}), " "]
          }),
          id: "supply-chain",
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(SupplyChainContainer, {
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(Image, {
              src: "/images/supply-chain-coming-soon.png"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .ZP, {
              size: "subtitle",
              children: "Supply chain integration coming soon!"
            })]
          })
        })]
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)(DataCollection));
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 78010:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "unstable_getStaticParams": () => (/* binding */ unstable_getStaticParams),
/* harmony export */   "unstable_getStaticProps": () => (/* binding */ unstable_getStaticProps),
/* harmony export */   "unstable_getStaticPaths": () => (/* binding */ unstable_getStaticPaths),
/* harmony export */   "unstable_getServerProps": () => (/* binding */ unstable_getServerProps),
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "_app": () => (/* binding */ _app),
/* harmony export */   "renderReqToHTML": () => (/* binding */ renderReqToHTML),
/* harmony export */   "render": () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(70607);
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59450);
/* harmony import */ var private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97020);
/* harmony import */ var private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(73978);
/* harmony import */ var next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99436);

      
      
      
      

      
      const { processEnv } = __webpack_require__(85360)
      processEnv([{"path":".env","contents":"API_HOST=https://api.inhabit.eco\nNEXT_PUBLIC_CALENDLY_URL=https://calendly.com/inhabit-meet/inhabit-measurement-tutorial\nNEXT_PUBLIC_FLAGS_ENVIRONMENT_KEY=flags_pub_289425705564897805\nNEXT_PUBLIC_GOOGLE_ANALYTICS=G-1CBB78XFQ4\nNEXT_PUBLIC_INTERCOM_APP_ID=bw9p6mfd\nNEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_bQDaTEuYc10x3BZt9YcGj2cE00Gzwm4gDD\nSTRIPE_PUBLISHABLE_KEY=pk_live_bQDaTEuYc10x3BZt9YcGj2cE00Gzwm4gDD\n\n"}])
    
      
      const runtimeConfig = {}
      ;

      const documentModule = __webpack_require__(9968)

      const appMod = __webpack_require__(13724)
      let App = appMod.default || appMod.then && appMod.then(mod => mod.default);

      const compMod = __webpack_require__(90585)

      const Component = compMod.default || compMod.then && compMod.then(mod => mod.default)
      /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Component);
      const getStaticProps = compMod['getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['getStaticProp' + 's'])
      const getStaticPaths = compMod['getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['getStaticPath' + 's'])
      const getServerSideProps = compMod['getServerSideProp' + 's'] || compMod.then && compMod.then(mod => mod['getServerSideProp' + 's'])

      // kept for detecting legacy exports
      const unstable_getStaticParams = compMod['unstable_getStaticParam' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticParam' + 's'])
      const unstable_getStaticProps = compMod['unstable_getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticProp' + 's'])
      const unstable_getStaticPaths = compMod['unstable_getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticPath' + 's'])
      const unstable_getServerProps = compMod['unstable_getServerProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getServerProp' + 's'])

      let config = compMod['confi' + 'g'] || (compMod.then && compMod.then(mod => mod['confi' + 'g'])) || {}
      const _app = App

      const combinedRewrites = Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)
        ? private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg
        : []

      if (!Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)) {
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.beforeFiles */ .Dg.beforeFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.afterFiles */ .Dg.afterFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.fallback */ .Dg.fallback)
      }

      const { renderReqToHTML, render } = (0,next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__/* .getPageHandler */ .u)({
        pageModule: compMod,
        pageComponent: Component,
        pageConfig: config,
        appModule: App,
        documentModule: documentModule,
        errorModule: __webpack_require__(99651),
        notFoundModule: undefined,
        pageGetStaticProps: getStaticProps,
        pageGetStaticPaths: getStaticPaths,
        pageGetServerSideProps: getServerSideProps,

        assetPrefix: "",
        canonicalBase: "",
        generateEtags: true,
        poweredByHeader: true,
        reactRoot: false,

        runtimeConfig,
        buildManifest: private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__,
        reactLoadableManifest: private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__,

        rewrites: combinedRewrites,
        i18n: undefined,
        page: "/data-input",
        buildId: "lDoX7RBEQ31kzKIJJbkVC",
        escapedBuildId: "lDoX7RBEQ31kzKIJJbkVC",
        basePath: "",
        pageIsDynamic: false,
        encodedPreviewProps: {previewModeId:"89cdc9f6073608262d43eab6d636f3f4",previewModeSigningKey:"74c7e36a2414a3f7b0ebcc67250f915f156686e1610b45a21ae9358d5b7c6c5a",previewModeEncryptionKey:"8a4c97ad9e5cf12d5a140689be08539ea52d8b27a416c2b8ae67db636b45841b"}
      })
      
    

/***/ }),

/***/ 94970:
/***/ ((module) => {

module.exports = require("@happykit/flags/client");

/***/ }),

/***/ 46411:
/***/ ((module) => {

module.exports = require("@happykit/flags/config");

/***/ }),

/***/ 48095:
/***/ ((module) => {

module.exports = require("@happykit/flags/server");

/***/ }),

/***/ 83218:
/***/ ((module) => {

module.exports = require("@hookform/error-message");

/***/ }),

/***/ 8130:
/***/ ((module) => {

module.exports = require("@material-ui/core");

/***/ }),

/***/ 55562:
/***/ ((module) => {

module.exports = require("@material-ui/core/Slider");

/***/ }),

/***/ 48308:
/***/ ((module) => {

module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ 85360:
/***/ ((module) => {

module.exports = require("@next/env");

/***/ }),

/***/ 64515:
/***/ ((module) => {

module.exports = require("@stripe/react-stripe-js");

/***/ }),

/***/ 20943:
/***/ ((module) => {

module.exports = require("@stripe/stripe-js");

/***/ }),

/***/ 52167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 1043:
/***/ ((module) => {

module.exports = require("lodash.get");

/***/ }),

/***/ 51650:
/***/ ((module) => {

module.exports = require("lodash.uniqby");

/***/ }),

/***/ 54426:
/***/ ((module) => {

module.exports = require("next/dist/compiled/chalk");

/***/ }),

/***/ 40252:
/***/ ((module) => {

module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 19371:
/***/ ((module) => {

module.exports = require("next/dist/compiled/node-fetch");

/***/ }),

/***/ 97999:
/***/ ((module) => {

module.exports = require("next/dist/compiled/path-to-regexp");

/***/ }),

/***/ 60600:
/***/ ((module) => {

module.exports = require("next/dist/server/accept-header.js");

/***/ }),

/***/ 52155:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils/index.js");

/***/ }),

/***/ 90730:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils/node.js");

/***/ }),

/***/ 60562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 94140:
/***/ ((module) => {

module.exports = require("next/dist/server/get-page-files.js");

/***/ }),

/***/ 89716:
/***/ ((module) => {

module.exports = require("next/dist/server/htmlescape.js");

/***/ }),

/***/ 25071:
/***/ ((module) => {

module.exports = require("next/dist/server/render-result.js");

/***/ }),

/***/ 33100:
/***/ ((module) => {

module.exports = require("next/dist/server/render.js");

/***/ }),

/***/ 92779:
/***/ ((module) => {

module.exports = require("next/dist/server/request-meta.js");

/***/ }),

/***/ 79502:
/***/ ((module) => {

module.exports = require("next/dist/server/send-payload.js");

/***/ }),

/***/ 76368:
/***/ ((module) => {

module.exports = require("next/dist/server/utils.js");

/***/ }),

/***/ 56724:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 27664:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/escape-regexp.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 94957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 82374:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-locale-cookie.js");

/***/ }),

/***/ 34014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 78524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 78020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 29565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 64365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 95714:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-route-from-asset-path.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 91292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 25753:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-match.js");

/***/ }),

/***/ 99521:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/prepare-destination.js");

/***/ }),

/***/ 80979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 36052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 84226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 95566:
/***/ ((module) => {

module.exports = require("next/error");

/***/ }),

/***/ 40968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 71853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 59819:
/***/ ((module) => {

module.exports = require("querystring");

/***/ }),

/***/ 16689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 78684:
/***/ ((module) => {

module.exports = require("react-dom/server");

/***/ }),

/***/ 25716:
/***/ ((module) => {

module.exports = require("react-hotjar");

/***/ }),

/***/ 16666:
/***/ ((module) => {

module.exports = require("react-responsive");

/***/ }),

/***/ 61929:
/***/ ((module) => {

module.exports = require("react-select");

/***/ }),

/***/ 23618:
/***/ ((module) => {

module.exports = require("react-select/async");

/***/ }),

/***/ 1187:
/***/ ((module) => {

module.exports = require("react-toastify");

/***/ }),

/***/ 20997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 57518:
/***/ ((module) => {

module.exports = require("styled-components");

/***/ }),

/***/ 24535:
/***/ ((module) => {

module.exports = require("styled-normalize");

/***/ }),

/***/ 6153:
/***/ ((module) => {

module.exports = require("universal-cookie");

/***/ }),

/***/ 84269:
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ 63398:
/***/ ((module) => {

module.exports = require("uuidv4");

/***/ }),

/***/ 75609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 61908:
/***/ ((module) => {

module.exports = import("@hookform/resolvers/yup");;

/***/ }),

/***/ 45641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [4357,9703,6114,9067,8183,9899,805,6067,1233,9891,9343,1894,3033,7278,1217,3864,8822,6189,498], () => (__webpack_exec__(78010)));
module.exports = __webpack_exports__;

})();