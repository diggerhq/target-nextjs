"use strict";
(() => {
var exports = {};
exports.id = 9195;
exports.ids = [9195];
exports.modules = {

/***/ 43243:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ blog_FeaturesLanding)
});

// EXTERNAL MODULE: ./src/theme.js
var theme = __webpack_require__(91073);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(57518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: external "date-fns"
var external_date_fns_ = __webpack_require__(74146);
// EXTERNAL MODULE: external "lodash.get"
var external_lodash_get_ = __webpack_require__(1043);
var external_lodash_get_default = /*#__PURE__*/__webpack_require__.n(external_lodash_get_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(41664);
// EXTERNAL MODULE: external "react-responsive"
var external_react_responsive_ = __webpack_require__(16666);
// EXTERNAL MODULE: ./src/components/common/Text.jsx
var Text = __webpack_require__(87491);
// EXTERNAL MODULE: ./src/styles.jsx
var styles = __webpack_require__(72994);
// EXTERNAL MODULE: ./src/utils/text.js
var utils_text = __webpack_require__(88703);
// EXTERNAL MODULE: ./src/components/blog/common/index.js
var common = __webpack_require__(4261);
;// CONCATENATED MODULE: ./src/components/blog/FeatureCard.jsx


const FeatureCard = external_styled_components_default().div.withConfig({
  displayName: "FeatureCard",
  componentId: "xp2p8x-0"
})(["display:flex;margin-bottom:1rem;align-items:", ";position:relative;flex-direction:", ";", " ", ""], p => p.alignItems ? p.alignItems : "center", p => p.flexDirection || "row", p => p.padding && `padding: ${p.padding};`, theme/* media.tabletLarge */.BC.tabletLarge`
      margin-bottom: 1.5rem;
			display: block;
      flex-direction: row;
			position: relative;
  `);
/* harmony default export */ const blog_FeatureCard = (FeatureCard);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
;// CONCATENATED MODULE: ./src/components/blog/FeatureItem.jsx














const InnerContainer = external_styled_components_default().div.withConfig({
  displayName: "FeatureItem__InnerContainer",
  componentId: "kezwt8-0"
})(["width:65%;display:flex;flex-direction:column;padding:0 0 0 0.625rem;cursor:pointer;", ""], theme/* media.tablet */.BC.tablet`
    padding: 1rem;
		width: 100%;
	`);
const ImageContainer = external_styled_components_default()(InnerContainer).withConfig({
  displayName: "FeatureItem__ImageContainer",
  componentId: "kezwt8-1"
})(["width:35%;", " padding:0;", ""], styles/* borderRadius */.E, theme/* media.tablet */.BC.tablet`
    padding: 0.5rem;
		width: 100%;
	`);
const Image = external_styled_components_default().img.withConfig({
  displayName: "FeatureItem__Image",
  componentId: "kezwt8-2"
})(["width:100%;height:7rem;padding:0;", " object-fit:cover;", ""], styles/* borderRadius */.E, theme/* media.tablet */.BC.tablet`
    width: 100%;
		height: 230px;
	`);
const Title = external_styled_components_default().div.withConfig({
  displayName: "FeatureItem__Title",
  componentId: "kezwt8-3"
})(["text-transform:capitalize;", ""], theme/* media.tabletLarge */.BC.tabletLarge`
	margin-bottom: 1rem;
	`);
const Small = external_styled_components_default().div.withConfig({
  displayName: "FeatureItem__Small",
  componentId: "kezwt8-4"
})(["display:none;", ""], theme/* media.tabletLarge */.BC.tabletLarge`
	display: block;
`);
const BottomContainer = external_styled_components_default().div.withConfig({
  displayName: "FeatureItem__BottomContainer",
  componentId: "kezwt8-5"
})([""]);
const Dot = external_styled_components_default().div.withConfig({
  displayName: "FeatureItem__Dot",
  componentId: "kezwt8-6"
})(["margin:0 0.3rem;"]);

const FeatureItem = ({
  feature
}) => {
  const published = (0,external_date_fns_.formatDistance)(new Date(feature.published_at), new Date(), {
    addSuffix: true
  });
  const isTabletLarge = (0,external_react_responsive_.useMediaQuery)({
    query: `(min-width: ${theme/* sizes.tabletLarge */.J7.tabletLarge}px)`
  });
  const StyledFeatureCard = external_styled_components_default()(blog_FeatureCard).withConfig({
    displayName: "FeatureItem__StyledFeatureCard",
    componentId: "kezwt8-7"
  })(["&:hover{", "{text-decoration:underline;}}"], Title);
  return /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
    href: "/blog/[slug]",
    as: `/blog/${feature.slug}`,
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(StyledFeatureCard, {
      alignItems: "flex-start",
      children: [/*#__PURE__*/jsx_runtime_.jsx(ImageContainer, {
        children: /*#__PURE__*/jsx_runtime_.jsx(Image, {
          src: feature.feature_image
        })
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(InnerContainer, {
        children: [/*#__PURE__*/jsx_runtime_.jsx(Title, {
          children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
            size: "boldBody",
            children: isTabletLarge ? feature.title : (0,utils_text/* truncate */.$)(feature.title, 33)
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(Small, {
          children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
            size: "small",
            children: feature.excerpt
          })
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(BottomContainer, {
          children: [/*#__PURE__*/jsx_runtime_.jsx(common/* Divider */.iz, {}), /*#__PURE__*/(0,jsx_runtime_.jsxs)(common/* Author */.S3, {
            children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(Text/* default */.ZP, {
              size: isTabletLarge ? "small" : "tiny",
              color: "blue",
              children: ["By ", external_lodash_get_default()(feature, "primary_author.name", "Inhabit Team")]
            }), !isTabletLarge && /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
              children: [/*#__PURE__*/jsx_runtime_.jsx(Dot, {
                children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
                  size: "tiny",
                  color: "blue",
                  children: "|"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
                size: "tiny",
                color: "blue",
                children: `${feature.reading_time} min read`
              })]
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(common/* TimeStamps */.Af, {
            children: [/*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
              size: "small",
              color: "blue",
              children: published
            }), /*#__PURE__*/jsx_runtime_.jsx(Dot, {
              children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
                size: "small",
                color: "blue",
                children: "|"
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
              size: "small",
              color: "blue",
              children: `${feature.reading_time} min read`
            })]
          })]
        })]
      })]
    })
  });
};

/* harmony default export */ const blog_FeatureItem = (FeatureItem);
// EXTERNAL MODULE: ./src/components/blog/FeaturesContainer.jsx
var FeaturesContainer = __webpack_require__(85964);
;// CONCATENATED MODULE: ./src/components/blog/MainFeatureItem.jsx














const MainFeatureItem_InnerContainer = external_styled_components_default().div.withConfig({
  displayName: "MainFeatureItem__InnerContainer",
  componentId: "sc-1wftz79-0"
})(["width:100%;display:flex;flex-direction:column;cursor:pointer;", ""], theme/* media.tablet */.BC.tablet`
    padding: 1rem;
		width: 100%;
	`);
const MainFeatureItem_ImageContainer = external_styled_components_default()(MainFeatureItem_InnerContainer).withConfig({
  displayName: "MainFeatureItem__ImageContainer",
  componentId: "sc-1wftz79-1"
})(["", " min-height:13.75rem;padding:0;", ""], styles/* borderRadius */.E, theme/* media.tablet */.BC.tablet`
    padding: 1rem;
    min-width: 30rem;
    min-height: 20rem;
	`);
const MainFeatureItem_Image = external_styled_components_default().img.withConfig({
  displayName: "MainFeatureItem__Image",
  componentId: "sc-1wftz79-2"
})(["", " padding:0;width:100%;height:100%;object-fit:cover;", ""], styles/* borderRadius */.E, theme/* media.tablet */.BC.tablet`
	`);
const MainFeatureItem_Title = external_styled_components_default().div.withConfig({
  displayName: "MainFeatureItem__Title",
  componentId: "sc-1wftz79-3"
})(["text-transform:capitalize;", ""], theme/* media.tabletLarge */.BC.tabletLarge`
	margin-bottom: 1rem;
	`);
const MainFeatureItem_Small = external_styled_components_default().div.withConfig({
  displayName: "MainFeatureItem__Small",
  componentId: "sc-1wftz79-4"
})(["display:none;", ""], theme/* media.tabletLarge */.BC.tabletLarge`
	display: block;
`);
const MainFeatureItem_BottomContainer = external_styled_components_default().div.withConfig({
  displayName: "MainFeatureItem__BottomContainer",
  componentId: "sc-1wftz79-5"
})([""]);
const MainFeatureItem_Dot = external_styled_components_default().div.withConfig({
  displayName: "MainFeatureItem__Dot",
  componentId: "sc-1wftz79-6"
})(["margin:0 0.3rem;"]);
const StyledFeatureCard = external_styled_components_default()(blog_FeatureCard).withConfig({
  displayName: "MainFeatureItem__StyledFeatureCard",
  componentId: "sc-1wftz79-7"
})(["&:hover{", "{text-decoration:underline;}}"], MainFeatureItem_Title);

const MainFeatureItem = ({
  feature
}) => {
  const published = (0,external_date_fns_.formatDistance)(new Date(feature.published_at), new Date(), {
    addSuffix: true
  });
  const isTabletLarge = (0,external_react_responsive_.useMediaQuery)({
    query: `(min-width: ${theme/* sizes.tabletLarge */.J7.tabletLarge}px)`
  });
  return /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
    href: "/blog/[slug]",
    as: `/blog/${feature.slug}`,
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(StyledFeatureCard, {
      flexDirection: "column",
      alignItems: "center",
      children: [/*#__PURE__*/jsx_runtime_.jsx(MainFeatureItem_ImageContainer, {
        children: /*#__PURE__*/jsx_runtime_.jsx(MainFeatureItem_Image, {
          src: feature.feature_image
        })
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(MainFeatureItem_InnerContainer, {
        children: [/*#__PURE__*/jsx_runtime_.jsx(MainFeatureItem_Title, {
          children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
            size: "blogTitle",
            children: isTabletLarge ? feature.title : (0,utils_text/* truncate */.$)(feature.title, 40)
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(MainFeatureItem_Small, {
          children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
            size: "tiny",
            children: feature.excerpt
          })
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(MainFeatureItem_BottomContainer, {
          children: [/*#__PURE__*/jsx_runtime_.jsx(common/* Divider */.iz, {}), /*#__PURE__*/(0,jsx_runtime_.jsxs)(common/* Author */.S3, {
            children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(Text/* default */.ZP, {
              size: isTabletLarge ? "small" : "tiny",
              color: "blue",
              children: ["By ", external_lodash_get_default()(feature, "primary_author.name", "Inhabit Team")]
            }), !isTabletLarge && /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
              children: [/*#__PURE__*/jsx_runtime_.jsx(MainFeatureItem_Dot, {
                children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
                  size: "tiny",
                  color: "blue",
                  children: "|"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
                size: "tiny",
                color: "blue",
                children: `${feature.reading_time} min read`
              })]
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(common/* TimeStamps */.Af, {
            children: [/*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
              size: "small",
              color: "blue",
              children: published
            }), /*#__PURE__*/jsx_runtime_.jsx(MainFeatureItem_Dot, {
              children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
                size: "small",
                color: "blue",
                children: "|"
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
              size: "small",
              color: "blue",
              children: `${feature.reading_time} min read`
            })]
          })]
        })]
      })]
    })
  });
};

/* harmony default export */ const blog_MainFeatureItem = (MainFeatureItem);
;// CONCATENATED MODULE: ./src/components/blog/FeaturesLanding.jsx







const CardContainer = external_styled_components_default().div.withConfig({
  displayName: "FeaturesLanding__CardContainer",
  componentId: "nm01gc-0"
})(["width:100%;display:flex;flex-direction:column;", ""], theme/* media.tablet */.BC.tablet`
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;

   &> div {
    width: 33%;  
  }

  &> div:first-child {
    width: 100%;
    flex-direction: row;
    display: flex;
    background-color: unset;
  }
	`);
const MainContainer = external_styled_components_default().div.withConfig({
  displayName: "FeaturesLanding__MainContainer",
  componentId: "nm01gc-1"
})(["margin-top:0.5rem;"]);

const FeaturesLanding = ({
  features
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx(FeaturesContainer/* default */.Z, {
    children: /*#__PURE__*/jsx_runtime_.jsx(MainContainer, {
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(CardContainer, {
        children: [/*#__PURE__*/jsx_runtime_.jsx(blog_MainFeatureItem, {
          feature: features[0]
        }, features[0].id), features.slice(1).map(feature => {
          return /*#__PURE__*/jsx_runtime_.jsx(blog_FeatureItem, {
            feature: feature
          }, feature.id);
        })]
      })
    })
  });
};

/* harmony default export */ const blog_FeaturesLanding = (FeaturesLanding);

/***/ }),

/***/ 99553:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Spinner__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16114);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);




const Loadingcontainer = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Loading__Loadingcontainer",
  componentId: "sc-1rrv3tk-0"
})(["width:100%;height:", ";display:flex;flex-direction:column;justify-content:center;align-items:center;}"], p => p.height || "100vh");

const Loading = ({
  height,
  children,
  width = "10rem"
}) => {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(Loadingcontainer, {
    height: height,
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_Spinner__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
      width: width
    }), children]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Loading);

/***/ }),

/***/ 49906:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_common_Page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97598);
/* harmony import */ var _components_blog_FeaturesLanding__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(43243);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(11098);
/* harmony import */ var _components_common_Loading__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(99553);
/* harmony import */ var _components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(60805);
/* harmony import */ var _components_ContentContainer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(16067);
/* harmony import */ var _components_common_LoadingLarge__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(49899);
/* harmony import */ var _contexts_blog__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(36398);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_6__]);
_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];












const Features = () => {
  const {
    features,
    loading,
    progress,
    setProgress,
    getFeatures
  } = (0,_contexts_blog__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)();
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    getFeatures();
  }, []);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_components_common_Page__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
    children: loading || !(features.length > 0) ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_components_common_LoadingLarge__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
      loading: loading,
      progress: progress,
      setProgress: setProgress
    }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_components_ContentContainer__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
      title: "Blog",
      children: features.length > 0 && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_components_blog_FeaturesLanding__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        features: features
      })
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)(Features));
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 77972:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "unstable_getStaticParams": () => (/* binding */ unstable_getStaticParams),
/* harmony export */   "unstable_getStaticProps": () => (/* binding */ unstable_getStaticProps),
/* harmony export */   "unstable_getStaticPaths": () => (/* binding */ unstable_getStaticPaths),
/* harmony export */   "unstable_getServerProps": () => (/* binding */ unstable_getServerProps),
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "_app": () => (/* binding */ _app),
/* harmony export */   "renderReqToHTML": () => (/* binding */ renderReqToHTML),
/* harmony export */   "render": () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(70607);
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59450);
/* harmony import */ var private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97020);
/* harmony import */ var private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(73978);
/* harmony import */ var next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99436);

      
      
      
      

      
      const { processEnv } = __webpack_require__(85360)
      processEnv([{"path":".env","contents":"API_HOST=https://api.inhabit.eco\nNEXT_PUBLIC_CALENDLY_URL=https://calendly.com/inhabit-meet/inhabit-measurement-tutorial\nNEXT_PUBLIC_FLAGS_ENVIRONMENT_KEY=flags_pub_289425705564897805\nNEXT_PUBLIC_GOOGLE_ANALYTICS=G-1CBB78XFQ4\nNEXT_PUBLIC_INTERCOM_APP_ID=bw9p6mfd\nNEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_bQDaTEuYc10x3BZt9YcGj2cE00Gzwm4gDD\nSTRIPE_PUBLISHABLE_KEY=pk_live_bQDaTEuYc10x3BZt9YcGj2cE00Gzwm4gDD\n\n"}])
    
      
      const runtimeConfig = {}
      ;

      const documentModule = __webpack_require__(9968)

      const appMod = __webpack_require__(13724)
      let App = appMod.default || appMod.then && appMod.then(mod => mod.default);

      const compMod = __webpack_require__(49906)

      const Component = compMod.default || compMod.then && compMod.then(mod => mod.default)
      /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Component);
      const getStaticProps = compMod['getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['getStaticProp' + 's'])
      const getStaticPaths = compMod['getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['getStaticPath' + 's'])
      const getServerSideProps = compMod['getServerSideProp' + 's'] || compMod.then && compMod.then(mod => mod['getServerSideProp' + 's'])

      // kept for detecting legacy exports
      const unstable_getStaticParams = compMod['unstable_getStaticParam' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticParam' + 's'])
      const unstable_getStaticProps = compMod['unstable_getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticProp' + 's'])
      const unstable_getStaticPaths = compMod['unstable_getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticPath' + 's'])
      const unstable_getServerProps = compMod['unstable_getServerProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getServerProp' + 's'])

      let config = compMod['confi' + 'g'] || (compMod.then && compMod.then(mod => mod['confi' + 'g'])) || {}
      const _app = App

      const combinedRewrites = Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)
        ? private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg
        : []

      if (!Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)) {
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.beforeFiles */ .Dg.beforeFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.afterFiles */ .Dg.afterFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.fallback */ .Dg.fallback)
      }

      const { renderReqToHTML, render } = (0,next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__/* .getPageHandler */ .u)({
        pageModule: compMod,
        pageComponent: Component,
        pageConfig: config,
        appModule: App,
        documentModule: documentModule,
        errorModule: __webpack_require__(99651),
        notFoundModule: undefined,
        pageGetStaticProps: getStaticProps,
        pageGetStaticPaths: getStaticPaths,
        pageGetServerSideProps: getServerSideProps,

        assetPrefix: "",
        canonicalBase: "",
        generateEtags: true,
        poweredByHeader: true,
        reactRoot: false,

        runtimeConfig,
        buildManifest: private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__,
        reactLoadableManifest: private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__,

        rewrites: combinedRewrites,
        i18n: undefined,
        page: "/blog",
        buildId: "lDoX7RBEQ31kzKIJJbkVC",
        escapedBuildId: "lDoX7RBEQ31kzKIJJbkVC",
        basePath: "",
        pageIsDynamic: false,
        encodedPreviewProps: {previewModeId:"89cdc9f6073608262d43eab6d636f3f4",previewModeSigningKey:"74c7e36a2414a3f7b0ebcc67250f915f156686e1610b45a21ae9358d5b7c6c5a",previewModeEncryptionKey:"8a4c97ad9e5cf12d5a140689be08539ea52d8b27a416c2b8ae67db636b45841b"}
      })
      
    

/***/ }),

/***/ 94970:
/***/ ((module) => {

module.exports = require("@happykit/flags/client");

/***/ }),

/***/ 46411:
/***/ ((module) => {

module.exports = require("@happykit/flags/config");

/***/ }),

/***/ 48095:
/***/ ((module) => {

module.exports = require("@happykit/flags/server");

/***/ }),

/***/ 83218:
/***/ ((module) => {

module.exports = require("@hookform/error-message");

/***/ }),

/***/ 48308:
/***/ ((module) => {

module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ 85360:
/***/ ((module) => {

module.exports = require("@next/env");

/***/ }),

/***/ 64515:
/***/ ((module) => {

module.exports = require("@stripe/react-stripe-js");

/***/ }),

/***/ 20943:
/***/ ((module) => {

module.exports = require("@stripe/stripe-js");

/***/ }),

/***/ 52167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 74146:
/***/ ((module) => {

module.exports = require("date-fns");

/***/ }),

/***/ 1043:
/***/ ((module) => {

module.exports = require("lodash.get");

/***/ }),

/***/ 51650:
/***/ ((module) => {

module.exports = require("lodash.uniqby");

/***/ }),

/***/ 54426:
/***/ ((module) => {

module.exports = require("next/dist/compiled/chalk");

/***/ }),

/***/ 40252:
/***/ ((module) => {

module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 19371:
/***/ ((module) => {

module.exports = require("next/dist/compiled/node-fetch");

/***/ }),

/***/ 97999:
/***/ ((module) => {

module.exports = require("next/dist/compiled/path-to-regexp");

/***/ }),

/***/ 60600:
/***/ ((module) => {

module.exports = require("next/dist/server/accept-header.js");

/***/ }),

/***/ 52155:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils/index.js");

/***/ }),

/***/ 90730:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils/node.js");

/***/ }),

/***/ 60562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 94140:
/***/ ((module) => {

module.exports = require("next/dist/server/get-page-files.js");

/***/ }),

/***/ 89716:
/***/ ((module) => {

module.exports = require("next/dist/server/htmlescape.js");

/***/ }),

/***/ 25071:
/***/ ((module) => {

module.exports = require("next/dist/server/render-result.js");

/***/ }),

/***/ 33100:
/***/ ((module) => {

module.exports = require("next/dist/server/render.js");

/***/ }),

/***/ 92779:
/***/ ((module) => {

module.exports = require("next/dist/server/request-meta.js");

/***/ }),

/***/ 79502:
/***/ ((module) => {

module.exports = require("next/dist/server/send-payload.js");

/***/ }),

/***/ 76368:
/***/ ((module) => {

module.exports = require("next/dist/server/utils.js");

/***/ }),

/***/ 56724:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 27664:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/escape-regexp.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 94957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 82374:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-locale-cookie.js");

/***/ }),

/***/ 34014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 78524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 78020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 29565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 64365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 95714:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-route-from-asset-path.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 91292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 25753:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-match.js");

/***/ }),

/***/ 99521:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/prepare-destination.js");

/***/ }),

/***/ 80979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 36052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 84226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 95566:
/***/ ((module) => {

module.exports = require("next/error");

/***/ }),

/***/ 40968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 71853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 59819:
/***/ ((module) => {

module.exports = require("querystring");

/***/ }),

/***/ 16689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 25716:
/***/ ((module) => {

module.exports = require("react-hotjar");

/***/ }),

/***/ 16666:
/***/ ((module) => {

module.exports = require("react-responsive");

/***/ }),

/***/ 1187:
/***/ ((module) => {

module.exports = require("react-toastify");

/***/ }),

/***/ 20997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 57518:
/***/ ((module) => {

module.exports = require("styled-components");

/***/ }),

/***/ 24535:
/***/ ((module) => {

module.exports = require("styled-normalize");

/***/ }),

/***/ 6153:
/***/ ((module) => {

module.exports = require("universal-cookie");

/***/ }),

/***/ 84269:
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ 75609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 61908:
/***/ ((module) => {

module.exports = import("@hookform/resolvers/yup");;

/***/ }),

/***/ 45641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [4357,9703,6114,9067,8183,9899,805,6067,8015], () => (__webpack_exec__(77972)));
module.exports = __webpack_exports__;

})();