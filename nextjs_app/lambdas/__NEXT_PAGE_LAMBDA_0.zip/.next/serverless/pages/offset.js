"use strict";
(() => {
var exports = {};
exports.id = 3111;
exports.ids = [3111];
exports.modules = {

/***/ 13795:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16666);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_responsive__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(87491);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);






const Container = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
  displayName: "ProjectOffsetCount__Container",
  componentId: "lpdn0g-0"
})(["display:flex;align-items:center;justify-content:center;margin:1rem 0;"]);

const ProjectOffsetCount = ({
  count
}) => {
  const tablet = (0,react_responsive__WEBPACK_IMPORTED_MODULE_0__.useMediaQuery)({
    query: `(min-width: ${_theme__WEBPACK_IMPORTED_MODULE_2__/* .sizes.tablet */ .J7.tablet}px)`
  });
  const size = tablet ? "modalTitle" : "subtitle";
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(Container, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(_common_Text__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
      size: size,
      color: "black",
      children: ["Total tCO2e Offset:", " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
        size: size,
        color: "blue",
        children: count
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProjectOffsetCount);

/***/ }),

/***/ 98170:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ offset_ProjectsCarousel)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(71853);
;// CONCATENATED MODULE: external "react-multi-carousel"
const external_react_multi_carousel_namespaceObject = require("react-multi-carousel");
var external_react_multi_carousel_default = /*#__PURE__*/__webpack_require__.n(external_react_multi_carousel_namespaceObject);
// EXTERNAL MODULE: external "react-responsive"
var external_react_responsive_ = __webpack_require__(16666);
// EXTERNAL MODULE: ./src/theme.js
var theme = __webpack_require__(91073);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(57518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: ./src/components/offset/ProjectItem.jsx
var ProjectItem = __webpack_require__(21731);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
;// CONCATENATED MODULE: ./src/components/offset/ProjectsCarousel.jsx
const _excluded = ["next", "previous", "goToSlide"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }






var LeftArrowIcon = function LeftArrowIcon(props) {
  return /*#__PURE__*/jsx_runtime_.jsx("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: /*#__PURE__*/jsx_runtime_.jsx("path", {
      d: "M19.928 39.992c-.756.044-1.372-.265-1.89-.786A43297.723 43297.723 0 0 1 .829 21.87c-1.1-1.104-1.106-2.642 0-3.754A16023.13 16023.13 0 0 1 18.14.736c.96-.963 2.585-.98 3.52-.061 1.029 1.007 1.04 2.526.023 3.658-.09.1-.187.193-.282.288l-14.938 15c-.454.456-.44.353-.012.786C11.5 25.48 16.552 30.55 21.603 35.618c.748.751.99 1.624.717 2.645-.248.918-1.232 1.833-2.392 1.73z",
      fill: "#2E68F1"
    })
  }));
};

LeftArrowIcon.defaultProps = {
  width: "23",
  height: "40",
  viewBox: "0 0 23 40",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var RightArrowIcon = function RightArrowIcon(props) {
  return /*#__PURE__*/jsx_runtime_.jsx("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: /*#__PURE__*/jsx_runtime_.jsx("g", {
      clipPath: "url(#clip0)",
      children: /*#__PURE__*/jsx_runtime_.jsx("path", {
        d: "M3.072.008c.756-.044 1.372.265 1.89.786C10.7 6.57 16.436 12.35 22.171 18.13c1.1 1.104 1.106 2.642 0 3.754-5.765 5.797-11.535 11.59-17.31 17.38-.96.963-2.585.98-3.52.061-1.029-1.007-1.04-2.526-.023-3.658.09-.1.187-.193.282-.288l14.938-15c.454-.456.44-.353.012-.786C11.5 14.52 6.448 9.45 1.397 4.382.649 3.63.407 2.758.68 1.737.928.819 1.91-.096 3.072.007z",
        fill: "#2E68F1"
      })
    })
  }));
};

RightArrowIcon.defaultProps = {
  width: "23",
  height: "40",
  viewBox: "0 0 23 40",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};





const Container = external_styled_components_default().div.withConfig({
  displayName: "ProjectsCarousel__Container",
  componentId: "sc-17j9x0e-0"
})(["position:relative;width:100%;.image-item{width:100%;", "}}.react-multi-carousel-dot-list{left:initial;right:6rem;bottom:0.4rem;}.react-multi-carousel-dot button{border-color:", ";background-color:", ";}.react-multi-carousel-dot--active button{border-color:", ";background-color:", ";}"], theme/* media.desktop */.BC.desktop`
      padding: 0 10px;
    `, p => p.theme.colors.secondaryBlue, p => p.theme.colors.secondaryBlue, p => p.theme.colors.blue, p => p.theme.colors.blue);
const CustomArrowContainer = external_styled_components_default().div.withConfig({
  displayName: "ProjectsCarousel__CustomArrowContainer",
  componentId: "sc-17j9x0e-1"
})(["height:45px;width:45px;box-sizing:border-box;border-radius:10px;padding:10px 12px;display:flex;justify-content:center;align-items:center;& > svg{width:1rem;height:1.5rem;}", "}"], theme/* media.desktop */.BC.desktop`
    height: 2rem;
    outline: 0;
    transition: all 0.5s;
    border-radius: 35px;
    z-index: 1000;
    opacity: 1;
    cursor: pointer;
      box-sizing: border-box;
    border-radius: 10px;
    display: flex;
    justify-content: center;
    align-items: center;
  `);
const LeftArrowContiainer = external_styled_components_default()(CustomArrowContainer).withConfig({
  displayName: "ProjectsCarousel__LeftArrowContiainer",
  componentId: "sc-17j9x0e-2"
})(["left:calc(4% + 1px);"]);
const RightArrowContiainer = external_styled_components_default()(CustomArrowContainer).withConfig({
  displayName: "ProjectsCarousel__RightArrowContiainer",
  componentId: "sc-17j9x0e-3"
})(["right:calc(4% + 1px);"]);
const ButtonGroupContainer = external_styled_components_default().div.attrs({
  className: "carousel-button-group"
}).withConfig({
  displayName: "ProjectsCarousel__ButtonGroupContainer",
  componentId: "sc-17j9x0e-4"
})(["margin-top:1rem;display:flex;align-content:flex-end;justify-content:flex-end;& > div:first-child{border-left:1px solid ", ";border-radius:initial;}"], p => p.theme.colors.secondaryBlue);

const ButtonGroup = _ref => {
  let {
    next,
    previous,
    goToSlide
  } = _ref,
      rest = _objectWithoutProperties(_ref, _excluded);

  const {
    carouselState: {
      currentSlide
    }
  } = rest;
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(ButtonGroupContainer, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(LeftArrowContiainer, {
      className: currentSlide === 0 ? "disable" : "",
      onClick: () => previous(),
      children: /*#__PURE__*/jsx_runtime_.jsx(LeftArrowIcon, {})
    }), /*#__PURE__*/jsx_runtime_.jsx(RightArrowContiainer, {
      onClick: () => next(),
      children: /*#__PURE__*/jsx_runtime_.jsx(RightArrowIcon, {})
    })]
  });
};

const ProjectsCarousel = ({
  projects
}) => {
  const router = (0,router_.useRouter)();
  const desktop = (0,external_react_responsive_.useMediaQuery)({
    query: `(min-width: ${theme/* sizes.desktop */.J7.desktop}px)`
  });
  const tablet = (0,external_react_responsive_.useMediaQuery)({
    query: `(min-width: ${theme/* sizes.tablet */.J7.tablet}px)`
  });
  const responsive = {
    desktopLarge: {
      breakpoint: {
        max: 3000,
        min: 1360
      },
      items: 2.5,
      paritialVisibilityGutter: 10
    },
    desktop: {
      breakpoint: {
        max: 1360,
        min: 1200
      },
      items: 2.25,
      paritialVisibilityGutter: 10
    },
    tablet: {
      breakpoint: {
        max: 1200,
        min: 464
      },
      items: 1,
      paritialVisibilityGutter: 100
    },
    mobile: {
      breakpoint: {
        max: 464,
        min: 0
      },
      items: 1,
      paritialVisibilityGutter: 30
    }
  };
  return /*#__PURE__*/jsx_runtime_.jsx(Container, {
    children: /*#__PURE__*/jsx_runtime_.jsx((external_react_multi_carousel_default()), {
      ssr: true,
      showDots: true,
      responsive: responsive,
      itemClass: "image-item",
      deviceType: desktop ? "desktop" : "mobile",
      removeArrowOnDeviceType: ["tablet", "mobile", "desktop"],
      partialVisible: !!desktop,
      renderDotsOutside: true,
      renderButtonGroupOutside: true,
      customButtonGroup: /*#__PURE__*/jsx_runtime_.jsx(ButtonGroup, {}),
      swipeable: true,
      children: projects.map(project => /*#__PURE__*/jsx_runtime_.jsx(ProjectItem/* default */.Z, {
        project: project,
        onClick: !tablet ? () => router.push("/offset/projects/[slug]", `/offset/projects/${project.slug}`) : null
      }, project.id))
    })
  });
};

/* harmony default export */ const offset_ProjectsCarousel = (ProjectsCarousel);

/***/ }),

/***/ 42931:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_common_LoadingLarge__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(49899);
/* harmony import */ var _components_common_Page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97598);
/* harmony import */ var _components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(60805);
/* harmony import */ var _components_ContentContainer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(16067);
/* harmony import */ var _components_offset_ProjectOffsetCount__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(13795);
/* harmony import */ var _components_offset_ProjectsCarousel__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(98170);
/* harmony import */ var _contexts_auth__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(58368);
/* harmony import */ var _contexts_project__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(98605);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_3__]);
_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }














var OffsetHistoryIcon = function OffsetHistoryIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("path", {
      d: "M23.47 13.725c-.239-4.608-2.346-8.003-6.57-10-1.46-.69-3.019-.953-4.63-.923-.194.004-.266.067-.252.258.008.163.008.326 0 .489-.009.425-.384.653-.766.449-.402-.215-.791-.457-1.185-.69-.434-.253-.869-.507-1.3-.768-.477-.288-.474-.726.007-1.011.792-.471 1.586-.94 2.38-1.409.48-.282.864-.059.864.5 0 .625 0 .635.6.647 2.264.047 4.388.61 6.317 1.798 3.184 1.962 5.21 4.784 5.85 8.476.773 4.472-.571 8.31-3.863 11.421-1.967 1.858-4.345 2.926-7.046 3.207-3.693.383-6.945-.671-9.718-3.129C1.94 21.077.588 18.598.153 15.677-.415 11.87.574 8.481 3.082 5.546c.808-.947 1.764-1.717 2.805-2.386.42-.27.876-.197 1.124.178.254.386.144.845-.29 1.116-1.45.907-2.64 2.075-3.542 3.53a10.683 10.683 0 0 0-1.59 4.83c-.228 2.835.51 5.395 2.248 7.64 1.797 2.323 4.173 3.735 7.083 4.131 3.644.496 6.806-.58 9.408-3.185 1.725-1.729 2.703-3.849 3.045-6.264.066-.464.075-.929.096-1.411z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("path", {
      d: "M21.084 13.739c0 4.619-3.676 8.582-8.569 8.59-4.838.01-8.6-3.866-8.597-8.583.004-4.788 3.89-8.56 8.597-8.575 4.714-.014 8.567 3.856 8.569 8.568zm-4.09-3.715c-.566 0-.935-.633-.66-1.137.105-.195.272-.337.428-.487.11-.107.112-.18-.016-.275-.955-.713-2.015-1.175-3.198-1.348-.193-.028-.299.018-.277.24.01.13.01.263 0 .394a.753.753 0 0 1-.596.71c-.524.118-.951-.26-.955-.847-.004-.564.062-.555-.528-.447-1.078.197-2.042.66-2.929 1.296-.134.097-.142.174-.017.29.158.147.324.288.425.488a.768.768 0 0 1-.203.964.749.749 0 0 1-.964-.033 3.949 3.949 0 0 1-.347-.344c-.109-.122-.183-.095-.275.022-.753.965-1.188 2.059-1.368 3.262-.022.152.036.214.19.209.163-.008.326-.006.488.006a.772.772 0 0 1 .71.735c.016.376-.245.695-.627.781-.192.043-.386.03-.578.03-.14 0-.2.055-.179.197a7.096 7.096 0 0 0 1.387 3.283c.087.114.145.104.235.012.136-.138.262-.287.426-.394.316-.203.728-.176.969.064a.753.753 0 0 1 .081.998 2.511 2.511 0 0 1-.359.393c-.13.119-.134.197.015.305.973.715 2.047 1.182 3.248 1.343.14.019.203-.031.203-.174s-.006-.295.003-.441c.028-.449.38-.78.806-.765.426.015.736.355.745.798.002.124.007.248 0 .372-.011.173.05.237.23.206.337-.053.67-.127.997-.221a7.627 7.627 0 0 0 2.212-1.111c.165-.117.171-.21.019-.339a2.362 2.362 0 0 1-.293-.298c-.282-.34-.262-.791.04-1.07.303-.278.767-.264 1.077.028.104.093.202.192.295.296.109.127.187.102.27-.024.152-.225.318-.44.46-.67.456-.76.76-1.601.89-2.477.044-.276.01-.31-.27-.311-.17 0-.34.004-.507-.037a.79.79 0 0 1-.59-.675c-.036-.282.145-.604.412-.75.204-.109.42-.092.636-.093.35 0 .369-.026.308-.374a6.971 6.971 0 0 0-1.187-2.874c-.336-.476-.258-.39-.594-.058-.2.191-.405.342-.688.352z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("path", {
      d: "M13.89 14.532h-1.256c-.44 0-.738-.179-.913-.607-.584-1.425-1.19-2.842-1.783-4.263-.21-.502-.01-.956.47-1.098.373-.111.752.078.92.47.51 1.189 1.017 2.378 1.523 3.568.196.457.112.371.568.375.636.006 1.269-.004 1.906.006a.754.754 0 0 1 .728.549.781.781 0 0 1-.273.831c-.174.137-.38.168-.591.169-.432.002-.866 0-1.3 0z"
    })]
  }));
};

OffsetHistoryIcon.defaultProps = {
  width: "25",
  height: "27",
  viewBox: "0 0 25 27",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

function Offset() {
  const {
    user,
    organisation,
    isAdmin
  } = (0,_contexts_auth__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
  const {
    projects,
    getProjects,
    loading,
    progress,
    setProgress
  } = (0,_contexts_project__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    getProjects();
  }, []);
  const tonnesOffset = organisation.offsets.map(offset => offset.quantity).reduce((prev, curr) => prev + curr, 0);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_components_common_Page__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
    children: loading ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_components_common_LoadingLarge__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
      loading: loading,
      text: "Getting Projects...",
      progress: progress,
      setProgress: setProgress
    }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(_components_ContentContainer__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
      title: "Offset carbon",
      iconLink: isAdmin({
        user,
        organisation
      }) && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(OffsetHistoryIcon, {}),
      iconHref: "/settings/admin/offset-history",
      limitWidth: true,
      children: [projects.length > 0 && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_components_offset_ProjectsCarousel__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
        projects: projects
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_components_offset_ProjectOffsetCount__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
        count: tonnesOffset
      })]
    })
  });
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)(Offset));
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 63508:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "unstable_getStaticParams": () => (/* binding */ unstable_getStaticParams),
/* harmony export */   "unstable_getStaticProps": () => (/* binding */ unstable_getStaticProps),
/* harmony export */   "unstable_getStaticPaths": () => (/* binding */ unstable_getStaticPaths),
/* harmony export */   "unstable_getServerProps": () => (/* binding */ unstable_getServerProps),
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "_app": () => (/* binding */ _app),
/* harmony export */   "renderReqToHTML": () => (/* binding */ renderReqToHTML),
/* harmony export */   "render": () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(70607);
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59450);
/* harmony import */ var private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97020);
/* harmony import */ var private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(73978);
/* harmony import */ var next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99436);

      
      
      
      

      
      const { processEnv } = __webpack_require__(85360)
      processEnv([{"path":".env","contents":"API_HOST=https://api.inhabit.eco\nNEXT_PUBLIC_CALENDLY_URL=https://calendly.com/inhabit-meet/inhabit-measurement-tutorial\nNEXT_PUBLIC_FLAGS_ENVIRONMENT_KEY=flags_pub_289425705564897805\nNEXT_PUBLIC_GOOGLE_ANALYTICS=G-1CBB78XFQ4\nNEXT_PUBLIC_INTERCOM_APP_ID=bw9p6mfd\nNEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_bQDaTEuYc10x3BZt9YcGj2cE00Gzwm4gDD\nSTRIPE_PUBLISHABLE_KEY=pk_live_bQDaTEuYc10x3BZt9YcGj2cE00Gzwm4gDD\n\n"}])
    
      
      const runtimeConfig = {}
      ;

      const documentModule = __webpack_require__(9968)

      const appMod = __webpack_require__(13724)
      let App = appMod.default || appMod.then && appMod.then(mod => mod.default);

      const compMod = __webpack_require__(42931)

      const Component = compMod.default || compMod.then && compMod.then(mod => mod.default)
      /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Component);
      const getStaticProps = compMod['getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['getStaticProp' + 's'])
      const getStaticPaths = compMod['getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['getStaticPath' + 's'])
      const getServerSideProps = compMod['getServerSideProp' + 's'] || compMod.then && compMod.then(mod => mod['getServerSideProp' + 's'])

      // kept for detecting legacy exports
      const unstable_getStaticParams = compMod['unstable_getStaticParam' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticParam' + 's'])
      const unstable_getStaticProps = compMod['unstable_getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticProp' + 's'])
      const unstable_getStaticPaths = compMod['unstable_getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticPath' + 's'])
      const unstable_getServerProps = compMod['unstable_getServerProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getServerProp' + 's'])

      let config = compMod['confi' + 'g'] || (compMod.then && compMod.then(mod => mod['confi' + 'g'])) || {}
      const _app = App

      const combinedRewrites = Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)
        ? private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg
        : []

      if (!Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)) {
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.beforeFiles */ .Dg.beforeFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.afterFiles */ .Dg.afterFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.fallback */ .Dg.fallback)
      }

      const { renderReqToHTML, render } = (0,next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__/* .getPageHandler */ .u)({
        pageModule: compMod,
        pageComponent: Component,
        pageConfig: config,
        appModule: App,
        documentModule: documentModule,
        errorModule: __webpack_require__(99651),
        notFoundModule: undefined,
        pageGetStaticProps: getStaticProps,
        pageGetStaticPaths: getStaticPaths,
        pageGetServerSideProps: getServerSideProps,

        assetPrefix: "",
        canonicalBase: "",
        generateEtags: true,
        poweredByHeader: true,
        reactRoot: false,

        runtimeConfig,
        buildManifest: private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__,
        reactLoadableManifest: private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__,

        rewrites: combinedRewrites,
        i18n: undefined,
        page: "/offset",
        buildId: "lDoX7RBEQ31kzKIJJbkVC",
        escapedBuildId: "lDoX7RBEQ31kzKIJJbkVC",
        basePath: "",
        pageIsDynamic: false,
        encodedPreviewProps: {previewModeId:"89cdc9f6073608262d43eab6d636f3f4",previewModeSigningKey:"74c7e36a2414a3f7b0ebcc67250f915f156686e1610b45a21ae9358d5b7c6c5a",previewModeEncryptionKey:"8a4c97ad9e5cf12d5a140689be08539ea52d8b27a416c2b8ae67db636b45841b"}
      })
      
    

/***/ }),

/***/ 94970:
/***/ ((module) => {

module.exports = require("@happykit/flags/client");

/***/ }),

/***/ 46411:
/***/ ((module) => {

module.exports = require("@happykit/flags/config");

/***/ }),

/***/ 48095:
/***/ ((module) => {

module.exports = require("@happykit/flags/server");

/***/ }),

/***/ 83218:
/***/ ((module) => {

module.exports = require("@hookform/error-message");

/***/ }),

/***/ 48308:
/***/ ((module) => {

module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ 85360:
/***/ ((module) => {

module.exports = require("@next/env");

/***/ }),

/***/ 64515:
/***/ ((module) => {

module.exports = require("@stripe/react-stripe-js");

/***/ }),

/***/ 20943:
/***/ ((module) => {

module.exports = require("@stripe/stripe-js");

/***/ }),

/***/ 52167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 1043:
/***/ ((module) => {

module.exports = require("lodash.get");

/***/ }),

/***/ 51650:
/***/ ((module) => {

module.exports = require("lodash.uniqby");

/***/ }),

/***/ 54426:
/***/ ((module) => {

module.exports = require("next/dist/compiled/chalk");

/***/ }),

/***/ 40252:
/***/ ((module) => {

module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 19371:
/***/ ((module) => {

module.exports = require("next/dist/compiled/node-fetch");

/***/ }),

/***/ 97999:
/***/ ((module) => {

module.exports = require("next/dist/compiled/path-to-regexp");

/***/ }),

/***/ 60600:
/***/ ((module) => {

module.exports = require("next/dist/server/accept-header.js");

/***/ }),

/***/ 52155:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils/index.js");

/***/ }),

/***/ 90730:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils/node.js");

/***/ }),

/***/ 60562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 94140:
/***/ ((module) => {

module.exports = require("next/dist/server/get-page-files.js");

/***/ }),

/***/ 89716:
/***/ ((module) => {

module.exports = require("next/dist/server/htmlescape.js");

/***/ }),

/***/ 25071:
/***/ ((module) => {

module.exports = require("next/dist/server/render-result.js");

/***/ }),

/***/ 33100:
/***/ ((module) => {

module.exports = require("next/dist/server/render.js");

/***/ }),

/***/ 92779:
/***/ ((module) => {

module.exports = require("next/dist/server/request-meta.js");

/***/ }),

/***/ 79502:
/***/ ((module) => {

module.exports = require("next/dist/server/send-payload.js");

/***/ }),

/***/ 76368:
/***/ ((module) => {

module.exports = require("next/dist/server/utils.js");

/***/ }),

/***/ 56724:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 27664:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/escape-regexp.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 94957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 82374:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-locale-cookie.js");

/***/ }),

/***/ 34014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 78524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 78020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 29565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 64365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 95714:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-route-from-asset-path.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 91292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 25753:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-match.js");

/***/ }),

/***/ 99521:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/prepare-destination.js");

/***/ }),

/***/ 80979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 36052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 84226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 95566:
/***/ ((module) => {

module.exports = require("next/error");

/***/ }),

/***/ 40968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 71853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 59819:
/***/ ((module) => {

module.exports = require("querystring");

/***/ }),

/***/ 16689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 25716:
/***/ ((module) => {

module.exports = require("react-hotjar");

/***/ }),

/***/ 16666:
/***/ ((module) => {

module.exports = require("react-responsive");

/***/ }),

/***/ 1187:
/***/ ((module) => {

module.exports = require("react-toastify");

/***/ }),

/***/ 20997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 57518:
/***/ ((module) => {

module.exports = require("styled-components");

/***/ }),

/***/ 24535:
/***/ ((module) => {

module.exports = require("styled-normalize");

/***/ }),

/***/ 6153:
/***/ ((module) => {

module.exports = require("universal-cookie");

/***/ }),

/***/ 84269:
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ 75609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 61908:
/***/ ((module) => {

module.exports = import("@hookform/resolvers/yup");;

/***/ }),

/***/ 45641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [4357,9703,6114,9067,8183,9899,805,6067,7898,1731], () => (__webpack_exec__(63508)));
module.exports = __webpack_exports__;

})();