"use strict";
(() => {
var exports = {};
exports.id = 5658;
exports.ids = [5658];
exports.modules = {

/***/ 45527:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var recharts__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(36157);
/* harmony import */ var recharts__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(recharts__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(87491);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(72994);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _utils_charts__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(19343);
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(19390);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__);









const Container = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
  displayName: "MeasurementFullBreakdownBarChart__Container",
  componentId: "sc-9h2hzj-0"
})(["", ";display:none;flex-direction:column;align-items:center;background:", ";padding:1.75rem;margin:2rem 0;", " ", " .custom-tooltip{border-radius:50%;backgroundcolor:white;}text{font-size:", ";fill:", ";}.recharts-layer.recharts-cartesian-axis-tick{text{font-size:", ";}}"], _styles__WEBPACK_IMPORTED_MODULE_2__/* .borderRadius */ .E, p => p.theme.colors.white, _theme__WEBPACK_IMPORTED_MODULE_3__/* .media.tablet */ .BC.tablet`
    display: flex;
      width: 90%;
  `, _theme__WEBPACK_IMPORTED_MODULE_3__/* .media.desktop */ .BC.desktop`
    width: 58%;
    margin: initial;
  `, p => p.theme.miniscule.size, p => p.theme.colors.black, p => p.theme.tiny.size);
const InnerContainer = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
  displayName: "MeasurementFullBreakdownBarChart__InnerContainer",
  componentId: "sc-9h2hzj-1"
})(["display:flex;align-items:center;text-align:center;margin:1.625rem 0 0;height:22.5rem;width:100%;", ""], _theme__WEBPACK_IMPORTED_MODULE_3__/* .media.desktop */ .BC.desktop`
    padding: 0 1rem;
  `);
const Legend = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
  displayName: "MeasurementFullBreakdownBarChart__Legend",
  componentId: "sc-9h2hzj-2"
})(["display:flex;"]);
const LegendItem = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
  displayName: "MeasurementFullBreakdownBarChart__LegendItem",
  componentId: "sc-9h2hzj-3"
})(["display:flex;align-items:center;&:not(:last-of-type){margin-right:1.5rem;}"]);
const LegendColor = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
  displayName: "MeasurementFullBreakdownBarChart__LegendColor",
  componentId: "sc-9h2hzj-4"
})(["background-color:", ";height:0.75rem;width:0.75rem;margin-right:0.52rem;"], p => p.color);
const StyledTooltip = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
  displayName: "MeasurementFullBreakdownBarChart__StyledTooltip",
  componentId: "sc-9h2hzj-5"
})(["background-color:", ";border-radius:100%;height:3rem;width:3rem;display:flex;justify-content:center;align-items:center;box-shadow:0px 5px 5px rgba(46,104,241,0.5);"], p => p.theme.colors.backgroundGrey);
const TitleContainer = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
  displayName: "MeasurementFullBreakdownBarChart__TitleContainer",
  componentId: "sc-9h2hzj-6"
})(["align-self:flex-start;display:flex;justify-content:space-between;width:100%;"]);
const SubtitleContainer = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
  displayName: "MeasurementFullBreakdownBarChart__SubtitleContainer",
  componentId: "sc-9h2hzj-7"
})(["width:100%;"]);

const CustomTooltip = ({
  active,
  payload,
  label
}) => {
  if (active && payload && payload.length) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(StyledTooltip, {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
        children: `${payload[0].value}`
      })
    });
  }

  return null;
};

const CustomXAxisTick = props => {
  const {
    x,
    y,
    payload,
    angle
  } = props;
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("g", {
    transform: `translate(${x},${y}) rotate(${angle})`,
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("text", {
      fill: _theme__WEBPACK_IMPORTED_MODULE_3__/* ["default"].colors.black */ .ZP.colors.black,
      textAnchor: "end",
      dominantBaseline: "middle",
      children: payload.value
    })
  });
};

const MeasurementFullBreakdownBarChart = ({
  measurement,
  height = 200,
  width = 700,
  useWidth,
  isMonthly,
  officeId
}) => {
  var _measurement$office_m;

  const scopes = {
    scope_1: ["gas", "vehicle_usage"],
    scope_2: ["electricity"]
  };
  const totalMeasurementResults = (0,_utils_charts__WEBPACK_IMPORTED_MODULE_7__/* .createTotalMeasurementResults */ .d)(measurement);
  const measurementResults = officeId ? measurement === null || measurement === void 0 ? void 0 : (_measurement$office_m = measurement.office_measurements.find(office => office.office_id === officeId)) === null || _measurement$office_m === void 0 ? void 0 : _measurement$office_m.measurement_result : totalMeasurementResults;

  const formatValue = value => isMonthly ? value : value / 1000;

  const data = Object.keys(measurementResults).filter(key => !_utils_constants__WEBPACK_IMPORTED_MODULE_5__/* .EXCLUDED_CHART_KEYS.includes */ .Nx.includes(key)).filter(key => measurementResults[key] > 0).sort((a, b) => measurementResults[a] > measurementResults[b] ? -1 : 1).sort((a, b) => scopes.scope_2.includes(a) && !scopes.scope_2.includes(b) ? -1 : 1).sort((a, b) => scopes.scope_1.includes(a) && !scopes.scope_1.includes(b) ? -1 : 1).map(key => ({
    name: (0,_utils_charts__WEBPACK_IMPORTED_MODULE_7__/* .formatChartLabels */ .e)(key),
    value: parseFloat(formatValue(measurementResults[key]).toFixed(2)),
    key
  }));
  const colorScopes = {
    scope_1: _theme__WEBPACK_IMPORTED_MODULE_3__/* ["default"].colors.graphBlue */ .ZP.colors.graphBlue,
    scope_2: _theme__WEBPACK_IMPORTED_MODULE_3__/* ["default"].colors.graphYellow */ .ZP.colors.graphYellow,
    scope_3: _theme__WEBPACK_IMPORTED_MODULE_3__/* ["default"].colors.graphGreen */ .ZP.colors.graphGreen
  };

  const colorFill = name => scopes.scope_1.includes(name) ? colorScopes["scope_1"] : scopes.scope_2.includes(name) ? colorScopes["scope_2"] : colorScopes["scope_3"];

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(Container, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(TitleContainer, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
        size: "cardHeader",
        children: "Emissions breakdown"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(Legend, {
        children: Object.keys(colorScopes).map(key => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(LegendItem, {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(LegendColor, {
            color: colorScopes[key]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
            size: "smallBold",
            children: key.replace("_", " ").replace(/^\w/, c => c.toUpperCase())
          })]
        }, key))
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(SubtitleContainer, {
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(_common_Text__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
        align: "left",
        size: "miniscule",
        children: ["(", isMonthly ? "kgCO2e" : "tCO2e", ")"]
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(InnerContainer, {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(recharts__WEBPACK_IMPORTED_MODULE_0__.ResponsiveContainer, {
        width: useWidth ? width : "100%",
        height: "100%",
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(recharts__WEBPACK_IMPORTED_MODULE_0__.BarChart, {
          layout: "vertical",
          data: data,
          margin: {
            top: 0,
            right: 20,
            bottom: 0,
            left: 20
          },
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(recharts__WEBPACK_IMPORTED_MODULE_0__.YAxis, {
            type: "category",
            dataKey: "name",
            angle: 0,
            textAnchor: "end",
            axisLine: false,
            tickLine: false,
            tick: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(CustomXAxisTick, {}),
            width: 125,
            interval: 0
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(recharts__WEBPACK_IMPORTED_MODULE_0__.XAxis, {
            type: "number",
            axisLine: false,
            tickLine: false
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(recharts__WEBPACK_IMPORTED_MODULE_0__.Tooltip, {
            content: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(CustomTooltip, {
              width: width
            }),
            cursor: {
              fill: _theme__WEBPACK_IMPORTED_MODULE_3__/* ["default"].colors.transparent */ .ZP.colors.transparent
            }
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(recharts__WEBPACK_IMPORTED_MODULE_0__.CartesianGrid, {
            horizontal: false
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(recharts__WEBPACK_IMPORTED_MODULE_0__.Bar, {
            dataKey: "value",
            maxBarSize: 20,
            children: data.map((entry, index) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(recharts__WEBPACK_IMPORTED_MODULE_0__.Cell, {
              fill: colorFill(entry.key)
            }, `cell-${index}`))
          })]
        })
      })
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MeasurementFullBreakdownBarChart);

/***/ }),

/***/ 18702:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var recharts__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(36157);
/* harmony import */ var recharts__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(recharts__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(87491);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(72994);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _utils_charts__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(19343);
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(19390);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__);









const Container = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
  displayName: "MeasurementScopeBarChart__Container",
  componentId: "pvc2zt-0"
})(["", ";display:flex;flex-direction:column;align-items:center;background:", ";padding:1.125rem 1rem;margin:1rem 0;min-height:24rem;height:fit-content;", " ", " .custom-tooltip{border-radius:50%;backgroundcolor:white;}text{font-size:", ";}.recharts-cartesian-axis-tick{text{font-size:", ";}}"], _styles__WEBPACK_IMPORTED_MODULE_2__/* .borderRadius */ .E, p => p.theme.colors.white, _theme__WEBPACK_IMPORTED_MODULE_3__/* .media.tablet */ .BC.tablet`
      width: 90%;
  `, _theme__WEBPACK_IMPORTED_MODULE_3__/* .media.desktop */ .BC.desktop`
    margin: initial;
    width: 29.25%;
  `, p => p.theme.tiny.size, p => p.theme.tiny.size);
const InnerContainer = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
  displayName: "MeasurementScopeBarChart__InnerContainer",
  componentId: "pvc2zt-1"
})(["display:flex;align-items:center;text-align:center;margin:2rem 0 0;width:100%;"]);
const TitleContainer = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
  displayName: "MeasurementScopeBarChart__TitleContainer",
  componentId: "pvc2zt-2"
})(["display:flex;justify-content:space-between;align-items:center;width:100%;"]);

const CustomXAxisTick = props => {
  const {
    x,
    y,
    payload,
    angle
  } = props;
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("g", {
    transform: `translate(${x},${y + 7.5}) rotate(${angle})`,
    children: payload.value.split(" ").map((w, i) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("text", {
      x: 0,
      y: 0 + i * 10,
      fill: _theme__WEBPACK_IMPORTED_MODULE_3__/* ["default"].colors.black */ .ZP.colors.black,
      textAnchor: "middle",
      dominantBaseline: "middle",
      children: w
    }))
  });
};

const MeasurementScopeBarChart = ({
  measurement,
  scope,
  isMonthly,
  officeId
}) => {
  var _measurement$office_m, _formatValue;

  const scopes = {
    scope_1: ["gas", "vehicle_usage"],
    scope_2: ["electricity"],
    scope_3: ["water", "waste", "commutes", "business_travel"]
  };
  const totalMeasurementResults = (0,_utils_charts__WEBPACK_IMPORTED_MODULE_7__/* .createTotalMeasurementResults */ .d)(measurement);
  const measurementResults = officeId ? measurement === null || measurement === void 0 ? void 0 : (_measurement$office_m = measurement.office_measurements.find(office => office.office_id === officeId)) === null || _measurement$office_m === void 0 ? void 0 : _measurement$office_m.measurement_result : totalMeasurementResults;

  const formatValue = value => !value ? 0 : isMonthly ? value : value / 1000;

  const data = Object.keys(measurementResults).filter(key => !_utils_constants__WEBPACK_IMPORTED_MODULE_5__/* .EXCLUDED_CHART_KEYS.includes */ .Nx.includes(key)).filter(key => scopes[scope].includes(key)).sort((a, b) => measurementResults[a] > measurementResults[b] ? -1 : 1).map(key => ({
    name: (0,_utils_charts__WEBPACK_IMPORTED_MODULE_7__/* .formatChartLabels */ .e)(key),
    value: parseFloat(formatValue(measurementResults[key]).toFixed(1)),
    key
  }));
  const colorScopes = {
    scope_1: _theme__WEBPACK_IMPORTED_MODULE_3__/* ["default"].colors.graphBlue */ .ZP.colors.graphBlue,
    scope_2: _theme__WEBPACK_IMPORTED_MODULE_3__/* ["default"].colors.graphYellow */ .ZP.colors.graphYellow,
    scope_3: _theme__WEBPACK_IMPORTED_MODULE_3__/* ["default"].colors.graphGreen */ .ZP.colors.graphGreen
  };

  const colorFill = name => scopes.scope_1.includes(name) ? colorScopes["scope_1"] : scopes.scope_2.includes(name) ? colorScopes["scope_2"] : colorScopes["scope_3"];

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(Container, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(TitleContainer, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
        size: "cardHeader",
        capitalize: true,
        children: scope.replace(/_/gi, " ")
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(_common_Text__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
        fontWeight: 400,
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
          size: "h3",
          children: (_formatValue = formatValue(measurementResults === null || measurementResults === void 0 ? void 0 : measurementResults[scope])) === null || _formatValue === void 0 ? void 0 : _formatValue.toFixed(1)
        }), " ", isMonthly ? "kgCO2e" : "tCO2e"]
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(InnerContainer, {
      scope: scope,
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(recharts__WEBPACK_IMPORTED_MODULE_0__.ResponsiveContainer, {
        width: "100%",
        height: 280,
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(recharts__WEBPACK_IMPORTED_MODULE_0__.BarChart, {
          data: data,
          margin: {
            left: -35,
            right: 5
          },
          barCategoryGap: 0,
          barGap: 0,
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(recharts__WEBPACK_IMPORTED_MODULE_0__.YAxis, {
            type: "number",
            axisLine: false,
            tickLine: false
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(recharts__WEBPACK_IMPORTED_MODULE_0__.XAxis, {
            type: "category",
            dataKey: "name",
            angle: 0,
            textAnchor: "middle",
            interval: 0,
            axisLine: false,
            tickLine: false,
            tick: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(CustomXAxisTick, {})
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(recharts__WEBPACK_IMPORTED_MODULE_0__.CartesianGrid, {
            vertical: false
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(recharts__WEBPACK_IMPORTED_MODULE_0__.Bar, {
            isAnimationActive: false,
            dataKey: "value",
            maxBarSize: 15,
            minPointSize: 5,
            children: data.map((entry, index) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(recharts__WEBPACK_IMPORTED_MODULE_0__.Cell, {
              fill: colorFill(entry.key)
            }, `cell-${index}`))
          })]
        })
      })
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MeasurementScopeBarChart);

/***/ }),

/***/ 81667:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(74146);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(date_fns__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16666);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_responsive__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_common_InputDropdown__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(31217);
/* harmony import */ var _components_common_LoadingLarge__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(49899);
/* harmony import */ var _components_common_Page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(97598);
/* harmony import */ var _components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(60805);
/* harmony import */ var _components_common_Text__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(87491);
/* harmony import */ var _components_ContentContainer__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(16067);
/* harmony import */ var _components_measurement_MeasurementFullBreakdownBarChart__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(45527);
/* harmony import */ var _components_measurement_MeasurementPieChart__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(95411);
/* harmony import */ var _components_measurement_MeasurementScopeBarChart__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(18702);
/* harmony import */ var _contexts_measurements__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(85238);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(72994);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_6__]);
_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
















var AssetsIcon = function AssetsIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("g", {
      clipPath: "url(#clip0_1482:31467)",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
        d: "M58.238 13.411l-4.18-2.389a7 7 0 0 0 .141-7.194 5.625 5.625 0 0 0-4.875-2.83h-7.613a9.193 9.193 0 0 0-5.476 1.825l-2.953 2.214a3.165 3.165 0 0 1-4.125-.292l-1.266-1.27a4.59 4.59 0 0 0-5.953-.485l-.365.237A13 13 0 0 0 0 13a13.04 13.04 0 0 0 5 10.25v3.75a1 1 0 0 0 1 1h1v20a1 1 0 0 0 .293.708l5 5a.998.998 0 0 0 1.415 0l5-5a1.001 1.001 0 0 0 .293-.707v-4a1 1 0 0 0-.445-.833l-1.75-1.168 1.75-1.167a1 1 0 0 0 .302-1.348l-2.599-4.33 2.45-2.447a1 1 0 0 0 .292-.708v-4h1a1 1 0 0 0 1-1v-3.75a13.038 13.038 0 0 0 5-10.25 12.887 12.887 0 0 0-3-8.312l.053-.035a2.602 2.602 0 0 1 3.428.236l1.269 1.272a5.178 5.178 0 0 0 6.735.477l2.948-2.214a7.178 7.178 0 0 1 4.276-1.425h7.613a3.625 3.625 0 0 1 3.14 1.823 5 5 0 0 1-.144 5.207l-5.581-3.19a3.517 3.517 0 0 0-3.473 0l-11.5 6.573A3.506 3.506 0 0 0 30 16.45V56.5a3.5 3.5 0 0 0 3.5 3.5h23a3.5 3.5 0 0 0 3.5-3.5V16.45a3.506 3.506 0 0 0-1.763-3.039zM17.001 31.585l-2.708 2.707a1 1 0 0 0-.15 1.222l2.51 4.182-2.208 1.47a1 1 0 0 0 0 1.666L17 44.535v3.05l-4 4.001-4-4V27.999h8v3.586zM19 26H7v-4h12v4zm5-13a11.03 11.03 0 0 1-3.074 7.625 1 1 0 0 0-.926-.625H6a1 1 0 0 0-.927.625A11 11 0 0 1 13 1.998a10.91 10.91 0 0 1 6.818 2.375l-4.041 2.625H8.302A2.304 2.304 0 0 0 6 9.3v1.397A2.304 2.304 0 0 0 8.302 13h9.397a2.304 2.304 0 0 0 2.302-2.302V9.3a2.3 2.3 0 0 0-1.092-1.954l2.394-1.558a10.907 10.907 0 0 1 2.698 7.21zm-6.302-4a.301.301 0 0 1 .301.3v1.398a.301.301 0 0 1-.3.302H8.301A.301.301 0 0 1 8 10.697V9.3a.301.301 0 0 1 .302-.302h4.402l-.25.162a1 1 0 0 0 1.09 1.677l2.831-1.839H17.7zm40.303 47.5a1.5 1.5 0 0 1-1.5 1.5H33.5a1.5 1.5 0 0 1-1.5-1.5V16.45a1.5 1.5 0 0 1 .756-1.303l11.5-6.571a1.5 1.5 0 0 1 1.488 0l5.118 2.923-2.487 1.81a5 5 0 1 0 1.178 1.618l2.686-1.953c.175-.128.342-.262.5-.403l4.512 2.576a1.5 1.5 0 0 1 .75 1.303V56.5zm-10-39.5a3 3 0 1 1-1.303-2.472l-2.286 1.663a1 1 0 1 0 1.177 1.617l2.286-1.663c.084.277.126.565.125.855z"
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("defs", {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("clipPath", {
        id: "clip0_1482:31467",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
          fill: "#fff",
          d: "M0 0h60v60H0z"
        })
      })
    })]
  }));
};

AssetsIcon.defaultProps = {
  width: "60",
  height: "60",
  viewBox: "0 0 60 60",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var CapitalGoodsIcon = function CapitalGoodsIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)("g", {
      clipPath: "url(#clip0_1481:31459)",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
        d: "M32.809 55.458H12.524a9.857 9.857 0 0 1-8.123-15.442l12.3-17.89h11.931l12.37 19.4 2.198-1.51-12.533-19.638v-4.475l3.05-4.067a4.75 4.75 0 0 0-5.924-7.098L22.667 7.3 17.54 4.738a4.75 4.75 0 0 0-5.923 7.098l3.05 4.067v4.475L2.204 38.505a12.524 12.524 0 0 0 10.32 19.62H32.81c.194 0 6.897-.005 7.091-.014l-.122-2.663c-.154.007-6.816.01-6.969.01zm-15.476-36v-2.666H28v2.666H17.333zm-4-10.472a2.084 2.084 0 0 1 3.015-1.863l5.722 2.861a1.333 1.333 0 0 0 1.193 0l5.722-2.86a2.083 2.083 0 0 1 2.598 3.112l-2.916 3.89h-12l-2.917-3.89c-.27-.36-.416-.8-.417-1.25z"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
        d: "M26.666 38.125v-.194A3.812 3.812 0 0 0 24 34.299v-1.507h-2.667v1.507a3.806 3.806 0 0 0-.563 7.035l2.6 1.3a1.138 1.138 0 0 1-.509 2.158h-.389a1.14 1.14 0 0 1-1.139-1.14v-.194h-2.666v.195a3.812 3.812 0 0 0 2.666 3.631v1.508H24v-1.508a3.806 3.806 0 0 0 .563-7.035l-2.6-1.3a1.139 1.139 0 0 1 .509-2.157h.389A1.14 1.14 0 0 1 24 37.93v.194h2.666zM16 39.458h-2.667v2.667H16v-2.667zM32 39.458h-2.666v2.667H32v-2.667zM60 43.458a4.005 4.005 0 0 0-4-4H40a3.997 3.997 0 0 0-3.717 5.475 4 4 0 0 0 0 7.718A3.998 3.998 0 0 0 40 58.125h16a4 4 0 0 0 1.05-7.859 3.983 3.983 0 0 0 0-2.949A4.006 4.006 0 0 0 60 43.458zm-22.666 4h16a1.333 1.333 0 0 1 0 2.667h-16a1.333 1.333 0 0 1 0-2.667zm18.666 8H40a1.333 1.333 0 1 1 0-2.666h16a1.333 1.333 0 1 1 0 2.666zm0-10.666H40a1.333 1.333 0 1 1 0-2.667h16a1.334 1.334 0 0 1 0 2.667z"
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("defs", {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("clipPath", {
        id: "clip0_1481:31459",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
          fill: "#fff",
          d: "M0 0h60v60H0z"
        })
      })
    })]
  }));
};

CapitalGoodsIcon.defaultProps = {
  width: "60",
  height: "60",
  viewBox: "0 0 60 60",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var CommuteIcon = function CommuteIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
      d: "M21.339 37.071H6.61c-1.507 0-2.762-1.255-2.762-2.761V18.745c0-1.507 1.255-2.762 2.762-2.762h14.728c1.506 0 2.761 1.255 2.761 2.762V34.31c0 1.506-1.255 2.761-2.761 2.761zM6.61 18.075a.66.66 0 0 0-.67.67V34.31c0 .334.251.67.67.67h14.728a.66.66 0 0 0 .67-.67V18.745a.66.66 0 0 0-.67-.67H6.61zM44.183 35.983H29.455c-.92 0-1.673-.753-1.673-1.673M66.945 37.071H52.217c-1.506 0-2.761-1.255-2.761-2.761V18.745c0-1.507 1.255-2.762 2.761-2.762h14.728c1.507 0 2.762 1.255 2.762 2.762V34.31c-.084 1.506-1.255 2.761-2.762 2.761zM52.217 18.075a.66.66 0 0 0-.67.67V34.31c0 .334.252.67.67.67h14.728a.66.66 0 0 0 .67-.67V18.745a.66.66 0 0 0-.67-.67H52.217z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
      d: "M44.184 15.983H29.456c-1.506 0-2.761 1.255-2.761 2.762V34.31c0 1.506 1.255 2.761 2.761 2.761h14.728c1.507 0 2.762-1.255 2.762-2.761V18.745c-.084-1.507-1.255-2.762-2.762-2.762zM28.787 34.31V18.745a.66.66 0 0 1 .67-.67h14.727a.66.66 0 0 1 .67.67V34.31a.66.66 0 0 1-.67.67h-.92v-2.93c0-2.427-1.925-4.435-4.268-4.435h-4.351c-2.344 0-4.268 2.008-4.268 4.435v2.93h-.92a.66.66 0 0 1-.67-.67zm3.682.67v-2.93c0-1.255 1.004-2.343 2.176-2.343h4.351c1.172 0 2.176 1.004 2.176 2.343v2.93h-8.703z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
      d: "M40.837 23.096c0-2.26-1.84-4.017-4.016-4.017s-4.017 1.841-4.017 4.017 1.841 4.017 4.017 4.017c2.175 0 4.016-1.841 4.016-4.017zm-6.025 0c0-1.088.837-1.924 1.925-1.924s1.925.836 1.925 1.924a1.894 1.894 0 0 1-1.925 1.925c-1.088 0-1.925-.92-1.925-1.925z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
      d: "M58.912 57.824c2.594-1.255 4.352-3.85 4.352-6.945v-.335h7.698c1.507 0 2.762-1.255 2.762-2.762V13.054c0-1.506-1.255-2.761-2.762-2.761h-9.958l2.762-2.762c.334-.334.418-.836.167-1.255L60.418.502C60.251.167 59.916 0 59.498 0c-.335 0-.67.167-.92.502l-3.432 5.69c-.25.419-.167.921.168 1.256l2.845 2.845H15.481l2.762-2.762c.334-.334.418-.836.167-1.255L14.895.502C14.728.167 14.31 0 13.975 0c-.335 0-.67.167-.92.502l-3.432 5.69c-.25.419-.167.921.168 1.256l2.845 2.845H2.762C1.255 10.293 0 11.548 0 13.054v34.812c0 1.506 1.255 2.762 2.762 2.762h5.94v.334c0 3.097 1.758 5.69 4.352 6.946H0V60h73.724v-2.092H58.912v-.084zm.586-54.728l2.176 3.599-2.092 2.092-2.176-2.176 2.092-3.515zm-45.523 0l2.176 3.599-2.092 2.092-2.176-2.176 2.092-3.515zM61.172 50.88a5.607 5.607 0 0 1-11.214 0v-.335h11.214v.335zM2.762 12.385h68.2a.66.66 0 0 1 .67.67v29.54H2.176v-29.54c-.084-.335.25-.67.586-.67zm-.67 35.481v-3.18h69.456v3.18a.66.66 0 0 1-.67.67H2.763c-.335-.084-.67-.335-.67-.67zm8.62 3.013v-.335h11.213v.335a5.607 5.607 0 0 1-11.214 0zm13.388 0v-.335h23.766v.335c0 3.096 1.757 5.69 4.352 6.945H19.749c2.594-1.255 4.351-3.85 4.351-6.945z"
    })]
  }));
};

CommuteIcon.defaultProps = {
  width: "74",
  height: "60",
  viewBox: "0 0 74 60",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var DisposalIcon = function DisposalIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
      d: "M58.583 52.348h-.966v-6.326c0-3.169-2.585-5.746-5.762-5.746H41.552v-.942c0-.788-.635-1.428-1.418-1.428h-4.01v-2.214c0-2.182-1.184-4.201-3.09-5.271l-6.982-3.92v-1.99h1.272c.783 0 1.417-.639 1.417-1.427v-4.078h1.444a4.093 4.093 0 0 0 3.985-3.224l1.735-8.17a3.36 3.36 0 0 0 2.879-3.33V2.766C38.784.91 37.284-.6 35.44-.6H3.343C1.5-.6 0 .91 0 2.766v1.516c0 1.846 1.484 3.349 3.313 3.365l1.728 8.134a4.093 4.093 0 0 0 3.985 3.225h1.265v4.077c0 .789.634 1.428 1.417 1.428h1.406v1.99l-6.982 3.92a6.054 6.054 0 0 0-3.09 5.27V56.54a4.067 4.067 0 0 0 4.065 4.06H32.06a4.067 4.067 0 0 0 4.065-4.06v-3.888h4.01c.783 0 1.417-.64 1.417-1.428v-.941h6.036v2.065h-.966c-.783 0-1.418.64-1.418 1.428v5.396c0 .789.635 1.428 1.418 1.428h11.962c.782 0 1.417-.64 1.417-1.428v-5.396c0-.788-.634-1.428-1.417-1.428zM13.126 21.656v-2.628h12.78v2.628h-12.78zM2.836 4.283V2.767a.51.51 0 0 1 .506-.51h32.1c.279 0 .507.229.507.51v1.516a.51.51 0 0 1-.508.51H3.342a.51.51 0 0 1-.507-.51zm4.977 10.9l-1.6-7.534h26.785l-1.6 7.535c-.12.56-.63.966-1.213.966H9.026a1.239 1.239 0 0 1-1.213-.966zM33.289 56.54c0 .664-.552 1.204-1.23 1.204H7.107c-.678 0-1.23-.54-1.23-1.204V35.692c0-1.147.626-2.21 1.635-2.777l7.71-4.328c.449-.252.727-.73.727-1.247v-2.828h7.267v2.828c0 .518.279.995.728 1.247l7.709 4.328a3.192 3.192 0 0 1 1.636 2.777V56.54zm5.427-6.743h-2.592v-9.035h2.592v9.035zm10.29-2.37h-7.454v-4.295h10.303c1.614 0 2.927 1.297 2.927 2.89v6.327h-4.36v-3.494c0-.789-.634-1.428-1.417-1.428zm8.16 10.317h-9.127v-2.54h9.127v2.54z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
      d: "M28.178 42.185a.938.938 0 0 0-1.618.947l2.636 4.505c.25.426.086.804.005.947a.982.982 0 0 1-.864.493h-4.295l.04-.03a.937.937 0 1 0-1.126-1.498l-2.28 1.714a.939.939 0 0 0-.002 1.498l2.276 1.719a.937.937 0 0 0 1.13-1.496l-.041-.032h4.297a2.838 2.838 0 0 0 2.491-1.436 2.79 2.79 0 0 0-.012-2.826l-2.637-4.505zM20.394 33.541c.173 0 .602.05.858.49l2.135 3.674-.077-.032a.937.937 0 1 0-.72 1.73l2.64 1.1a.937.937 0 0 0 1.29-.74l.38-2.804a.938.938 0 0 0-1.859-.251l-.012.09-2.156-3.71a2.84 2.84 0 0 0-2.473-1.422h-.01c-1.029 0-1.953.526-2.472 1.407l-2.65 4.497a.938.938 0 0 0 1.616.952l2.65-4.497a.978.978 0 0 1 .858-.484h.002zM17.648 49.056h-5.276a.983.983 0 0 1-.864-.495.926.926 0 0 1 .007-.948l2.19-3.712.01.09a.938.938 0 0 0 1.86-.236l-.354-2.807a.938.938 0 0 0-1.283-.751l-2.65 1.077a.938.938 0 0 0 .705 1.737l.078-.032L9.9 46.66a2.788 2.788 0 0 0-.02 2.83 2.837 2.837 0 0 0 2.493 1.441h5.276a.937.937 0 0 0 0-1.875z"
    })]
  }));
};

DisposalIcon.defaultProps = {
  viewBox: "0 0 60 60",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var ElectricityIcon = function ElectricityIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("g", {
      clipPath: "url(#clip0_992_15070)",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
        d: "M48.75 24.375H35.33l-.807-7.5h7.664v2.813a.938.938 0 0 0 1.876 0v-3.75a.937.937 0 0 0-.938-.938h-8.798L32.813.839A.938.938 0 0 0 31.875 0h-3.75a.937.937 0 0 0-.938.839L25.674 15h-8.798a.938.938 0 0 0-.938.938v3.75a.938.938 0 0 0 1.876 0v-2.813h7.664l-.807 7.5H11.25a.938.938 0 0 0-.938.938v3.75a.938.938 0 0 0 1.876 0V26.25h12.28L21.657 52.5h-.093a2.813 2.813 0 0 0-2.813 2.813v2.812h-6.563a.938.938 0 0 0 0 1.875h35.626a.938.938 0 0 0 0-1.875H41.25v-2.813a2.813 2.813 0 0 0-2.813-2.812h-.093L35.53 26.25h12.282v2.813a.938.938 0 0 0 1.874 0v-3.75a.937.937 0 0 0-.937-.938zm-19.781-22.5h2.062L32.438 15h-4.876L28.97 1.875zm-1.608 15h5.278l.806 7.5h-6.89l.806-7.5zm12.014 38.438v2.812h-18.75v-2.813a.937.937 0 0 1 .938-.937h16.875a.938.938 0 0 1 .937.938zm-2.92-2.813h-12.91l2.813-26.25h7.284l2.813 26.25z"
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("defs", {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("clipPath", {
        id: "clip0_992_15070",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
          fill: "#fff",
          d: "M0 0h60v60H0z"
        })
      })
    })]
  }));
};

ElectricityIcon.defaultProps = {
  width: "60",
  height: "60",
  viewBox: "0 0 60 60",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var FranchiseIcon = function FranchiseIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)("g", {
      clipPath: "url(#clip0_1485:31517)",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
        d: "M29 3.414V10h2V3.414l1.293 1.293 1.414-1.414-3-3a1 1 0 0 0-1.414 0l-3 3 1.414 1.414L29 3.414zM31 56.586V50h-2v6.586l-1.293-1.293-1.414 1.414 3 3a1 1 0 0 0 1.414 0l3-3-1.414-1.414L31 56.586zM59.707 29.293l-3-3-1.414 1.414L56.586 29H51v2h5.586l-1.293 1.293 1.414 1.414 3-3a1 1 0 0 0 0-1.414zM47.707 13.707L52 9.414V12h2V7a1 1 0 0 0-1-1h-5v2h2.586l-4.293 4.293 1.414 1.414zM52 50.586l-4.293-4.293-1.414 1.414L50.586 52H48v2h5a1 1 0 0 0 1-1v-5h-2v2.586zM9 31v-2H3.414l1.293-1.293-1.414-1.414-3 3a1 1 0 0 0 0 1.414l3 3 1.414-1.414L3.414 31H9zM8 9.414l4.293 4.293 1.414-1.414L9.414 8H12V6H7a1 1 0 0 0-1 1v5h2V9.414zM12.293 46.293L8 50.586V48H6v5a1 1 0 0 0 1 1h5v-2H9.414l4.293-4.293-1.414-1.414zM47 30.308v-9.154c0-.203-.047-.403-.138-.585l-2.194-4.388-1.233-2.466-.496-.992a1.308 1.308 0 0 0-1.17-.723H18.231a1.307 1.307 0 0 0-1.17.723l-.496.992-1.233 2.466-2.194 4.388c-.09.182-.138.382-.138.585V44.15L14.85 46H45.15L47 44.15V30.309zm-28.77-7.846v1.307a1.308 1.308 0 0 1-2.615 0v-1.307h2.616zm13.577-7.847l-2.615 5.231h-2.307l2.615-5.23h2.307zm2.616 5.231h-2.307l2.615-5.23h2.307l-2.615 5.23zm-10.462 0h-2.307l2.616-5.23h2.306l-2.615 5.23zm-3.115 2.616h2.616v1.307a1.307 1.307 0 1 1-2.616 0v-1.307zm5.23 0h2.616v1.307a1.308 1.308 0 0 1-2.615 0v-1.307zm5.232 0h2.615v1.307a1.308 1.308 0 0 1-2.615 0v-1.307zm5.23 0h2.616v1.307a1.307 1.307 0 1 1-2.616 0v-1.307zm5.231 0h2.616v1.307a1.308 1.308 0 0 1-2.616 0v-1.307zm-.154-6.539l-1.962 3.923h-2.306l2.615-5.23h.999l.654 1.307zm-22.576-1.308h2.307l-2.616 5.231h-2.306l2.615-5.23zm14.884 28.77V32.923h5.23v10.462h-5.23zm7.846 0v-11.77a1.308 1.308 0 0 0-1.307-1.307h-7.847a1.309 1.309 0 0 0-1.307 1.307v11.77H15.615V27.467a3.914 3.914 0 0 0 3.923-.777 3.914 3.914 0 0 0 5.231 0 3.914 3.914 0 0 0 5.231 0 3.914 3.914 0 0 0 5.23 0 3.914 3.914 0 0 0 5.232 0 3.914 3.914 0 0 0 3.923.777v15.918h-2.616z"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
        d: "M27.5 30h-9a1.5 1.5 0 0 0-1.5 1.5v9a1.5 1.5 0 0 0 1.5 1.5h9a1.5 1.5 0 0 0 1.5-1.5v-9a1.5 1.5 0 0 0-1.5-1.5zM26 39h-6v-6h6v6z"
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("defs", {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("clipPath", {
        id: "clip0_1485:31517",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
          fill: "#fff",
          d: "M0 0h60v60H0z"
        })
      })
    })]
  }));
};

FranchiseIcon.defaultProps = {
  width: "60",
  height: "60",
  viewBox: "0 0 60 60",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var HomeworkingIcon = function HomeworkingIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
      d: "M42.692 4.615c-.634 0-1.153.52-1.153 1.154v13.37L28.506 6.108a1.137 1.137 0 0 0-.814-.338 1.18 1.18 0 0 0-.813.338L.336 32.648a1.15 1.15 0 0 0 0 1.627l3.461 3.462c.226.226.522.34.818.34v20.77A1.154 1.154 0 0 0 5.77 60h43.846a1.154 1.154 0 0 0 1.154-1.154v-20.77c.297 0 .593-.113.818-.34l3.462-3.46a1.151 1.151 0 0 0 0-1.628l-4.28-4.28V5.77a1.154 1.154 0 0 0-1.154-1.154h-6.923zm1.154 2.308h4.616l.004 19.142-4.618-4.617-.002-14.525zm-16.154 1.63c8.3 8.309 16.608 16.602 24.91 24.909l-1.833 1.827-22.263-22.261a1.15 1.15 0 0 0-1.627 0L4.615 35.289l-1.832-1.827 24.91-24.91zm0 6.925l20.77 20.769v21.445H6.923l.009-21.454 20.76-20.76z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
      d: "M23.077 30a1.154 1.154 0 0 0-1.154 1.154v3.461h-3.461A3.48 3.48 0 0 0 15 38.078v11.538a3.48 3.48 0 0 0 3.462 3.462h18.461a3.48 3.48 0 0 0 3.462-3.462V38.078a3.48 3.48 0 0 0-3.462-3.462h-3.461v-3.461A1.154 1.154 0 0 0 32.308 30h-9.231zm1.154 2.308h6.923v2.307H24.23v-2.307zm-5.77 4.615h18.462c.66 0 1.154.495 1.154 1.154v3.462h-20.77v-3.462c0-.66.495-1.154 1.155-1.154zm-1.153 6.923h5.769V45a1.14 1.14 0 0 0 1.167 1.154A1.144 1.144 0 0 0 25.384 45v-1.154H30v1.14a1.153 1.153 0 1 0 2.308.002v-1.142h5.769v5.77c0 .659-.495 1.153-1.154 1.153H18.461c-.659 0-1.153-.494-1.153-1.154v-5.769zM41.539 2.308a1.154 1.154 0 1 0 0-2.308 1.154 1.154 0 0 0 0 2.308zM46.154 2.308a1.154 1.154 0 1 0 0-2.308 1.154 1.154 0 0 0 0 2.308zM50.77 2.308a1.154 1.154 0 1 0 0-2.308 1.154 1.154 0 0 0 0 2.308z"
    })]
  }));
};

HomeworkingIcon.defaultProps = {
  width: "56",
  height: "60",
  viewBox: "0 0 56 60",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var InvestmentsIcon = function InvestmentsIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)("g", {
      clipPath: "url(#clip0_1486:31537)",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
        d: "M31.223 17.147v-1.16a3.5 3.5 0 0 0 2.27-3.267A3.506 3.506 0 0 0 29.99 9.22a1.365 1.365 0 1 1 1.365-1.365 1.068 1.068 0 1 0 2.137 0 3.5 3.5 0 0 0-2.269-3.267V3.43a1.068 1.068 0 1 0-2.138 0v1.055c-1.491.402-2.598 1.752-2.598 3.369a3.506 3.506 0 0 0 3.502 3.501 1.365 1.365 0 0 1 .002 2.73 1.365 1.365 0 0 1-1.364-1.363 1.068 1.068 0 1 0-2.138 0c0 1.616 1.106 2.966 2.597 3.368v1.057a1.068 1.068 0 1 0 2.137 0z"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
        d: "M48.387 30.886c-2.756-.529-6.113-.072-9.985 1.354a40.517 40.517 0 0 0-5.32 2.454v-2.999c.207-.17.454-.37.729-.593a92.957 92.957 0 0 0 1.903-1.568c.802.776 1.747 1.246 2.78 1.37.164.018.342.03.532.03 1.114 0 2.67-.397 4.467-1.972 1.962-1.722 3.322-4.854 4.052-6.535.124-.286.219-.511.287-.65a1.068 1.068 0 0 0-.52-1.73l-.056-.014c-.509-.128-5.248-1.267-8.692.045-2.93 1.12-4.637 3.08-4.68 5.379-.012.71.174 1.452.552 2.2l.055.109c-.4.347-.911.77-1.407 1.174v-8.837c4.167-1.316 7.197-5.217 7.197-9.813C40.281 4.616 35.665 0 29.991 0c-5.674 0-10.29 4.616-10.29 10.29 0 4.596 3.031 8.497 7.198 9.813v8.232c-.512-.468-1.018-.937-1.417-1.316l.063-.126c.378-.749.564-1.49.552-2.205-.043-2.298-1.748-4.258-4.68-5.377-3.443-1.312-8.185-.175-8.692-.045l-.055.015a1.067 1.067 0 0 0-.52 1.73c.067.138.162.364.287.648.73 1.681 2.09 4.814 4.053 6.537 1.797 1.573 3.352 1.97 4.465 1.97.19 0 .368-.012.532-.03 1.023-.121 1.957-.586 2.754-1.347.838.788 1.98 1.823 2.658 2.425v3.482a40.334 40.334 0 0 0-5.322-2.454c-3.871-1.426-7.23-1.883-9.983-1.354a1.07 1.07 0 0 0-.203 2.04c.076.03 6.517 2.695 9.987 5.87h-4.292c-.591 0-1.069.478-1.069 1.07V43.6c0 .591.478 1.07 1.069 1.07h2.035l1.552 9.46h-1.681c-.591 0-1.069.477-1.069 1.068v3.733c0 .591.478 1.069 1.069 1.069h21.995c.59 0 1.069-.478 1.069-1.069v-3.733c0-.59-.478-1.069-1.07-1.069h-1.68l1.551-9.46h2.036c.59 0 1.069-.478 1.069-1.069v-3.733c0-.59-.478-1.069-1.07-1.069h-4.291c3.468-3.175 9.911-5.84 9.987-5.87a1.071 1.071 0 0 0-.201-2.042zm-9.062-8.81c1.95-.743 4.588-.482 6.137-.226-.653 1.499-1.876 4.184-3.38 5.504-1.196 1.048-2.35 1.545-3.336 1.424-.611-.072-1.097-.381-1.483-.737 1.418-1.442 2.897-2.85 4.59-3.644.112-.053.227-.102.34-.15l.075-.031c.544-.231.761-.841.532-1.385-.23-.542-.889-.782-1.438-.554-.138.059-.276.116-.415.182-1.843.864-3.413 2.284-4.819 3.69-.07-.23-.112-.45-.109-.655.028-1.38 1.233-2.626 3.306-3.418zm-18.09 5.935c-.986.12-2.14-.377-3.335-1.423-1.506-1.321-2.728-4.007-3.382-5.505 1.552-.256 4.19-.517 6.137.225 2.074.791 3.279 2.038 3.304 3.419.004.204-.04.425-.109.655-1.54-1.542-3.194-3.02-5.31-3.905a1.069 1.069 0 1 0-.825 1.974c1.917.801 3.497 2.293 5.001 3.822-.385.356-.871.665-1.481.738zm.604-17.722c0-4.495 3.656-8.152 8.151-8.152 4.495 0 8.152 3.657 8.152 8.152 0 4.495-3.657 8.151-8.152 8.151-4.495 0-8.151-3.657-8.151-8.151zm9.106 10.29v18.218h-1.908V20.578h1.908zm-14.3 12.489c1.297.234 2.697.627 4.19 1.178 2.632.975 4.863 2.203 5.96 2.849.033.019.07.02.104.035v1.667h-2.623c-1.728-2.241-4.939-4.288-7.63-5.73zM39.92 57.86H20.062v-1.595h19.857v1.595zm-2.778-3.733h-14.3l-1.552-9.46h17.403l-1.551 9.46zm4.684-11.598H18.156v-1.595h23.67v1.595h-.001zm-6.119-3.733h-2.623V37.13c.034-.015.07-.016.104-.035 1.096-.646 3.328-1.874 5.957-2.848 1.495-.552 2.895-.944 4.192-1.18-2.692 1.442-5.905 3.489-7.63 5.73z"
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("defs", {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("clipPath", {
        id: "clip0_1486:31537",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
          fill: "#fff",
          d: "M0 0h60v60H0z"
        })
      })
    })]
  }));
};

InvestmentsIcon.defaultProps = {
  width: "60",
  height: "60",
  viewBox: "0 0 60 60",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
}; // Scope Analysis

var OfficeIcon = function OfficeIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)("g", {
      clipPath: "url(#clip0_1038:16439)",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
        d: "M45.894 27.528h-2.046v3.276h2.046v-3.276zM49.938 27.528h-2.046v3.276h2.046v-3.276zM53.976 27.528H51.93v3.276h2.046v-3.276zM45.894 33.78h-2.046v3.276h2.046V33.78zM49.938 33.78h-2.046v3.276h2.046V33.78zM53.976 33.78H51.93v3.276h2.046V33.78zM45.894 40.068h-2.046v3.276h2.046v-3.276zM49.938 40.068h-2.046v3.276h2.046v-3.276zM53.976 40.068H51.93v3.276h2.046v-3.276zM45.894 46.134h-2.046v3.276h2.046v-3.276zM49.938 46.134h-2.046v3.276h2.046v-3.276zM53.976 46.134H51.93v3.276h2.046v-3.276zM6.78 44.106H4.734v3.276H6.78v-3.276zM10.824 44.106H8.778v3.276h2.046v-3.276zM14.862 44.106h-2.046v3.276h2.046v-3.276zM6.78 37.8H4.734v3.276H6.78V37.8zM10.824 37.8H8.778v3.276h2.046V37.8zM14.862 37.8h-2.046v3.276h2.046V37.8zM34.746 21.786H23.1v2.04h11.646v-2.04zM34.746 27.126H23.1v2.04h11.646v-2.04zM34.746 32.46H23.1v2.04h11.646v-2.04zM34.746 37.8H23.1v2.04h11.646V37.8zM34.746 43.134H23.1v2.04h11.646v-2.04zM34.746 16.452H23.1v2.04h11.646v-2.04z"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
        d: "M59.262 23.298l-.054 35.232v1.368h-1.374L0 59.976V34.23l16.728-3.972c.162-.036.318-.084.54-.15V10.116h4.752v-5.7h5.886v-1.83V.024h2.004V4.44h5.874V10.122h4.74v11.67h18.714l.024 1.506zm-20.79 34.62V12.18H19.344v45.738h19.128zm13.476-4.134v4.074h5.226v-34.02H40.59V57.87h5.298v-5.316h6.066l-.006 1.23zm-34.71-21.57l-15.186 3.6v22.11h15.186v-25.71zm16.518-22.122V6.45h-9.684v3.642h9.684zm14.19 47.796h1.968v-3.282h-1.938l-.03 3.282z"
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("defs", {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("clipPath", {
        id: "clip0_1038:16439",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
          fill: "#fff",
          d: "M0 0h59.262v60H0z"
        })
      })
    })]
  }));
};

OfficeIcon.defaultProps = {
  width: "60",
  height: "60",
  viewBox: "0 0 60 60",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var ProcessingIcon = function ProcessingIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)("g", {
      clipPath: "url(#clip0_1484:31495)",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
        d: "M41.981 27.17H25.894v7.013H41.98V27.17zm-14.093 5.083v-3.025h12.099v3.025H27.888z"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
        d: "M45.971 37.272V10.116H13.796V37.272l-.065 1.03h-7.98c-7.979.257-7.979 11.776 0 12.098h48.264c7.98-.257 7.98-11.776 0-12.098h-7.98l-.064-1.03zM34.903 18.16H24.864v-6.05h10.039v6.05zm8.044 20.077H15.79V12.11h7.08v8.045H36.897V12.11H43.977V38.303h-1.03v-.065zm11.068 10.104H5.752c-2.253 0-4.055-1.802-4.055-3.99a4.037 4.037 0 0 1 4.055-4.054h48.263c2.253 0 3.99 1.866 3.99 4.054s-1.802 3.925-3.99 3.99z"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
        d: "M11.8 41.262c-1.673 0-3.024 1.351-2.96 3.025 0 1.608 1.352 2.96 2.96 2.96 1.674 0 3.025-1.416 2.96-3.09 0-1.544-1.35-2.83-2.96-2.895zm0 4.054c-.579 0-.965-.45-.965-1.03a.99.99 0 0 1 .965-.965c.58 0 .966.45.966 1.03 0 .515-.45.9-.966.965zM20.81 41.262c-1.673 0-3.024 1.351-2.96 3.025 0 1.608 1.351 2.96 2.96 2.96 1.673 0 3.025-1.416 2.96-3.09 0-1.544-1.287-2.83-2.96-2.895zm0 4.054c-.58 0-1.03-.45-1.03-1.03 0-.579.45-1.029 1.03-1.029.58 0 1.03.45 1.03 1.03 0 .579-.45 1.03-1.03 1.03zM29.884 41.262a3.021 3.021 0 0 0-3.025 3.025 3.021 3.021 0 0 0 3.025 3.024 3.021 3.021 0 0 0 3.024-3.024 3.021 3.021 0 0 0-3.024-3.025zm0 4.054c-.58 0-1.03-.45-1.03-1.03 0-.579.45-1.029 1.03-1.029.579 0 .965.45.965 1.03 0 .579-.45.965-.965 1.03zM38.957 41.262a3.021 3.021 0 0 0-3.025 3.025 3.021 3.021 0 0 0 3.025 3.024 3.021 3.021 0 0 0 3.024-3.024 3.021 3.021 0 0 0-3.024-3.025zm0 4.054c-.58 0-1.03-.45-1.03-1.03 0-.579.45-1.029 1.03-1.029.58 0 .965.45.965 1.03 0 .579-.45.965-.965 1.03zM47.966 41.262a3.02 3.02 0 0 0-3.024 3.025 3.021 3.021 0 0 0 3.024 3.024 3.021 3.021 0 0 0 3.025-3.024 3.021 3.021 0 0 0-3.025-3.025zm0 4.054c-.579 0-1.03-.45-1.03-1.03 0-.579.451-1.029 1.03-1.029.58 0 .965.45.965 1.03 0 .579-.386.965-.965 1.03zM29.883 35.213h-3.99v1.995h3.99v-1.995zM41.917 35.213h-9.009v1.995h9.01v-1.995z"
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("defs", {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("clipPath", {
        id: "clip0_1484:31495",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
          fill: "#fff",
          d: "M0 0h60v60H0z"
        })
      })
    })]
  }));
};

ProcessingIcon.defaultProps = {
  width: "60",
  height: "60",
  viewBox: "0 0 60 60",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var PurchasedGoodsIcon = function PurchasedGoodsIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
      d: "M49.07 2.274H8.069l-1.54 2.494L0 15.917v41.81h60v-41.81l-6.528-11.15-1.614-2.493h-2.787zm1.248 2.934l.66 1.1 4.914 8.142H37.995l-1.687-9.242h14.01zM24.646 17.384H35.28V31.32H24.645V17.384zm.293-2.934l1.687-9.242h6.748l1.687 9.242H24.94zm-14.01-9.242h12.763l-1.687 9.242H4.108l4.914-8.142.66-1.1h1.247zm46.137 49.584H2.934V17.384h18.777v16.87h16.504v-16.87h18.851v37.408z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
      d: "M7.628 50.758h12.763V40.342l-3.08-.073H7.628v10.489zm2.934-7.482h6.822v4.621l-.073-.073h-6.749v-4.548z"
    })]
  }));
};

PurchasedGoodsIcon.defaultProps = {
  width: "60",
  height: "60",
  viewBox: "0 0 60 60",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var TransportIcon = function TransportIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
      d: "M58.8 31.2h-6.217l-2.206-11.036A1.2 1.2 0 0 0 49.2 19.2H33.6v-6a1.2 1.2 0 0 0-1.2-1.2H1.2A1.2 1.2 0 0 0 0 13.2V42a1.2 1.2 0 0 0 1.2 1.2h1.321A5.979 5.979 0 0 0 13.2 45.563 5.98 5.98 0 0 0 23.879 43.2H38.52a6 6 0 0 0 11.758 0H58.8A1.2 1.2 0 0 0 60 42v-9.6a1.2 1.2 0 0 0-1.2-1.2zm-47.021 12a3.58 3.58 0 0 1-6.758 0 3.366 3.366 0 0 1 0-2.4 3.579 3.579 0 0 1 6.758 0 3.367 3.367 0 0 1 0 2.4zm9.6 0a3.58 3.58 0 0 1-6.758 0 3.366 3.366 0 0 1 0-2.4 3.58 3.58 0 0 1 6.758 0 3.367 3.367 0 0 1 0 2.4zM31.2 20.4v20.4h-7.321A5.978 5.978 0 0 0 13.2 38.437 5.979 5.979 0 0 0 2.521 40.8H2.4V14.4h28.8v6zm18.936 10.8h-7.271l-1.6-4.8h7.912l.96 4.8zm-2.357 12a3.579 3.579 0 0 1-6.758 0 3.366 3.366 0 0 1 0-2.4 3.58 3.58 0 0 1 6.758 0 3.367 3.367 0 0 1 0 2.4zm9.821-2.4h-7.321a6 6 0 0 0-11.758 0H33.6V21.6h14.617l.48 2.4H39.6a1.2 1.2 0 0 0-1.138 1.58l2.4 7.2A1.199 1.199 0 0 0 42 33.6h15.6v7.2z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
      d: "M22.3 19.2h5.2c.345 0 .675-.126.92-.351.243-.226.38-.53.38-.849 0-.318-.137-.623-.38-.849a1.357 1.357 0 0 0-.92-.351h-5.2c-.345 0-.675.126-.92.351-.243.226-.38.53-.38.849 0 .318.137.623.38.849.245.225.575.351.92.351zM17.4 24h7.2a1.2 1.2 0 0 0 0-2.4h-7.2a1.2 1.2 0 1 0 0 2.4zM13.14 28.8h9.12c.302 0 .592-.126.806-.352.214-.224.334-.53.334-.848 0-.318-.12-.623-.334-.849a1.112 1.112 0 0 0-.806-.351h-9.12c-.302 0-.592.126-.806.352-.214.225-.334.53-.334.848 0 .318.12.623.334.848.214.226.504.352.806.352zM5.957 33.6h13.886c.307 0 .601-.126.818-.352.217-.224.339-.53.339-.848 0-.318-.122-.623-.339-.848a1.136 1.136 0 0 0-.818-.352H5.957c-.307 0-.601.126-.818.352-.217.224-.339.53-.339.848 0 .318.122.623.339.849.217.225.511.351.818.351z"
    })]
  }));
};

TransportIcon.defaultProps = {
  width: "60",
  height: "60",
  viewBox: "0 0 60 60",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var UsedIcon = function UsedIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
      d: "M16.8 41.6h7.5v-6.1h-7.5v6.1zm1.8-4.4h4v2.7h-4v-2.7z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
      d: "M51 11.4l-8.1 1.7H17.1L9 11.4l-9 7.2 12.3 2.6v24.6h35.4V21.1L60 18.5l-9-7.1zm-33.4 4l.4-.6h24l.4.6 2.9 4.8H14.7l2.9-4.8zM33.1 22v8.2h-6.3V22h6.3zM3.9 17.8L9.3 13l6.7 1.5-3.2 5.1-8.9-1.8zM46 44H14.1V22h11.1v9.9h9.7V22H46v22zm1.1-24.4l-3.2-5.1 6.7-1.5 5.5 4.8-9 1.8z"
    })]
  }));
};

UsedIcon.defaultProps = {
  width: "60",
  height: "60",
  viewBox: "0 0 60 60",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var VehicleIcon = function VehicleIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
      d: "M26.217 40.007h-4.77a1.25 1.25 0 1 1 0-2.5h4.77a1.25 1.25 0 1 1 0 2.5zM45.575 59.848c-4.397 0-7.975-3.578-7.975-7.975s3.578-7.975 7.975-7.975c4.39 0 7.963 3.578 7.963 7.975s-3.572 7.975-7.963 7.975zm0-13.45a5.481 5.481 0 0 0-5.475 5.475 5.481 5.481 0 0 0 5.475 5.475c3.013 0 5.463-2.456 5.463-5.475 0-3.018-2.45-5.475-5.463-5.475zM14.438 59.848c-4.398 0-7.975-3.578-7.975-7.975s3.577-7.975 7.974-7.975 7.975 3.578 7.975 7.975-3.578 7.975-7.974 7.975zm0-13.45a5.481 5.481 0 0 0-5.475 5.475 5.481 5.481 0 0 0 5.475 5.475 5.481 5.481 0 0 0 5.474-5.475 5.481 5.481 0 0 0-5.474-5.475z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
      d: "M58.75 53.123h-6.462c-.691 0-1.25-.559-1.25-1.25 0-3.018-2.45-5.475-5.463-5.475a5.481 5.481 0 0 0-5.475 5.475c0 .691-.559 1.25-1.25 1.25H21.162c-.69 0-1.25-.559-1.25-1.25a5.481 5.481 0 0 0-5.475-5.475 5.481 5.481 0 0 0-5.475 5.475c0 .691-.559 1.25-1.25 1.25H1.25c-.69 0-1.25-.559-1.25-1.25V37.68c0-2.988 2.43-5.42 5.419-5.42h43.543C55.05 32.26 60 37.211 60 43.298v8.575c0 .691-.56 1.25-1.25 1.25zm-5.31-2.5h4.06v-7.325c0-4.708-3.83-8.538-8.538-8.538H5.42A2.923 2.923 0 0 0 2.5 37.68v12.943h4.06c.602-3.806 3.905-6.725 7.877-6.725s7.276 2.92 7.877 6.725h15.384c.602-3.806 3.905-6.725 7.877-6.725 3.966 0 7.264 2.92 7.865 6.725z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
      d: "M32.722 34.76c-.69 0-1.25-.559-1.25-1.25V19.25a1.25 1.25 0 1 1 2.5 0v14.26c0 .691-.559 1.25-1.25 1.25z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
      d: "M49.315 34.76H8.158a1.251 1.251 0 0 1-1.132-1.78l6.678-14.26a1.25 1.25 0 0 1 1.131-.72h27.803c.485 0 .926.28 1.132.72l6.677 14.26a1.25 1.25 0 0 1-1.132 1.78zm-39.192-2.5H47.35L41.843 20.5H15.63l-5.507 11.76z"
    })]
  }));
};

VehicleIcon.defaultProps = {
  width: "60",
  height: "60",
  viewBox: "0 0 60 60",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var WasteIcon = function WasteIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)("mask", {
      id: "path-1-outside-1_992:15021",
      maskUnits: "userSpaceOnUse",
      x: "0",
      y: "0",
      width: "62",
      height: "62",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
        fill: "#fff",
        d: "M0 0h62v62H0z"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
        d: "M49.32 19.979a3.375 3.375 0 0 0 1.765-2.955 3.382 3.382 0 0 0-1.537-2.83c1.706-1.491 4.887-4.979 4.887-10.258a.75.75 0 0 0-.75-.75h-6.199a9.82 9.82 0 0 0-.078-1.54.75.75 0 0 0-.742-.646H31.432a.75.75 0 0 0-.742.646 9.844 9.844 0 0 0-.078 1.54h-6.2a.75.75 0 0 0-.749.75c0 5.28 3.182 8.767 4.888 10.258a3.382 3.382 0 0 0-1.537 2.83c0 1.235.67 2.306 1.66 2.897-.792.652-1.893 1.69-3.131 3.233-.14-.164-.279-.328-.435-.492-.793-.837-1.744-1.645-2.907-2.47l-1.76-1.247a1.974 1.974 0 0 0 1.019-1.72v-5.077a1.983 1.983 0 0 0-1.98-1.981H9.334c-1.092 0-1.98.889-1.98 1.981v5.077c0 .741.414 1.38 1.018 1.72l-1.759 1.247c-1.164.826-2.115 1.634-2.907 2.47-1.704 1.797-2.4 3.508-2.4 5.905v.16c0 1.61.699 3.109 1.881 4.14a5.365 5.365 0 0 0 .44 8.935A5.365 5.365 0 0 0 1 46.413a5.365 5.365 0 0 0 2.628 4.612A5.365 5.365 0 0 0 1 55.638 5.367 5.367 0 0 0 6.36 61h16.095a5.363 5.363 0 0 0 4.875-3.146c1.964.855 5.351 1.702 7.796 1.702h6.324c7.303 0 13.938-4.039 17.315-10.54 3.386-6.518 2.902-13.979-1.296-19.958-3.024-4.308-6.456-7.578-8.15-9.08zM47.358 4.686h5.553c-.353 5.203-4.273 8.366-5.082 8.965-.043-.001-.084-.013-.128-.013h-4.454c1.33-1.775 3.553-5.22 4.111-8.952zM32.111 2.5h13.876c.282 4.853-3.69 9.975-4.652 11.138h-4.572C35.8 12.476 31.827 7.361 32.11 2.5zm-6.923 2.186h5.552c.559 3.732 2.781 7.177 4.112 8.952h-4.454c-.044 0-.085.012-.129.013-.808-.599-4.729-3.761-5.081-8.965zm3.325 12.338c0-1.04.846-1.886 1.885-1.886H47.7c1.04 0 1.885.846 1.885 1.886S48.74 18.91 47.7 18.91H30.398a1.887 1.887 0 0 1-1.885-1.886zM8.855 12.148c0-.265.215-.481.48-.481H19.48c.266 0 .481.216.481.481v5.077c0 .265-.215.48-.48.48H9.334a.481.481 0 0 1-.48-.48v-5.077zm13.6 47.352H6.36a3.866 3.866 0 0 1-3.86-3.862 3.866 3.866 0 0 1 3.86-3.862.75.75 0 0 0 0-1.5 3.866 3.866 0 0 1-3.86-3.862 3.866 3.866 0 0 1 3.86-3.863.75.75 0 0 0 0-1.5A3.866 3.866 0 0 1 2.5 37.19c0-1.566.935-2.967 2.384-3.568a.75.75 0 0 0 .062-1.356 3.991 3.991 0 0 1-2.139-3.538v-.16c0-2.312.76-3.58 1.988-4.873.724-.765 1.603-1.51 2.686-2.278l3.118-2.21h7.617l3.118 2.21c1.082.768 1.96 1.513 2.686 2.278 1.227 1.294 1.987 2.56 1.987 4.873v.16c0 1.487-.82 2.843-2.138 3.538a.75.75 0 0 0 .062 1.356 3.852 3.852 0 0 1 2.384 3.568 3.866 3.866 0 0 1-3.86 3.862.75.75 0 0 0 0 1.5 3.866 3.866 0 0 1 3.86 3.863 3.866 3.866 0 0 1-3.86 3.862.75.75 0 0 0 0 1.5 3.866 3.866 0 0 1 3.86 3.862 3.866 3.866 0 0 1-3.86 3.862zm34.98-11.176c-3.166 6.094-9.141 9.732-15.985 9.732h-6.324c-2.237 0-5.63-.855-7.372-1.654.036-.25.06-.504.06-.764a5.365 5.365 0 0 0-2.628-4.612 5.365 5.365 0 0 0 2.628-4.612 5.365 5.365 0 0 0-2.628-4.613 5.365 5.365 0 0 0 .44-8.935 5.482 5.482 0 0 0 1.88-4.14v-.16c0-1.614-.325-2.916-1.052-4.144 1.958-2.517 3.582-3.692 4.067-4.012h17.002c.944.791 5.179 4.466 8.719 9.51 3.87 5.513 4.316 12.393 1.193 18.404z"
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
      d: "M49.32 19.979a3.375 3.375 0 0 0 1.765-2.955 3.382 3.382 0 0 0-1.537-2.83c1.706-1.491 4.887-4.979 4.887-10.258a.75.75 0 0 0-.75-.75h-6.199a9.82 9.82 0 0 0-.078-1.54.75.75 0 0 0-.742-.646H31.432a.75.75 0 0 0-.742.646 9.844 9.844 0 0 0-.078 1.54h-6.2a.75.75 0 0 0-.749.75c0 5.28 3.182 8.767 4.888 10.258a3.382 3.382 0 0 0-1.537 2.83c0 1.235.67 2.306 1.66 2.897-.792.652-1.893 1.69-3.131 3.233-.14-.164-.279-.328-.435-.492-.793-.837-1.744-1.645-2.907-2.47l-1.76-1.247a1.974 1.974 0 0 0 1.019-1.72v-5.077a1.983 1.983 0 0 0-1.98-1.981H9.334c-1.092 0-1.98.889-1.98 1.981v5.077c0 .741.414 1.38 1.018 1.72l-1.759 1.247c-1.164.826-2.115 1.634-2.907 2.47-1.704 1.797-2.4 3.508-2.4 5.905v.16c0 1.61.699 3.109 1.881 4.14a5.365 5.365 0 0 0 .44 8.935A5.365 5.365 0 0 0 1 46.413a5.365 5.365 0 0 0 2.628 4.612A5.365 5.365 0 0 0 1 55.638 5.367 5.367 0 0 0 6.36 61h16.095a5.363 5.363 0 0 0 4.875-3.146c1.964.855 5.351 1.702 7.796 1.702h6.324c7.303 0 13.938-4.039 17.315-10.54 3.386-6.518 2.902-13.979-1.296-19.958-3.024-4.308-6.456-7.578-8.15-9.08zM47.358 4.686h5.553c-.353 5.203-4.273 8.366-5.082 8.965-.043-.001-.084-.013-.128-.013h-4.454c1.33-1.775 3.553-5.22 4.111-8.952zM32.111 2.5h13.876c.282 4.853-3.69 9.975-4.652 11.138h-4.572C35.8 12.476 31.827 7.361 32.11 2.5zm-6.923 2.186h5.552c.559 3.732 2.781 7.177 4.112 8.952h-4.454c-.044 0-.085.012-.129.013-.808-.599-4.729-3.761-5.081-8.965zm3.325 12.338c0-1.04.846-1.886 1.885-1.886H47.7c1.04 0 1.885.846 1.885 1.886S48.74 18.91 47.7 18.91H30.398a1.887 1.887 0 0 1-1.885-1.886zM8.855 12.148c0-.265.215-.481.48-.481H19.48c.266 0 .481.216.481.481v5.077c0 .265-.215.48-.48.48H9.334a.481.481 0 0 1-.48-.48v-5.077zm13.6 47.352H6.36a3.866 3.866 0 0 1-3.86-3.862 3.866 3.866 0 0 1 3.86-3.862.75.75 0 0 0 0-1.5 3.866 3.866 0 0 1-3.86-3.862 3.866 3.866 0 0 1 3.86-3.863.75.75 0 0 0 0-1.5A3.866 3.866 0 0 1 2.5 37.19c0-1.566.935-2.967 2.384-3.568a.75.75 0 0 0 .062-1.356 3.991 3.991 0 0 1-2.139-3.538v-.16c0-2.312.76-3.58 1.988-4.873.724-.765 1.603-1.51 2.686-2.278l3.118-2.21h7.617l3.118 2.21c1.082.768 1.96 1.513 2.686 2.278 1.227 1.294 1.987 2.56 1.987 4.873v.16c0 1.487-.82 2.843-2.138 3.538a.75.75 0 0 0 .062 1.356 3.852 3.852 0 0 1 2.384 3.568 3.866 3.866 0 0 1-3.86 3.862.75.75 0 0 0 0 1.5 3.866 3.866 0 0 1 3.86 3.863 3.866 3.866 0 0 1-3.86 3.862.75.75 0 0 0 0 1.5 3.866 3.866 0 0 1 3.86 3.862 3.866 3.866 0 0 1-3.86 3.862zm34.98-11.176c-3.166 6.094-9.141 9.732-15.985 9.732h-6.324c-2.237 0-5.63-.855-7.372-1.654.036-.25.06-.504.06-.764a5.365 5.365 0 0 0-2.628-4.612 5.365 5.365 0 0 0 2.628-4.612 5.365 5.365 0 0 0-2.628-4.613 5.365 5.365 0 0 0 .44-8.935 5.482 5.482 0 0 0 1.88-4.14v-.16c0-1.614-.325-2.916-1.052-4.144 1.958-2.517 3.582-3.692 4.067-4.012h17.002c.944.791 5.179 4.466 8.719 9.51 3.87 5.513 4.316 12.393 1.193 18.404z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
      d: "M49.32 19.979a3.375 3.375 0 0 0 1.765-2.955 3.382 3.382 0 0 0-1.537-2.83c1.706-1.491 4.887-4.979 4.887-10.258a.75.75 0 0 0-.75-.75h-6.199a9.82 9.82 0 0 0-.078-1.54.75.75 0 0 0-.742-.646H31.432a.75.75 0 0 0-.742.646 9.844 9.844 0 0 0-.078 1.54h-6.2a.75.75 0 0 0-.749.75c0 5.28 3.182 8.767 4.888 10.258a3.382 3.382 0 0 0-1.537 2.83c0 1.235.67 2.306 1.66 2.897-.792.652-1.893 1.69-3.131 3.233-.14-.164-.279-.328-.435-.492-.793-.837-1.744-1.645-2.907-2.47l-1.76-1.247a1.974 1.974 0 0 0 1.019-1.72v-5.077a1.983 1.983 0 0 0-1.98-1.981H9.334c-1.092 0-1.98.889-1.98 1.981v5.077c0 .741.414 1.38 1.018 1.72l-1.759 1.247c-1.164.826-2.115 1.634-2.907 2.47-1.704 1.797-2.4 3.508-2.4 5.905v.16c0 1.61.699 3.109 1.881 4.14a5.365 5.365 0 0 0 .44 8.935A5.365 5.365 0 0 0 1 46.413a5.365 5.365 0 0 0 2.628 4.612A5.365 5.365 0 0 0 1 55.638 5.367 5.367 0 0 0 6.36 61h16.095a5.363 5.363 0 0 0 4.875-3.146c1.964.855 5.351 1.702 7.796 1.702h6.324c7.303 0 13.938-4.039 17.315-10.54 3.386-6.518 2.902-13.979-1.296-19.958-3.024-4.308-6.456-7.578-8.15-9.08zM47.358 4.686h5.553c-.353 5.203-4.273 8.366-5.082 8.965-.043-.001-.084-.013-.128-.013h-4.454c1.33-1.775 3.553-5.22 4.111-8.952zM32.111 2.5h13.876c.282 4.853-3.69 9.975-4.652 11.138h-4.572C35.8 12.476 31.827 7.361 32.11 2.5zm-6.923 2.186h5.552c.559 3.732 2.781 7.177 4.112 8.952h-4.454c-.044 0-.085.012-.129.013-.808-.599-4.729-3.761-5.081-8.965zm3.325 12.338c0-1.04.846-1.886 1.885-1.886H47.7c1.04 0 1.885.846 1.885 1.886S48.74 18.91 47.7 18.91H30.398a1.887 1.887 0 0 1-1.885-1.886zM8.855 12.148c0-.265.215-.481.48-.481H19.48c.266 0 .481.216.481.481v5.077c0 .265-.215.48-.48.48H9.334a.481.481 0 0 1-.48-.48v-5.077zm13.6 47.352H6.36a3.866 3.866 0 0 1-3.86-3.862 3.866 3.866 0 0 1 3.86-3.862.75.75 0 0 0 0-1.5 3.866 3.866 0 0 1-3.86-3.862 3.866 3.866 0 0 1 3.86-3.863.75.75 0 0 0 0-1.5A3.866 3.866 0 0 1 2.5 37.19c0-1.566.935-2.967 2.384-3.568a.75.75 0 0 0 .062-1.356 3.991 3.991 0 0 1-2.139-3.538v-.16c0-2.312.76-3.58 1.988-4.873.724-.765 1.603-1.51 2.686-2.278l3.118-2.21h7.617l3.118 2.21c1.082.768 1.96 1.513 2.686 2.278 1.227 1.294 1.987 2.56 1.987 4.873v.16c0 1.487-.82 2.843-2.138 3.538a.75.75 0 0 0 .062 1.356 3.852 3.852 0 0 1 2.384 3.568 3.866 3.866 0 0 1-3.86 3.862.75.75 0 0 0 0 1.5 3.866 3.866 0 0 1 3.86 3.863 3.866 3.866 0 0 1-3.86 3.862.75.75 0 0 0 0 1.5 3.866 3.866 0 0 1 3.86 3.862 3.866 3.866 0 0 1-3.86 3.862zm34.98-11.176c-3.166 6.094-9.141 9.732-15.985 9.732h-6.324c-2.237 0-5.63-.855-7.372-1.654.036-.25.06-.504.06-.764a5.365 5.365 0 0 0-2.628-4.612 5.365 5.365 0 0 0 2.628-4.612 5.365 5.365 0 0 0-2.628-4.613 5.365 5.365 0 0 0 .44-8.935 5.482 5.482 0 0 0 1.88-4.14v-.16c0-1.614-.325-2.916-1.052-4.144 1.958-2.517 3.582-3.692 4.067-4.012h17.002c.944.791 5.179 4.466 8.719 9.51 3.87 5.513 4.316 12.393 1.193 18.404z",
      stroke: "#76B591",
      mask: "url(#path-1-outside-1_992:15021)"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
      d: "M45.777 32.887a.85.85 0 0 0 1.179.237.85.85 0 0 0 .236-1.179c-1.857-2.789-4.29-4.569-4.4-4.648a.85.85 0 0 0-.998 1.376l.027.02.078.06a18.813 18.813 0 0 1 1.261 1.084c.786.738 1.777 1.788 2.617 3.05zm.208-.138a.6.6 0 0 0 .832.167l-.832-.167zM46.644 39.66a.846.846 0 0 0-.983.693l.247.042-.247-.043c-.002.012-.476 2.584-3.295 3.972a.85.85 0 1 0 .75 1.524c3.586-1.764 4.193-5.045 4.22-5.207l-.692-.981zm0 0a.85.85 0 0 1 .692.981l-.692-.981z",
      stroke: "#76B591",
      strokeWidth: ".5"
    })]
  }));
};

WasteIcon.defaultProps = {
  width: "62",
  height: "62",
  viewBox: "0 0 62 62",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var WaterIcon = function WaterIcon(props) {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("path", {
      d: "M1.206 42.524c.666 0 1.207-.533 1.207-1.19v-8.027h11.382a2.354 2.354 0 0 0 2.36 2.245h15.993c1.275 0 2.31-1 2.36-2.245h5.8v5.76c0 .658.54 1.19 1.207 1.19h13.783c.667 0 1.207-.532 1.207-1.19v-10.73c0-6.068-5.003-11.005-11.153-11.005H34.508a2.354 2.354 0 0 0-2.36-2.238h-4.275v-6.47a8.16 8.16 0 0 1 1.631.78c.818.511 1.763.782 2.733.782 1.53 0 2.972-.664 3.955-1.822a5.067 5.067 0 0 0 1.124-4.19c-.367-2.04-2.068-3.722-4.137-4.09h-.001a5.164 5.164 0 0 0-3.964.893c-1.113.805-2.524.975-3.512.975h-3.099c-.988 0-2.399-.17-3.512-.974C17.949.15 16.54-.164 15.125.084c-2.07.368-3.77 2.049-4.137 4.09a5.067 5.067 0 0 0 1.124 4.19 5.178 5.178 0 0 0 3.956 1.822c.97 0 1.915-.27 2.731-.78a8.154 8.154 0 0 1 1.637-.783v6.47h-4.28a2.354 2.354 0 0 0-2.36 2.239H2.413v-8.02c0-.658-.54-1.191-1.207-1.191C.54 8.12 0 8.654 0 9.31v32.023c0 .657.54 1.19 1.206 1.19zm21.642-34.29h2.612v6.853h-2.612V8.235zm-5.34-.84c-1.117.696-2.695.444-3.547-.56a2.678 2.678 0 0 1-.597-2.245c.194-1.079 1.093-1.967 2.188-2.161a2.738 2.738 0 0 1 2.112.47c1.298.938 3.006 1.434 4.939 1.434h3.1c1.933 0 3.64-.496 4.938-1.435a2.743 2.743 0 0 1 2.11-.47c1.096.194 1.995 1.083 2.189 2.161a2.676 2.676 0 0 1-.596 2.247c-.855 1.003-2.431 1.256-3.55.558-1.611-1.006-3.36-1.539-5.056-1.539h-3.171c-1.697 0-3.446.533-5.058 1.54zm36.584 20.943v9.54H42.721v-5.76c0-.658-.54-1.19-1.206-1.19h-6.996V19.711h10.833c4.82 0 8.74 3.87 8.74 8.625zM21.605 17.46c.013 0 .024.007.037.007h5.025c.037 0 .068-.017.105-.02l5.334-.015v1.084l-.001.006v13.595l.001.005v1.05l-15.908.041-.003-1.057c0-.014.008-.025.008-.04 0-.014-.007-.026-.008-.04l-.036-13.337c.014-.073.044-.14.044-.217 0-.079-.03-.148-.045-.222l-.002-.826 5.449-.014zm-7.82 2.252v11.214H2.414V19.713h11.373zM48.35 60c2.89 0 5.243-2.417 5.243-5.39 0-2.498-3.516-9.06-4.22-10.351-.417-.76-1.63-.759-2.046 0-.705 1.29-4.22 7.853-4.22 10.352 0 2.972 2.352 5.389 5.243 5.389zm0-12.615c1.423 2.807 2.898 6.123 2.898 7.226 0 1.642-1.3 2.979-2.898 2.979s-2.898-1.337-2.898-2.98c0-1.102 1.474-4.418 2.898-7.225z"
    })
  }));
};

WaterIcon.defaultProps = {
  width: "57",
  height: "60",
  viewBox: "0 0 57 60",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};






const MeasurementResultCharts = styled_components__WEBPACK_IMPORTED_MODULE_16___default().div.withConfig({
  displayName: "result__MeasurementResultCharts",
  componentId: "xnr155-0"
})(["margin:1rem 0;", ""], _theme__WEBPACK_IMPORTED_MODULE_15__/* .media.desktop */ .BC.desktop`
    display: flex;

     & > div:first-child {
      margin-right: 1.95%;
  }
  `);
const MeasurementScopeCharts = styled_components__WEBPACK_IMPORTED_MODULE_16___default().div.withConfig({
  displayName: "result__MeasurementScopeCharts",
  componentId: "xnr155-1"
})(["margin:1rem 0;", ""], _theme__WEBPACK_IMPORTED_MODULE_15__/* .media.desktop */ .BC.desktop`
    display: flex;
     & > div:not(:last-child) {
    margin-right: 1.1%;
  }
  `);
const Actions = styled_components__WEBPACK_IMPORTED_MODULE_16___default().div.withConfig({
  displayName: "result__Actions",
  componentId: "xnr155-2"
})(["align-self:flex-start;", " ", ""], _theme__WEBPACK_IMPORTED_MODULE_15__/* .media.tablet */ .BC.tablet`
    position: absolute;
    margin-bottom: 0.5rem;
  `, _theme__WEBPACK_IMPORTED_MODULE_15__/* .media.tabletLarge */ .BC.tabletLarge`
    margin-top: -2rem;
  `);
const InformationContainer = styled_components__WEBPACK_IMPORTED_MODULE_16___default().div.withConfig({
  displayName: "result__InformationContainer",
  componentId: "xnr155-3"
})(["display:flex;flex-direction:column;border-bottom:2px solid ", ";padding:1rem 0;", ""], p => p.theme.colors.secondaryBlue, _theme__WEBPACK_IMPORTED_MODULE_15__/* .media.desktop */ .BC.desktop`
    flex-direction: row;
    padding: 0;
    & > div:not(:last-child) {
      margin-right: 2rem;
    }
  `);
const TextContainer = styled_components__WEBPACK_IMPORTED_MODULE_16___default().div.withConfig({
  displayName: "result__TextContainer",
  componentId: "xnr155-4"
})(["display:flex;align-items:center;& > div:first-child{margin-right:0.25rem;}", ""], _theme__WEBPACK_IMPORTED_MODULE_15__/* .media.tablet */ .BC.tablet`
    margin: 1rem 0;

    & > div:first-child {
      margin-right: 0.5rem;
    }
  `);
const AvatarContainer = styled_components__WEBPACK_IMPORTED_MODULE_16___default().div.withConfig({
  displayName: "result__AvatarContainer",
  componentId: "xnr155-5"
})(["min-width:", ";width:", ";height:", ";display:flex;align-items:center;justify-content:center;border-radius:50%;background-color:", ";", ""], p => p.size || "2rem", p => p.size || "2rem", p => p.size || "2rem", p => p.theme.colors.progressYellow, _theme__WEBPACK_IMPORTED_MODULE_15__/* .media.tablet */ .BC.tablet`
    min-width: ${p => p.size || "2rem"};
    width: ${p => p.size || "2rem"};
    height: ${p => p.size || "2rem"};
  `);
const Image = styled_components__WEBPACK_IMPORTED_MODULE_16___default().img.withConfig({
  displayName: "result__Image",
  componentId: "xnr155-6"
})(["width:100%;height:100%;border-radius:50%;object-fit:cover;"]);
const TitleContainer = styled_components__WEBPACK_IMPORTED_MODULE_16___default().div.withConfig({
  displayName: "result__TitleContainer",
  componentId: "xnr155-7"
})(["display:flex;flex-direction:column;align-items:flex-start;justify-content:center;", ";background:", ";padding:1.125rem;margin:2rem 0;", " ", " .custom-tooltip{border-radius:50%;backgroundcolor:white;}text{fill:", ";font-size:", ";}"], _styles__WEBPACK_IMPORTED_MODULE_14__/* .borderRadius */ .E, p => p.theme.colors.white, _theme__WEBPACK_IMPORTED_MODULE_15__/* .media.tablet */ .BC.tablet`
      width: 90%;
  `, _theme__WEBPACK_IMPORTED_MODULE_15__/* .media.desktop */ .BC.desktop`
    margin: initial;
  `, p => p.theme.colors.black, p => p.theme.small.size);
const MeasurementScopeAnalysisContainer = styled_components__WEBPACK_IMPORTED_MODULE_16___default().div.withConfig({
  displayName: "result__MeasurementScopeAnalysisContainer",
  componentId: "xnr155-8"
})(["margin:1rem 0;", ";background:", ";padding:1.5rem 2rem;", " ", ""], _styles__WEBPACK_IMPORTED_MODULE_14__/* .borderRadius */ .E, p => p.theme.colors.white, _theme__WEBPACK_IMPORTED_MODULE_15__/* .media.tablet */ .BC.tablet`
      width: 90%;
  `, _theme__WEBPACK_IMPORTED_MODULE_15__/* .media.desktop */ .BC.desktop`
    display: flex;
     & > div:not(:last-child) {
    margin-right: 1.5%;
  }
  `);
const MeasurementScopeAnalysis = styled_components__WEBPACK_IMPORTED_MODULE_16___default().div.withConfig({
  displayName: "result__MeasurementScopeAnalysis",
  componentId: "xnr155-9"
})(["width:100%;"]);
const AnalysisContainer = styled_components__WEBPACK_IMPORTED_MODULE_16___default().div.withConfig({
  displayName: "result__AnalysisContainer",
  componentId: "xnr155-10"
})(["display:flex;margin:1rem 0;svg{fill:", ";height:2rem;width:2rem;margin-right:1rem;}"], p => p.scope === 1 ? p.theme.colors.graphBlue : p.scope === 2 ? p.theme.colors.graphYellow : p.scope === 3 ? p.theme.colors.graphGreen : p.theme.colors.placeholderGrey);
const ScopeContainer = styled_components__WEBPACK_IMPORTED_MODULE_16___default().div.withConfig({
  displayName: "result__ScopeContainer",
  componentId: "xnr155-11"
})(["height:2rem;& > span{border-bottom:1px solid ", ";}"], p => p.scope === 1 ? p.theme.colors.graphBlue : p.scope === 2 ? p.theme.colors.graphYellow : p.scope === 3 ? p.theme.colors.graphGreen : p.theme.colors.transparent);
const scopeAnalysis = [{
  label: "Company facilities",
  icon: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(OfficeIcon, {}),
  scope: 1
}, {
  label: "Company vehicles",
  icon: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(VehicleIcon, {}),
  scope: 1
}, {
  label: "Purchased electricity",
  icon: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(ElectricityIcon, {}),
  scope: 2
}, {
  label: "Employee commuting",
  icon: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(CommuteIcon, {}),
  scope: 3
}, {
  label: "Homeworking",
  icon: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(HomeworkingIcon, {}),
  scope: 3
}, {
  label: "Waste",
  icon: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(WasteIcon, {}),
  scope: 3
}, {
  label: "Water",
  icon: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(WaterIcon, {}),
  scope: 3
}, {
  label: "Transport + distribution",
  icon: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(TransportIcon, {}),
  scope: 4
}, {
  label: "Purchased goods + services",
  icon: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(PurchasedGoodsIcon, {}),
  scope: 4
}, {
  label: "Capital goods",
  icon: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(CapitalGoodsIcon, {}),
  scope: 4
}, {
  label: "Investments",
  icon: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(InvestmentsIcon, {}),
  scope: 4
}, {
  label: "Leased assets",
  icon: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(AssetsIcon, {}),
  scope: 5
}, {
  label: "Processing of sold products",
  icon: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(ProcessingIcon, {}),
  scope: 5
}, {
  label: "Use of sold products",
  icon: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(UsedIcon, {}),
  scope: 5
}, {
  label: "Franchises",
  icon: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(FranchiseIcon, {}),
  scope: 6
}, {
  label: "End-of-life treatment of sold products",
  icon: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(DisposalIcon, {}),
  scope: 6
}];

const Measurement = () => {
  const {
    selectedMeasurement,
    setSelectedMeasurement,
    loading,
    setProgress,
    getSelectedMeasurement
  } = (0,_contexts_measurements__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z)();
  const {
    0: selectedOfficeId,
    1: setSelectedOfficeId
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
  const isTablet = (0,react_responsive__WEBPACK_IMPORTED_MODULE_2__.useMediaQuery)({
    query: `(min-width: ${_theme__WEBPACK_IMPORTED_MODULE_15__/* .sizes.tablet */ .J7.tablet}px)`
  });
  const isDesktop = (0,react_responsive__WEBPACK_IMPORTED_MODULE_2__.useMediaQuery)({
    query: `(min-width: ${_theme__WEBPACK_IMPORTED_MODULE_15__/* .sizes.desktop */ .J7.desktop}px)`
  });
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    getSelectedMeasurement();
    return () => setSelectedMeasurement(null);
  }, []);
  const periodStart = selectedMeasurement && (0,date_fns__WEBPACK_IMPORTED_MODULE_1__.format)(new Date(selectedMeasurement.year, selectedMeasurement.month), "MM/yyyy");
  const periodEnd = selectedMeasurement && (0,date_fns__WEBPACK_IMPORTED_MODULE_1__.format)((0,date_fns__WEBPACK_IMPORTED_MODULE_1__.subDays)((0,date_fns__WEBPACK_IMPORTED_MODULE_1__.addMonths)(new Date(selectedMeasurement.year, selectedMeasurement.month), selectedMeasurement.time_period), 1), "MM/yyyy");
  const moreThanOneMonth = (selectedMeasurement === null || selectedMeasurement === void 0 ? void 0 : selectedMeasurement.time_period) > 1;
  const optionArray = selectedMeasurement && [{
    label: "All",
    value: null
  }, ...selectedMeasurement.office_measurements.map(office => ({
    label: office.details.name,
    value: office.id
  }))];
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_components_common_Page__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_components_ContentContainer__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
      title: "Carbon Measurements",
      children: [loading && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_components_common_LoadingLarge__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
        loading: loading,
        text: "Initialising Measurement...",
        setProgress: setProgress
      }), !!selectedMeasurement && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.Fragment, {
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(InformationContainer, {
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(TextContainer, {
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("div", {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
                size: "subtitle",
                children: "Calculation Period:"
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("div", {
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_components_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
                size: "subtitle",
                color: "blue",
                children: [" ", moreThanOneMonth ? `${periodStart} - ${periodEnd}` : periodStart]
              })
            })]
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(TextContainer, {
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("div", {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
                size: "subtitle",
                children: "Date Submitted:"
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("div", {
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_components_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
                size: "subtitle",
                color: "blue",
                children: [" ", (0,date_fns__WEBPACK_IMPORTED_MODULE_1__.format)(new Date(selectedMeasurement.submitted_at || selectedMeasurement.updated_at), "dd/MM/yyyy")]
              })
            })]
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(TextContainer, {
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("div", {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
                size: "subtitle",
                children: "Office:"
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_components_common_InputDropdown__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
              optionArray: optionArray,
              defaultValue: optionArray[0],
              onChange: ({
                value
              }) => setSelectedOfficeId(value),
              width: "20rem"
            })]
          })]
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(MeasurementResultCharts, {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_components_measurement_MeasurementPieChart__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
            measurement: selectedMeasurement,
            width: "30%",
            officeId: selectedOfficeId,
            isMonthly: !moreThanOneMonth
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_components_measurement_MeasurementFullBreakdownBarChart__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
            measurement: selectedMeasurement,
            officeId: selectedOfficeId,
            isMonthly: !moreThanOneMonth
          })]
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(TitleContainer, {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
            size: isTablet ? "cardHeader" : "subtitle",
            children: "Scope Breakdown"
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(MeasurementScopeCharts, {
          children: ["scope_1", "scope_2", "scope_3"].map(scope => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_components_measurement_MeasurementScopeBarChart__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
            measurement: selectedMeasurement,
            scope: scope,
            officeId: selectedOfficeId,
            isMonthly: !moreThanOneMonth
          }))
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(TitleContainer, {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
            size: isTablet ? "cardHeader" : "subtitle",
            children: "Measurement Boundary"
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(MeasurementScopeAnalysisContainer, {
          children: [...new Set(scopeAnalysis.map(category => category.scope))].map(scope => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(MeasurementScopeAnalysis, {
            children: [scope < 4 ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(ScopeContainer, {
              scope: scope,
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_components_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
                size: "cardHeader",
                capitalize: true,
                children: ["Scope ", scope]
              })
            }) : isDesktop && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(ScopeContainer, {}), scopeAnalysis.filter(analysis => analysis.scope === scope).map(analysis => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(AnalysisContainer, {
              scope: analysis.scope,
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("div", {
                children: analysis.icon
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("div", {
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
                  size: "small",
                  children: analysis.label
                })
              })]
            }))]
          }))
        })]
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)(Measurement));
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 39218:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "unstable_getStaticParams": () => (/* binding */ unstable_getStaticParams),
/* harmony export */   "unstable_getStaticProps": () => (/* binding */ unstable_getStaticProps),
/* harmony export */   "unstable_getStaticPaths": () => (/* binding */ unstable_getStaticPaths),
/* harmony export */   "unstable_getServerProps": () => (/* binding */ unstable_getServerProps),
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "_app": () => (/* binding */ _app),
/* harmony export */   "renderReqToHTML": () => (/* binding */ renderReqToHTML),
/* harmony export */   "render": () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(70607);
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59450);
/* harmony import */ var private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97020);
/* harmony import */ var private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(73978);
/* harmony import */ var next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99436);

      
      
      
      

      
      const { processEnv } = __webpack_require__(85360)
      processEnv([{"path":".env","contents":"API_HOST=https://api.inhabit.eco\nNEXT_PUBLIC_CALENDLY_URL=https://calendly.com/inhabit-meet/inhabit-measurement-tutorial\nNEXT_PUBLIC_FLAGS_ENVIRONMENT_KEY=flags_pub_289425705564897805\nNEXT_PUBLIC_GOOGLE_ANALYTICS=G-1CBB78XFQ4\nNEXT_PUBLIC_INTERCOM_APP_ID=bw9p6mfd\nNEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_bQDaTEuYc10x3BZt9YcGj2cE00Gzwm4gDD\nSTRIPE_PUBLISHABLE_KEY=pk_live_bQDaTEuYc10x3BZt9YcGj2cE00Gzwm4gDD\n\n"}])
    
      
      const runtimeConfig = {}
      ;

      const documentModule = __webpack_require__(9968)

      const appMod = __webpack_require__(13724)
      let App = appMod.default || appMod.then && appMod.then(mod => mod.default);

      const compMod = __webpack_require__(81667)

      const Component = compMod.default || compMod.then && compMod.then(mod => mod.default)
      /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Component);
      const getStaticProps = compMod['getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['getStaticProp' + 's'])
      const getStaticPaths = compMod['getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['getStaticPath' + 's'])
      const getServerSideProps = compMod['getServerSideProp' + 's'] || compMod.then && compMod.then(mod => mod['getServerSideProp' + 's'])

      // kept for detecting legacy exports
      const unstable_getStaticParams = compMod['unstable_getStaticParam' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticParam' + 's'])
      const unstable_getStaticProps = compMod['unstable_getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticProp' + 's'])
      const unstable_getStaticPaths = compMod['unstable_getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticPath' + 's'])
      const unstable_getServerProps = compMod['unstable_getServerProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getServerProp' + 's'])

      let config = compMod['confi' + 'g'] || (compMod.then && compMod.then(mod => mod['confi' + 'g'])) || {}
      const _app = App

      const combinedRewrites = Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)
        ? private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg
        : []

      if (!Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)) {
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.beforeFiles */ .Dg.beforeFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.afterFiles */ .Dg.afterFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.fallback */ .Dg.fallback)
      }

      const { renderReqToHTML, render } = (0,next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__/* .getPageHandler */ .u)({
        pageModule: compMod,
        pageComponent: Component,
        pageConfig: config,
        appModule: App,
        documentModule: documentModule,
        errorModule: __webpack_require__(99651),
        notFoundModule: undefined,
        pageGetStaticProps: getStaticProps,
        pageGetStaticPaths: getStaticPaths,
        pageGetServerSideProps: getServerSideProps,

        assetPrefix: "",
        canonicalBase: "",
        generateEtags: true,
        poweredByHeader: true,
        reactRoot: false,

        runtimeConfig,
        buildManifest: private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__,
        reactLoadableManifest: private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__,

        rewrites: combinedRewrites,
        i18n: undefined,
        page: "/measurements/[id]/result",
        buildId: "lDoX7RBEQ31kzKIJJbkVC",
        escapedBuildId: "lDoX7RBEQ31kzKIJJbkVC",
        basePath: "",
        pageIsDynamic: true,
        encodedPreviewProps: {previewModeId:"89cdc9f6073608262d43eab6d636f3f4",previewModeSigningKey:"74c7e36a2414a3f7b0ebcc67250f915f156686e1610b45a21ae9358d5b7c6c5a",previewModeEncryptionKey:"8a4c97ad9e5cf12d5a140689be08539ea52d8b27a416c2b8ae67db636b45841b"}
      })
      
    

/***/ }),

/***/ 94970:
/***/ ((module) => {

module.exports = require("@happykit/flags/client");

/***/ }),

/***/ 46411:
/***/ ((module) => {

module.exports = require("@happykit/flags/config");

/***/ }),

/***/ 48095:
/***/ ((module) => {

module.exports = require("@happykit/flags/server");

/***/ }),

/***/ 83218:
/***/ ((module) => {

module.exports = require("@hookform/error-message");

/***/ }),

/***/ 48308:
/***/ ((module) => {

module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ 85360:
/***/ ((module) => {

module.exports = require("@next/env");

/***/ }),

/***/ 64515:
/***/ ((module) => {

module.exports = require("@stripe/react-stripe-js");

/***/ }),

/***/ 20943:
/***/ ((module) => {

module.exports = require("@stripe/stripe-js");

/***/ }),

/***/ 52167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 74146:
/***/ ((module) => {

module.exports = require("date-fns");

/***/ }),

/***/ 1043:
/***/ ((module) => {

module.exports = require("lodash.get");

/***/ }),

/***/ 51650:
/***/ ((module) => {

module.exports = require("lodash.uniqby");

/***/ }),

/***/ 54426:
/***/ ((module) => {

module.exports = require("next/dist/compiled/chalk");

/***/ }),

/***/ 40252:
/***/ ((module) => {

module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 19371:
/***/ ((module) => {

module.exports = require("next/dist/compiled/node-fetch");

/***/ }),

/***/ 97999:
/***/ ((module) => {

module.exports = require("next/dist/compiled/path-to-regexp");

/***/ }),

/***/ 60600:
/***/ ((module) => {

module.exports = require("next/dist/server/accept-header.js");

/***/ }),

/***/ 52155:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils/index.js");

/***/ }),

/***/ 90730:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils/node.js");

/***/ }),

/***/ 60562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 94140:
/***/ ((module) => {

module.exports = require("next/dist/server/get-page-files.js");

/***/ }),

/***/ 89716:
/***/ ((module) => {

module.exports = require("next/dist/server/htmlescape.js");

/***/ }),

/***/ 25071:
/***/ ((module) => {

module.exports = require("next/dist/server/render-result.js");

/***/ }),

/***/ 33100:
/***/ ((module) => {

module.exports = require("next/dist/server/render.js");

/***/ }),

/***/ 92779:
/***/ ((module) => {

module.exports = require("next/dist/server/request-meta.js");

/***/ }),

/***/ 79502:
/***/ ((module) => {

module.exports = require("next/dist/server/send-payload.js");

/***/ }),

/***/ 76368:
/***/ ((module) => {

module.exports = require("next/dist/server/utils.js");

/***/ }),

/***/ 56724:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 27664:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/escape-regexp.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 94957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 82374:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-locale-cookie.js");

/***/ }),

/***/ 34014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 78524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 78020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 29565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 64365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 95714:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-route-from-asset-path.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 91292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 25753:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-match.js");

/***/ }),

/***/ 99521:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/prepare-destination.js");

/***/ }),

/***/ 80979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 36052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 84226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 95566:
/***/ ((module) => {

module.exports = require("next/error");

/***/ }),

/***/ 40968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 71853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 59819:
/***/ ((module) => {

module.exports = require("querystring");

/***/ }),

/***/ 16689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 25716:
/***/ ((module) => {

module.exports = require("react-hotjar");

/***/ }),

/***/ 16666:
/***/ ((module) => {

module.exports = require("react-responsive");

/***/ }),

/***/ 61929:
/***/ ((module) => {

module.exports = require("react-select");

/***/ }),

/***/ 1187:
/***/ ((module) => {

module.exports = require("react-toastify");

/***/ }),

/***/ 20997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 36157:
/***/ ((module) => {

module.exports = require("recharts");

/***/ }),

/***/ 57518:
/***/ ((module) => {

module.exports = require("styled-components");

/***/ }),

/***/ 24535:
/***/ ((module) => {

module.exports = require("styled-normalize");

/***/ }),

/***/ 6153:
/***/ ((module) => {

module.exports = require("universal-cookie");

/***/ }),

/***/ 84269:
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ 75609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 61908:
/***/ ((module) => {

module.exports = import("@hookform/resolvers/yup");;

/***/ }),

/***/ 45641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [4357,9703,6114,9067,8183,9899,805,6067,1233,9343,1217,5411], () => (__webpack_exec__(39218)));
module.exports = __webpack_exports__;

})();