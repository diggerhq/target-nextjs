"use strict";
(() => {
var exports = {};
exports.id = 747;
exports.ids = [747];
exports.modules = {

/***/ 77027:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export textAreaStyles */
/* harmony import */ var _hookform_error_message__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(83218);
/* harmony import */ var _hookform_error_message__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_hookform_error_message__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(45641);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(87491);
/* harmony import */ var _Error__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(26428);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_1__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
const _excluded = ["label", "name", "disabled", "labelColor", "color", "maxLength"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }









const textAreaStyles = (0,styled_components__WEBPACK_IMPORTED_MODULE_5__.css)(["border:none;resize:none;background-color:inherit;padding:0.5rem 0.75rem;width:100%;height:100%;min-height:9rem;text-align:", ";font-family:", ";font-weight:", ";font-size:", ";color:", ";margin-bottom:1rem;border-bottom:0.0625rem solid ", ";", " ", " ", " border-radius:10px;::placeholder{color:", ";font-weight:", ";}&:focus{outline:none;border:2px solid #2e68f1;}", ""], p => p.align || "left", p => p.theme.textarea.font, p => p.theme.textarea.fontWeight, p => p.theme.textarea.size, p => p.color ? p.color : p.theme.colors.black, p => p.theme.colors.black, p => !p.disabled && "border: 2px solid #BED1FF;", p => p.height && `height: ${p.height};`, p => p.padding && `padding: ${p.padding};`, p => p.theme.colors.placeholderGrey, p => p.theme.textarea.fontWeight, _theme__WEBPACK_IMPORTED_MODULE_4__/* .media.tabletLarge */ .BC.tabletLarge`
    text-align: left;
      ${p => p.width && `width: ${p.width};`}
  `);
const StyledTextArea = styled_components__WEBPACK_IMPORTED_MODULE_5___default().textarea.withConfig({
  displayName: "TextArea__StyledTextArea",
  componentId: "sc-1hw0meb-0"
})(["", ""], textAreaStyles);
const TextAreaContainer = styled_components__WEBPACK_IMPORTED_MODULE_5___default().div.withConfig({
  displayName: "TextArea__TextAreaContainer",
  componentId: "sc-1hw0meb-1"
})(["display:flex;flex-direction:column;width:100%;height:100%;"]);
const Label = styled_components__WEBPACK_IMPORTED_MODULE_5___default().label.withConfig({
  displayName: "TextArea__Label",
  componentId: "sc-1hw0meb-2"
})(["color:", ";font-weight:lighter;margin-bottom:1.125rem;"], p => p.color ? p.color : p.theme.colors.label);
const Counter = styled_components__WEBPACK_IMPORTED_MODULE_5___default().div.withConfig({
  displayName: "TextArea__Counter",
  componentId: "sc-1hw0meb-3"
})(["align-self:flex-end;margin-top:-1rem;"]);

const TextArea = _ref => {
  let {
    label,
    name,
    disabled,
    labelColor,
    color,
    maxLength
  } = _ref,
      rest = _objectWithoutProperties(_ref, _excluded);

  const {
    register,
    control,
    formState: {
      errors
    }
  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_1__.useFormContext)();
  const value = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_1__.useWatch)({
    control,
    name
  });
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(TextAreaContainer, {
    children: [label && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(Label, {
      color: labelColor,
      htmlFor: name,
      children: label
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(StyledTextArea, _objectSpread(_objectSpread({
      id: name,
      color: color
    }, register(name)), {}, {
      disabled: disabled,
      maxLength: maxLength,
      "data-cy": `${name}`
    }, rest)), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(Counter, {
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(_common_Text__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
        size: "tiny",
        color: "blue",
        children: [value ? value.length : 0, maxLength && `/${maxLength}`, " characters"]
      })
    }), errors && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_hookform_error_message__WEBPACK_IMPORTED_MODULE_0__.ErrorMessage, {
      errors: errors,
      name: name,
      as: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_Error__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TextArea);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 78082:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ pdf_Policy)
});

// EXTERNAL MODULE: external "@react-pdf/renderer"
var renderer_ = __webpack_require__(13260);
// EXTERNAL MODULE: external "date-fns"
var external_date_fns_ = __webpack_require__(74146);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./src/theme.js
var theme = __webpack_require__(91073);
;// CONCATENATED MODULE: external "svg-parser"
const external_svg_parser_namespaceObject = require("svg-parser");
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
;// CONCATENATED MODULE: ./src/components/pdf/Policy.jsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }








const FIRST_PAGE_TOTAL = 6;

const convertStylesStringToObject = stringStyles => {
  let styles = typeof stringStyles === "string" && stringStyles !== undefined ? stringStyles.replaceAll("&quot;", "'")
  /* font-family sometimes uses &quot; and we don't want that semicolon  */
  .split(";").reduce((acc, style) => {
    const colonPosition = style.indexOf(":");

    if (colonPosition === -1) {
      return acc;
    }

    const camelCaseProperty = style.substr(0, colonPosition).trim().replace(/^-ms-/, "ms-").replace(/-./g, c => c.substr(1).toUpperCase()),
          value = style.substr(colonPosition + 1).trim(); // all supported svg styles of react-pdf

    let isSvgStyle = ["color", "dominantBaseline", "fill", "fillOpacity", "fillRule", "opacity", "stroke", "strokeWidth", "strokeOpacity", "strokeLinecap", "strokeDasharray", "transform", "textAnchor", "visibility"].includes(camelCaseProperty);
    return isSvgStyle && value ? _objectSpread(_objectSpread({}, acc), {}, {
      [camelCaseProperty]: value
    }) : acc;
  }, {}) : {};
  return styles;
};

const svgToJsx = (obj, index, parentX, parentY) => {
  //obj.type can be element or text, if its text, then its most probably raw text {type: text, value: "our text"}
  let name = obj.type === "element" ? obj.tagName : "rawText"; //defs and clipPath are currently not supported by react-pdf, so lets skip them

  if (name !== "defs" && name !== "clipPath") {
    //lets give each element a unique key
    let props = {
      key: index + name
    };

    if (obj.properties !== undefined) {
      // text and tspan elements can create issues with some values being NaN, therefore we deal with them seperately
      // furthermore if parent elements provide x, y values we add them to the current x, y element,
      // since react-pdf does not handle relative positioning yet
      if (name === "text" || name === "tspan") {
        var _ref, _obj$properties$x, _ref2, _obj$properties$y;

        obj.properties.x = (_ref = (_obj$properties$x = obj.properties.x) !== null && _obj$properties$x !== void 0 ? _obj$properties$x : 0 + parentX) !== null && _ref !== void 0 ? _ref : 0; // + obj.properties.dx ?? 0;

        obj.properties.y = (_ref2 = (_obj$properties$y = obj.properties.y) !== null && _obj$properties$y !== void 0 ? _obj$properties$y : 0 + parentY) !== null && _ref2 !== void 0 ? _ref2 : 0; // + obj.properties.dy ?? 0;

        props = _objectSpread({
          x: obj.properties.x,
          y: obj.properties.y,
          textAnchor: obj.properties["text-anchor"]
        }, props);
      } else {
        props = _objectSpread(_objectSpread({}, obj.properties), props);
      } // add styling


      if (obj.properties.style !== undefined) {
        props.style = _objectSpread({}, convertStylesStringToObject(obj.properties.style));
      }
    }

    let children = obj.children !== undefined && obj.children.length > 0 ? obj.children.map((c, i) => {
      var _obj$properties$x2, _obj$properties$y2;

      return svgToJsx(c, index + "-" + i, (_obj$properties$x2 = obj.properties.x) !== null && _obj$properties$x2 !== void 0 ? _obj$properties$x2 : 0, (_obj$properties$y2 = obj.properties.y) !== null && _obj$properties$y2 !== void 0 ? _obj$properties$y2 : 0);
    }) : ""; // uppercase to have correct elemment for react-pdf
    // remove line breaks from text
    // might mess up text that is supposed to have line breaks?
    // but handles issues where svg xml has line breaks:
    // <svg...><text>
    //    foo
    // instead of onliner <svg...><text>foo
    // other svg interpreters will still handle text often a bit different..

    name = name.toUpperCase();
    return obj.type === "text" ? obj.value.replace(/(\r\n|\n|\r)/gm, "") : /*#__PURE__*/external_react_default().createElement(name, _objectSpread(_objectSpread({}, props), {}, {
      fill: theme/* default.colors.black */.ZP.colors.black
    }, name === "SVG" ? {
      height: 24,
      width: 24
    } : {}), children);
  }
};

const CreateSvg = ({
  svgXml
}) => {
  const svg = svgXml.replaceAll("px", "pt");
  let parsed = (0,external_svg_parser_namespaceObject.parse)(svg);
  const svgElement = svgToJsx(parsed.children[0], 0);
  return svgElement;
};

const PolicyItem = ({
  policy,
  icon
}) => /*#__PURE__*/(0,jsx_runtime_.jsxs)(renderer_.View, {
  style: {
    width: "50%",
    height: 175,
    maxHeight: 175,
    display: "flex",
    marginBottom: 10,
    paddingRight: 20
  },
  children: [/*#__PURE__*/jsx_runtime_.jsx(renderer_.View, {
    style: {
      width: 42,
      height: 42,
      marginBottom: 5,
      borderRadius: 10,
      backgroundColor: theme/* default.colors.progressYellow */.ZP.colors.progressYellow,
      alignItems: "center",
      justifyContent: "center"
    },
    children: !!icon ? CreateSvg({
      svgXml: icon.svg
    }) : /*#__PURE__*/(0,jsx_runtime_.jsxs)(renderer_.Svg, {
      width: "19",
      height: "25",
      viewBox: "0 0 19 25",
      xmlns: "http://www.w3.org/2000/svg",
      children: [/*#__PURE__*/jsx_runtime_.jsx(renderer_.Path, {
        fill: theme/* default.colors.black */.ZP.colors.black,
        d: "M9.5538 -0.00147276C10.265 0.182582 10.8878 0.535475 11.1705 1.22556C11.3561 1.67956 11.6226 1.73404 12.025 1.70852C12.4069 1.68447 12.7917 1.70066 13.1755 1.7041C13.6501 1.70852 13.8955 1.92791 13.9117 2.39565C13.9201 2.6013 14.0099 2.63615 14.1856 2.63419C14.7402 2.62781 15.2953 2.63173 15.8504 2.63419C17.2993 2.63419 18.2098 3.52697 18.2161 4.98174C18.226 7.23408 18.2201 9.48739 18.2201 11.7397C18.2201 15.2409 18.2201 18.742 18.2201 22.2431C18.2201 22.5445 18.2103 22.8468 18.1828 23.1472C18.0964 24.0984 17.183 24.9548 16.2244 24.9941C16.1675 24.9941 16.1101 24.9941 16.0531 24.9941C11.4248 24.9941 6.79642 24.9941 2.16806 24.9941C1.66893 24.9996 1.18381 24.8291 0.797873 24.5125C0.411931 24.196 0.149827 23.7536 0.0575689 23.263C-0.0204702 22.8704 0.000143951 22.4664 0.000143951 22.0669C0.000143951 16.3941 0.000143951 10.7213 0.000143951 5.04849C0.000143951 4.16503 0.282361 3.43421 1.06079 2.9488C1.39561 2.74068 1.78217 2.63082 2.1764 2.63173C2.78894 2.62682 3.40343 2.62388 4.01302 2.63173C4.21327 2.63517 4.3026 2.59051 4.31095 2.36522C4.32763 1.92349 4.57353 1.70754 5.02508 1.70165C5.55516 1.69477 6.08572 1.6987 6.61629 1.69821C6.72427 1.69821 6.83323 1.70459 6.87937 1.57403C7.18072 0.712659 7.80749 0.220374 8.66936 -0.00588989L9.5538 -0.00147276ZM16.7393 13.8129C16.7393 11.7312 16.7393 9.64985 16.7393 7.56881C16.7393 6.67897 16.7417 5.78913 16.7393 4.89928C16.7393 4.45755 16.489 4.14 16.1155 4.13165C15.4543 4.11693 14.7932 4.12773 14.1321 4.12282C13.9682 4.12282 13.9191 4.20135 13.9215 4.35007C13.9264 4.58664 13.9294 4.8237 13.9215 5.05978C13.9063 5.48728 13.6467 5.74201 13.2197 5.74201C10.4934 5.74397 7.76708 5.74397 5.04078 5.74201C4.56568 5.74201 4.32076 5.4966 4.308 5.01708C4.30211 4.80505 4.29868 4.59204 4.308 4.37902C4.31831 4.1881 4.24567 4.1184 4.05376 4.12135C3.44172 4.12969 2.82968 4.12135 2.21714 4.12675C1.76658 4.13067 1.51185 4.38639 1.49074 4.84186C1.48485 4.96407 1.4873 5.08727 1.4873 5.20899V22.6696C1.4873 23.2822 1.7494 23.5428 2.3742 23.5428C5.85177 23.5428 9.32901 23.5428 12.8059 23.5428C13.8263 23.5428 14.8467 23.5457 15.8671 23.5428C16.4772 23.5398 16.7329 23.2797 16.7383 22.677C16.7383 22.5955 16.7383 22.514 16.7383 22.4316L16.7393 13.8129ZM9.10618 4.49338C10.1997 4.49338 11.2927 4.48798 12.3863 4.49731C12.6116 4.49731 12.6891 4.42761 12.6808 4.20282C12.6646 3.87741 12.6646 3.54955 12.6808 3.22414C12.6916 3.00524 12.6125 2.94291 12.4 2.94732C11.7963 2.9591 11.1921 2.95223 10.5884 2.95076C10.2625 2.95076 10.2346 2.9218 10.2311 2.60719C10.2311 2.49283 10.2375 2.37798 10.2272 2.26362C10.1869 1.80913 9.9597 1.46998 9.54006 1.30409C9.12041 1.13819 8.72237 1.1966 8.37438 1.50041C8.05633 1.77919 7.98909 2.14338 7.9994 2.5429C8.00873 2.9326 7.98517 2.9488 7.60675 2.94929C7.00305 2.94929 6.39886 2.9542 5.79516 2.94634C5.61553 2.94389 5.54976 3.00426 5.55368 3.18635C5.56448 3.52992 5.56792 3.87349 5.55368 4.21706C5.54387 4.43252 5.617 4.49829 5.83197 4.49633C6.91912 4.48848 8.01265 4.49338 9.10618 4.49338Z"
      }), /*#__PURE__*/jsx_runtime_.jsx(renderer_.Path, {
        fill: theme/* default.colors.black */.ZP.colors.black,
        d: "M11.1871 18.6523C12.1344 18.6523 13.0812 18.6474 14.028 18.6523C14.5482 18.6562 14.8623 19.1269 14.6371 19.5554C14.4996 19.8175 14.264 19.899 13.9823 19.899C12.913 19.897 11.8437 19.897 10.7744 19.899C9.97434 19.899 9.17431 19.9034 8.37428 19.8955C7.84961 19.8906 7.5399 19.4253 7.76666 18.9949C7.8982 18.7446 8.12053 18.6513 8.39539 18.6513C9.32597 18.6533 10.2566 18.6536 11.1871 18.6523Z"
      }), /*#__PURE__*/jsx_runtime_.jsx(renderer_.Path, {
        fill: theme/* default.colors.black */.ZP.colors.black,
        d: "M11.1932 10.15C10.2547 10.15 9.3158 10.1559 8.37688 10.15C7.85269 10.1456 7.5425 9.67981 7.76827 9.24888C7.90521 8.98777 8.13785 8.90531 8.42154 8.90531C10.0301 8.90825 11.6382 8.90825 13.2457 8.90531C13.5068 8.90531 13.7684 8.90138 14.031 8.90531C14.4276 8.91267 14.7118 9.17428 14.7123 9.52619C14.7128 9.8781 14.435 10.1476 14.0354 10.15C13.0847 10.1544 12.1375 10.15 11.1932 10.15Z"
      }), /*#__PURE__*/jsx_runtime_.jsx(renderer_.Path, {
        fill: theme/* default.colors.black */.ZP.colors.black,
        d: "M11.1858 13.7835C12.1222 13.7835 13.0587 13.7835 13.9952 13.7835C14.3795 13.7835 14.6583 13.9872 14.7039 14.319C14.7466 14.6287 14.5395 14.9379 14.2332 14.9938C14.0644 15.0232 13.8931 15.0362 13.7218 15.0326C12.8103 15.0184 11.8994 15.0252 10.988 15.0326C10.0844 15.039 9.18079 15.0223 8.27721 15.0056C8.12047 14.9996 7.97201 14.9337 7.86244 14.8215C7.75286 14.7092 7.6905 14.5592 7.68823 14.4024C7.69155 14.2413 7.75764 14.0878 7.87241 13.9747C7.98718 13.8616 8.14158 13.7977 8.30273 13.7968C9.07625 13.7904 9.85026 13.7968 10.6238 13.7938H11.1858V13.7835Z"
      }), /*#__PURE__*/jsx_runtime_.jsx(renderer_.Path, {
        fill: theme/* default.colors.black */.ZP.colors.black,
        d: "M3.91989 13.4036C4.15941 13.4036 4.32334 13.5371 4.45979 13.7231C4.83919 14.2321 4.84213 14.2306 5.22938 13.7231C5.52387 13.3344 5.81836 12.9422 6.11628 12.555C6.38132 12.2114 6.73078 12.1388 7.0287 12.3587C7.32663 12.5785 7.36098 12.9525 7.1092 13.2912C6.53985 14.0559 5.96609 14.8171 5.38791 15.5749C5.05956 16.0029 4.61783 15.9926 4.29046 15.5622C3.99008 15.1661 3.6897 14.77 3.39816 14.368C3.32377 14.2743 3.28048 14.1598 3.27432 14.0403C3.26816 13.9208 3.29944 13.8024 3.3638 13.7015C3.48749 13.491 3.67498 13.3977 3.91989 13.4036Z"
      }), /*#__PURE__*/jsx_runtime_.jsx(renderer_.Path, {
        fill: theme/* default.colors.black */.ZP.colors.black,
        d: "M4.85535 11.001C4.75474 11.0032 4.65512 10.9808 4.56514 10.9357C4.47516 10.8906 4.39754 10.8243 4.33902 10.7424C4.02686 10.3345 3.71225 9.92812 3.41384 9.51044C3.21457 9.23166 3.23518 8.95337 3.43789 8.72514C3.6936 8.43654 4.11177 8.44538 4.38221 8.7541C4.50471 8.89684 4.6194 9.0461 4.72578 9.20123C4.82148 9.33866 4.88873 9.31461 4.97903 9.19239C5.35254 8.68587 5.73292 8.18917 6.10888 7.68658C6.24778 7.50056 6.41662 7.36951 6.65663 7.3646C6.76784 7.35933 6.87822 7.38619 6.97458 7.44198C7.07093 7.49777 7.14917 7.58013 7.19996 7.67922C7.2619 7.78169 7.29115 7.90062 7.28378 8.02014C7.27641 8.13966 7.23279 8.2541 7.15873 8.34819C6.93983 8.6525 6.70964 8.94895 6.48435 9.24884C6.12672 9.72427 5.7694 10.2005 5.41242 10.6776C5.2691 10.869 5.09781 11.0089 4.85535 11.001Z"
      }), /*#__PURE__*/jsx_runtime_.jsx(renderer_.Path, {
        fill: theme/* default.colors.black */.ZP.colors.black,
        d: "M7.27805 17.7129C7.2818 17.8612 7.23411 18.0061 7.14308 18.1232C6.5595 18.8992 5.98084 19.6801 5.39137 20.4507C5.07087 20.8708 4.62865 20.8669 4.3057 20.4507C4.01563 20.0771 3.72899 19.7002 3.4512 19.3174C3.19499 18.964 3.23278 18.6081 3.53267 18.3887C3.83256 18.1694 4.18201 18.2469 4.45 18.5851C4.57957 18.747 4.6635 19.0361 4.85442 19.0332C5.0213 19.0302 5.11603 18.7495 5.23971 18.5915C5.55481 18.1851 5.85813 17.7698 6.1752 17.3644C6.25377 17.2583 6.36462 17.1804 6.49115 17.1425C6.61769 17.1047 6.75308 17.1088 6.87706 17.1544C6.99178 17.1972 7.09117 17.2731 7.16258 17.3726C7.23398 17.4721 7.27418 17.5905 7.27805 17.7129Z"
      })]
    })
  }), /*#__PURE__*/jsx_runtime_.jsx(renderer_.Text, {
    style: {
      color: theme/* default.colors.black */.ZP.colors.black,
      fontSize: 12,
      fontFamily: "Poppins SemiBold"
    },
    children: policy.description
  })]
});

const policyPages = (array, categoryIcons, size = 8) => {
  const slicedArray = array.slice(FIRST_PAGE_TOTAL, array.length - 1);
  let results = [/*#__PURE__*/jsx_runtime_.jsx(renderer_.View, {
    style: _objectSpread(_objectSpread({}, styles.relative), {}, {
      flexDirection: "row",
      flexWrap: "wrap"
    }),
    children: array.slice(0, FIRST_PAGE_TOTAL).map(policy => /*#__PURE__*/jsx_runtime_.jsx(PolicyItem, {
      policy: policy,
      icon: categoryIcons.find(a => policy.category && a.id === policy.category.id)
    }))
  })];

  while (slicedArray.length) {
    results = [results, /*#__PURE__*/jsx_runtime_.jsx(renderer_.View, {
      style: _objectSpread(_objectSpread({}, styles.relative), {}, {
        marginTop: 50,
        flexDirection: "row",
        flexWrap: "wrap"
      }),
      break: true,
      children: slicedArray.splice(0, size).map(policy => /*#__PURE__*/jsx_runtime_.jsx(PolicyItem, {
        policy: policy,
        icon: categoryIcons.find(a => policy.category && a.id === policy.category.id)
      }))
    })];
  }

  return results;
};

renderer_.Font.register({
  family: "Poppins",
  src: "https://fonts.gstatic.com/s/poppins/v13/pxiByp8kv8JHgFVrLDz8V1s.ttf"
});
renderer_.Font.register({
  family: "Poppins Regular",
  src: "https://fonts.gstatic.com/s/poppins/v13/pxiEyp8kv8JHgFVrFJA.ttf"
});
renderer_.Font.register({
  family: "Poppins Light",
  src: "https://fonts.gstatic.com/s/poppins/v13/pxiByp8kv8JHgFVrLDz8V1s.ttf"
});
renderer_.Font.register({
  family: "Poppins Medium",
  src: "https://fonts.gstatic.com/s/poppins/v13/pxiByp8kv8JHgFVrLGT9V1s.ttf"
});
renderer_.Font.register({
  family: "Poppins SemiBold",
  src: "https://fonts.gstatic.com/s/poppins/v13/pxiByp8kv8JHgFVrLEj6V1s.ttf"
});
renderer_.Font.register({
  family: "Poppins Bold",
  src: "https://fonts.gstatic.com/s/poppins/v13/pxiByp8kv8JHgFVrLCz7V1s.ttf"
});
renderer_.Font.register({
  family: "Kabel Black",
  src: "/fonts/kabel_black.ttf"
});
const styles = renderer_.StyleSheet.create({
  body: {
    paddingTop: 35,
    paddingBottom: 65,
    paddingHorizontal: 35
  },
  title: {
    fontSize: 24,
    textAlign: "center",
    fontFamily: "Poppins SemiBold"
  },
  author: {
    fontSize: 12,
    textAlign: "center",
    marginBottom: 40
  },
  subtitle: {
    fontSize: 18,
    fontFamily: "Poppins SemiBold"
  },
  subtitleContainer: {
    backgroundColor: "white",
    position: "absolute",
    width: "100%",
    height: 48,
    display: "flex",
    justifyContent: "center",
    paddingRight: 12,
    bottom: "30px",
    textAlign: "right"
  },
  subtitleText: {
    fontSize: 10,
    fontFamily: "Poppins Medium"
  },
  text: {
    margin: 12,
    fontSize: 14,
    textAlign: "justify",
    fontFamily: "Poppins Medium"
  },
  image: {
    marginVertical: 15
  },
  images: {
    width: "55%"
  },
  imageMap: {
    bottom: -25,
    left: -30,
    width: "55%",
    position: "absolute"
  },
  header: {
    fontSize: 25,
    fontFamily: "Kabel Black"
  },
  pageNumber: {
    position: "absolute",
    fontSize: 12,
    bottom: 30,
    left: 0,
    right: 0,
    textAlign: "center",
    color: "grey"
  },
  relative: {
    position: "relative"
  },
  flex: {
    display: "flex",
    flexDirection: "row"
  },
  page: {
    backgroundColor: theme/* default.colors.backgroundGrey */.ZP.colors.backgroundGrey
  },
  projectSectionTitle: {
    width: 58,
    fontFamily: "Poppins SemiBold",
    marginTop: 9,
    width: "100%",
    marginLeft: 5,
    fontSize: 10,
    fontStyle: "normal",
    color: "#000000"
  }
});

const Policy = ({
  organisation,
  policies,
  categoryIcons
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx(renderer_.Document, {
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(renderer_.Page, {
      wrap: true,
      style: styles.page,
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(renderer_.View, {
        style: {
          width: 595,
          backgroundColor: "#f6f6f6",
          padding: "5px 2px 2px",
          display: "flex",
          flexDirection: "row",
          alignItems: "baseline"
        },
        children: [/*#__PURE__*/jsx_runtime_.jsx(renderer_.Text, {
          style: styles.text,
          children: "Created by"
        }), /*#__PURE__*/jsx_runtime_.jsx(renderer_.Text, {
          style: styles.header,
          children: "inhabit."
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(renderer_.Text, {
          style: _objectSpread(_objectSpread({}, styles.text), {}, {
            marginLeft: "auto"
          }),
          children: ["Date: ", (0,external_date_fns_.format)(new Date(), "dd.MM.yyyy")]
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(renderer_.View, {
        style: {
          width: 595,
          height: 170,
          backgroundColor: theme/* default.colors.blue */.ZP.colors.blue,
          padding: "25px 25px"
        },
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(renderer_.View, {
          style: {
            flexDirection: "row",
            marginBottom: 20
          },
          children: [organisation.logo && /*#__PURE__*/jsx_runtime_.jsx(renderer_.Image, {
            src: organisation.logo,
            source: {
              header: {
                "Access-Control-Allow-Origin": "*"
              }
            },
            style: {
              width: 75,
              height: 75,
              marginLeft: 10,
              marginRight: 30,
              borderRadius: 10,
              objectFit: "cover"
            }
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(renderer_.View, {
            children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(renderer_.Text, {
              style: _objectSpread(_objectSpread({}, !organisation.logo ? {
                margin: 12
              } : {}), {}, {
                fontSize: 28,
                letterSpacing: 0.27,
                color: theme/* default.colors.white */.ZP.colors.white,
                fontWeight: "bold",
                fontFamily: "Poppins Bold"
              }),
              children: [organisation.name, "'s"]
            }), /*#__PURE__*/jsx_runtime_.jsx(renderer_.Text, {
              style: _objectSpread(_objectSpread({}, !organisation.logo ? {
                margin: 12
              } : {}), {}, {
                fontSize: 28,
                letterSpacing: 0.27,
                color: theme/* default.colors.white */.ZP.colors.white,
                fontWeight: "bold",
                fontFamily: "Poppins Bold"
              }),
              children: "Environmental Policy"
            })]
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx(renderer_.Text, {
          style: _objectSpread(_objectSpread({}, styles.text), {}, {
            color: theme/* default.colors.white */.ZP.colors.white,
            fontSize: 12
          }),
          children: "This policy outlines our environmental efforts and the steps we are taking to encourage good environmental stewardship within our organisation:"
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx(renderer_.View, {
        style: {
          flexDirection: "row",
          flexWrap: "wrap",
          marginTop: 10,
          paddingHorizontal: 40
        },
        children: policyPages(policies, categoryIcons)
      }), /*#__PURE__*/jsx_runtime_.jsx(renderer_.View, {
        style: {
          position: "absolute",
          bottom: 18,
          right: 18,
          display: "flex",
          flexDirection: "row"
        },
        fixed: true,
        children: /*#__PURE__*/jsx_runtime_.jsx(renderer_.Text, {
          style: _objectSpread(_objectSpread({}, styles.text), {}, {
            color: theme/* default.colors.blue */.ZP.colors.blue
          }),
          fixed: true,
          children: "inhabit.eco"
        })
      })]
    })
  });
};

/* harmony default export */ const pdf_Policy = (Policy);

/***/ }),

/***/ 43491:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16666);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_responsive__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _button_Button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(59067);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);





const Container = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "PolicyAddButton__Container",
  componentId: "sc-1hdno1z-0"
})(["display:flex;margin-bottom:5rem;"]);
const ButtonsContainer = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "PolicyAddButton__ButtonsContainer",
  componentId: "sc-1hdno1z-1"
})(["display:flex;align-items:center;justify-content:center;width:100%;", ""], _theme__WEBPACK_IMPORTED_MODULE_1__/* .media.tabletLarge */ .BC.tabletLarge`
    justify-content: flex-start;

  `);
const TextContainer = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "PolicyAddButton__TextContainer",
  componentId: "sc-1hdno1z-2"
})(["line-height:1;"]);

const PolicyAddButton = ({
  onClick
}) => {
  const tablet = (0,react_responsive__WEBPACK_IMPORTED_MODULE_0__.useMediaQuery)({
    query: `(min-width: ${_theme__WEBPACK_IMPORTED_MODULE_1__/* .sizes.tablet */ .J7.tablet}px)`
  });
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(Container, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(ButtonsContainer, {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP, {
        type: "button",
        onClick: onClick,
        children: "Add more"
      })
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PolicyAddButton);

/***/ }),

/***/ 506:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16666);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_responsive__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _button_Button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(59067);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);






const Container = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "PolicyCTAButtons__Container",
  componentId: "sc-14zj4lq-0"
})(["position:fixed;bottom:0;left:0;right:0;height:5rem;background:", ";width:100vw;", " ", ""], p => p.theme.colors.backgroundGrey, _theme__WEBPACK_IMPORTED_MODULE_1__/* .media.mobileLandscape */ .BC.mobileLandscape`
  max-width: 1200px;
  margin: 0 auto;
  `, _theme__WEBPACK_IMPORTED_MODULE_1__/* .media.tablet */ .BC.tablet`
    padding: 0 6.5%;
  `);
const Divider = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "PolicyCTAButtons__Divider",
  componentId: "sc-14zj4lq-1"
})(["margin:0.5rem 0 0.75rem;background:#bed1ff;height:1px;width:100%;"]);
const ButtonsContainer = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "PolicyCTAButtons__ButtonsContainer",
  componentId: "sc-14zj4lq-2"
})(["display:flex;justify-content:space-between;align-items:center;padding:0 1.25rem;", " ", ""], _theme__WEBPACK_IMPORTED_MODULE_1__/* .media.mobileLandscape */ .BC.mobileLandscape`
justify-content: space-between;
  & > button:not(:last-of-type) {
margin-right: 2.25rem;
  }
  `, _theme__WEBPACK_IMPORTED_MODULE_1__/* .media.tablet */ .BC.tablet`
    padding: 0 2rem;
    justify-content: flex-end;
  `);

const PolicyCTAButtons = ({
  onDiscard,
  loading
}) => {
  const tablet = (0,react_responsive__WEBPACK_IMPORTED_MODULE_0__.useMediaQuery)({
    query: `(min-width: ${_theme__WEBPACK_IMPORTED_MODULE_1__/* .sizes.tablet */ .J7.tablet}px)`
  });
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(Container, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(Divider, {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(ButtonsContainer, {
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(_button_Button__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP, {
        secondary: true,
        type: "button",
        onClick: onDiscard,
        width: "11.875rem",
        disabled: loading,
        children: ["Discard ", tablet && "Changes"]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(_button_Button__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP, {
        type: "submit",
        width: "11.875rem",
        loading: loading,
        children: ["Save ", tablet && "Changes"]
      })]
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PolicyCTAButtons);

/***/ }),

/***/ 94406:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16666);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_responsive__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _common_ConfirmationModal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65487);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(87491);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






var Bin = function Bin(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("g", {
      clipPath: "url(#clip0)",
      fill: "#EC5F59",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("path", {
        d: "M11.768 25c-2.014 0-4.028.003-6.041 0-.49 0-.98-.006-1.467-.049-.847-.073-1.573-.835-1.622-1.719-.126-2.313-.235-4.626-.343-6.94-.16-3.384-.314-6.769-.463-10.154-.017-.38-.173-.516-.522-.489a2.16 2.16 0 0 1-.282 0C.413 5.621-.013 5.213 0 4.667c.013-.561.496-.976 1.115-.971 1.712.012 3.424.021 5.136.027 1.275 0 1.274-.005 1.486-1.298.052-.322.092-.647.176-.96.11-.42.355-.792.696-1.057.341-.264.758-.406 1.187-.403 1.335.007 2.67.026 4.007.04 1.085.01 1.81.64 1.988 1.726.083.51.174 1.019.241 1.53.04.312.18.393.49.393 2.031-.004 4.063.013 6.093.033.615.007.99.375 1 .933.008.583-.375.958-1.01.989-.786.037-.772.041-.81.872-.215 4.512-.434 9.024-.657 13.536-.048 1.032-.083 2.067-.136 3.099-.052 1.007-.8 1.796-1.778 1.804-2.484.02-4.969.007-7.453.007l-.004.033zm.063-1.96c2.163 0 4.326-.022 6.49.016.574.01.772-.193.788-.737.025-.841.087-1.682.125-2.523.202-4.474.401-8.95.598-13.424.033-.73.03-.73-.727-.724-2.389.017-4.776.046-7.164.046-2.538 0-5.077-.018-7.615-.054-.452-.006-.567.127-.545.592.22 4.512.405 9.026.628 13.538.04.823.067 1.645.105 2.467.037.769.084.804.827.804h6.49zm.093-19.338v.008c.377 0 .754.022 1.13-.004 1.061-.074 1.043-.08.887-1.179-.063-.435-.252-.576-.67-.566-.976.023-1.954.005-2.932.008-.22 0-.508-.052-.563.246-.086.46-.273.922-.13 1.4.034.113.194.09.307.089.657-.004 1.314-.003 1.971-.003v.001z"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("path", {
        d: "M8.69 18.497c0 .268.003.536 0 .803-.012.631-.339 1.023-.878 1.059-.553.037-.954-.295-1.014-.916a63.554 63.554 0 0 1-.186-2.86 598.873 598.873 0 0 1-.258-6.133c-.028-.742.278-1.15.84-1.2.6-.055.983.3 1.062 1.056.08.756.118 1.523.154 2.289.093 1.967.174 3.935.26 5.902h.02zM17.265 11.124c-.12 2.598-.242 5.195-.363 7.792-.013.19-.037.38-.072.569-.096.577-.47.9-1 .873-.537-.027-.898-.42-.883-1.046.032-1.357.085-2.715.145-4.07.06-1.337.135-2.673.21-4.008.021-.382.04-.765.096-1.142.087-.57.489-.884 1.022-.844.495.04.835.412.857.959.011.305 0 .612 0 .918h-.012zM10.868 14.807c0-1.51-.01-3.019.005-4.528.007-.665.379-1.043.95-1.034.571.009.932.396.935 1.057.01 2.062.004 4.125.008 6.188 0 .898.005 1.796.02 2.693.013.697-.357 1.165-.95 1.175-.604.012-.97-.419-.97-1.137v-4.414h.002z"
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("defs", {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("clipPath", {
        id: "clip0",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("path", {
          fill: "#fff",
          d: "M0 0h23.611v25H0z"
        })
      })
    })]
  }));
};

Bin.defaultProps = {
  width: "24",
  height: "25",
  viewBox: "0 0 24 25",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};




const TitleContainer = styled_components__WEBPACK_IMPORTED_MODULE_6___default().div.withConfig({
  displayName: "PolicyConfirmDelete__TitleContainer",
  componentId: "i2edrk-0"
})(["display:flex;flex-direction:column;align-items:center;justify-content:center;"]);
const BodyContainer = styled_components__WEBPACK_IMPORTED_MODULE_6___default()(TitleContainer).withConfig({
  displayName: "PolicyConfirmDelete__BodyContainer",
  componentId: "i2edrk-1"
})(["padding:0 10%;", ""], _theme__WEBPACK_IMPORTED_MODULE_5__/* .media.tablet */ .BC.tablet`
  padding: 0 25%;
`);

const PolicyConfirmDelete = ({
  showConfirmationModal,
  setShowConfirmationModal,
  confirmationPolicies,
  onConfirm,
  loading
}) => {
  const tablet = (0,react_responsive__WEBPACK_IMPORTED_MODULE_1__.useMediaQuery)({
    query: `(min-width: ${_theme__WEBPACK_IMPORTED_MODULE_5__/* .sizes.tablet */ .J7.tablet}px)`
  });
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_common_ConfirmationModal__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
    open: showConfirmationModal,
    onClose: () => setShowConfirmationModal(!showConfirmationModal),
    onConfirm: () => onConfirm(confirmationPolicies),
    cancelText: "No, don\u2019t save",
    confirmText: tablet ? "Yes, save and delete" : "Yes, save",
    title: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(TitleContainer, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(Bin, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP, {
        size: "modalTitle",
        color: "error",
        children: "Are you sure?"
      })]
    }),
    body: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(BodyContainer, {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP, {
        children: "You\u2019ve removed 1 or more policy statements. Saving this will remove it permanently from your Policy."
      })
    }),
    loading: loading,
    warning: true
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PolicyConfirmDelete);

/***/ }),

/***/ 89004:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_beautiful_dnd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(99191);
/* harmony import */ var react_beautiful_dnd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_beautiful_dnd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(45641);
/* harmony import */ var _hooks_useWarnOnBeforeUnload__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(65220);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _PolicyAddButton__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(43491);
/* harmony import */ var _PolicyCTAButtons__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(506);
/* harmony import */ var _PolicyEditItem__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(79193);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _PolicyEditItem__WEBPACK_IMPORTED_MODULE_8__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _PolicyEditItem__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }













const Container = styled_components__WEBPACK_IMPORTED_MODULE_5___default().div.withConfig({
  displayName: "PolicyEdit__Container",
  componentId: "sc-1f90tp5-0"
})(["height:90%;display:flex;"]);
const PolicyEditItemsContainer = styled_components__WEBPACK_IMPORTED_MODULE_5___default().div.withConfig({
  displayName: "PolicyEdit__PolicyEditItemsContainer",
  componentId: "sc-1f90tp5-1"
})(["width:content;", " ", ";"], _theme__WEBPACK_IMPORTED_MODULE_4__/* .media.tablet */ .BC.tablet`
    padding: unset;
    margin-top: 1.75rem;
    display: flex;
    align-items: flex-start;
    justify-content: center;
    flex-wrap: wrap;
    flex-direction: column;
  `, _theme__WEBPACK_IMPORTED_MODULE_4__/* .media.tabletLarge */ .BC.tabletLarge`
      justify-content: flex-start;
      align-items: flex-start;
  `);

const PolicyEdit = ({
  policies,
  categories,
  onSubmit,
  onDiscard,
  loading
}) => {
  (0,_hooks_useWarnOnBeforeUnload__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)();
  const methods = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_2__.useForm)({
    shouldUnregister: false,
    defaultValues: {
      policies: policies.map(policy => _objectSpread(_objectSpread({}, policy), {}, {
        delete: false
      }, policy.category && {
        policy_category_id: {
          value: policy.policy_category_id,
          label: policy.category.icon
        }
      }))
    }
  });
  const {
    control,
    handleSubmit,
    getValues
  } = methods;
  const {
    fields,
    append,
    move,
    remove
  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_2__.useFieldArray)({
    control,
    name: "policies"
  });

  function onDragEnd(result) {
    if (!result.destination) {
      return;
    }

    if (result.destination.index === result.source.index) {
      return;
    }

    move(result.source.index, result.destination.index);
  }

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    append({
      description: "",
      policy_category_id: null
    }, false);
  }, []);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(Container, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("form", {
      onSubmit: handleSubmit(onSubmit),
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(react_beautiful_dnd__WEBPACK_IMPORTED_MODULE_1__.DragDropContext, {
        onDragEnd: onDragEnd,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(react_beautiful_dnd__WEBPACK_IMPORTED_MODULE_1__.Droppable, {
          droppableId: "droppable",
          children: (provided, snapshot) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.Fragment, {
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(PolicyEditItemsContainer, _objectSpread(_objectSpread({}, provided.droppableProps), {}, {
              ref: provided.innerRef,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.FormProvider, _objectSpread(_objectSpread({}, methods), {}, {
                children: fields && fields.map((policy, index) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(react_beautiful_dnd__WEBPACK_IMPORTED_MODULE_1__.Draggable, {
                  draggableId: `${policy.id}`,
                  index: index,
                  children: (provided, snapshot) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("div", _objectSpread(_objectSpread(_objectSpread({
                    ref: provided.innerRef,
                    "data-cy": `draggable-${index}`
                  }, provided.draggableProps), provided.dragHandleProps), {}, {
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_PolicyEditItem__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                      policy: policy,
                      position: index + 1,
                      index: index,
                      remove: remove,
                      fieldNamePrefix: `policies.${index}`,
                      categories: categories
                    }, policy.id)
                  }))
                }, `${policy.id}`))
              }))
            })), provided.placeholder]
          })
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_PolicyAddButton__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
        onClick: () => append({
          description: "",
          policy_category_id: null
        }),
        loading: loading
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_PolicyCTAButtons__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
        onDiscard: onDiscard
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PolicyEdit);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 79193:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(45641);
/* harmony import */ var react_inlinesvg__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(96932);
/* harmony import */ var react_inlinesvg__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_inlinesvg__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(16666);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_responsive__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_select__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(61929);
/* harmony import */ var react_select__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_select__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(87491);
/* harmony import */ var _form_TextArea__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(77027);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _button_Button__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(59067);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_1__, _form_TextArea__WEBPACK_IMPORTED_MODULE_6__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_1__, _form_TextArea__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
const _excluded = ["children", "src"],
      _excluded2 = ["children", "src"],
      _excluded3 = ["children", "src"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }










var DeleteButton = function DeleteButton(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("circle", {
      cx: "16",
      cy: "16",
      r: "14",
      strokeWidth: "3"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("path", {
      strokeWidth: "3",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      d: "M20.606 12.121l-8.485 8.486M20.727 20.607l-8.485-8.486"
    })]
  }));
};

DeleteButton.defaultProps = {
  width: "32",
  height: "32",
  viewBox: "0 0 32 32",
  fill: "none",
  stroke: "#BBB",
  xmlns: "http://www.w3.org/2000/svg"
};

var DragButton = function DragButton(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("circle", {
      r: "3.396",
      transform: "matrix(-1 0 0 1 3.396 3.396)"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("circle", {
      r: "3.396",
      transform: "matrix(-1 0 0 1 3.396 14)"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("circle", {
      r: "3.396",
      transform: "matrix(-1 0 0 1 3.396 24.604)"
    })]
  }));
};

DragButton.defaultProps = {
  width: "7",
  height: "28",
  viewBox: "0 0 7 28",
  fill: "#BBB",
  xmlns: "http://www.w3.org/2000/svg"
};






const StyledDragButton = styled_components__WEBPACK_IMPORTED_MODULE_9___default()(DragButton).withConfig({
  displayName: "PolicyEditItem__StyledDragButton",
  componentId: "sc-1c8jh9m-0"
})(["margin-right:1rem;margin-top:0.75rem;cursor:grab;"]);
const Container = styled_components__WEBPACK_IMPORTED_MODULE_9___default().div.withConfig({
  displayName: "PolicyEditItem__Container",
  componentId: "sc-1c8jh9m-1"
})(["display:flex;margin-bottom:1rem;align-items:flex-start;justify:flex-start;&:active{& > ", "{fill:", ";}}"], StyledDragButton, p => p.theme.colors.progressYellow);
const StyledDeleteButton = styled_components__WEBPACK_IMPORTED_MODULE_9___default()(DeleteButton).withConfig({
  displayName: "PolicyEditItem__StyledDeleteButton",
  componentId: "sc-1c8jh9m-2"
})(["margin-left:1rem;cursor:pointer;&:active{stroke:", ";}"], p => p.theme.colors.progressYellow);
const IconContainer = styled_components__WEBPACK_IMPORTED_MODULE_9___default().div.withConfig({
  displayName: "PolicyEditItem__IconContainer",
  componentId: "sc-1c8jh9m-3"
})(["min-width:3rem;width:3rem;height:3rem;display:flex;align-items:center;justify-content:center;background-color:#fbd365;border-radius:10px;"]);
const Description = styled_components__WEBPACK_IMPORTED_MODULE_9___default().div.withConfig({
  displayName: "PolicyEditItem__Description",
  componentId: "sc-1c8jh9m-4"
})(["height:15rem;", " ", " ", ""], _theme__WEBPACK_IMPORTED_MODULE_8__/* .media.mobileModern */ .BC.mobileModern`
  width: 12rem;
  height: unset;
  `, _theme__WEBPACK_IMPORTED_MODULE_8__/* .media.mobileLandscape */ .BC.mobileLandscape`
  width: 14rem;
  height: unset;
  `, _theme__WEBPACK_IMPORTED_MODULE_8__/* .media.mobileLarge */ .BC.mobileLarge`
  width: 32.5rem;
  `);
const DeletedContainer = styled_components__WEBPACK_IMPORTED_MODULE_9___default().div.withConfig({
  displayName: "PolicyEditItem__DeletedContainer",
  componentId: "sc-1c8jh9m-5"
})(["display:flex;"]);
const Icon = styled_components__WEBPACK_IMPORTED_MODULE_9___default()((react_inlinesvg__WEBPACK_IMPORTED_MODULE_2___default())).withConfig({
  displayName: "PolicyEditItem__Icon",
  componentId: "sc-1c8jh9m-6"
})(["width:1.5rem;height:1.5rem;"]);
const ButtonContainer = styled_components__WEBPACK_IMPORTED_MODULE_9___default().div.withConfig({
  displayName: "PolicyEditItem__ButtonContainer",
  componentId: "sc-1c8jh9m-7"
})(["margin-left:1rem;"]);

const SingleValue = _ref => {
  let {
    children,
    src
  } = _ref,
      props = _objectWithoutProperties(_ref, _excluded);

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(react_select__WEBPACK_IMPORTED_MODULE_4__.components.SingleValue, _objectSpread(_objectSpread({}, props), {}, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(IconContainer, _objectSpread(_objectSpread({}, props), {}, {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(Icon, {
        src: props.getValue()[0].label
      })
    }))
  }));
};

const Option = _ref2 => {
  let {
    children,
    src
  } = _ref2,
      props = _objectWithoutProperties(_ref2, _excluded2);

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(react_select__WEBPACK_IMPORTED_MODULE_4__.components.Option, _objectSpread(_objectSpread({}, props), {}, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(IconContainer, _objectSpread(_objectSpread({}, props), {}, {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(Icon, {
        src: props.label
      })
    }))
  }));
};

const Placeholder = _ref3 => {
  let {
    children,
    src
  } = _ref3,
      props = _objectWithoutProperties(_ref3, _excluded3);

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(react_select__WEBPACK_IMPORTED_MODULE_4__.components.Placeholder, _objectSpread(_objectSpread({}, props), {}, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(IconContainer, _objectSpread({}, props))
  }));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.forwardRef)(({
  policy,
  categories,
  fieldNamePrefix,
  position,
  index,
  remove
}, ref) => {
  const tablet = (0,react_responsive__WEBPACK_IMPORTED_MODULE_3__.useMediaQuery)({
    query: `(min-width: ${_theme__WEBPACK_IMPORTED_MODULE_8__/* .sizes.tablet */ .J7.tablet}px)`
  });
  const {
    0: deleted,
    1: setDeleted
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    control,
    setValue
  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_1__.useFormContext)();
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    setValue(`${fieldNamePrefix}.delete`, deleted);
  }, [deleted]);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    setValue(`${fieldNamePrefix}.position`, position);
  }, [position]);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(Container, {
    ref: ref,
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("input", {
      name: "id",
      disabled: true,
      hidden: true
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("input", {
      name: `${fieldNamePrefix}.delete`,
      disabled: true,
      hidden: true
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("input", {
      name: `${fieldNamePrefix}.position`,
      disabled: true,
      hidden: true
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(StyledDragButton, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_1__.Controller, {
      render: ({
        field
      }) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx((react_select__WEBPACK_IMPORTED_MODULE_4___default()), {
        styles: {
          container: base => _objectSpread(_objectSpread({}, base), {}, {
            width: "3rem",
            height: "3rem",
            marginRight: "1.5rem",
            background: "none",
            ":focus": {
              outline: "none"
            }
          }),
          singleValue: base => _objectSpread(_objectSpread({}, base), {}, {
            maxWidth: "unset",
            top: 0,
            transform: "unset"
          }),
          placeholder: base => _objectSpread(_objectSpread({}, base), {}, {
            top: 0,
            transform: "unset"
          }),
          valueContainer: base => _objectSpread(_objectSpread({}, base), {}, {
            overflow: "unset",
            padding: "unset"
          }),
          indicatorsContainer: base => _objectSpread(_objectSpread({}, base), {}, {
            display: "none"
          }),
          control: base => _objectSpread(_objectSpread({}, base), {}, {
            background: "none",
            borderWidth: 0,
            boxShadow: "none"
          }),
          menu: base => _objectSpread(_objectSpread({}, base), {}, {
            width: "5rem",
            padding: 0
          }),
          menuList: base => _objectSpread({}, base),
          option: (base, {
            isSelected
          }) => _objectSpread(_objectSpread({}, base), {}, {
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            padding: "1rem"
          }, isSelected && {
            background: _theme__WEBPACK_IMPORTED_MODULE_8__/* ["default"].colors.backgroundYellow */ .ZP.colors.backgroundYellow
          })
        },
        defaultValue: policy.category && {
          value: policy.category.id,
          label: policy.category.icon
        },
        options: categories.map(category => ({
          value: category.id,
          label: category.icon
        })),
        onChange: value => field.onChange(value),
        components: {
          SingleValue,
          Option,
          Placeholder
        }
      }),
      name: `${fieldNamePrefix}.policy_category_id`,
      control: control
    }), deleted ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(DeletedContainer, {
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(_common_Text__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP, {
          color: "blue",
          size: "subtitle",
          children: ["Policy statement deleted.", " "]
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(ButtonContainer, {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .ZP, {
            type: "button",
            small: true,
            onClick: () => setDeleted(false),
            children: "Undo"
          })
        })]
      })
    }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(Description, {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_form_TextArea__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
          size: tablet ? "subtitle" : "tiny",
          name: `${fieldNamePrefix}.description`,
          defaultValue: policy.description,
          maxLength: 280,
          placeholder: "Enter a policy statement here..."
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(StyledDeleteButton, {
        onClick: () => Number.isInteger(policy.id) ? setDeleted(true) : remove(index)
      })]
    })]
  });
}));
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 53851:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ policy_PolicyList)
});

// EXTERNAL MODULE: ./src/theme.js
var theme = __webpack_require__(91073);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(57518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
// EXTERNAL MODULE: external "react-inlinesvg"
var external_react_inlinesvg_ = __webpack_require__(96932);
var external_react_inlinesvg_default = /*#__PURE__*/__webpack_require__.n(external_react_inlinesvg_);
// EXTERNAL MODULE: external "react-responsive"
var external_react_responsive_ = __webpack_require__(16666);
// EXTERNAL MODULE: ./src/components/common/Text.jsx
var Text = __webpack_require__(87491);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
;// CONCATENATED MODULE: ./src/components/policy/PolicyItem.jsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






var PolicyIcon = function PolicyIcon(props) {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/jsx_runtime_.jsx("path", {
      d: "M9.554-.001c.711.184 1.334.536 1.617 1.227.185.454.452.508.854.483.382-.025.767-.008 1.15-.005.475.005.72.224.737.692.008.205.098.24.274.238.554-.006 1.11-.002 1.664 0 1.45 0 2.36.893 2.366 2.348.01 2.252.004 4.505.004 6.758v10.503c0 .302-.01.604-.037.904-.087.951-1 1.808-1.959 1.847H2.168a2.123 2.123 0 0 1-2.11-1.731C-.02 22.87 0 22.466 0 22.067V5.048c0-.883.282-1.614 1.06-2.1a2.104 2.104 0 0 1 1.116-.316 88.12 88.12 0 0 1 1.837 0c.2.003.29-.041.298-.267.017-.442.263-.657.714-.663.53-.007 1.06-.003 1.591-.004.108 0 .217.007.263-.124.302-.861.928-1.354 1.79-1.58L9.554 0zm7.185 13.814V7.569c0-.89.003-1.78 0-2.67 0-.441-.25-.759-.623-.767-.662-.015-1.323-.004-1.984-.01-.164 0-.213.08-.21.228.004.237.007.474 0 .71-.016.427-.275.682-.702.682-2.727.002-5.453.002-8.18 0-.474 0-.72-.245-.732-.725a8.925 8.925 0 0 1 0-.638c.01-.19-.062-.26-.254-.258-.612.009-1.224 0-1.837.006-.45.004-.705.26-.726.715-.006.122-.004.245-.004.367v17.46c0 .613.262.874.887.874h10.432c1.02 0 2.04.003 3.061 0 .61-.003.866-.263.871-.866v-.245l.001-8.62zm-7.633-9.32c1.094 0 2.187-.005 3.28.004.226 0 .303-.07.295-.294a9.86 9.86 0 0 1 0-.979c.01-.219-.068-.281-.281-.277-.604.012-1.208.005-1.812.004-.325 0-.353-.03-.357-.344 0-.114.007-.229-.004-.343-.04-.455-.267-.794-.687-.96-.42-.166-.818-.107-1.166.196-.318.28-.385.643-.375 1.043.01.39-.014.406-.392.406-.604 0-1.208.005-1.812-.003-.18-.002-.245.058-.241.24.01.344.014.687 0 1.031-.01.216.063.281.278.28 1.087-.009 2.18-.004 3.274-.004z"
    }), /*#__PURE__*/jsx_runtime_.jsx("path", {
      d: "M11.187 18.652c.947 0 1.894-.005 2.841 0 .52.004.834.475.61.903-.138.262-.374.344-.656.344-1.069-.002-2.138-.002-3.208 0-.8 0-1.6.004-2.4-.004-.524-.004-.834-.47-.607-.9.131-.25.354-.344.628-.344.931.002 1.862.003 2.792.001zM11.193 10.15c-.938 0-1.877.006-2.816 0-.524-.004-.835-.47-.609-.901.137-.261.37-.344.654-.344 1.608.003 3.216.003 4.824 0 .26 0 .522-.004.785 0 .397.008.68.27.681.621 0 .352-.277.622-.677.624-.95.004-1.898 0-2.842 0zM11.186 13.784h2.81c.383 0 .662.203.708.535.043.31-.165.619-.47.675-.17.03-.34.042-.512.039-.912-.015-1.823-.008-2.734 0-.904.006-1.807-.01-2.71-.027a.612.612 0 0 1-.59-.604.618.618 0 0 1 .615-.605c.773-.007 1.547 0 2.32-.003h.563v-.01zM3.92 13.404c.24 0 .403.133.54.32.38.508.382.507.77 0 .294-.39.588-.782.886-1.169.265-.344.615-.416.913-.196.298.22.332.594.08.932-.57.765-1.143 1.526-1.721 2.284-.328.428-.77.418-1.098-.013a69.8 69.8 0 0 1-.892-1.194.574.574 0 0 1-.034-.667c.123-.21.311-.303.556-.297zM4.855 11.001a.617.617 0 0 1-.516-.259c-.312-.408-.627-.814-.925-1.232-.2-.278-.179-.557.024-.785.256-.288.674-.28.944.03.123.142.237.291.344.446.095.138.163.114.253-.009.374-.506.754-1.003 1.13-1.505.139-.186.308-.317.548-.322a.58.58 0 0 1 .543.314.589.589 0 0 1-.041.67c-.22.303-.45.6-.675.9-.357.475-.715.951-1.072 1.429-.143.191-.314.33-.557.323zM7.278 17.713a.642.642 0 0 1-.135.41c-.583.776-1.162 1.557-1.752 2.328-.32.42-.762.416-1.085 0-.29-.374-.577-.75-.855-1.134-.256-.353-.218-.709.082-.928.3-.22.649-.142.917.196.13.162.213.451.404.448.167-.003.262-.284.386-.442.315-.406.618-.821.935-1.227a.612.612 0 0 1 1.103.349z"
    })]
  }));
};

PolicyIcon.defaultProps = {
  width: "19",
  height: "25",
  viewBox: "0 0 19 25",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};




const Container = external_styled_components_default().div.withConfig({
  displayName: "PolicyItem__Container",
  componentId: "n0p6xo-0"
})(["display:flex;margin-bottom:2rem;align-items:flex-start;", ""], theme/* media.tablet */.BC.tablet`
  width: 15rem;
  margin-bottom: 5rem;
    flex-direction: column;
  `);
const IconContainer = external_styled_components_default().div.withConfig({
  displayName: "PolicyItem__IconContainer",
  componentId: "n0p6xo-1"
})(["min-width:3rem;width:3rem;height:3rem;display:flex;align-items:center;justify-content:center;border-radius:10px;margin-right:1.5rem;background-color:", ";& > svg{height:1.5rem;width:1.5rem;fill:", ";}", ""], p => p.theme.colors.progressYellow, p => p.theme.colors.black, theme/* media.tablet */.BC.tablet`
    margin-bottom: 1rem;
  `);
const Description = external_styled_components_default().div.withConfig({
  displayName: "PolicyItem__Description",
  componentId: "n0p6xo-2"
})(["overflow-wrap:break-word;line-height:1;"]);
const Icon = external_styled_components_default()((external_react_inlinesvg_default())).withConfig({
  displayName: "PolicyItem__Icon",
  componentId: "n0p6xo-3"
})([""]);

const PolicyItem = ({
  policy
}) => {
  const tablet = (0,external_react_responsive_.useMediaQuery)({
    query: `(min-width: ${theme/* sizes.tablet */.J7.tablet}px)`
  });
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(Container, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(IconContainer, {
      children: policy.category && policy.category.icon ? /*#__PURE__*/jsx_runtime_.jsx(Icon, {
        src: policy.category.icon
      }) : /*#__PURE__*/jsx_runtime_.jsx(PolicyIcon, {})
    }), /*#__PURE__*/jsx_runtime_.jsx(Description, {
      children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
        size: tablet ? "subtitle" : "tiny",
        children: policy.description
      })
    })]
  });
};

/* harmony default export */ const policy_PolicyItem = (PolicyItem);
;// CONCATENATED MODULE: ./src/components/policy/PolicyList.jsx




const PolicyItemsContainer = external_styled_components_default().div.withConfig({
  displayName: "PolicyList__PolicyItemsContainer",
  componentId: "sc-84b0w7-0"
})(["", " ", " ", ""], theme/* media.tablet */.BC.tablet`
    padding: unset;
    margin-top: 1.75rem;
    display: flex;
    flex-wrap: wrap;

    &> div:not(:nth-child(2n)) {
      margin-right: 4.5rem;
    }
  `, theme/* media.tabletLarge */.BC.tabletLarge`
    padding: unset;
    margin-top: 1.75rem;
    display: flex;
    flex-wrap: wrap;

    &> div:not(:nth-child(2n)) {
      margin-right: unset;
    }

    &> div:not(:nth-child(3n)) {
      margin-right: 4.5rem;
    }
  `, theme/* media.desktopLarge */.BC.desktopLarge`
    &> div:not(:nth-child(3n)) {
      margin-right: unset;
    }

    &> div:not(:nth-child(4n)) {
      margin-right: 4.5rem;
    }
  `);

const PolicyList = ({
  policies
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx(PolicyItemsContainer, {
    children: policies && policies.map(policy => /*#__PURE__*/jsx_runtime_.jsx(policy_PolicyItem, {
      policy: policy
    }))
  });
};

/* harmony default export */ const policy_PolicyList = (PolicyList);

/***/ }),

/***/ 65220:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export handleBeforeUnload */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const handleBeforeUnload = e => {
  e.preventDefault();
  const returnValue = "Changes that you made may not be saved.";
  e.returnValue = returnValue;
  return returnValue;
};

const useWarnOnBeforeUnload = () => {
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (true) {
      window.addEventListener("beforeunload", handleBeforeUnload);
      return () => window.removeEventListener("beforeunload", handleBeforeUnload);
    }
  }, []);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useWarnOnBeforeUnload);

/***/ }),

/***/ 49891:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _react_pdf_renderer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(13260);
/* harmony import */ var _react_pdf_renderer__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_button_Button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(59067);
/* harmony import */ var _components_common_FormToastContainer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(41593);
/* harmony import */ var _components_common_LoadingLarge__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(49899);
/* harmony import */ var _components_common_Page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(97598);
/* harmony import */ var _components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(60805);
/* harmony import */ var _components_common_Spinner__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(16114);
/* harmony import */ var _components_ContentContainer__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(16067);
/* harmony import */ var _components_pdf_Policy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(78082);
/* harmony import */ var _components_policy_PolicyConfirmDelete__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(94406);
/* harmony import */ var _components_policy_PolicyEdit__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(89004);
/* harmony import */ var _components_policy_PolicyList__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(53851);
/* harmony import */ var _contexts_auth__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(58368);
/* harmony import */ var _contexts_policy__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(24175);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_6__, _components_policy_PolicyEdit__WEBPACK_IMPORTED_MODULE_11__]);
([_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_6__, _components_policy_PolicyEdit__WEBPACK_IMPORTED_MODULE_11__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


















const CONTAINER_ID = "policy";
const PDFLink = styled_components__WEBPACK_IMPORTED_MODULE_15___default()(_react_pdf_renderer__WEBPACK_IMPORTED_MODULE_0__.PDFDownloadLink).withConfig({
  displayName: "policy__PDFLink",
  componentId: "sc-1wafpyc-0"
})(["", ""], _components_button_Button__WEBPACK_IMPORTED_MODULE_2__/* .buttonStyles */ .$Y);

function Policy() {
  const {
    organisation,
    user,
    isAdmin
  } = (0,_contexts_auth__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z)();
  const {
    policies,
    categories,
    getPolicies,
    setPolicies,
    categoryIcons,
    confirmationPolicies,
    handlePolicies,
    submitPolicies,
    loading,
    progress,
    setProgress,
    showConfirmationModal,
    setShowConfirmationModal,
    editing,
    setEditing
  } = (0,_contexts_policy__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z)();
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
    getPolicies();
  }, []);
  const {
    0: ready,
    1: setReady
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
    setTimeout(() => {
      setReady(true);
    }, 3000);
  }, []);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_components_common_Page__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)(_components_ContentContainer__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
      title: `${organisation.name}'s Policy`,
      description: "This policy outlines our environmental efforts and the steps we are taking to encourage good environmental stewardship within our organisation:",
      cta: editing || !isAdmin({
        organisation,
        user
      }) ? null : "Add / Edit",
      onClick: () => setEditing(!editing),
      secondaryCta: editing ? null : !!policies.length && ready ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(PDFLink, {
        secondary: true,
        document: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_components_pdf_Policy__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
          organisation: organisation,
          policies: policies,
          categoryIcons: categoryIcons
        }),
        fileName: `${organisation.name}_policy.pdf`,
        children: "Export"
      }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_components_common_Spinner__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
        color: "blue"
      }),
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_components_common_FormToastContainer__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        containerId: CONTAINER_ID,
        maxWidth: "70%"
      }), loading ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_components_common_LoadingLarge__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
        loading: loading,
        text: editing ? "Saving changes..." : "Getting Policies...",
        progress: progress,
        setProgress: setProgress
      }) : editing ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_components_policy_PolicyEdit__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
        policies: policies,
        categories: categories,
        onSubmit: submitPolicies,
        setPolicies: setPolicies,
        loading: loading,
        onDiscard: () => setEditing(!editing)
      }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_components_policy_PolicyList__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
        policies: policies
      }), showConfirmationModal && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_components_policy_PolicyConfirmDelete__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
        showConfirmationModal: showConfirmationModal,
        setShowConfirmationModal: setShowConfirmationModal,
        confirmationPolicies: confirmationPolicies,
        onConfirm: handlePolicies,
        loading: loading
      })]
    })
  });
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)(Policy));
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 32004:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "unstable_getStaticParams": () => (/* binding */ unstable_getStaticParams),
/* harmony export */   "unstable_getStaticProps": () => (/* binding */ unstable_getStaticProps),
/* harmony export */   "unstable_getStaticPaths": () => (/* binding */ unstable_getStaticPaths),
/* harmony export */   "unstable_getServerProps": () => (/* binding */ unstable_getServerProps),
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "_app": () => (/* binding */ _app),
/* harmony export */   "renderReqToHTML": () => (/* binding */ renderReqToHTML),
/* harmony export */   "render": () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(70607);
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59450);
/* harmony import */ var private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97020);
/* harmony import */ var private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(73978);
/* harmony import */ var next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99436);

      
      
      
      

      
      const { processEnv } = __webpack_require__(85360)
      processEnv([{"path":".env","contents":"API_HOST=https://api.inhabit.eco\nNEXT_PUBLIC_CALENDLY_URL=https://calendly.com/inhabit-meet/inhabit-measurement-tutorial\nNEXT_PUBLIC_FLAGS_ENVIRONMENT_KEY=flags_pub_289425705564897805\nNEXT_PUBLIC_GOOGLE_ANALYTICS=G-1CBB78XFQ4\nNEXT_PUBLIC_INTERCOM_APP_ID=bw9p6mfd\nNEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_bQDaTEuYc10x3BZt9YcGj2cE00Gzwm4gDD\nSTRIPE_PUBLISHABLE_KEY=pk_live_bQDaTEuYc10x3BZt9YcGj2cE00Gzwm4gDD\n\n"}])
    
      
      const runtimeConfig = {}
      ;

      const documentModule = __webpack_require__(9968)

      const appMod = __webpack_require__(13724)
      let App = appMod.default || appMod.then && appMod.then(mod => mod.default);

      const compMod = __webpack_require__(49891)

      const Component = compMod.default || compMod.then && compMod.then(mod => mod.default)
      /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Component);
      const getStaticProps = compMod['getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['getStaticProp' + 's'])
      const getStaticPaths = compMod['getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['getStaticPath' + 's'])
      const getServerSideProps = compMod['getServerSideProp' + 's'] || compMod.then && compMod.then(mod => mod['getServerSideProp' + 's'])

      // kept for detecting legacy exports
      const unstable_getStaticParams = compMod['unstable_getStaticParam' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticParam' + 's'])
      const unstable_getStaticProps = compMod['unstable_getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticProp' + 's'])
      const unstable_getStaticPaths = compMod['unstable_getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticPath' + 's'])
      const unstable_getServerProps = compMod['unstable_getServerProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getServerProp' + 's'])

      let config = compMod['confi' + 'g'] || (compMod.then && compMod.then(mod => mod['confi' + 'g'])) || {}
      const _app = App

      const combinedRewrites = Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)
        ? private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg
        : []

      if (!Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)) {
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.beforeFiles */ .Dg.beforeFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.afterFiles */ .Dg.afterFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.fallback */ .Dg.fallback)
      }

      const { renderReqToHTML, render } = (0,next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__/* .getPageHandler */ .u)({
        pageModule: compMod,
        pageComponent: Component,
        pageConfig: config,
        appModule: App,
        documentModule: documentModule,
        errorModule: __webpack_require__(99651),
        notFoundModule: undefined,
        pageGetStaticProps: getStaticProps,
        pageGetStaticPaths: getStaticPaths,
        pageGetServerSideProps: getServerSideProps,

        assetPrefix: "",
        canonicalBase: "",
        generateEtags: true,
        poweredByHeader: true,
        reactRoot: false,

        runtimeConfig,
        buildManifest: private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__,
        reactLoadableManifest: private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__,

        rewrites: combinedRewrites,
        i18n: undefined,
        page: "/policy",
        buildId: "lDoX7RBEQ31kzKIJJbkVC",
        escapedBuildId: "lDoX7RBEQ31kzKIJJbkVC",
        basePath: "",
        pageIsDynamic: false,
        encodedPreviewProps: {previewModeId:"89cdc9f6073608262d43eab6d636f3f4",previewModeSigningKey:"74c7e36a2414a3f7b0ebcc67250f915f156686e1610b45a21ae9358d5b7c6c5a",previewModeEncryptionKey:"8a4c97ad9e5cf12d5a140689be08539ea52d8b27a416c2b8ae67db636b45841b"}
      })
      
    

/***/ }),

/***/ 94970:
/***/ ((module) => {

module.exports = require("@happykit/flags/client");

/***/ }),

/***/ 46411:
/***/ ((module) => {

module.exports = require("@happykit/flags/config");

/***/ }),

/***/ 48095:
/***/ ((module) => {

module.exports = require("@happykit/flags/server");

/***/ }),

/***/ 83218:
/***/ ((module) => {

module.exports = require("@hookform/error-message");

/***/ }),

/***/ 48308:
/***/ ((module) => {

module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ 85360:
/***/ ((module) => {

module.exports = require("@next/env");

/***/ }),

/***/ 13260:
/***/ ((module) => {

module.exports = require("@react-pdf/renderer");

/***/ }),

/***/ 64515:
/***/ ((module) => {

module.exports = require("@stripe/react-stripe-js");

/***/ }),

/***/ 20943:
/***/ ((module) => {

module.exports = require("@stripe/stripe-js");

/***/ }),

/***/ 52167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 74146:
/***/ ((module) => {

module.exports = require("date-fns");

/***/ }),

/***/ 1043:
/***/ ((module) => {

module.exports = require("lodash.get");

/***/ }),

/***/ 51650:
/***/ ((module) => {

module.exports = require("lodash.uniqby");

/***/ }),

/***/ 54426:
/***/ ((module) => {

module.exports = require("next/dist/compiled/chalk");

/***/ }),

/***/ 40252:
/***/ ((module) => {

module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 19371:
/***/ ((module) => {

module.exports = require("next/dist/compiled/node-fetch");

/***/ }),

/***/ 97999:
/***/ ((module) => {

module.exports = require("next/dist/compiled/path-to-regexp");

/***/ }),

/***/ 60600:
/***/ ((module) => {

module.exports = require("next/dist/server/accept-header.js");

/***/ }),

/***/ 52155:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils/index.js");

/***/ }),

/***/ 90730:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils/node.js");

/***/ }),

/***/ 60562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 94140:
/***/ ((module) => {

module.exports = require("next/dist/server/get-page-files.js");

/***/ }),

/***/ 89716:
/***/ ((module) => {

module.exports = require("next/dist/server/htmlescape.js");

/***/ }),

/***/ 25071:
/***/ ((module) => {

module.exports = require("next/dist/server/render-result.js");

/***/ }),

/***/ 33100:
/***/ ((module) => {

module.exports = require("next/dist/server/render.js");

/***/ }),

/***/ 92779:
/***/ ((module) => {

module.exports = require("next/dist/server/request-meta.js");

/***/ }),

/***/ 79502:
/***/ ((module) => {

module.exports = require("next/dist/server/send-payload.js");

/***/ }),

/***/ 76368:
/***/ ((module) => {

module.exports = require("next/dist/server/utils.js");

/***/ }),

/***/ 56724:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 27664:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/escape-regexp.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 94957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 82374:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-locale-cookie.js");

/***/ }),

/***/ 34014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 78524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 78020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 29565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 64365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 95714:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-route-from-asset-path.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 91292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 25753:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-match.js");

/***/ }),

/***/ 99521:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/prepare-destination.js");

/***/ }),

/***/ 80979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 36052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 84226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 95566:
/***/ ((module) => {

module.exports = require("next/error");

/***/ }),

/***/ 40968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 71853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 59819:
/***/ ((module) => {

module.exports = require("querystring");

/***/ }),

/***/ 16689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 99191:
/***/ ((module) => {

module.exports = require("react-beautiful-dnd");

/***/ }),

/***/ 25716:
/***/ ((module) => {

module.exports = require("react-hotjar");

/***/ }),

/***/ 96932:
/***/ ((module) => {

module.exports = require("react-inlinesvg");

/***/ }),

/***/ 16666:
/***/ ((module) => {

module.exports = require("react-responsive");

/***/ }),

/***/ 61929:
/***/ ((module) => {

module.exports = require("react-select");

/***/ }),

/***/ 1187:
/***/ ((module) => {

module.exports = require("react-toastify");

/***/ }),

/***/ 20997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 57518:
/***/ ((module) => {

module.exports = require("styled-components");

/***/ }),

/***/ 24535:
/***/ ((module) => {

module.exports = require("styled-normalize");

/***/ }),

/***/ 6153:
/***/ ((module) => {

module.exports = require("universal-cookie");

/***/ }),

/***/ 84269:
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ 75609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 61908:
/***/ ((module) => {

module.exports = import("@hookform/resolvers/yup");;

/***/ }),

/***/ 45641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [4357,9703,6114,9067,8183,9899,805,6067,1593], () => (__webpack_exec__(32004)));
module.exports = __webpack_exports__;

})();