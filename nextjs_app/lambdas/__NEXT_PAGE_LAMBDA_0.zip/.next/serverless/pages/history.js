"use strict";
(() => {
var exports = {};
exports.id = 8276;
exports.ids = [8276];
exports.modules = {

/***/ 22873:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(87491);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);



const Button = styled_components__WEBPACK_IMPORTED_MODULE_1___default().button.withConfig({
  displayName: "TextButton__Button",
  componentId: "sc-10zi0dq-0"
})(["cursor:pointer;display:flex;align-items:center;justify-content:center;border:none;border-radius:10px;background:inherit;span{text-decoration:underline;}"]);

const TextButton = ({
  onClick,
  children,
  size = "small"
}) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(Button, {
  onClick: onClick,
  type: "button",
  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .ZP, {
    size: size,
    color: "blue",
    children: children
  })
});

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TextButton);

/***/ }),

/***/ 6394:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ history_HistoryTable)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
// EXTERNAL MODULE: external "date-fns"
var external_date_fns_ = __webpack_require__(74146);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(71853);
// EXTERNAL MODULE: external "react-responsive"
var external_react_responsive_ = __webpack_require__(16666);
// EXTERNAL MODULE: ./src/components/button/Button.jsx
var Button = __webpack_require__(59067);
// EXTERNAL MODULE: ./src/components/button/TextButton.jsx
var TextButton = __webpack_require__(22873);
// EXTERNAL MODULE: ./src/components/common/Divider.jsx
var Divider = __webpack_require__(6459);
// EXTERNAL MODULE: ./src/components/common/Text.jsx
var Text = __webpack_require__(87491);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(57518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
;// CONCATENATED MODULE: ./src/components/common/Table.jsx





const Container = external_styled_components_default().div.withConfig({
  displayName: "Table__Container",
  componentId: "sc-1rgpvn0-0"
})([""]);
const Row = external_styled_components_default().div.withConfig({
  displayName: "Table__Row",
  componentId: "sc-1rgpvn0-1"
})(["display:flex;"]);
const Cell = external_styled_components_default().div.withConfig({
  displayName: "Table__Cell",
  componentId: "sc-1rgpvn0-2"
})(["padding:0.875rem 0.5rem;display:flex;align-items:center;justify-content:flex-start;", ""], p => p.width && `width: ${p.width};`);
const HeaderRow = external_styled_components_default()(Row).withConfig({
  displayName: "Table__HeaderRow",
  componentId: "sc-1rgpvn0-3"
})(["padding:0 0.625rem;"]);
const SUPPLIER_WIDTH = "30%";
const CATEGORY_WIDTH = "30%";
const AMOUNT_WIDTH = "10%";
const EMISSIONS_WIDTH = "10%";
const EDIT_WIDTH = "10%";

const Table = ({
  headers,
  key,
  children
}) => {
  const dataKey = key || "id";
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(Container, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(HeaderRow, {
      children: headers.map(({
        name,
        width
      }) => /*#__PURE__*/jsx_runtime_.jsx(Cell, {
        width,
        children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
          size: "tiny",
          children: name
        })
      }))
    }), /*#__PURE__*/jsx_runtime_.jsx(Divider/* default */.Z, {
      secondary: true,
      margin: "0 auto 1.5px",
      width: "99%",
      color: "black"
    }), children]
  });
};

/* harmony default export */ const common_Table = (Table);
;// CONCATENATED MODULE: ./src/components/common/TableCell.jsx

const TableCell = external_styled_components_default().div.withConfig({
  displayName: "TableCell",
  componentId: "zxv17a-0"
})(["padding:0.875rem 0.5rem;display:flex;align-items:center;justify-content:flex-start;", " & > *:not(:last-child){margin-right:1rem;}"], p => p.width && `width: ${p.width};`);
/* harmony default export */ const common_TableCell = (TableCell);
;// CONCATENATED MODULE: ./src/components/common/TableRow.jsx






const createColor = ({
  color,
  size,
  theme
}) => theme.colors[color] || size && theme[size].color || theme.colors.transparent;

const TableRow_Container = external_styled_components_default().div.withConfig({
  displayName: "TableRow__Container",
  componentId: "juqs8s-0"
})([""]);
const InnerContainer = external_styled_components_default().div.withConfig({
  displayName: "TableRow__InnerContainer",
  componentId: "juqs8s-1"
})(["border:2px solid ", ";", ";"], p => p.theme.colors.transparent, p => p.editing && (0,external_styled_components_.css)(["border:2px solid ", ";border-radius:4px;"], p => p.theme.colors.blue));
const TableRow_Row = external_styled_components_default().div.withConfig({
  displayName: "TableRow__Row",
  componentId: "juqs8s-2"
})(["display:flex;border-radius:2px;transition:background-color 0.3s;padding:0 0.625rem;background-color:", ";"], createColor);

const TableRow = ({
  children,
  key,
  color
}) => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(TableRow_Container, {
      children: /*#__PURE__*/jsx_runtime_.jsx(InnerContainer, {
        children: /*#__PURE__*/jsx_runtime_.jsx(TableRow_Row, {
          color: color,
          children: children
        }, key)
      })
    }), /*#__PURE__*/jsx_runtime_.jsx(Divider/* default */.Z, {
      secondary: true,
      margin: "1.5px auto 1.5px",
      width: "99%"
    })]
  });
};

/* harmony default export */ const common_TableRow = (TableRow);
// EXTERNAL MODULE: ./src/components/data-collection/utils/index.js
var utils = __webpack_require__(63033);
// EXTERNAL MODULE: ./src/components/measurement/utils/charts.js
var charts = __webpack_require__(19343);
// EXTERNAL MODULE: ./src/theme.js
var theme = __webpack_require__(91073);
;// CONCATENATED MODULE: ./src/components/history/HistoryTable.jsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }















var CarbonNeutralIcon = function CarbonNeutralIcon(props) {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("g", {
      clipPath: "url(#clip0_6163_87762)",
      children: [/*#__PURE__*/jsx_runtime_.jsx("path", {
        d: "M19.292 36a1.073 1.073 0 0 0-.29-.04 17.13 17.13 0 0 1-5.804-1.519 17.34 17.34 0 0 1-7.13-6.049 16.904 16.904 0 0 1-1.948-3.854 18.417 18.417 0 0 1-.622-2.22c-.05-.228-.019-.43.135-.609a.6.6 0 0 1 .278-.179c.237-.075.473-.156.712-.227.39-.115.732.086.818.482.104.48.219.957.36 1.427.39 1.294.953 2.529 1.677 3.672A15.512 15.512 0 0 0 9.87 29.81a15.058 15.058 0 0 0 3.127 2.296 15.029 15.029 0 0 0 5.284 1.769c.556.077 1.113.114 1.674.142.467.019.935.013 1.401-.018a15.235 15.235 0 0 0 8.239-3.01 15.184 15.184 0 0 0 3.626-3.843c.972-1.47 1.677-3.099 2.08-4.812.15-.646.256-1.301.32-1.961.074-.735.096-1.474.067-2.211-.05-1.18-.243-2.35-.575-3.485a15.19 15.19 0 0 0-4.063-6.708 15.348 15.348 0 0 0-6.884-3.813 14.909 14.909 0 0 0-3.126-.441c-.258-.009-.516-.021-.774-.016-.431.01-.862.032-1.292.07a15.09 15.09 0 0 0-3.084.605c-.137.042-.138.043-.078.166.234.488.412 1 .533 1.526.096.427.157.86.181 1.298a8.006 8.006 0 0 1-.284 2.65 7.584 7.584 0 0 1-1.447 2.741c-.783.967-1.754 1.686-2.889 2.197a15.027 15.027 0 0 1-3.489 1.059 22.9 22.9 0 0 1-1.77.252c-.384.04-.77.065-1.156.091-.956.067-1.913.06-2.87.04-.493-.01-.987-.042-1.478-.092-.185-.019-.372-.028-.557-.058-.243-.04-.382-.177-.408-.421-.032-.29-.053-.581-.078-.871-.02-.233-.038-.467-.059-.7A.306.306 0 0 0 0 14.112v-2.731a.527.527 0 0 0 .05-.244c.027-.392.049-.785.087-1.176.063-.647.159-1.29.278-1.929C.633 6.877.945 5.75 1.44 4.68c.416-.9.953-1.72 1.653-2.427A7.277 7.277 0 0 1 5.392.686c.69-.3 1.417-.507 2.162-.617.171-.026.343-.046.515-.069h1.175a.54.54 0 0 0 .078.018c.26.025.52.058.78.106a7.819 7.819 0 0 1 2.88 1.144 7.527 7.527 0 0 1 1.547 1.336c.064.074.117.08.204.05A17.156 17.156 0 0 1 18.7 1.79c.417-.04.836-.074 1.252-.086.747-.02 1.495.01 2.238.088.523.054 1.043.13 1.559.229a17.397 17.397 0 0 1 8.066 3.94 17.218 17.218 0 0 1 4.996 7.418c.321.938.558 1.902.707 2.882.08.461.128.928.142 1.396.003.03.008.061.017.091v2.202a.52.52 0 0 0-.018.17c-.004.12 0 .24-.014.358a20.37 20.37 0 0 1-.118.92 17.094 17.094 0 0 1-4.543 9.246 17.367 17.367 0 0 1-4.428 3.36 17.183 17.183 0 0 1-6.69 1.956.825.825 0 0 0-.248.043L19.292 36zM9.477 8.466a.354.354 0 0 0-.127.099 24.844 24.844 0 0 0-2.388 2.644c-.214.276-.417.299-.695.087l-.754-.57c-.259-.192-.288-.427-.08-.67l.361-.426c.416-.49.828-.984 1.261-1.459.311-.342.646-.658.975-.983.025-.025.051-.049.074-.075.024-.026.028-.055-.012-.074a2.209 2.209 0 0 0-1.227-.15c-.27.038-.452-.084-.507-.348-.07-.337-.137-.675-.203-1.014-.055-.287.083-.474.374-.514.062-.008.125-.008.186-.018a3.615 3.615 0 0 1 1.064-.006c.639.08 1.251.303 1.789.654.124.082.126.08.24-.012.499-.407 1.02-.786 1.562-1.135.431-.275.861-.551 1.29-.829.03-.02.06-.038.09-.059a.048.048 0 0 0 .01-.08 1.203 1.203 0 0 0-.066-.066 5.85 5.85 0 0 0-1.483-1.005 5.657 5.657 0 0 0-2.89-.549c-.346.023-.69.071-1.03.143a5.58 5.58 0 0 0-2.313 1.08 6.104 6.104 0 0 0-1.433 1.646c-.404.669-.678 1.391-.89 2.138a17.31 17.31 0 0 0-.521 2.516c-.095.715-.15 1.433-.175 2.156-.031.914-.002 1.829.023 2.744v.026c0 .067.03.094.097.096.205.007.41.021.612.024.298.004.594.01.891.005.69-.01 1.38 0 2.068-.05.52-.037 1.037-.09 1.553-.16.706-.09 1.405-.225 2.093-.406.82-.22 1.614-.507 2.353-.924a5.692 5.692 0 0 0 2.295-2.361c.35-.659.567-1.379.64-2.12.05-.475.045-.955-.018-1.429a5.782 5.782 0 0 0-.536-1.768c-.076-.155-.073-.157-.223-.07a23.799 23.799 0 0 0-2.722 1.857c-.111.086-.111.088-.045.203.097.18.18.366.247.558.215.588.294 1.216.23 1.839a1.584 1.584 0 0 1-.062.378.375.375 0 0 1-.383.273.768.768 0 0 1-.158-.015c-.227-.047-.454-.092-.68-.137-.112-.022-.22-.038-.328-.065-.216-.055-.323-.192-.321-.41a1.043 1.043 0 0 1 .011-.173c.021-.13.026-.264.015-.396a2.008 2.008 0 0 0-.134-.64z",
        fill: "#000"
      }), /*#__PURE__*/jsx_runtime_.jsx("path", {
        d: "M29.57 13.141c.03.277-.106.509-.286.724l-2.56 3.057-6.9 8.231c-.516.617-1.03 1.235-1.543 1.855-.457.552-1.406.56-1.866.012-1.55-1.85-3.098-3.7-4.646-5.552-.287-.345-.4-.722-.198-1.14.215-.444.594-.69 1.105-.722.38-.026.693.138.927.415 1.209 1.438 2.416 2.878 3.62 4.32.117.138.118.138.236 0l9.661-11.524c.11-.132.218-.266.33-.395.314-.359.71-.495 1.195-.385.445.099.973.568.925 1.104z",
        fill: "#76B591"
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx("defs", {
      children: /*#__PURE__*/jsx_runtime_.jsx("clipPath", {
        id: "clip0_6163_87762",
        children: /*#__PURE__*/jsx_runtime_.jsx("path", {
          fill: "#fff",
          d: "M0 0h37.674v36H0z"
        })
      })
    })]
  }));
};

CarbonNeutralIcon.defaultProps = {
  width: "38",
  height: "36",
  viewBox: "0 0 38 36",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};





const HistoryTable_Container = external_styled_components_default().div.withConfig({
  displayName: "HistoryTable__Container",
  componentId: "obmulb-0"
})(["background:", ";padding:1.75rem;border-radius:8px;"], p => p.theme.colors.white);

const carbonNeutralStatus = measurement => {
  var _measurement$offsets;

  return measurement !== null && measurement !== void 0 && (_measurement$offsets = measurement.offsets) !== null && _measurement$offsets !== void 0 && _measurement$offsets.every(offset => offset.status === "complete") ? "carbon_neutral" : "processing";
};

const ButtonContainer = external_styled_components_default().div.withConfig({
  displayName: "HistoryTable__ButtonContainer",
  componentId: "obmulb-1"
})(["display:flex;width:100%;justify-content:flex-end;"]);

const HistoryTable = ({
  measurements,
  dataCollectionMeasurement
}) => {
  const router = (0,router_.useRouter)();
  const {
    0: showAddMeasurementButton,
    1: setShowAddMeasurementButton
  } = (0,external_react_.useState)();

  const formatValue = value => !value ? 0 : value / 1000;

  const isTablet = (0,external_react_responsive_.useMediaQuery)({
    query: `(min-width: ${theme/* sizes.tablet */.J7.tablet}px)`
  });
  const data = measurements.sort((a, b) => {
    if (a.id === (dataCollectionMeasurement === null || dataCollectionMeasurement === void 0 ? void 0 : dataCollectionMeasurement.id) || b.id === (dataCollectionMeasurement === null || dataCollectionMeasurement === void 0 ? void 0 : dataCollectionMeasurement.id)) return a.id === (dataCollectionMeasurement === null || dataCollectionMeasurement === void 0 ? void 0 : dataCollectionMeasurement.id) && b.id !== (dataCollectionMeasurement === null || dataCollectionMeasurement === void 0 ? void 0 : dataCollectionMeasurement.id) ? -1 : 1;
    return new Date(a.year, a.month) < new Date(b.year, b.month) ? 1 : -1;
  }).map(measurement => {
    var _createTotalMeasureme, _measurement$offsets2;

    return {
      id: measurement.id,
      ["Year(s)"]: measurement.time_period === 1 ? measurement.year : [...new Set([(0,external_date_fns_.format)(new Date(measurement.year, measurement.month), "yyyy"), (0,external_date_fns_.format)((0,external_date_fns_.subDays)((0,external_date_fns_.addMonths)(new Date(measurement.year, measurement.month), measurement.time_period), 1), "yyyy")])].join(" - "),
      ["Month(s)"]: measurement.time_period === 1 ? (0,external_date_fns_.format)(new Date(measurement.year, measurement.month), isTablet ? "LLLL" : "LLL") : (0,external_date_fns_.format)(new Date(measurement.year, measurement.month), isTablet ? "LLLL" : "LLL") + " - " + (0,external_date_fns_.format)(new Date(measurement.year, measurement.month + measurement.time_period - 1), isTablet ? "LLLL" : "LLL"),
      "Footprint (tCO2e)": formatValue((_createTotalMeasureme = (0,charts/* createTotalMeasurementResults */.d)(measurement)) === null || _createTotalMeasureme === void 0 ? void 0 : _createTotalMeasureme.total).toFixed(1),
      time_period: measurement.time_period,
      has_offsets: !!(measurement !== null && measurement !== void 0 && (_measurement$offsets2 = measurement.offsets) !== null && _measurement$offsets2 !== void 0 && _measurement$offsets2.length),
      carbon_status: carbonNeutralStatus(measurement),
      has_result: (0,utils/* checkMeasurementHasResults */._u)(measurement)
    };
  });
  const widths = {
    ["Year(s)"]: "10%",
    ["Month(s)"]: isTablet ? "17.5%" : "17.5%",
    "Footprint (tCO2e)": "15%"
  };
  const filteredKeys = ["id", "time_period", "has_offsets", "has_result", "carbon_status"];
  const headers = [...new Set(data.flatMap(Object.keys).filter(name => !filteredKeys.includes(name)))].map(name => ({
    name,
    width: widths[name]
  }));
  (0,external_react_.useEffect)(() => {
    router.query.tabId === "annual" ? setShowAddMeasurementButton(true) : setShowAddMeasurementButton(false);
  }, [router.query]);
  router.query.tabId === "annual" && headers.push({
    name: "Carbon neutral?",
    width: "15%"
  });
  headers.push({
    name: "",
    width: "15%"
  });
  const currentDataCollectionKeys = ["Year(s)", "Month(s)"];
  return /*#__PURE__*/jsx_runtime_.jsx(HistoryTable_Container, {
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
      children: [/*#__PURE__*/jsx_runtime_.jsx(ButtonContainer, {
        children: /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.ZP, {
          href: "/history/annual/new",
          children: "Add Measurement"
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(common_Table, {
        headers: headers,
        children: data.filter(measurement => measurement.time_period === 12).map((row, index) => /*#__PURE__*/jsx_runtime_.jsx(common_TableRow, {
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
            children: [Object.keys(row).map(key => !filteredKeys.includes(key) && /*#__PURE__*/jsx_runtime_.jsx(common_TableCell, {
              width: widths[key],
              children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
                size: "small",
                children: row[key]
              })
            })), /*#__PURE__*/jsx_runtime_.jsx(common_TableCell, {
              width: "25%",
              children: row.has_result && (row.has_offsets ? row.carbon_status === "carbon_neutral" ? /*#__PURE__*/jsx_runtime_.jsx(CarbonNeutralIcon, {}) : /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
                size: "small",
                children: "Processing"
              }) : /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.ZP, {
                size: "small",
                href: "/history/[id]/compensate",
                as: `/history/${row.id}/compensate`,
                children: "Compensate"
              }))
            }), /*#__PURE__*/jsx_runtime_.jsx(common_TableCell, {
              width: "25%",
              children: /*#__PURE__*/jsx_runtime_.jsx(TextButton/* default */.Z, {
                size: "small",
                color: "blue",
                onClick: () => router.push(row.has_result ? `/history/annual/${row.id}` : `/history/annual/${row.id}/edit`),
                children: row.has_result ? "See results" : "Edit"
              })
            })]
          })
        }, `${row.id}-${index}`))
      })]
    })
  });
};

/* harmony default export */ const history_HistoryTable = (HistoryTable);

/***/ }),

/***/ 40372:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16666);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_responsive__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_common_LoadingLarge__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(49899);
/* harmony import */ var _components_common_Page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(97598);
/* harmony import */ var _components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(60805);
/* harmony import */ var _components_ContentContainer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(16067);
/* harmony import */ var _components_history_HistoryTable__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6394);
/* harmony import */ var _contexts_measurements__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(85238);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(91073);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_5__]);
_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];













const Measurement = () => {
  const {
    getMeasurements,
    measurements,
    dataCollectionMeasurement,
    loading,
    setLoading,
    setProgress
  } = (0,_contexts_measurements__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
  const isDesktop = (0,react_responsive__WEBPACK_IMPORTED_MODULE_2__.useMediaQuery)({
    query: `(min-width: ${_theme__WEBPACK_IMPORTED_MODULE_9__/* .sizes.desktop */ .J7.desktop}px)`
  });
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_0__.useRouter)();
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
    getMeasurements();
  }, []);
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
    if (!router.query.tabId) {
      router.replace(router.pathname + "/?tabId=annual", undefined, {
        shallow: true
      });
    }
  }, [router]);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_components_common_Page__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(_components_ContentContainer__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
      title: "History",
      children: [loading && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_components_common_LoadingLarge__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        loading: loading,
        text: "Initialising Measurement...",
        setProgress: setProgress
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_components_history_HistoryTable__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
        measurements: measurements,
        dataCollectionMeasurement: dataCollectionMeasurement
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)(Measurement));
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 84748:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "unstable_getStaticParams": () => (/* binding */ unstable_getStaticParams),
/* harmony export */   "unstable_getStaticProps": () => (/* binding */ unstable_getStaticProps),
/* harmony export */   "unstable_getStaticPaths": () => (/* binding */ unstable_getStaticPaths),
/* harmony export */   "unstable_getServerProps": () => (/* binding */ unstable_getServerProps),
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "_app": () => (/* binding */ _app),
/* harmony export */   "renderReqToHTML": () => (/* binding */ renderReqToHTML),
/* harmony export */   "render": () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(70607);
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59450);
/* harmony import */ var private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97020);
/* harmony import */ var private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(73978);
/* harmony import */ var next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99436);

      
      
      
      

      
      const { processEnv } = __webpack_require__(85360)
      processEnv([{"path":".env","contents":"API_HOST=https://api.inhabit.eco\nNEXT_PUBLIC_CALENDLY_URL=https://calendly.com/inhabit-meet/inhabit-measurement-tutorial\nNEXT_PUBLIC_FLAGS_ENVIRONMENT_KEY=flags_pub_289425705564897805\nNEXT_PUBLIC_GOOGLE_ANALYTICS=G-1CBB78XFQ4\nNEXT_PUBLIC_INTERCOM_APP_ID=bw9p6mfd\nNEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_bQDaTEuYc10x3BZt9YcGj2cE00Gzwm4gDD\nSTRIPE_PUBLISHABLE_KEY=pk_live_bQDaTEuYc10x3BZt9YcGj2cE00Gzwm4gDD\n\n"}])
    
      
      const runtimeConfig = {}
      ;

      const documentModule = __webpack_require__(9968)

      const appMod = __webpack_require__(13724)
      let App = appMod.default || appMod.then && appMod.then(mod => mod.default);

      const compMod = __webpack_require__(40372)

      const Component = compMod.default || compMod.then && compMod.then(mod => mod.default)
      /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Component);
      const getStaticProps = compMod['getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['getStaticProp' + 's'])
      const getStaticPaths = compMod['getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['getStaticPath' + 's'])
      const getServerSideProps = compMod['getServerSideProp' + 's'] || compMod.then && compMod.then(mod => mod['getServerSideProp' + 's'])

      // kept for detecting legacy exports
      const unstable_getStaticParams = compMod['unstable_getStaticParam' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticParam' + 's'])
      const unstable_getStaticProps = compMod['unstable_getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticProp' + 's'])
      const unstable_getStaticPaths = compMod['unstable_getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticPath' + 's'])
      const unstable_getServerProps = compMod['unstable_getServerProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getServerProp' + 's'])

      let config = compMod['confi' + 'g'] || (compMod.then && compMod.then(mod => mod['confi' + 'g'])) || {}
      const _app = App

      const combinedRewrites = Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)
        ? private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg
        : []

      if (!Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)) {
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.beforeFiles */ .Dg.beforeFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.afterFiles */ .Dg.afterFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.fallback */ .Dg.fallback)
      }

      const { renderReqToHTML, render } = (0,next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__/* .getPageHandler */ .u)({
        pageModule: compMod,
        pageComponent: Component,
        pageConfig: config,
        appModule: App,
        documentModule: documentModule,
        errorModule: __webpack_require__(99651),
        notFoundModule: undefined,
        pageGetStaticProps: getStaticProps,
        pageGetStaticPaths: getStaticPaths,
        pageGetServerSideProps: getServerSideProps,

        assetPrefix: "",
        canonicalBase: "",
        generateEtags: true,
        poweredByHeader: true,
        reactRoot: false,

        runtimeConfig,
        buildManifest: private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__,
        reactLoadableManifest: private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__,

        rewrites: combinedRewrites,
        i18n: undefined,
        page: "/history",
        buildId: "lDoX7RBEQ31kzKIJJbkVC",
        escapedBuildId: "lDoX7RBEQ31kzKIJJbkVC",
        basePath: "",
        pageIsDynamic: false,
        encodedPreviewProps: {previewModeId:"89cdc9f6073608262d43eab6d636f3f4",previewModeSigningKey:"74c7e36a2414a3f7b0ebcc67250f915f156686e1610b45a21ae9358d5b7c6c5a",previewModeEncryptionKey:"8a4c97ad9e5cf12d5a140689be08539ea52d8b27a416c2b8ae67db636b45841b"}
      })
      
    

/***/ }),

/***/ 94970:
/***/ ((module) => {

module.exports = require("@happykit/flags/client");

/***/ }),

/***/ 46411:
/***/ ((module) => {

module.exports = require("@happykit/flags/config");

/***/ }),

/***/ 48095:
/***/ ((module) => {

module.exports = require("@happykit/flags/server");

/***/ }),

/***/ 83218:
/***/ ((module) => {

module.exports = require("@hookform/error-message");

/***/ }),

/***/ 48308:
/***/ ((module) => {

module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ 85360:
/***/ ((module) => {

module.exports = require("@next/env");

/***/ }),

/***/ 64515:
/***/ ((module) => {

module.exports = require("@stripe/react-stripe-js");

/***/ }),

/***/ 20943:
/***/ ((module) => {

module.exports = require("@stripe/stripe-js");

/***/ }),

/***/ 52167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 74146:
/***/ ((module) => {

module.exports = require("date-fns");

/***/ }),

/***/ 1043:
/***/ ((module) => {

module.exports = require("lodash.get");

/***/ }),

/***/ 51650:
/***/ ((module) => {

module.exports = require("lodash.uniqby");

/***/ }),

/***/ 54426:
/***/ ((module) => {

module.exports = require("next/dist/compiled/chalk");

/***/ }),

/***/ 40252:
/***/ ((module) => {

module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 19371:
/***/ ((module) => {

module.exports = require("next/dist/compiled/node-fetch");

/***/ }),

/***/ 97999:
/***/ ((module) => {

module.exports = require("next/dist/compiled/path-to-regexp");

/***/ }),

/***/ 60600:
/***/ ((module) => {

module.exports = require("next/dist/server/accept-header.js");

/***/ }),

/***/ 52155:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils/index.js");

/***/ }),

/***/ 90730:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils/node.js");

/***/ }),

/***/ 60562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 94140:
/***/ ((module) => {

module.exports = require("next/dist/server/get-page-files.js");

/***/ }),

/***/ 89716:
/***/ ((module) => {

module.exports = require("next/dist/server/htmlescape.js");

/***/ }),

/***/ 25071:
/***/ ((module) => {

module.exports = require("next/dist/server/render-result.js");

/***/ }),

/***/ 33100:
/***/ ((module) => {

module.exports = require("next/dist/server/render.js");

/***/ }),

/***/ 92779:
/***/ ((module) => {

module.exports = require("next/dist/server/request-meta.js");

/***/ }),

/***/ 79502:
/***/ ((module) => {

module.exports = require("next/dist/server/send-payload.js");

/***/ }),

/***/ 76368:
/***/ ((module) => {

module.exports = require("next/dist/server/utils.js");

/***/ }),

/***/ 56724:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 27664:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/escape-regexp.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 94957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 82374:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-locale-cookie.js");

/***/ }),

/***/ 34014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 78524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 78020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 29565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 64365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 95714:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-route-from-asset-path.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 91292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 25753:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-match.js");

/***/ }),

/***/ 99521:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/prepare-destination.js");

/***/ }),

/***/ 80979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 36052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 84226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 95566:
/***/ ((module) => {

module.exports = require("next/error");

/***/ }),

/***/ 40968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 71853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 59819:
/***/ ((module) => {

module.exports = require("querystring");

/***/ }),

/***/ 16689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 25716:
/***/ ((module) => {

module.exports = require("react-hotjar");

/***/ }),

/***/ 16666:
/***/ ((module) => {

module.exports = require("react-responsive");

/***/ }),

/***/ 1187:
/***/ ((module) => {

module.exports = require("react-toastify");

/***/ }),

/***/ 20997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 57518:
/***/ ((module) => {

module.exports = require("styled-components");

/***/ }),

/***/ 24535:
/***/ ((module) => {

module.exports = require("styled-normalize");

/***/ }),

/***/ 6153:
/***/ ((module) => {

module.exports = require("universal-cookie");

/***/ }),

/***/ 84269:
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ 75609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 61908:
/***/ ((module) => {

module.exports = import("@hookform/resolvers/yup");;

/***/ }),

/***/ 45641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [4357,9703,6114,9067,8183,9899,805,6067,9343,3033], () => (__webpack_exec__(84748)));
module.exports = __webpack_exports__;

})();