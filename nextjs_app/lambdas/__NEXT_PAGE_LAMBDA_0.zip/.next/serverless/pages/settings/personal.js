"use strict";
(() => {
var exports = {};
exports.id = 1721;
exports.ids = [1721];
exports.modules = {

/***/ 92691:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16666);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_responsive__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _Menu__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(48294);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




var LockIcon = function LockIcon(props) {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("g", {
      clipPath: "url(#clip0)",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
        d: "M8.998 24.995H4.477C1.843 24.989.013 23.158.012 20.528c0-3.038-.023-6.08.008-9.115.019-1.878.926-3.228 2.627-4.034.113-.053.23-.117.351-.128.42-.041.512-.266.512-.666 0-.945-.104-1.895.12-2.833A4.84 4.84 0 0 1 8.284.01c1.084-.015 2.17-.07 3.19.431 1.114.547 1.92 1.38 2.414 2.513.205.473.013.99-.398 1.171-.466.206-.934.038-1.177-.441-.625-1.236-1.653-1.815-3.012-1.84-.707-.013-1.427-.045-2.092.241-1.307.562-1.91 1.604-1.946 2.999-.014.547.013 1.097-.009 1.644-.012.32.102.41.414.408 2.66-.01 5.32.004 7.98-.01.885-.006 1.697.191 2.437.674 1.205.788 1.875 1.918 1.893 3.345.039 3.22.027 6.442.006 9.663-.016 2.315-1.892 4.148-4.254 4.182-1.576.021-3.152.004-4.727.004h-.005zM1.81 16.068c0 1.518.038 3.038-.012 4.554-.043 1.307.778 2.67 2.596 2.681 3.104.019 6.208.019 9.312 0 1.29-.008 2.17-.711 2.5-1.847.119-.408-.027-.784-.026-1.175.006-2.968.006-5.937 0-8.905-.005-1.45-1.041-2.478-2.492-2.481-3.115-.007-6.23-.007-9.346 0-1.504 0-2.527 1.04-2.53 2.55-.005 1.54-.002 3.081-.002 4.623z"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
        d: "M8.15 16.698c0-.194-.009-.388 0-.581a1.179 1.179 0 0 0-.208-.766c-.37-.556-.245-1.214.273-1.652a1.263 1.263 0 0 1 1.66.007c.51.437.628 1.105.25 1.657-.16.233-.237.513-.22.796.011.478.009.956 0 1.435-.009.524-.345.857-.858.867-.492.01-.87-.34-.894-.843-.015-.307 0-.615 0-.923l-.003.003z"
      })]
    })
  }));
};

LockIcon.defaultProps = {
  width: "18",
  height: "25",
  viewBox: "0 0 18 25",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var ProfileIcon = function ProfileIcon(props) {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("g", {
      clipPath: "url(#clip0)",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
        d: "M13.102 25H1.496C.258 25-.07 24.646.01 23.405c.287-4.43 3.938-8.003 8.395-8.182 3.272-.131 6.545-.128 9.819.009 3.758.157 7.318 3.483 7.887 7.35.062.384.1.77.114 1.159.019.867-.347 1.25-1.21 1.256-1.556.012-3.112.005-4.667.005L13.102 25zm-.01-1.997h10.38c.696 0 .735-.058.558-.745a6.811 6.811 0 0 0-6.527-5.108 367.271 367.271 0 0 0-8.782 0c-3.033.038-5.618 2.044-6.468 4.942-.257.879-.238.907.645.907l10.195.004zM20.104 7.023c.003 3.902-3.113 7.04-7 7.046-3.913.005-7.085-3.15-7.083-7.045 0-3.855 3.177-7.018 7.05-7.024a7.021 7.021 0 0 1 7.033 7.023zm-12.086.03c.01 2.805 2.332 5.129 5.076 5.081 2.795-.05 5.082-2.356 5.073-5.118-.009-2.787-2.295-5.037-5.108-5.028-2.852.009-5.051 2.219-5.041 5.065z"
      })
    })
  }));
};

ProfileIcon.defaultProps = {
  width: "27",
  height: "25",
  viewBox: "0 0 27 25",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};





const Container = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
  displayName: "personal__Container",
  componentId: "sc-19boy6b-0"
})(["display:flex;"]);

const Index = ({
  children,
  showMenu
}) => {
  const isTablet = (0,react_responsive__WEBPACK_IMPORTED_MODULE_1__.useMediaQuery)({
    query: `(min-width: ${_theme__WEBPACK_IMPORTED_MODULE_3__/* .sizes.tablet */ .J7.tablet}px)`
  });
  const route = "/settings/personal";
  const pages = [{
    icon: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(ProfileIcon, {}),
    title: "Profile",
    description: "Name, Email, Interests",
    path: "profile"
  }, {
    icon: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(LockIcon, {}),
    title: "Password",
    description: "Change your password",
    path: "password"
  }];
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(Container, {
    children: [!isTablet ? showMenu && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_Menu__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
      pages: pages,
      route: route
    }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_Menu__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
      pages: pages,
      route: route
    }), children]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Index);

/***/ }),

/***/ 75215:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16666);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_responsive__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_common_Page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97598);
/* harmony import */ var _components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(60805);
/* harmony import */ var _components_ContentContainer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(16067);
/* harmony import */ var _components_settings_personal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(92691);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(91073);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_3__]);
_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }








var AdminSettingsIcon = function AdminSettingsIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("path", {
      d: "M24.978 12.572c-.013.328.022.734-.018 1.139-.081.812-.622 1.396-1.43 1.535-.46.08-.923.157-1.385.229-.145.023-.228.082-.277.23a6.956 6.956 0 0 1-.476 1.14c-.076.139-.07.245.026.373.28.376.547.761.82 1.142.503.7.447 1.575-.154 2.192a81.343 81.343 0 0 1-1.537 1.538c-.62.6-1.492.657-2.193.154-.39-.281-.784-.558-1.172-.842a.239.239 0 0 0-.288-.024 7.937 7.937 0 0 1-1.193.495c-.15.05-.207.128-.23.272-.069.445-.144.887-.222 1.33-.164.928-.742 1.465-1.688 1.5-.767.028-1.537.042-2.304-.014a1.652 1.652 0 0 1-1.5-1.373c-.081-.48-.16-.961-.235-1.442a.3.3 0 0 0-.233-.274 7.312 7.312 0 0 1-1.14-.475.223.223 0 0 0-.271.021c-.409.3-.821.594-1.237.88-.71.492-1.555.42-2.173-.187-.51-.5-1.015-1.003-1.515-1.512-.61-.618-.671-1.5-.162-2.206.273-.38.543-.764.822-1.14.08-.108.1-.194.031-.319a7.112 7.112 0 0 1-.502-1.185.26.26 0 0 0-.233-.203c-.45-.068-.9-.15-1.35-.226-.955-.158-1.5-.74-1.537-1.715a21.514 21.514 0 0 1 .014-2.285 1.64 1.64 0 0 1 1.322-1.486c.496-.095.995-.179 1.495-.256.14-.022.204-.088.244-.214.132-.41.294-.81.487-1.197a.265.265 0 0 0-.028-.309c-.287-.394-.57-.79-.85-1.19-.516-.743-.437-1.589.205-2.23l1.46-1.457c.634-.629 1.487-.705 2.218-.192.389.273.774.551 1.155.834.108.08.2.096.322.03.381-.2.78-.368 1.19-.5a.258.258 0 0 0 .2-.234c.063-.433.15-.862.216-1.293C9.827.644 10.364.101 11.34.04c.767-.05 1.537-.048 2.303.007.835.065 1.407.614 1.55 1.434.08.461.16.922.231 1.385.02.126.072.2.197.24.44.141.869.318 1.281.527a.247.247 0 0 0 .29-.027c.4-.29.803-.574 1.206-.86a1.647 1.647 0 0 1 2.13.153 79.24 79.24 0 0 1 1.591 1.59c.568.583.621 1.463.144 2.134-.286.4-.57.805-.862 1.203a.242.242 0 0 0-.022.289c.196.37.357.758.48 1.158.05.172.146.236.312.261.432.065.862.142 1.293.219.975.173 1.493.781 1.51 1.771.007.32.003.645.003 1.049zm-7.9 6.894a.887.887 0 0 1 .544.178c.529.378 1.06.75 1.587 1.131.1.072.177.1.276 0 .416-.423.835-.842 1.257-1.26.11-.109.11-.192.018-.318-.38-.52-.75-1.05-1.118-1.573-.23-.325-.237-.656-.036-1a7.886 7.886 0 0 0 .832-2c.105-.407.363-.64.78-.707.622-.1 1.243-.21 1.865-.308.15-.024.211-.077.209-.239a57.87 57.87 0 0 1 0-1.743c0-.14-.044-.2-.184-.22-.623-.1-1.243-.216-1.866-.313-.425-.066-.688-.293-.797-.708a7.545 7.545 0 0 0-.813-1.968c-.235-.393-.206-.75.064-1.112.369-.497.716-1.009 1.082-1.507.096-.129.082-.203-.03-.312a54.582 54.582 0 0 1-1.232-1.232c-.104-.106-.175-.116-.296-.027-.523.386-1.05.763-1.581 1.14-.31.221-.637.243-.968.05a8.374 8.374 0 0 0-2.11-.869c-.4-.104-.624-.365-.689-.773-.1-.616-.206-1.231-.304-1.85-.024-.153-.079-.221-.25-.217a40.65 40.65 0 0 1-1.687 0c-.18-.004-.25.05-.28.228-.093.611-.208 1.218-.303 1.829-.067.429-.292.704-.716.815-.69.18-1.35.458-1.963.825-.392.236-.75.2-1.112-.067-.5-.372-1.018-.725-1.523-1.093-.104-.077-.164-.065-.25.023-.42.43-.845.854-1.273 1.274-.104.1-.098.175-.017.286.374.515.737 1.04 1.112 1.555.253.347.276.692.056 1.064a7.607 7.607 0 0 0-.808 1.99c-.1.391-.342.627-.744.695-.633.108-1.267.221-1.9.32-.15.024-.2.085-.196.231a95 95 0 0 1 0 1.743c0 .15.05.207.2.23.653.105 1.305.22 1.957.333.355.061.595.27.69.61.204.742.503 1.454.889 2.119.195.336.165.666-.064.983-.374.516-.738 1.039-1.114 1.554-.086.119-.087.197.021.3.42.41.837.825 1.245 1.246.108.112.179.103.295.018.5-.365 1.011-.712 1.507-1.082.375-.279.74-.306 1.15-.071a7.615 7.615 0 0 0 1.904.774c.4.104.631.356.7.765.1.61.208 1.218.3 1.83.028.186.088.263.293.257a28.907 28.907 0 0 1 1.65 0c.197.005.256-.07.284-.246.09-.587.21-1.169.29-1.756.065-.486.325-.753.792-.873a7.36 7.36 0 0 0 1.945-.819.837.837 0 0 1 .428-.133h.002z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("path", {
      d: "M12.497 7.025c3.006 0 5.477 2.474 5.477 5.48 0 3.006-2.48 5.477-5.485 5.473-3.005-.004-5.487-2.488-5.465-5.491a5.487 5.487 0 0 1 5.473-5.462zm.005 1.7a3.789 3.789 0 0 0-3.782 3.779c0 2.068 1.705 3.772 3.773 3.773 2.067.002 3.776-1.697 3.779-3.764a3.78 3.78 0 0 0-3.77-3.787v-.001z"
    })]
  }));
};

AdminSettingsIcon.defaultProps = {
  width: "25",
  height: "25",
  viewBox: "0 0 25 25",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};




function Offset() {
  const isTablet = (0,react_responsive__WEBPACK_IMPORTED_MODULE_1__.useMediaQuery)({
    query: `(min-width: ${_theme__WEBPACK_IMPORTED_MODULE_7__/* .sizes.tablet */ .J7.tablet}px)`
  });
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_components_common_Page__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_components_ContentContainer__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
      title: "Settings",
      limit: true,
      icon: !isTablet ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(AdminSettingsIcon, {}) : null,
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_components_settings_personal__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
        showMenu: true
      })
    })
  });
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)(Offset));
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 66588:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "unstable_getStaticParams": () => (/* binding */ unstable_getStaticParams),
/* harmony export */   "unstable_getStaticProps": () => (/* binding */ unstable_getStaticProps),
/* harmony export */   "unstable_getStaticPaths": () => (/* binding */ unstable_getStaticPaths),
/* harmony export */   "unstable_getServerProps": () => (/* binding */ unstable_getServerProps),
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "_app": () => (/* binding */ _app),
/* harmony export */   "renderReqToHTML": () => (/* binding */ renderReqToHTML),
/* harmony export */   "render": () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(70607);
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59450);
/* harmony import */ var private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97020);
/* harmony import */ var private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(73978);
/* harmony import */ var next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99436);

      
      
      
      

      
      const { processEnv } = __webpack_require__(85360)
      processEnv([{"path":".env","contents":"API_HOST=https://api.inhabit.eco\nNEXT_PUBLIC_CALENDLY_URL=https://calendly.com/inhabit-meet/inhabit-measurement-tutorial\nNEXT_PUBLIC_FLAGS_ENVIRONMENT_KEY=flags_pub_289425705564897805\nNEXT_PUBLIC_GOOGLE_ANALYTICS=G-1CBB78XFQ4\nNEXT_PUBLIC_INTERCOM_APP_ID=bw9p6mfd\nNEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_bQDaTEuYc10x3BZt9YcGj2cE00Gzwm4gDD\nSTRIPE_PUBLISHABLE_KEY=pk_live_bQDaTEuYc10x3BZt9YcGj2cE00Gzwm4gDD\n\n"}])
    
      
      const runtimeConfig = {}
      ;

      const documentModule = __webpack_require__(9968)

      const appMod = __webpack_require__(13724)
      let App = appMod.default || appMod.then && appMod.then(mod => mod.default);

      const compMod = __webpack_require__(75215)

      const Component = compMod.default || compMod.then && compMod.then(mod => mod.default)
      /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Component);
      const getStaticProps = compMod['getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['getStaticProp' + 's'])
      const getStaticPaths = compMod['getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['getStaticPath' + 's'])
      const getServerSideProps = compMod['getServerSideProp' + 's'] || compMod.then && compMod.then(mod => mod['getServerSideProp' + 's'])

      // kept for detecting legacy exports
      const unstable_getStaticParams = compMod['unstable_getStaticParam' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticParam' + 's'])
      const unstable_getStaticProps = compMod['unstable_getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticProp' + 's'])
      const unstable_getStaticPaths = compMod['unstable_getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticPath' + 's'])
      const unstable_getServerProps = compMod['unstable_getServerProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getServerProp' + 's'])

      let config = compMod['confi' + 'g'] || (compMod.then && compMod.then(mod => mod['confi' + 'g'])) || {}
      const _app = App

      const combinedRewrites = Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)
        ? private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg
        : []

      if (!Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)) {
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.beforeFiles */ .Dg.beforeFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.afterFiles */ .Dg.afterFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.fallback */ .Dg.fallback)
      }

      const { renderReqToHTML, render } = (0,next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__/* .getPageHandler */ .u)({
        pageModule: compMod,
        pageComponent: Component,
        pageConfig: config,
        appModule: App,
        documentModule: documentModule,
        errorModule: __webpack_require__(99651),
        notFoundModule: undefined,
        pageGetStaticProps: getStaticProps,
        pageGetStaticPaths: getStaticPaths,
        pageGetServerSideProps: getServerSideProps,

        assetPrefix: "",
        canonicalBase: "",
        generateEtags: true,
        poweredByHeader: true,
        reactRoot: false,

        runtimeConfig,
        buildManifest: private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__,
        reactLoadableManifest: private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__,

        rewrites: combinedRewrites,
        i18n: undefined,
        page: "/settings/personal",
        buildId: "lDoX7RBEQ31kzKIJJbkVC",
        escapedBuildId: "lDoX7RBEQ31kzKIJJbkVC",
        basePath: "",
        pageIsDynamic: false,
        encodedPreviewProps: {previewModeId:"89cdc9f6073608262d43eab6d636f3f4",previewModeSigningKey:"74c7e36a2414a3f7b0ebcc67250f915f156686e1610b45a21ae9358d5b7c6c5a",previewModeEncryptionKey:"8a4c97ad9e5cf12d5a140689be08539ea52d8b27a416c2b8ae67db636b45841b"}
      })
      
    

/***/ }),

/***/ 94970:
/***/ ((module) => {

module.exports = require("@happykit/flags/client");

/***/ }),

/***/ 46411:
/***/ ((module) => {

module.exports = require("@happykit/flags/config");

/***/ }),

/***/ 48095:
/***/ ((module) => {

module.exports = require("@happykit/flags/server");

/***/ }),

/***/ 83218:
/***/ ((module) => {

module.exports = require("@hookform/error-message");

/***/ }),

/***/ 48308:
/***/ ((module) => {

module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ 85360:
/***/ ((module) => {

module.exports = require("@next/env");

/***/ }),

/***/ 64515:
/***/ ((module) => {

module.exports = require("@stripe/react-stripe-js");

/***/ }),

/***/ 20943:
/***/ ((module) => {

module.exports = require("@stripe/stripe-js");

/***/ }),

/***/ 52167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 1043:
/***/ ((module) => {

module.exports = require("lodash.get");

/***/ }),

/***/ 51650:
/***/ ((module) => {

module.exports = require("lodash.uniqby");

/***/ }),

/***/ 54426:
/***/ ((module) => {

module.exports = require("next/dist/compiled/chalk");

/***/ }),

/***/ 40252:
/***/ ((module) => {

module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 19371:
/***/ ((module) => {

module.exports = require("next/dist/compiled/node-fetch");

/***/ }),

/***/ 97999:
/***/ ((module) => {

module.exports = require("next/dist/compiled/path-to-regexp");

/***/ }),

/***/ 60600:
/***/ ((module) => {

module.exports = require("next/dist/server/accept-header.js");

/***/ }),

/***/ 52155:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils/index.js");

/***/ }),

/***/ 90730:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils/node.js");

/***/ }),

/***/ 60562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 94140:
/***/ ((module) => {

module.exports = require("next/dist/server/get-page-files.js");

/***/ }),

/***/ 89716:
/***/ ((module) => {

module.exports = require("next/dist/server/htmlescape.js");

/***/ }),

/***/ 25071:
/***/ ((module) => {

module.exports = require("next/dist/server/render-result.js");

/***/ }),

/***/ 33100:
/***/ ((module) => {

module.exports = require("next/dist/server/render.js");

/***/ }),

/***/ 92779:
/***/ ((module) => {

module.exports = require("next/dist/server/request-meta.js");

/***/ }),

/***/ 79502:
/***/ ((module) => {

module.exports = require("next/dist/server/send-payload.js");

/***/ }),

/***/ 76368:
/***/ ((module) => {

module.exports = require("next/dist/server/utils.js");

/***/ }),

/***/ 56724:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 27664:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/escape-regexp.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 94957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 82374:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-locale-cookie.js");

/***/ }),

/***/ 34014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 78524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 78020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 29565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 64365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 95714:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-route-from-asset-path.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 91292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 25753:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-match.js");

/***/ }),

/***/ 99521:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/prepare-destination.js");

/***/ }),

/***/ 80979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 36052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 84226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 95566:
/***/ ((module) => {

module.exports = require("next/error");

/***/ }),

/***/ 40968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 71853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 59819:
/***/ ((module) => {

module.exports = require("querystring");

/***/ }),

/***/ 16689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 25716:
/***/ ((module) => {

module.exports = require("react-hotjar");

/***/ }),

/***/ 16666:
/***/ ((module) => {

module.exports = require("react-responsive");

/***/ }),

/***/ 1187:
/***/ ((module) => {

module.exports = require("react-toastify");

/***/ }),

/***/ 20997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 57518:
/***/ ((module) => {

module.exports = require("styled-components");

/***/ }),

/***/ 24535:
/***/ ((module) => {

module.exports = require("styled-normalize");

/***/ }),

/***/ 6153:
/***/ ((module) => {

module.exports = require("universal-cookie");

/***/ }),

/***/ 84269:
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ 75609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 61908:
/***/ ((module) => {

module.exports = import("@hookform/resolvers/yup");;

/***/ }),

/***/ 45641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [4357,9703,6114,9067,8183,9899,805,6067,8294], () => (__webpack_exec__(66588)));
module.exports = __webpack_exports__;

})();