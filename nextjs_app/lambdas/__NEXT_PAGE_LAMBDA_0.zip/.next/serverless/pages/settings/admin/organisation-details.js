"use strict";
(() => {
var exports = {};
exports.id = 6491;
exports.ids = [6491];
exports.modules = {

/***/ 48800:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _hookform_error_message__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(83218);
/* harmony import */ var _hookform_error_message__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_hookform_error_message__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(45641);
/* harmony import */ var _button_Button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(59067);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(87491);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _Error__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(26428);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_1__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
const _excluded = ["label", "name", "disabled", "labelColor", "alt", "src", "isRequired", "placeholder"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }










const StyledInput = styled_components__WEBPACK_IMPORTED_MODULE_5___default().input.withConfig({
  displayName: "ImageInput__StyledInput",
  componentId: "sc-1e3xyj-0"
})(["", ""], _button_Button__WEBPACK_IMPORTED_MODULE_2__/* .smallStyles */ .BC);
const InputContainer = styled_components__WEBPACK_IMPORTED_MODULE_5___default().div.withConfig({
  displayName: "ImageInput__InputContainer",
  componentId: "sc-1e3xyj-1"
})(["display:flex;flex-direction:column;position:relative;margin-bottom:1rem;", ""], p => p.isRequired && (0,styled_components__WEBPACK_IMPORTED_MODULE_5__.css)(["&::before{content:\"\";display:block;position:absolute;right:1rem;top:", ";bottom:0;width:0.5rem;min-width:0.5rem;height:0.5rem;border-radius:50%;background-color:", ";}"], p => p.label ? "2rem" : "1rem", p => p.isError ? p.theme.colors.red : p.isValid ? p.theme.colors.green : p.value ? p.theme.colors.placeholderGrey : p.theme.colors.blue));
const Label = styled_components__WEBPACK_IMPORTED_MODULE_5___default().label.withConfig({
  displayName: "ImageInput__Label",
  componentId: "sc-1e3xyj-2"
})(["color:", ";font-weight:lighter;margin-bottom:0.125rem;"], p => p.color ? p.color : p.theme.colors.label);
const LabelButton = styled_components__WEBPACK_IMPORTED_MODULE_5___default().label.withConfig({
  displayName: "ImageInput__LabelButton",
  componentId: "sc-1e3xyj-3"
})(["", " ", " max-width:6rem;", " & > input[type=\"file\"]{display:none;}"], _button_Button__WEBPACK_IMPORTED_MODULE_2__/* .commonStyles */ .iq, _button_Button__WEBPACK_IMPORTED_MODULE_2__/* .smallStyles */ .BC, _theme__WEBPACK_IMPORTED_MODULE_4__/* .media.tablet */ .BC.tablet`
  max-width:6rem;
  `);
const InnerContainer = styled_components__WEBPACK_IMPORTED_MODULE_5___default().div.withConfig({
  displayName: "ImageInput__InnerContainer",
  componentId: "sc-1e3xyj-4"
})(["display:flex;align-items:center;"]);
const ImageContainer = styled_components__WEBPACK_IMPORTED_MODULE_5___default().div.withConfig({
  displayName: "ImageInput__ImageContainer",
  componentId: "sc-1e3xyj-5"
})(["width:6.25rem;height:3rem;border-radius:10px;background:", ";margin-right:1.25rem;"], p => p.theme.colors.white);
const Image = styled_components__WEBPACK_IMPORTED_MODULE_5___default().img.withConfig({
  displayName: "ImageInput__Image",
  componentId: "sc-1e3xyj-6"
})(["width:100%;height:100%;border-radius:10px;object-fit:cover;"]);

const ImageInput = _ref => {
  let {
    label,
    name,
    disabled,
    labelColor,
    alt,
    src,
    isRequired,
    placeholder
  } = _ref,
      rest = _objectWithoutProperties(_ref, _excluded);

  const {
    register,
    control,
    formState
  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_1__.useFormContext)();
  const {
    errors
  } = formState;
  const {
    touchedFields
  } = formState;
  const isValid = touchedFields[name] && !errors[name];
  const isError = errors[name];
  const value = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_1__.useWatch)({
    control,
    name
  });
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(InputContainer, {
    label: label,
    value: value,
    isRequired: isRequired,
    isValid: isValid,
    isError: isError,
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(Label, {
      color: labelColor,
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP, {
        color: labelColor,
        size: "small",
        children: label
      })
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(InnerContainer, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(ImageContainer, {
        children: value && value.length > 0 ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(Image, {
          src: URL.createObjectURL(value[0]),
          alt: alt
        }) : src ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(Image, {
          src: src,
          alt: alt
        }) : null
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(LabelButton, {
        small: true,
        children: ["Upload", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(StyledInput, _objectSpread(_objectSpread({
          id: name,
          "data-cy": `${name}`
        }, register(name)), {}, {
          disabled: disabled,
          type: "file",
          accept: "image/jpg,image/jpeg"
        }, rest))]
      })]
    }), errors && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_hookform_error_message__WEBPACK_IMPORTED_MODULE_0__.ErrorMessage, {
      errors: errors,
      name: name,
      as: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_Error__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ImageInput);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 34737:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(61908);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(45641);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(16666);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_responsive__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _common_ConfirmationModal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(65487);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(87491);
/* harmony import */ var _form_PasswordInput__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(20661);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(75609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_1__, react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _form_PasswordInput__WEBPACK_IMPORTED_MODULE_6__]);
([_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_1__, react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _form_PasswordInput__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }









var Bin = function Bin(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("g", {
      clipPath: "url(#clip0)",
      fill: "#EC5F59",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("path", {
        d: "M11.768 25c-2.014 0-4.028.003-6.041 0-.49 0-.98-.006-1.467-.049-.847-.073-1.573-.835-1.622-1.719-.126-2.313-.235-4.626-.343-6.94-.16-3.384-.314-6.769-.463-10.154-.017-.38-.173-.516-.522-.489a2.16 2.16 0 0 1-.282 0C.413 5.621-.013 5.213 0 4.667c.013-.561.496-.976 1.115-.971 1.712.012 3.424.021 5.136.027 1.275 0 1.274-.005 1.486-1.298.052-.322.092-.647.176-.96.11-.42.355-.792.696-1.057.341-.264.758-.406 1.187-.403 1.335.007 2.67.026 4.007.04 1.085.01 1.81.64 1.988 1.726.083.51.174 1.019.241 1.53.04.312.18.393.49.393 2.031-.004 4.063.013 6.093.033.615.007.99.375 1 .933.008.583-.375.958-1.01.989-.786.037-.772.041-.81.872-.215 4.512-.434 9.024-.657 13.536-.048 1.032-.083 2.067-.136 3.099-.052 1.007-.8 1.796-1.778 1.804-2.484.02-4.969.007-7.453.007l-.004.033zm.063-1.96c2.163 0 4.326-.022 6.49.016.574.01.772-.193.788-.737.025-.841.087-1.682.125-2.523.202-4.474.401-8.95.598-13.424.033-.73.03-.73-.727-.724-2.389.017-4.776.046-7.164.046-2.538 0-5.077-.018-7.615-.054-.452-.006-.567.127-.545.592.22 4.512.405 9.026.628 13.538.04.823.067 1.645.105 2.467.037.769.084.804.827.804h6.49zm.093-19.338v.008c.377 0 .754.022 1.13-.004 1.061-.074 1.043-.08.887-1.179-.063-.435-.252-.576-.67-.566-.976.023-1.954.005-2.932.008-.22 0-.508-.052-.563.246-.086.46-.273.922-.13 1.4.034.113.194.09.307.089.657-.004 1.314-.003 1.971-.003v.001z"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("path", {
        d: "M8.69 18.497c0 .268.003.536 0 .803-.012.631-.339 1.023-.878 1.059-.553.037-.954-.295-1.014-.916a63.554 63.554 0 0 1-.186-2.86 598.873 598.873 0 0 1-.258-6.133c-.028-.742.278-1.15.84-1.2.6-.055.983.3 1.062 1.056.08.756.118 1.523.154 2.289.093 1.967.174 3.935.26 5.902h.02zM17.265 11.124c-.12 2.598-.242 5.195-.363 7.792-.013.19-.037.38-.072.569-.096.577-.47.9-1 .873-.537-.027-.898-.42-.883-1.046.032-1.357.085-2.715.145-4.07.06-1.337.135-2.673.21-4.008.021-.382.04-.765.096-1.142.087-.57.489-.884 1.022-.844.495.04.835.412.857.959.011.305 0 .612 0 .918h-.012zM10.868 14.807c0-1.51-.01-3.019.005-4.528.007-.665.379-1.043.95-1.034.571.009.932.396.935 1.057.01 2.062.004 4.125.008 6.188 0 .898.005 1.796.02 2.693.013.697-.357 1.165-.95 1.175-.604.012-.97-.419-.97-1.137v-4.414h.002z"
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("defs", {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("clipPath", {
        id: "clip0",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("path", {
          fill: "#fff",
          d: "M0 0h23.611v25H0z"
        })
      })
    })]
  }));
};

Bin.defaultProps = {
  width: "24",
  height: "25",
  viewBox: "0 0 24 25",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var CardChipIcon = function CardChipIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("path", {
      d: "M12.506.006h9.5c1.466 0 2.622.944 2.922 2.37.044.207.067.418.068.63.004 3.82.004 7.64 0 11.46-.003 1.47-1.012 2.673-2.435 2.923a4.676 4.676 0 0 1-.804.06c-6.17.003-12.34.005-18.511.005-1.235 0-2.234-.418-2.877-1.517A2.65 2.65 0 0 1 0 14.585V2.856C.002 1.354 1.275.05 2.782.014 3.867-.01 4.952.006 6.04.006h6.467zm0 6.936H1.51c-.182 0-.306 0-.305.25.008 2.448 0 4.897.007 7.346a1.69 1.69 0 0 0 .507 1.21c.41.42.93.513 1.482.513h18.365c.188 0 .374-.024.56-.034.911-.051 1.658-.812 1.644-1.868-.03-2.35-.01-4.702-.01-7.052 0-.364 0-.364-.358-.364H12.505v-.001zm-.016-3.905h10.525c.18 0 .36-.006.538 0 .165.008.217-.067.207-.22a1.65 1.65 0 0 0-.306-.865c-.402-.572-.984-.741-1.644-.741H5.41c-.775 0-1.55-.007-2.325 0-1.017.012-1.68.547-1.847 1.472-.06.337-.048.35.287.35l10.965.004zm-.008 1.209H1.76a1.974 1.974 0 0 1-.245 0c-.229-.029-.327.051-.31.296.02.268.005.538.006.807 0 .385 0 .385.382.385H23.38c.049-.002.098-.002.147 0 .187.022.24-.07.235-.244-.008-.294 0-.587 0-.881 0-.362 0-.363-.36-.363h-10.92z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("path", {
      d: "M21.143 11.399v1.958c0 .444-.231.68-.678.682-1.265.005-2.53.005-3.794 0-.453 0-.696-.247-.697-.7a870.154 870.154 0 0 1 0-3.892c0-.416.195-.64.606-.686.22-.02.44-.026.66-.02 1.003-.002 2.006-.002 3.01 0 .13-.002.26.009.389.03.315.056.5.273.503.596.004.678 0 1.355 0 2.032zm-1.208-.013h.01c0-.391-.003-.783 0-1.174.003-.159-.042-.24-.22-.24-.765.005-1.532.005-2.298 0-.156 0-.22.06-.219.216.004.79.004 1.58 0 2.371 0 .167.062.231.23.23.759-.005 1.516-.005 2.274 0 .174 0 .228-.067.225-.232-.007-.389-.002-.78-.002-1.17zM8.534 10.852H4.619a1.349 1.349 0 0 1-.411-.043.601.601 0 0 1-.433-.562.604.604 0 0 1 .429-.589 1.29 1.29 0 0 1 .385-.045h7.9c.13-.004.26.012.385.048a.615.615 0 0 1 .423.571.61.61 0 0 1-.42.573 1.302 1.302 0 0 1-.41.048H8.534zM7.39 12.541c.977 0 1.956-.003 2.934 0 .386 0 .662.264.657.607-.005.335-.273.582-.648.598-.082.003-.163 0-.244 0h-4.11c-.53 0-1.059 0-1.589-.003a.588.588 0 0 1-.552-.34.57.57 0 0 1 .044-.604c.135-.202.338-.263.573-.263.978.007 1.956.005 2.934.005z"
    })]
  }));
};

CardChipIcon.defaultProps = {
  viewBox: "0 0 25 18",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};





const schema = yup__WEBPACK_IMPORTED_MODULE_10__.object().shape({
  password: yup__WEBPACK_IMPORTED_MODULE_10__.string().required("Please enter your password").min(8, "Please enter a valid password")
});
const TitleContainer = styled_components__WEBPACK_IMPORTED_MODULE_9___default().div.withConfig({
  displayName: "ConfirmDelete__TitleContainer",
  componentId: "sc-1jomx6n-0"
})(["display:flex;flex-direction:column;align-items:center;justify-content:center;"]);
const ButtonContainer = styled_components__WEBPACK_IMPORTED_MODULE_9___default().div.withConfig({
  displayName: "ConfirmDelete__ButtonContainer",
  componentId: "sc-1jomx6n-1"
})(["margin-top:2rem;display:flex;justify-content:flex-end;width:100%;& > button:not(:first-of-type){margin-left:0.5rem;}", ""], _theme__WEBPACK_IMPORTED_MODULE_8__/* .media.tabletLarge */ .BC.tabletLarge`
    margin-top: auto;
    margin-left: -40%;
    width: 147%;

    & > button {
        width: 8rem;
  }
  `);
const BodyContainer = styled_components__WEBPACK_IMPORTED_MODULE_9___default()(TitleContainer).withConfig({
  displayName: "ConfirmDelete__BodyContainer",
  componentId: "sc-1jomx6n-2"
})(["padding:0 10%;", ""], _theme__WEBPACK_IMPORTED_MODULE_8__/* .media.tablet */ .BC.tablet`
    padding: 0 15%;
  `);
const TextContainer = styled_components__WEBPACK_IMPORTED_MODULE_9___default()(TitleContainer).withConfig({
  displayName: "ConfirmDelete__TextContainer",
  componentId: "sc-1jomx6n-3"
})(["margin-bottom:0.875rem;"]);
const Form = styled_components__WEBPACK_IMPORTED_MODULE_9___default().form.withConfig({
  displayName: "ConfirmDelete__Form",
  componentId: "sc-1jomx6n-4"
})(["width:100%;height:100%;display:flex;justify-content:space-between;align-items:flex-end;flex-direction:column;"]);
const FormGroup = styled_components__WEBPACK_IMPORTED_MODULE_9___default().div.withConfig({
  displayName: "ConfirmDelete__FormGroup",
  componentId: "sc-1jomx6n-5"
})(["width:100%;display:flex;flex-direction:column;align-items:center;"]);
const StyledCardChipIcon = styled_components__WEBPACK_IMPORTED_MODULE_9___default()(CardChipIcon).withConfig({
  displayName: "ConfirmDelete__StyledCardChipIcon",
  componentId: "sc-1jomx6n-6"
})(["width:1.5rem;height:1.125rem;& > *{fill:", ";}"], p => p.theme.colors.blue);

const ConfirmDelete = ({
  showConfirmationModal,
  setShowConfirmationModal,
  onConfirm,
  loading
}) => {
  const tablet = (0,react_responsive__WEBPACK_IMPORTED_MODULE_3__.useMediaQuery)({
    query: `(min-width: ${_theme__WEBPACK_IMPORTED_MODULE_8__/* .sizes.tablet */ .J7.tablet}px)`
  });
  const methods = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_2__.useForm)({
    resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_1__.yupResolver)(schema),
    mode: "onBlur",
    reValidateMode: "onChange",
    defaultValues: {
      password: ""
    }
  });
  const {
    handleSubmit
  } = methods;
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_common_ConfirmationModal__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
    open: showConfirmationModal,
    onClose: () => setShowConfirmationModal(!showConfirmationModal),
    onConfirm: handleSubmit(onConfirm),
    cancelText: "No, go back",
    confirmText: "Delete Organisation",
    confirmClose: true,
    title: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(TitleContainer, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(Bin, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP, {
        size: "modalTitle",
        color: "red",
        children: "Delete your organisation?"
      })]
    }),
    body: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(BodyContainer, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(TextContainer, {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP, {
          size: "tiny",
          children: "You are deleting your organisation. This will stop all payments and all members will only have the remainder of that period to access the platform."
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(TextContainer, {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP, {
          size: "tiny",
          color: "red",
          children: "Please enter your password to delete organisation."
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.FormProvider, _objectSpread(_objectSpread({}, methods), {}, {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(Form, {
          onSubmit: handleSubmit(onConfirm),
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(FormGroup, {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_form_PasswordInput__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
              name: "password",
              isRequired: true,
              type: "password",
              placeholder: "Enter password..."
            })
          })
        })
      }))]
    }),
    loading: loading,
    warning: true
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ConfirmDelete);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 42052:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61908);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(45641);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1187);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _button_Button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(59067);
/* harmony import */ var _button_CTAButtons__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(13508);
/* harmony import */ var _common_Divider__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6459);
/* harmony import */ var _form_ImageInput__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(48800);
/* harmony import */ var _form_Input__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(18183);
/* harmony import */ var _form_Label__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(54251);
/* harmony import */ var _contexts_auth__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(58368);
/* harmony import */ var _lib_images__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(39310);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(91073);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(11098);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(75609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(92107);
/* harmony import */ var _SettingsContainer__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(89857);
/* harmony import */ var _ConfirmDelete__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(34737);
/* harmony import */ var _UserItem__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(32083);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__, react_hook_form__WEBPACK_IMPORTED_MODULE_3__, _form_ImageInput__WEBPACK_IMPORTED_MODULE_8__, _form_Input__WEBPACK_IMPORTED_MODULE_9__, _ConfirmDelete__WEBPACK_IMPORTED_MODULE_18__]);
([_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__, react_hook_form__WEBPACK_IMPORTED_MODULE_3__, _form_ImageInput__WEBPACK_IMPORTED_MODULE_8__, _form_Input__WEBPACK_IMPORTED_MODULE_9__, _ConfirmDelete__WEBPACK_IMPORTED_MODULE_18__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
























const DeleteContainer = styled_components__WEBPACK_IMPORTED_MODULE_15___default().div.withConfig({
  displayName: "OrganisationDetails__DeleteContainer",
  componentId: "sc-1dtek96-0"
})(["margin:1rem auto 5rem;", ""], _theme__WEBPACK_IMPORTED_MODULE_13__/* .media.tablet */ .BC.tablet`
    margin: 3rem auto;
  `);
const FormGroup = styled_components__WEBPACK_IMPORTED_MODULE_15___default().div.withConfig({
  displayName: "OrganisationDetails__FormGroup",
  componentId: "sc-1dtek96-1"
})(["margin-bottom:2rem;"]);
const FILE_SIZE = 2;
const SUPPORTED_FORMATS = ["image/jpg", "image/jpeg"];
const schema = yup__WEBPACK_IMPORTED_MODULE_16__.object().shape({
  name: yup__WEBPACK_IMPORTED_MODULE_16__.string().required(),
  logo: yup__WEBPACK_IMPORTED_MODULE_16__.mixed().when("value", {
    is: value => value,
    then: yup__WEBPACK_IMPORTED_MODULE_16__.mixed().test("fileSize", "File Size is too large", value => value && value[0].size / 1024 / 1024 <= FILE_SIZE).test("fileFormat", "Unsupported Format", value => value && SUPPORTED_FORMATS.includes(value[0].type))
  })
});

const OrganisationDetails = () => {
  const {
    user,
    organisation,
    setOrganisation
  } = (0,_contexts_auth__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z)();
  const {
    0: src,
    1: setSrc
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(organisation.logo);
  const {
    0: loading,
    1: setLoading
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
  const {
    0: showConfirmationModal,
    1: setShowConfirmationModal
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
  const defaultValues = {
    name: organisation.name
  };
  const methods = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_3__.useForm)({
    resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__.yupResolver)(schema),
    defaultValues
  });
  const {
    handleSubmit,
    formState,
    reset
  } = methods;
  const {
    isDirty,
    dirtyFields
  } = formState;
  const changed = !!Object.keys(dirtyFields).length;
  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(() => {
    setSrc(organisation.logo);
  }, [organisation]);

  const onSubmit = async ({
    name,
    logo
  }) => {
    try {
      setLoading(true);
      const updatedLogo = dirtyFields.logo ? await (0,_lib_images__WEBPACK_IMPORTED_MODULE_12__/* .signFile */ .a)({
        file: logo[0],
        filename: `organisations/${organisation.id}/logo`
      }) : null;
      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_1___default().patch(`/api/organisations/${user.organisation_id}`, _objectSpread({
        name
      }, updatedLogo ? {
        logo: updatedLogo
      } : {}));
      setOrganisation(data);
      reset({
        name: data.name,
        logo
      });
      react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.success("Organisation Updated", {
        containerId: _constants__WEBPACK_IMPORTED_MODULE_21__/* .SETTINGS_CONTAINER_ID */ .f
      });
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_14__/* .logError */ .H)(error, _constants__WEBPACK_IMPORTED_MODULE_21__/* .SETTINGS_CONTAINER_ID */ .f);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteClick = async values => {
    try {
      setLoading(true);
      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_1___default()["delete"](`/api/organisations/${user.organisation_id}`, {
        data: values
      });
      setOrganisation(data);
      setShowConfirmationModal(false);
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_14__/* .logError */ .H)(error);
    } finally {
      setLoading(false);
    }
  };

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxs)(_SettingsContainer__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
    title: "Organisation Details",
    cta: changed && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_button_CTAButtons__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
      onDiscard: () => reset(defaultValues),
      loading: loading,
      onSave: handleSubmit(onSubmit)
    }),
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_ConfirmDelete__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {
      showConfirmationModal: showConfirmationModal,
      setShowConfirmationModal: setShowConfirmationModal,
      onConfirm: handleDeleteClick,
      loading: loading,
      setLoading: setLoading
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_3__.FormProvider, _objectSpread(_objectSpread({}, methods), {}, {
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxs)("form", {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(FormGroup, {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_form_Input__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
            name: "name",
            label: "Organisation Name:",
            width: "100%",
            isRequired: true
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(FormGroup, {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_form_ImageInput__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
            name: "logo",
            label: "Logo:",
            src: src,
            loading: loading
          })
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxs)(FormGroup, {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_form_Label__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
            children: "Owner:"
          }), organisation.owner && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_UserItem__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z, {
            user: organisation.owner,
            size: "3rem",
            wrap: "wrap",
            actionWidth: "100%",
            action: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP, {
              small: true,
              type: "button",
              href: "manage-team",
              children: "Change"
            })
          })]
        }), organisation.owner && user.id === organisation.owner.id && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxs)(DeleteContainer, {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_common_Divider__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
            margin: "0.5rem 0 2rem"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP, {
            warning: true,
            secondary: true,
            type: "button",
            onClick: () => setShowConfirmationModal(!showConfirmationModal),
            children: "Delete Organisation"
          })]
        })]
      })
    }))]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (OrganisationDetails);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 39310:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "a": () => (/* binding */ signFile)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);

const signFile = async ({
  file,
  filename
}) => {
  const {
    data: {
      url
    }
  } = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`/api/images`, {
    params: {
      filename,
      filetype: file.type
    }
  });
  const response = await axios__WEBPACK_IMPORTED_MODULE_0___default().put(url, file, {
    headers: {
      "Content-Type": file.type
    }
  });
  return `${url.split("?")[0]}?versionId=${response.headers["x-amz-version-id"]}`;
};

/***/ }),

/***/ 59029:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16666);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_responsive__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_common_Page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97598);
/* harmony import */ var _components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(60805);
/* harmony import */ var _components_ContentContainer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(16067);
/* harmony import */ var _components_settings_admin__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(75467);
/* harmony import */ var _components_settings_admin_OrganisationDetails__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(42052);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(91073);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_3__, _components_settings_admin_OrganisationDetails__WEBPACK_IMPORTED_MODULE_6__]);
([_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_3__, _components_settings_admin_OrganisationDetails__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }










var AdminSettingsIcon = function AdminSettingsIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("path", {
      d: "M24.978 12.572c-.013.328.022.734-.018 1.139-.081.812-.622 1.396-1.43 1.535-.46.08-.923.157-1.385.229-.145.023-.228.082-.277.23a6.956 6.956 0 0 1-.476 1.14c-.076.139-.07.245.026.373.28.376.547.761.82 1.142.503.7.447 1.575-.154 2.192a81.343 81.343 0 0 1-1.537 1.538c-.62.6-1.492.657-2.193.154-.39-.281-.784-.558-1.172-.842a.239.239 0 0 0-.288-.024 7.937 7.937 0 0 1-1.193.495c-.15.05-.207.128-.23.272-.069.445-.144.887-.222 1.33-.164.928-.742 1.465-1.688 1.5-.767.028-1.537.042-2.304-.014a1.652 1.652 0 0 1-1.5-1.373c-.081-.48-.16-.961-.235-1.442a.3.3 0 0 0-.233-.274 7.312 7.312 0 0 1-1.14-.475.223.223 0 0 0-.271.021c-.409.3-.821.594-1.237.88-.71.492-1.555.42-2.173-.187-.51-.5-1.015-1.003-1.515-1.512-.61-.618-.671-1.5-.162-2.206.273-.38.543-.764.822-1.14.08-.108.1-.194.031-.319a7.112 7.112 0 0 1-.502-1.185.26.26 0 0 0-.233-.203c-.45-.068-.9-.15-1.35-.226-.955-.158-1.5-.74-1.537-1.715a21.514 21.514 0 0 1 .014-2.285 1.64 1.64 0 0 1 1.322-1.486c.496-.095.995-.179 1.495-.256.14-.022.204-.088.244-.214.132-.41.294-.81.487-1.197a.265.265 0 0 0-.028-.309c-.287-.394-.57-.79-.85-1.19-.516-.743-.437-1.589.205-2.23l1.46-1.457c.634-.629 1.487-.705 2.218-.192.389.273.774.551 1.155.834.108.08.2.096.322.03.381-.2.78-.368 1.19-.5a.258.258 0 0 0 .2-.234c.063-.433.15-.862.216-1.293C9.827.644 10.364.101 11.34.04c.767-.05 1.537-.048 2.303.007.835.065 1.407.614 1.55 1.434.08.461.16.922.231 1.385.02.126.072.2.197.24.44.141.869.318 1.281.527a.247.247 0 0 0 .29-.027c.4-.29.803-.574 1.206-.86a1.647 1.647 0 0 1 2.13.153 79.24 79.24 0 0 1 1.591 1.59c.568.583.621 1.463.144 2.134-.286.4-.57.805-.862 1.203a.242.242 0 0 0-.022.289c.196.37.357.758.48 1.158.05.172.146.236.312.261.432.065.862.142 1.293.219.975.173 1.493.781 1.51 1.771.007.32.003.645.003 1.049zm-7.9 6.894a.887.887 0 0 1 .544.178c.529.378 1.06.75 1.587 1.131.1.072.177.1.276 0 .416-.423.835-.842 1.257-1.26.11-.109.11-.192.018-.318-.38-.52-.75-1.05-1.118-1.573-.23-.325-.237-.656-.036-1a7.886 7.886 0 0 0 .832-2c.105-.407.363-.64.78-.707.622-.1 1.243-.21 1.865-.308.15-.024.211-.077.209-.239a57.87 57.87 0 0 1 0-1.743c0-.14-.044-.2-.184-.22-.623-.1-1.243-.216-1.866-.313-.425-.066-.688-.293-.797-.708a7.545 7.545 0 0 0-.813-1.968c-.235-.393-.206-.75.064-1.112.369-.497.716-1.009 1.082-1.507.096-.129.082-.203-.03-.312a54.582 54.582 0 0 1-1.232-1.232c-.104-.106-.175-.116-.296-.027-.523.386-1.05.763-1.581 1.14-.31.221-.637.243-.968.05a8.374 8.374 0 0 0-2.11-.869c-.4-.104-.624-.365-.689-.773-.1-.616-.206-1.231-.304-1.85-.024-.153-.079-.221-.25-.217a40.65 40.65 0 0 1-1.687 0c-.18-.004-.25.05-.28.228-.093.611-.208 1.218-.303 1.829-.067.429-.292.704-.716.815-.69.18-1.35.458-1.963.825-.392.236-.75.2-1.112-.067-.5-.372-1.018-.725-1.523-1.093-.104-.077-.164-.065-.25.023-.42.43-.845.854-1.273 1.274-.104.1-.098.175-.017.286.374.515.737 1.04 1.112 1.555.253.347.276.692.056 1.064a7.607 7.607 0 0 0-.808 1.99c-.1.391-.342.627-.744.695-.633.108-1.267.221-1.9.32-.15.024-.2.085-.196.231a95 95 0 0 1 0 1.743c0 .15.05.207.2.23.653.105 1.305.22 1.957.333.355.061.595.27.69.61.204.742.503 1.454.889 2.119.195.336.165.666-.064.983-.374.516-.738 1.039-1.114 1.554-.086.119-.087.197.021.3.42.41.837.825 1.245 1.246.108.112.179.103.295.018.5-.365 1.011-.712 1.507-1.082.375-.279.74-.306 1.15-.071a7.615 7.615 0 0 0 1.904.774c.4.104.631.356.7.765.1.61.208 1.218.3 1.83.028.186.088.263.293.257a28.907 28.907 0 0 1 1.65 0c.197.005.256-.07.284-.246.09-.587.21-1.169.29-1.756.065-.486.325-.753.792-.873a7.36 7.36 0 0 0 1.945-.819.837.837 0 0 1 .428-.133h.002z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("path", {
      d: "M12.497 7.025c3.006 0 5.477 2.474 5.477 5.48 0 3.006-2.48 5.477-5.485 5.473-3.005-.004-5.487-2.488-5.465-5.491a5.487 5.487 0 0 1 5.473-5.462zm.005 1.7a3.789 3.789 0 0 0-3.782 3.779c0 2.068 1.705 3.772 3.773 3.773 2.067.002 3.776-1.697 3.779-3.764a3.78 3.78 0 0 0-3.77-3.787v-.001z"
    })]
  }));
};

AdminSettingsIcon.defaultProps = {
  width: "25",
  height: "25",
  viewBox: "0 0 25 25",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var OrganisationDetailsIcon = function OrganisationDetailsIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("path", {
      d: "M7.678 13.653V5.67c0-.495.129-.624.624-.625h1.422V3.222c0-.515.114-.629.634-.63h1.9v-.786c0-.367-.004-.734 0-1.101.003-.275.175-.455.426-.458.251-.004.434.169.438.446.007.54.002 1.077.003 1.617v.284h.393c.547 0 1.094-.004 1.641 0 .344.003.497.158.5.505.003.555 0 1.11 0 1.664v.281h1.397c.527 0 .642.118.642.651v4.374H25.1c.524 0 .653.129.653.648l-.025 15.165c0 .474-.124.6-.59.601l-24.283.032c-.48 0-.61-.13-.61-.611v-9.96c0-.454.063-.534.507-.638l6.694-1.59c.07-.017.136-.037.232-.063zm9.127 11.97V5.936H8.573v19.687h8.232zm8.054-14.657h-7.14v14.646h2.277v-1.766c0-.37.153-.524.527-.526.523 0 1.047-.003 1.572 0 .355 0 .509.16.511.52.003.508 0 1.016 0 1.524 0 .082.01.164.014.243h2.238V10.966zM7.665 14.558L1.128 16.11v9.515h6.537V14.558zm7.11-9.522V3.467h-4.166v1.569h4.166zm6.106 20.572h.835v-1.411h-.835v1.411z",
      strokeWidth: ".491",
      strokeMiterlimit: "10"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("path", {
      d: "M12.682 8.65c-.656 0-1.312.003-1.966 0-.319 0-.5-.142-.525-.388a.405.405 0 0 1 .313-.455c.098-.022.2-.033.3-.032 1.258-.002 2.516-.002 3.773 0 .405 0 .626.155.627.437.002.282-.219.442-.623.442-.633-.001-1.266-.003-1.9-.003zM12.682 23.852h1.92c.102-.001.203.011.3.037.198.055.296.208.296.402 0 .194-.098.344-.3.4a1.28 1.28 0 0 1-.323.036c-1.258.002-2.515.002-3.773 0h-.14c-.3-.022-.477-.186-.476-.443.002-.256.18-.425.48-.434.345-.01.689-.002 1.033-.002l.983.004zM12.683 21.554h1.921c.11-.002.218.012.323.044a.42.42 0 0 1-.008.79c-.105.03-.213.043-.322.04-1.273.003-2.546.003-3.82 0a1.15 1.15 0 0 1-.231-.02c-.232-.049-.361-.203-.36-.422.002-.218.134-.37.367-.417.076-.013.154-.018.232-.017l1.898.002zM12.69 10.947c-.656 0-1.313.004-1.969 0-.344 0-.532-.156-.534-.427 0-.21.099-.36.307-.415.098-.023.2-.035.3-.033a889.39 889.39 0 0 1 3.796 0h.094c.312.013.51.178.518.429.008.25-.2.444-.521.447-.664.003-1.328 0-1.991 0zM12.673 13.245h-1.874a1.275 1.275 0 0 1-.3-.032c-.211-.052-.312-.202-.31-.413 0-.2.102-.344.3-.396.098-.024.198-.036.3-.035 1.265-.002 2.53-.002 3.795 0h.024c.38 0 .6.168.595.446-.006.278-.219.43-.586.432l-1.944-.002zM12.689 15.541c-.656 0-1.313.003-1.969 0-.33 0-.515-.147-.532-.405a.403.403 0 0 1 .307-.437c.099-.024.2-.035.3-.033a889.39 889.39 0 0 1 3.796 0h.117c.295.017.488.185.494.429.007.243-.193.442-.498.445-.672.006-1.343.001-2.015.001zM12.68 20.136h-1.897a1.059 1.059 0 0 1-.322-.042c-.182-.06-.273-.202-.274-.393 0-.19.09-.336.27-.393a1.13 1.13 0 0 1 .344-.043c1.258-.003 2.516-.003 3.773 0 .406 0 .626.153.627.436.002.284-.22.443-.623.443-.632-.005-1.264-.007-1.897-.008zM12.69 17.839h-1.967c-.33 0-.516-.148-.533-.405a.403.403 0 0 1 .307-.438c.098-.023.2-.034.3-.033 1.265-.002 2.53-.002 3.796 0h.117c.295.017.487.186.494.428.007.251-.193.443-.498.446-.673.007-1.345.001-2.017.002zM19.997 18.645c0 .094.005.188 0 .28a.435.435 0 0 1-.424.419.419.419 0 0 1-.437-.374 3.494 3.494 0 0 1 0-.653.419.419 0 0 1 .439-.373.435.435 0 0 1 .421.42c.005.093 0 .187 0 .28zM21.732 18.656c0 .094.005.187 0 .28a.43.43 0 0 1-.409.407.414.414 0 0 1-.445-.361 3.69 3.69 0 0 1 0-.676.415.415 0 0 1 .446-.362.43.43 0 0 1 .407.408c.006.1 0 .202 0 .304zM19.996 21.268c0 .094.007.188 0 .281a.43.43 0 0 1-.414.4.413.413 0 0 1-.442-.364 3.309 3.309 0 0 1 .002-.676c.026-.23.22-.364.45-.352a.426.426 0 0 1 .406.407c.003.1-.002.203-.002.304zM21.732 15.942c0 .093.005.187 0 .28a.424.424 0 0 1-.401.411c-.24.014-.436-.132-.456-.371a3.781 3.781 0 0 1 0-.654.414.414 0 0 1 .439-.369.43.43 0 0 1 .416.399c.009.1.002.203.002.304zM19.996 15.934c0 .094.005.188 0 .281a.427.427 0 0 1-.397.416c-.239.016-.438-.125-.462-.366a3.416 3.416 0 0 1 0-.653.418.418 0 0 1 .436-.375.433.433 0 0 1 .425.417c.003.094-.002.189-.002.28zM21.732 21.265c0 .094.006.188 0 .281a.43.43 0 0 1-.434.405.417.417 0 0 1-.425-.386 4.023 4.023 0 0 1 0-.63c.02-.24.212-.39.451-.378a.422.422 0 0 1 .407.404c.007.1 0 .203 0 .304zM19.996 13.231c0 .094.005.188 0 .281a.431.431 0 0 1-.419.42.421.421 0 0 1-.445-.393 3.625 3.625 0 0 1 0-.607c.02-.254.216-.408.463-.393.228.013.393.186.403.433.001.086-.002.172-.002.259zM21.732 13.228c0 .101.007.203 0 .304a.426.426 0 0 1-.415.398.411.411 0 0 1-.442-.365 3.775 3.775 0 0 1 0-.654c.02-.24.216-.386.455-.372a.422.422 0 0 1 .402.408c.005.093 0 .186 0 .281zM23.468 15.938c0 .101.007.204 0 .304a.419.419 0 0 1-.417.394c-.228.005-.418-.142-.435-.369a4.22 4.22 0 0 1 0-.653.412.412 0 0 1 .435-.373.424.424 0 0 1 .418.393c.006.1 0 .202 0 .304zM23.47 21.25c0 .094.004.188 0 .28a.43.43 0 1 1-.86.004 5.352 5.352 0 0 1 0-.561c.012-.257.193-.421.439-.416.246.005.41.179.421.436.003.086 0 .171 0 .257zM23.47 18.657c0 .093.005.187 0 .28a.428.428 0 0 1-.432.407.418.418 0 0 1-.424-.386 4.576 4.576 0 0 1 0-.63.417.417 0 0 1 .426-.384.428.428 0 0 1 .429.41c.005.1 0 .202 0 .303zM23.47 13.227c0 .1.005.203 0 .303a.425.425 0 0 1-.436.401.412.412 0 0 1-.42-.388 4.63 4.63 0 0 1 0-.607.409.409 0 0 1 .432-.398.419.419 0 0 1 .425.408c.003.093-.002.187-.002.28zM4.899 20.388c0 .093.006.187 0 .28a.432.432 0 0 1-.427.413.416.416 0 0 1-.433-.378 3.624 3.624 0 0 1 .003-.653.416.416 0 0 1 .442-.367.434.434 0 0 1 .415.401c.009.1 0 .203 0 .304zM3.162 20.407c0 .086.005.172 0 .257a.435.435 0 0 1-.423.42.419.419 0 0 1-.44-.372 3.412 3.412 0 0 1 0-.653.423.423 0 0 1 .44-.374.438.438 0 0 1 .423.418c.006.098 0 .2 0 .304zM3.161 23.1c0 .094.007.188 0 .281a.436.436 0 0 1-.414.404.418.418 0 0 1-.445-.364 3.24 3.24 0 0 1 0-.677c.025-.228.224-.367.45-.354a.43.43 0 0 1 .408.406c.008.101.002.203.001.305zM4.898 23.081c0 .102.008.204 0 .305a.433.433 0 0 1-.416.4.418.418 0 0 1-.442-.37 3.7 3.7 0 0 1-.006-.63.418.418 0 0 1 .438-.397c.24.004.415.18.427.435.004.085 0 .171 0 .257zM3.162 17.691c0 .094.006.188 0 .28a.428.428 0 0 1-.414.4c-.227.01-.422-.13-.446-.358a3.278 3.278 0 0 1 0-.677c.025-.227.227-.369.45-.355a.43.43 0 0 1 .408.406c.009.1.002.203.002.304zM4.898 17.68c0 .101.008.204 0 .304a.424.424 0 0 1-.4.387c-.23.014-.428-.118-.451-.347a3.36 3.36 0 0 1 0-.7c.023-.217.218-.352.433-.343a.427.427 0 0 1 .417.396c.01.1.001.202.001.303zM6.636 23.077c0 .1.006.203 0 .303a.432.432 0 0 1-.722.296.42.42 0 0 1-.135-.277 4.396 4.396 0 0 1 0-.608.413.413 0 0 1 .43-.402c.241 0 .417.176.43.43.004.086 0 .172 0 .258h-.003zM6.636 20.388c0 .093.005.187 0 .28a.43.43 0 0 1-.426.413.42.42 0 0 1-.434-.4 4.465 4.465 0 0 1 0-.608.422.422 0 0 1 .42-.393.431.431 0 0 1 .437.403c.009.102.003.204.003.305zM6.635 17.688c0 .102.008.203 0 .304a.42.42 0 0 1-.406.38c-.231.01-.424-.129-.445-.356a3.89 3.89 0 0 1 0-.677c.018-.216.205-.36.421-.36a.423.423 0 0 1 .43.381c.008.109 0 .219 0 .328z",
      strokeWidth: ".491",
      strokeMiterlimit: "10"
    })]
  }));
};

OrganisationDetailsIcon.defaultProps = {
  width: "26",
  height: "27",
  viewBox: "0 0 26 27",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};




function OrganisationDetailsSettings() {
  const {
    0: showMenu,
    1: setShowMenu
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const isTablet = (0,react_responsive__WEBPACK_IMPORTED_MODULE_1__.useMediaQuery)({
    query: `(min-width: ${_theme__WEBPACK_IMPORTED_MODULE_8__/* .sizes.tablet */ .J7.tablet}px)`
  });
  const isTabletLarge = (0,react_responsive__WEBPACK_IMPORTED_MODULE_1__.useMediaQuery)({
    query: `(min-width: ${_theme__WEBPACK_IMPORTED_MODULE_8__/* .sizes.tabletLarge */ .J7.tabletLarge}px)`
  });
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_components_common_Page__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_components_ContentContainer__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
      title: "Settings",
      limitWidth: isTabletLarge,
      icon: !isTablet ? showMenu ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(AdminSettingsIcon, {}) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(OrganisationDetailsIcon, {}) : null,
      onIconClick: () => setShowMenu(!showMenu),
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_components_settings_admin__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
        showMenu: showMenu,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_components_settings_admin_OrganisationDetails__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
      })
    })
  });
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)(OrganisationDetailsSettings, true));
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 57886:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "unstable_getStaticParams": () => (/* binding */ unstable_getStaticParams),
/* harmony export */   "unstable_getStaticProps": () => (/* binding */ unstable_getStaticProps),
/* harmony export */   "unstable_getStaticPaths": () => (/* binding */ unstable_getStaticPaths),
/* harmony export */   "unstable_getServerProps": () => (/* binding */ unstable_getServerProps),
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "_app": () => (/* binding */ _app),
/* harmony export */   "renderReqToHTML": () => (/* binding */ renderReqToHTML),
/* harmony export */   "render": () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(70607);
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59450);
/* harmony import */ var private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97020);
/* harmony import */ var private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(73978);
/* harmony import */ var next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99436);

      
      
      
      

      
      const { processEnv } = __webpack_require__(85360)
      processEnv([{"path":".env","contents":"API_HOST=https://api.inhabit.eco\nNEXT_PUBLIC_CALENDLY_URL=https://calendly.com/inhabit-meet/inhabit-measurement-tutorial\nNEXT_PUBLIC_FLAGS_ENVIRONMENT_KEY=flags_pub_289425705564897805\nNEXT_PUBLIC_GOOGLE_ANALYTICS=G-1CBB78XFQ4\nNEXT_PUBLIC_INTERCOM_APP_ID=bw9p6mfd\nNEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_bQDaTEuYc10x3BZt9YcGj2cE00Gzwm4gDD\nSTRIPE_PUBLISHABLE_KEY=pk_live_bQDaTEuYc10x3BZt9YcGj2cE00Gzwm4gDD\n\n"}])
    
      
      const runtimeConfig = {}
      ;

      const documentModule = __webpack_require__(9968)

      const appMod = __webpack_require__(13724)
      let App = appMod.default || appMod.then && appMod.then(mod => mod.default);

      const compMod = __webpack_require__(59029)

      const Component = compMod.default || compMod.then && compMod.then(mod => mod.default)
      /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Component);
      const getStaticProps = compMod['getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['getStaticProp' + 's'])
      const getStaticPaths = compMod['getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['getStaticPath' + 's'])
      const getServerSideProps = compMod['getServerSideProp' + 's'] || compMod.then && compMod.then(mod => mod['getServerSideProp' + 's'])

      // kept for detecting legacy exports
      const unstable_getStaticParams = compMod['unstable_getStaticParam' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticParam' + 's'])
      const unstable_getStaticProps = compMod['unstable_getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticProp' + 's'])
      const unstable_getStaticPaths = compMod['unstable_getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticPath' + 's'])
      const unstable_getServerProps = compMod['unstable_getServerProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getServerProp' + 's'])

      let config = compMod['confi' + 'g'] || (compMod.then && compMod.then(mod => mod['confi' + 'g'])) || {}
      const _app = App

      const combinedRewrites = Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)
        ? private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg
        : []

      if (!Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)) {
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.beforeFiles */ .Dg.beforeFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.afterFiles */ .Dg.afterFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.fallback */ .Dg.fallback)
      }

      const { renderReqToHTML, render } = (0,next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__/* .getPageHandler */ .u)({
        pageModule: compMod,
        pageComponent: Component,
        pageConfig: config,
        appModule: App,
        documentModule: documentModule,
        errorModule: __webpack_require__(99651),
        notFoundModule: undefined,
        pageGetStaticProps: getStaticProps,
        pageGetStaticPaths: getStaticPaths,
        pageGetServerSideProps: getServerSideProps,

        assetPrefix: "",
        canonicalBase: "",
        generateEtags: true,
        poweredByHeader: true,
        reactRoot: false,

        runtimeConfig,
        buildManifest: private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__,
        reactLoadableManifest: private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__,

        rewrites: combinedRewrites,
        i18n: undefined,
        page: "/settings/admin/organisation-details",
        buildId: "lDoX7RBEQ31kzKIJJbkVC",
        escapedBuildId: "lDoX7RBEQ31kzKIJJbkVC",
        basePath: "",
        pageIsDynamic: false,
        encodedPreviewProps: {previewModeId:"89cdc9f6073608262d43eab6d636f3f4",previewModeSigningKey:"74c7e36a2414a3f7b0ebcc67250f915f156686e1610b45a21ae9358d5b7c6c5a",previewModeEncryptionKey:"8a4c97ad9e5cf12d5a140689be08539ea52d8b27a416c2b8ae67db636b45841b"}
      })
      
    

/***/ }),

/***/ 94970:
/***/ ((module) => {

module.exports = require("@happykit/flags/client");

/***/ }),

/***/ 46411:
/***/ ((module) => {

module.exports = require("@happykit/flags/config");

/***/ }),

/***/ 48095:
/***/ ((module) => {

module.exports = require("@happykit/flags/server");

/***/ }),

/***/ 83218:
/***/ ((module) => {

module.exports = require("@hookform/error-message");

/***/ }),

/***/ 48308:
/***/ ((module) => {

module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ 85360:
/***/ ((module) => {

module.exports = require("@next/env");

/***/ }),

/***/ 64515:
/***/ ((module) => {

module.exports = require("@stripe/react-stripe-js");

/***/ }),

/***/ 20943:
/***/ ((module) => {

module.exports = require("@stripe/stripe-js");

/***/ }),

/***/ 52167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 1043:
/***/ ((module) => {

module.exports = require("lodash.get");

/***/ }),

/***/ 51650:
/***/ ((module) => {

module.exports = require("lodash.uniqby");

/***/ }),

/***/ 54426:
/***/ ((module) => {

module.exports = require("next/dist/compiled/chalk");

/***/ }),

/***/ 40252:
/***/ ((module) => {

module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 19371:
/***/ ((module) => {

module.exports = require("next/dist/compiled/node-fetch");

/***/ }),

/***/ 97999:
/***/ ((module) => {

module.exports = require("next/dist/compiled/path-to-regexp");

/***/ }),

/***/ 60600:
/***/ ((module) => {

module.exports = require("next/dist/server/accept-header.js");

/***/ }),

/***/ 52155:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils/index.js");

/***/ }),

/***/ 90730:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils/node.js");

/***/ }),

/***/ 60562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 94140:
/***/ ((module) => {

module.exports = require("next/dist/server/get-page-files.js");

/***/ }),

/***/ 89716:
/***/ ((module) => {

module.exports = require("next/dist/server/htmlescape.js");

/***/ }),

/***/ 25071:
/***/ ((module) => {

module.exports = require("next/dist/server/render-result.js");

/***/ }),

/***/ 33100:
/***/ ((module) => {

module.exports = require("next/dist/server/render.js");

/***/ }),

/***/ 92779:
/***/ ((module) => {

module.exports = require("next/dist/server/request-meta.js");

/***/ }),

/***/ 79502:
/***/ ((module) => {

module.exports = require("next/dist/server/send-payload.js");

/***/ }),

/***/ 76368:
/***/ ((module) => {

module.exports = require("next/dist/server/utils.js");

/***/ }),

/***/ 56724:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 27664:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/escape-regexp.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 94957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 82374:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-locale-cookie.js");

/***/ }),

/***/ 34014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 78524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 78020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 29565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 64365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 95714:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-route-from-asset-path.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 91292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 25753:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-match.js");

/***/ }),

/***/ 99521:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/prepare-destination.js");

/***/ }),

/***/ 80979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 36052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 84226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 95566:
/***/ ((module) => {

module.exports = require("next/error");

/***/ }),

/***/ 40968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 71853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 59819:
/***/ ((module) => {

module.exports = require("querystring");

/***/ }),

/***/ 16689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 25716:
/***/ ((module) => {

module.exports = require("react-hotjar");

/***/ }),

/***/ 16666:
/***/ ((module) => {

module.exports = require("react-responsive");

/***/ }),

/***/ 1187:
/***/ ((module) => {

module.exports = require("react-toastify");

/***/ }),

/***/ 20997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 57518:
/***/ ((module) => {

module.exports = require("styled-components");

/***/ }),

/***/ 24535:
/***/ ((module) => {

module.exports = require("styled-normalize");

/***/ }),

/***/ 6153:
/***/ ((module) => {

module.exports = require("universal-cookie");

/***/ }),

/***/ 84269:
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ 75609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 61908:
/***/ ((module) => {

module.exports = import("@hookform/resolvers/yup");;

/***/ }),

/***/ 45641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [4357,9703,6114,9067,8183,9899,805,6067,1593,8294,5467,661,9857,3508,1537], () => (__webpack_exec__(57886)));
module.exports = __webpack_exports__;

})();