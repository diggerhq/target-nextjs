"use strict";
(() => {
var exports = {};
exports.id = 2870;
exports.ids = [2870];
exports.modules = {

/***/ 45486:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);



const createColor = ({
  backgroundColor,
  size,
  theme
}) => theme.colors[backgroundColor] || size && theme[size].color || theme.colors.secondaryBlue;

const Progress = styled_components__WEBPACK_IMPORTED_MODULE_0___default().progress.withConfig({
  displayName: "ProgressBar__Progress",
  componentId: "m3wjqd-0"
})(["-webkit-appearance:none;-moz-appearance:none;appearance:none;height:0.5rem;margin:1rem 0;width:100%;::-webkit-progress-bar{border-radius:10px;background:", ";}::-webkit-progress-value{border-radius:10px;background:", ";}"], createColor, p => p.theme.colors.blue);

const ProgressBar = ({
  value,
  max,
  backgroundColor
}) => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(Progress, {
    value: value,
    max: max,
    backgroundColor: backgroundColor
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProgressBar);

/***/ }),

/***/ 89336:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(87491);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(72994);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _Error__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(26428);
/* harmony import */ var _Input__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(18183);
/* harmony import */ var _Label__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(54251);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Input__WEBPACK_IMPORTED_MODULE_6__]);
_Input__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];











const Input = styled_components__WEBPACK_IMPORTED_MODULE_4___default().input.withConfig({
  displayName: "EmailInput__Input",
  componentId: "yn751z-0"
})(["", " resize:none;height:fit-content;width:100%;margin-bottom:0.5rem;::placeholder{color:", ";font-weight:", ";}&:focus{outline:none;}", ""], _Input__WEBPACK_IMPORTED_MODULE_6__/* .inputStyles */ .T, p => p.theme.colors.placeholderGrey, p => p.theme.input.fontWeight, _theme__WEBPACK_IMPORTED_MODULE_3__/* .media.tabletLarge */ .BC.tabletLarge`
	text-align: left;
  margin-bottom: 0.5rem;
		${p => p.width && `width: ${p.width};`}
`);
const InputContainer = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
  displayName: "EmailInput__InputContainer",
  componentId: "yn751z-1"
})(["display:flex;flex-wrap:wrap;width:100%;", " ", ""], p => p.height && `height: ${p.height};`, p => p.padding && `padding: ${p.padding};`);
const TagItem = styled_components__WEBPACK_IMPORTED_MODULE_4___default().li.withConfig({
  displayName: "EmailInput__TagItem",
  componentId: "yn751z-2"
})(["font-weight:lighter;margin:0.5rem 0.5rem 0.5rem 0;background-color:#efefef;padding:0 0.5rem;align-items:center;", " display:flex;list-style:none;height:fit-content;"], _styles__WEBPACK_IMPORTED_MODULE_2__/* .borderRadius */ .E);
const RemoveButton = styled_components__WEBPACK_IMPORTED_MODULE_4___default().button.withConfig({
  displayName: "EmailInput__RemoveButton",
  componentId: "yn751z-3"
})(["border:none;", ""], _styles__WEBPACK_IMPORTED_MODULE_2__/* .borderRadius */ .E);
const InputTags = styled_components__WEBPACK_IMPORTED_MODULE_4___default().ul.withConfig({
  displayName: "EmailInput__InputTags",
  componentId: "yn751z-4"
})(["overflow:scroll;width:100%;margin:0 !important;padding:0 0 0 0.25rem !important;display:inline-flex;flex-wrap:wrap;list-style:none;&::-webkit-scrollbar{display:none;}"]);
const TagsInput = styled_components__WEBPACK_IMPORTED_MODULE_4___default().li.withConfig({
  displayName: "EmailInput__TagsInput",
  componentId: "yn751z-5"
})(["flex-grow:1;list-style:none;width:100%;"]);

const EmailInput = props => {
  const {
    0: items,
    1: setItems
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
  const {
    0: value,
    1: setValue
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
  const {
    0: error,
    1: setError
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);

  const handleKeyDown = evt => {
    if (["Enter", "Tab", ",", " "].includes(evt.key)) {
      evt.preventDefault();
      var value = evt.target.value.trim();

      if (value && isValid(value)) {
        setItems([...items, value]);
        setValue("");
      }
    }
  };

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    props.setEmails(items);
  }, [items]);

  const handleChange = evt => {
    setValue(evt.target.value);
    setError(null);
  };

  const handleDelete = item => {
    setItems(items.filter(i => i !== item));
  };

  const handlePaste = evt => {
    evt.preventDefault();
    var paste = evt.clipboardData.getData("text");
    var emails = paste.match(/[\w\d\.-]+@[\w\d\.-]+\.[\w\d\.-]+/g);

    if (emails) {
      var toBeAdded = emails.filter(email => !isInList(email));
      setItems([...items, ...toBeAdded]);
    }
  };

  const isValid = email => {
    let error = null;

    if (isInList(email)) {
      error = `${email} has already been added.`;
    }

    if (!isEmail(email)) {
      error = `${email} is not a valid email address.`;
    }

    if (error) {
      setError(error);
      return false;
    }

    return true;
  };

  const isInList = email => {
    return items.includes(email);
  };

  const isEmail = email => {
    return /[\w\d\.-]+@[\w\d\.-]+\.[\w\d\.-]+/.test(email);
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.Fragment, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(InputContainer, {
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(InputTags, {
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(TagsInput, {
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(_Label__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
            block: true,
            margin: "0 0 0.5rem 0",
            children: ["Invite via email:", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
              size: "tiny",
              children: "Please enter comma seperated list of emails"
            })]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(Input, {
            className: "input " + (error && " has-error"),
            value: value,
            onKeyDown: handleKeyDown,
            onChange: handleChange,
            onPaste: handlePaste,
            items: items,
            placeholder: !items.length > 0 ? "name@example.com" : ""
          }), error && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_Error__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
            children: error
          })]
        }), items.map(item => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(TagItem, {
          children: [item, /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(RemoveButton, {
            type: "button",
            className: "button",
            onClick: () => handleDelete(item),
            children: "\xD7"
          })]
        }, item))]
      })
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EmailInput);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 30728:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(45641);
/* harmony import */ var _button_Button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(59067);
/* harmony import */ var _common_LoadingLarge__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(49899);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(87491);
/* harmony import */ var _form_EmailInput__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(89336);
/* harmony import */ var _contexts_auth__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(58368);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(91073);
/* harmony import */ var _utils_custom_hooks_useLoading__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(68037);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(11098);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(92107);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _form_EmailInput__WEBPACK_IMPORTED_MODULE_6__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _form_EmailInput__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

















const FormGroup = styled_components__WEBPACK_IMPORTED_MODULE_11___default().div.withConfig({
  displayName: "InviteEmailForm__FormGroup",
  componentId: "cchha1-0"
})(["width:100%;", ""], _theme__WEBPACK_IMPORTED_MODULE_8__/* .media.tablet */ .BC.tablet`
		display: flex;
		flex-direction: row;
  `);
const ButtonContainer = styled_components__WEBPACK_IMPORTED_MODULE_11___default().div.withConfig({
  displayName: "InviteEmailForm__ButtonContainer",
  componentId: "cchha1-1"
})(["display:flex;align-items:center;justify-content:flex-end;", ""], _theme__WEBPACK_IMPORTED_MODULE_8__/* .media.tablet */ .BC.tablet`
    display: block;
    ${p => !p.sent && "padding-top: 3.1rem"};
    ${p => !p.sent && "margin-left: 1rem"};
  `);
const TextContainer = styled_components__WEBPACK_IMPORTED_MODULE_11___default().div.withConfig({
  displayName: "InviteEmailForm__TextContainer",
  componentId: "cchha1-2"
})(["width:100%;padding-bottom:1rem;"]);
const RejectedContainer = styled_components__WEBPACK_IMPORTED_MODULE_11___default().div.withConfig({
  displayName: "InviteEmailForm__RejectedContainer",
  componentId: "cchha1-3"
})(["padding-bottom:initial;"]);
const InviteLink = styled_components__WEBPACK_IMPORTED_MODULE_11___default().a.withConfig({
  displayName: "InviteEmailForm__InviteLink",
  componentId: "cchha1-4"
})(["text-decoration:none;font-family:", ";font-size:", ";font-weight:bold;cursor:pointer;color:", ";:hover{text-decoration:underline;}"], p => p.theme.body.font, p => p.theme.mobile.smallBold.size, ({
  active
}) => active ? "black" : "#cecece");
const SuccessContainer = styled_components__WEBPACK_IMPORTED_MODULE_11___default().div.withConfig({
  displayName: "InviteEmailForm__SuccessContainer",
  componentId: "cchha1-5"
})(["display:flex;"]);
const Form = styled_components__WEBPACK_IMPORTED_MODULE_11___default().form.withConfig({
  displayName: "InviteEmailForm__Form",
  componentId: "cchha1-6"
})(["margin-bottom:2rem;", ""], _theme__WEBPACK_IMPORTED_MODULE_8__/* .media.tablet */ .BC.tablet`
    display: flex;
    align-items: ${p => !p.sent ? "center" : "flex-start"};
    ${p => p.sent && "flex-direction: column;"}
  `);

const InviteEmailForm = ({
  getOrganisationInvites
}) => {
  const {
    user
  } = (0,_contexts_auth__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
  const {
    0: sent,
    1: setSent
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
  const {
    0: rejected,
    1: setRejected
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
  const {
    0: valid,
    1: setValid
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
  const {
    loading,
    setLoading,
    progress,
    setProgress
  } = (0,_utils_custom_hooks_useLoading__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)();
  const {
    0: emails,
    1: setEmails
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
  const methods = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_2__.useForm)();
  const {
    handleSubmit,
    setValue,
    formState: {
      isSubmitting,
      isValid
    }
  } = methods;

  const onSubmit = async () => {
    setLoading(true);

    try {
      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_0___default().post(`/api/organisations/${user.organisation_id}/email-link`, {
        emails
      }, {
        onUploadProgress: progressEvent => {
          setProgress(Math.floor(progressEvent.loaded * 100 / progressEvent.total));
        }
      });
      await getOrganisationInvites();
      setSent(true);
      setRejected(data.rejected);
      setValid(data.valid);
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_10__/* .logError */ .H)(error, _constants__WEBPACK_IMPORTED_MODULE_13__/* .SETTINGS_CONTAINER_ID */ .f);
    }

    setLoading(false);
  };

  const reset = () => {
    setSent(false);
    setEmails([]);
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.FormProvider, _objectSpread(_objectSpread({}, methods), {}, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(Form, {
      onSubmit: handleSubmit(onSubmit),
      sent: true,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_common_LoadingLarge__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
        loading: loading,
        text: "Inviting member(s)...",
        progress: progress,
        setProgress: setProgress
      }), sent ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.Fragment, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(SuccessContainer, {
          children: !!valid.length && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(TextContainer, {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP, {
              size: "smallBold",
              children: "Great, your invitations have been sent!"
            })
          })
        }), !!rejected.length && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(RejectedContainer, {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP, {
            size: "smallBold",
            children: "Invites have not been sent to the following email address(es), as they are already in use:"
          }), rejected.map(email => {
            return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx("ul", {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP, {
                size: "small",
                color: "red",
                children: email
              })
            });
          })]
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(ButtonContainer, {
          sent: true,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP, {
            small: true,
            onClick: reset,
            children: "Send more"
          })
        })]
      }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.Fragment, {
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(FormGroup, {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_form_EmailInput__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
            setEmails: setEmails
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(ButtonContainer, {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP, {
              borderColor: "transparent",
              loading: loading,
              disabled: emails.length === 0,
              width: "5rem",
              minWidth: "5rem",
              children: "Invite"
            })
          })]
        })
      })]
    })
  }));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (InviteEmailForm);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 25821:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ admin_InviteLinkForm)
});

// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(52167);
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);
// EXTERNAL MODULE: external "date-fns"
var external_date_fns_ = __webpack_require__(74146);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
// EXTERNAL MODULE: external "react-responsive"
var external_react_responsive_ = __webpack_require__(16666);
// EXTERNAL MODULE: ./src/components/button/Button.jsx
var Button = __webpack_require__(59067);
// EXTERNAL MODULE: ./src/components/button/CopyButton.jsx + 1 modules
var CopyButton = __webpack_require__(71476);
// EXTERNAL MODULE: ./src/components/common/Spinner.jsx
var Spinner = __webpack_require__(16114);
// EXTERNAL MODULE: ./src/components/common/Text.jsx
var Text = __webpack_require__(87491);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(57518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
;// CONCATENATED MODULE: ./src/components/common/ToggleSwitch.jsx



const CheckBoxWrapper = external_styled_components_default().div.withConfig({
  displayName: "ToggleSwitch__CheckBoxWrapper",
  componentId: "sc-106rcdv-0"
})(["position:relative;width:42px;"]);
const CheckBoxLabel = external_styled_components_default().label.withConfig({
  displayName: "ToggleSwitch__CheckBoxLabel",
  componentId: "sc-106rcdv-1"
})(["position:absolute;top:0;left:0;width:42px;height:26px;border-radius:15px;background:#bebebe;cursor:pointer;&::after{content:\"\";display:block;border-radius:50%;width:18px;height:18px;margin:3.5px;background:#ffffff;box-shadow:1px 3px 3px 1px rgba(0,0,0,0.2);transition:0.2s;}"]);
const CheckBox = external_styled_components_default().input.withConfig({
  displayName: "ToggleSwitch__CheckBox",
  componentId: "sc-106rcdv-2"
})(["opacity:0;z-index:1;border-radius:15px;width:42px;height:26px;&:checked + ", "{background:", ";&::after{content:\"\";display:block;border-radius:50%;width:18px;height:18px;margin-left:21px;transition:0.2s;}}"], CheckBoxLabel, p => p.theme.colors.blue);

const ToggleSwitch = ({
  onChange,
  checked
}) => /*#__PURE__*/(0,jsx_runtime_.jsxs)(CheckBoxWrapper, {
  children: [/*#__PURE__*/jsx_runtime_.jsx(CheckBox, {
    id: "checkbox",
    type: "checkbox",
    onChange: onChange,
    checked: checked
  }), /*#__PURE__*/jsx_runtime_.jsx(CheckBoxLabel, {
    htmlFor: "checkbox"
  })]
});

/* harmony default export */ const common_ToggleSwitch = (ToggleSwitch);
// EXTERNAL MODULE: ./src/components/form/Label.jsx
var Label = __webpack_require__(54251);
// EXTERNAL MODULE: ./src/contexts/auth.js
var auth = __webpack_require__(58368);
// EXTERNAL MODULE: ./src/theme.js
var theme = __webpack_require__(91073);
// EXTERNAL MODULE: ./src/utils/logger.js + 1 modules
var logger = __webpack_require__(11098);
// EXTERNAL MODULE: ./src/utils/text.js
var utils_text = __webpack_require__(88703);
// EXTERNAL MODULE: ./src/components/settings/constants.js
var constants = __webpack_require__(92107);
;// CONCATENATED MODULE: ./src/components/settings/admin/InviteLinkForm.jsx


















const FormGroup = external_styled_components_default().div.withConfig({
  displayName: "InviteLinkForm__FormGroup",
  componentId: "sc-1jip5c4-0"
})(["margin-top:0.5rem;", ""], theme/* media.tablet */.BC.tablet`
    margin-top: 0.125rem;
		display: flex;
		flex-direction: row;
    width: 100%;
    align-items: flex-start;
  `);
const Link = external_styled_components_default().div.withConfig({
  displayName: "InviteLinkForm__Link",
  componentId: "sc-1jip5c4-1"
})(["width:100%;background:", ";border:2px solid ", ";border-radius:10px;height:2.25rem;overflow:scroll;white-space:nowrap;padding:0.5rem;margin-bottom:0.4rem;& > span{display:inline-block;max-width:25rem;}&::-webkit-scrollbar{scrollbar-width:none;-ms-overflow-style:none;display:none;}"], p => p.theme.colors.secondaryBlue, p => p.theme.colors.secondaryBlue);
const ButtonContainer = external_styled_components_default().div.withConfig({
  displayName: "InviteLinkForm__ButtonContainer",
  componentId: "sc-1jip5c4-2"
})(["display:flex;justify-content:flex-end;margin-top:-1.45rem;", " ", ""], theme/* media.mobileModern */.BC.mobileModern`
    margin-top: -2.45rem;
  `, theme/* media.tablet */.BC.tablet`
    display: block;
    margin-top: initial;
    margin-left: 1rem;
  `);
const Container = external_styled_components_default().div.withConfig({
  displayName: "InviteLinkForm__Container",
  componentId: "sc-1jip5c4-3"
})(["margin-bottom:2rem;position:relative;", ""], theme/* media.tablet */.BC.tablet`
    display: flex;
    flex-direction: column;
    justify-content: center;
  `);
const LinkContainer = external_styled_components_default().div.withConfig({
  displayName: "InviteLinkForm__LinkContainer",
  componentId: "sc-1jip5c4-4"
})(["width:100%;display:flex;flex-direction:column;align-items:flex-start;", " ", " ", ""], theme/* media.tablet */.BC.tablet`
    max-width: 72%;
    align-items: flex-end;
  `, theme/* media.tabletLarge */.BC.tabletLarge`
    max-width: 78%;
  `, theme/* media.desktop */.BC.desktop`
    max-width: 88%;
  `);
const ToggleContainer = external_styled_components_default().div.withConfig({
  displayName: "InviteLinkForm__ToggleContainer",
  componentId: "sc-1jip5c4-5"
})(["position:absolute;top:0;right:0;display:flex;& > ", "{margin-right:1rem;}"], Spinner/* default */.Z);
const NumberOfDaysContainer = external_styled_components_default().div.withConfig({
  displayName: "InviteLinkForm__NumberOfDaysContainer",
  componentId: "sc-1jip5c4-6"
})(["display:flex;flex-direction:column;", ""], theme/* media.mobileModern */.BC.mobileModern`
    flex-direction: row;
  `);

const InviteLinkForm = ({
  setOrganisationInvites
}) => {
  const {
    user,
    organisation,
    setOrganisation
  } = (0,auth/* default */.Z)();
  const {
    0: loading,
    1: setLoading
  } = (0,external_react_.useState)(false);
  const {
    0: show,
    1: setShow
  } = (0,external_react_.useState)(!!(organisation.invite_link && organisation.invite_link.state !== "paused"));
  const {
    0: mounted,
    1: setMounted
  } = (0,external_react_.useState)(false);
  const {
    0: link,
    1: setLink
  } = (0,external_react_.useState)(organisation.invite_link && organisation.invite_link.link || "");
  const isDesktopLarge = (0,external_react_responsive_.useMediaQuery)({
    query: `(min-width: ${theme/* sizes.desktopLarge */.J7.desktopLarge}px)`
  });
  const isDesktop = (0,external_react_responsive_.useMediaQuery)({
    query: `(min-width: ${theme/* sizes.desktop */.J7.desktop}px)`
  });
  const isTabletLarge = (0,external_react_responsive_.useMediaQuery)({
    query: `(min-width: ${theme/* sizes.tabletLarge */.J7.tabletLarge}px)`
  });

  const createLink = async () => {
    setLoading(true);

    try {
      const {
        data
      } = await external_axios_default().post(`/api/organisations/${user.organisation_id}/invite-link`);
      setLink(data.invite_link && data.invite_link.link);
      setOrganisation(data);
    } catch (error) {
      (0,logger/* logError */.H)(error, constants/* SETTINGS_CONTAINER_ID */.f);
    }

    setLoading(false);
  };

  const updateLink = async state => {
    setLoading(true);

    try {
      const {
        data
      } = await external_axios_default().patch(`/api/organisations/${user.organisation_id}/invite-link`, {
        state
      });
      setLink(data.invite_link && data.invite_link.link);
      setOrganisation(data);
    } catch (error) {
      (0,logger/* logError */.H)(error);
    }

    setLoading(false);
  };

  const resetLink = async () => {
    setLoading(true);

    try {
      await external_axios_default()["delete"](`/api/organisations/${user.organisation_id}/invite-link`);
      const {
        data
      } = await external_axios_default().post(`/api/organisations/${user.organisation_id}/invite-link`);
      setLink(data.invite_link && data.invite_link.link);
      setOrganisation(data);
    } catch (error) {
      (0,logger/* logError */.H)(error);
    }

    setLoading(false);
  };

  (0,external_react_.useEffect)(() => {
    if (mounted) {
      if (show && !organisation.invite_link) {
        createLink();
      } else {
        updateLink(show);
      }
    }
  }, [show]);
  (0,external_react_.useEffect)(() => {
    setMounted(true);
  }, []);
  const numberofDays = organisation.invite_link && (0,external_date_fns_.differenceInDays)(new Date(organisation.invite_link.expires_at), new Date());
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(Container, {
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(ToggleContainer, {
      children: [loading && /*#__PURE__*/jsx_runtime_.jsx(Spinner/* default */.Z, {
        color: "blue"
      }), /*#__PURE__*/jsx_runtime_.jsx(common_ToggleSwitch, {
        onChange: () => {
          setShow(!show);
        },
        checked: show
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx(Label/* default */.Z, {
      margin: "0 0 0.5rem 0",
      children: "Invite via link:"
    }), show && /*#__PURE__*/(0,jsx_runtime_.jsxs)(FormGroup, {
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(LinkContainer, {
        children: [/*#__PURE__*/jsx_runtime_.jsx(Link, {
          children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
            children: isDesktopLarge ? link : isDesktop ? (0,utils_text/* truncate */.$)(link, 35) : isTabletLarge ? (0,utils_text/* truncate */.$)(link, 30) : link
          })
        }), numberofDays && /*#__PURE__*/(0,jsx_runtime_.jsxs)(NumberOfDaysContainer, {
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(Text/* default */.ZP, {
            size: "tiny",
            children: ["Expires in ", numberofDays, " days "]
          }), /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.ZP, {
            small: true,
            width: "6rem",
            onClick: resetLink,
            children: "Reset"
          })]
        })]
      }), link && /*#__PURE__*/jsx_runtime_.jsx(ButtonContainer, {
        children: /*#__PURE__*/jsx_runtime_.jsx(CopyButton/* default */.Z, {
          borderColor: "transparent",
          loading: loading,
          code: link,
          padding: "0",
          width: "5rem",
          children: "Invite"
        })
      })]
    })]
  });
};

/* harmony default export */ const admin_InviteLinkForm = (InviteLinkForm);

/***/ }),

/***/ 13606:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _contexts_auth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(58368);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(11098);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(92107);
/* harmony import */ var _SettingsContainer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(89857);
/* harmony import */ var _InviteEmailForm__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(30728);
/* harmony import */ var _InviteLinkForm__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(25821);
/* harmony import */ var _TeamCount__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(76942);
/* harmony import */ var _TeamList__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(51191);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_InviteEmailForm__WEBPACK_IMPORTED_MODULE_5__, _TeamCount__WEBPACK_IMPORTED_MODULE_7__]);
([_InviteEmailForm__WEBPACK_IMPORTED_MODULE_5__, _TeamCount__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);













const ManageTeam = () => {
  const {
    0: organisationInvites,
    1: setOrganisationInvites
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
  const {
    user
  } = (0,_contexts_auth__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)();

  const getOrganisationInvites = async () => {
    try {
      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`/api/organisations/${user.organisation_id}/invites`);
      setOrganisationInvites(data);
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_3__/* .logError */ .H)(error, _constants__WEBPACK_IMPORTED_MODULE_10__/* .SETTINGS_CONTAINER_ID */ .f);
    }
  };

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(_SettingsContainer__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
    title: "Manage Team",
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_TeamCount__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_InviteLinkForm__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_InviteEmailForm__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
      getOrganisationInvites: getOrganisationInvites
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_TeamList__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
      organisationInvites: organisationInvites,
      getOrganisationInvites: getOrganisationInvites
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ManageTeam);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 76942:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61908);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(45641);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1187);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _button_Button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(59067);
/* harmony import */ var _common_ProgressBar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(45486);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(87491);
/* harmony import */ var _form_Input__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(18183);
/* harmony import */ var _form_Label__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(54251);
/* harmony import */ var _contexts_auth__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(58368);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(91073);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(11098);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(75609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(92107);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__, react_hook_form__WEBPACK_IMPORTED_MODULE_3__, _form_Input__WEBPACK_IMPORTED_MODULE_8__]);
([_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__, react_hook_form__WEBPACK_IMPORTED_MODULE_3__, _form_Input__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



















const schema = yup__WEBPACK_IMPORTED_MODULE_14__.object().shape({
  max_users_count: yup__WEBPACK_IMPORTED_MODULE_14__.number().required().min(1).positive()
});
const Container = styled_components__WEBPACK_IMPORTED_MODULE_13___default().div.withConfig({
  displayName: "TeamCount__Container",
  componentId: "zaeqm8-0"
})(["margin-bottom:2rem;display:flex;flex-direction:column;", ""], _theme__WEBPACK_IMPORTED_MODULE_11__/* .media.tabletLarge */ .BC.tabletLarge`
        flex-direction: row;

        & > *:not(:last-child) {
            margin-right: 1.25rem;
        }
    `);
const Form = styled_components__WEBPACK_IMPORTED_MODULE_13___default().form.withConfig({
  displayName: "TeamCount__Form",
  componentId: "zaeqm8-1"
})(["width:100%;display:flex;flex-direction:column;"]);
const FormGroup = styled_components__WEBPACK_IMPORTED_MODULE_13___default().div.withConfig({
  displayName: "TeamCount__FormGroup",
  componentId: "zaeqm8-2"
})(["display:flex;"]);
const ButtonContainer = styled_components__WEBPACK_IMPORTED_MODULE_13___default().div.withConfig({
  displayName: "TeamCount__ButtonContainer",
  componentId: "zaeqm8-3"
})(["margin-left:1rem;"]);
const InnerContainer = styled_components__WEBPACK_IMPORTED_MODULE_13___default().div.withConfig({
  displayName: "TeamCount__InnerContainer",
  componentId: "zaeqm8-4"
})(["width:12rem;min-width:12rem;height:9rem;border-radius:10px;background:", ";padding:2.5rem 1.25rem 1rem;display:flex;align-items:center;flex-direction:column;margin-bottom:1rem;", ""], p => p.theme.colors.white, _theme__WEBPACK_IMPORTED_MODULE_11__/* .media.tablet */ .BC.tablet`
    margin-bottom: initial;
  `);
const CountContainer = styled_components__WEBPACK_IMPORTED_MODULE_13___default().div.withConfig({
  displayName: "TeamCount__CountContainer",
  componentId: "zaeqm8-5"
})(["display:flex;align-items:baseline;& > *{line-height:1;&:first-child{margin-right:0.25rem;}}"]);
const ContentContainer = styled_components__WEBPACK_IMPORTED_MODULE_13___default().div.withConfig({
  displayName: "TeamCount__ContentContainer",
  componentId: "zaeqm8-6"
})([""]);
const Image = styled_components__WEBPACK_IMPORTED_MODULE_13___default().img.withConfig({
  displayName: "TeamCount__Image",
  componentId: "zaeqm8-7"
})(["width:2.5rem;align-self:center;"]);
const AnotherDiv = styled_components__WEBPACK_IMPORTED_MODULE_13___default().div.withConfig({
  displayName: "TeamCount__AnotherDiv",
  componentId: "zaeqm8-8"
})(["display:flex;"]);

const TeamCount = () => {
  const {
    user,
    organisation,
    setOrganisation
  } = (0,_contexts_auth__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)();
  const {
    0: loading,
    1: setLoading
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)();
  const methods = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_3__.useForm)({
    resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__.yupResolver)(schema),
    defaultValues: {
      max_users_count: organisation.max_users_count
    }
  });

  const onSubmit = async ({
    max_users_count
  }) => {
    setLoading(true);

    try {
      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_1___default().patch(`/api/organisations/${user.organisation_id}`, {
        max_users_count
      });
      setOrganisation(data);
      react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.success("Updated number of people in your team!", {
        containerId: _constants__WEBPACK_IMPORTED_MODULE_16__/* .SETTINGS_CONTAINER_ID */ .f
      });
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_12__/* .logError */ .H)(error, _constants__WEBPACK_IMPORTED_MODULE_16__/* .SETTINGS_CONTAINER_ID */ .f);
    }

    setLoading(false);
  };

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxs)(Container, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxs)(InnerContainer, {
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxs)(AnotherDiv, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(Image, {
          src: "/images/footprint.png"
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxs)(ContentContainer, {
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxs)(CountContainer, {
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
              size: "logo",
              color: "blue",
              children: organisation.users_count
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
              size: "tiny",
              color: "blue",
              children: `/${organisation.max_users_count} people`
            })]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
            size: "tiny",
            children: "joined the team"
          })]
        })]
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_common_ProgressBar__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
        value: organisation.users_count,
        max: organisation.max_users_count
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_3__.FormProvider, _objectSpread(_objectSpread({}, methods), {}, {
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxs)(Form, {
        onSubmit: methods.handleSubmit(onSubmit),
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_form_Label__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
          children: "No. of people in your organisation:"
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxs)(FormGroup, {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_form_Input__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
            name: "max_users_count",
            isRequired: true,
            type: "number",
            width: "100%"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(ButtonContainer, {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP, {
              width: "5rem",
              minWidth: "5rem",
              loading: loading,
              children: "Update"
            })
          })]
        })]
      })
    }))]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TeamCount);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 51191:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ admin_TeamList)
});

// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(52167);
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
// EXTERNAL MODULE: ./src/components/common/Spinner.jsx
var Spinner = __webpack_require__(16114);
// EXTERNAL MODULE: ./src/components/common/Text.jsx
var Text = __webpack_require__(87491);
// EXTERNAL MODULE: ./src/contexts/auth.js
var auth = __webpack_require__(58368);
// EXTERNAL MODULE: ./src/theme.js
var theme = __webpack_require__(91073);
// EXTERNAL MODULE: ./src/utils/logger.js + 1 modules
var logger = __webpack_require__(11098);
// EXTERNAL MODULE: ./src/utils/text.js
var utils_text = __webpack_require__(88703);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(57518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: ./src/components/settings/constants.js
var constants = __webpack_require__(92107);
// EXTERNAL MODULE: external "react-responsive"
var external_react_responsive_ = __webpack_require__(16666);
// EXTERNAL MODULE: ./src/components/common/ConfirmationModal.jsx
var ConfirmationModal = __webpack_require__(65487);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
;// CONCATENATED MODULE: ./src/components/settings/admin/ConfirmUserDelete.jsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






var Bin = function Bin(props) {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("g", {
      clipPath: "url(#clip0)",
      fill: "#EC5F59",
      children: [/*#__PURE__*/jsx_runtime_.jsx("path", {
        d: "M11.768 25c-2.014 0-4.028.003-6.041 0-.49 0-.98-.006-1.467-.049-.847-.073-1.573-.835-1.622-1.719-.126-2.313-.235-4.626-.343-6.94-.16-3.384-.314-6.769-.463-10.154-.017-.38-.173-.516-.522-.489a2.16 2.16 0 0 1-.282 0C.413 5.621-.013 5.213 0 4.667c.013-.561.496-.976 1.115-.971 1.712.012 3.424.021 5.136.027 1.275 0 1.274-.005 1.486-1.298.052-.322.092-.647.176-.96.11-.42.355-.792.696-1.057.341-.264.758-.406 1.187-.403 1.335.007 2.67.026 4.007.04 1.085.01 1.81.64 1.988 1.726.083.51.174 1.019.241 1.53.04.312.18.393.49.393 2.031-.004 4.063.013 6.093.033.615.007.99.375 1 .933.008.583-.375.958-1.01.989-.786.037-.772.041-.81.872-.215 4.512-.434 9.024-.657 13.536-.048 1.032-.083 2.067-.136 3.099-.052 1.007-.8 1.796-1.778 1.804-2.484.02-4.969.007-7.453.007l-.004.033zm.063-1.96c2.163 0 4.326-.022 6.49.016.574.01.772-.193.788-.737.025-.841.087-1.682.125-2.523.202-4.474.401-8.95.598-13.424.033-.73.03-.73-.727-.724-2.389.017-4.776.046-7.164.046-2.538 0-5.077-.018-7.615-.054-.452-.006-.567.127-.545.592.22 4.512.405 9.026.628 13.538.04.823.067 1.645.105 2.467.037.769.084.804.827.804h6.49zm.093-19.338v.008c.377 0 .754.022 1.13-.004 1.061-.074 1.043-.08.887-1.179-.063-.435-.252-.576-.67-.566-.976.023-1.954.005-2.932.008-.22 0-.508-.052-.563.246-.086.46-.273.922-.13 1.4.034.113.194.09.307.089.657-.004 1.314-.003 1.971-.003v.001z"
      }), /*#__PURE__*/jsx_runtime_.jsx("path", {
        d: "M8.69 18.497c0 .268.003.536 0 .803-.012.631-.339 1.023-.878 1.059-.553.037-.954-.295-1.014-.916a63.554 63.554 0 0 1-.186-2.86 598.873 598.873 0 0 1-.258-6.133c-.028-.742.278-1.15.84-1.2.6-.055.983.3 1.062 1.056.08.756.118 1.523.154 2.289.093 1.967.174 3.935.26 5.902h.02zM17.265 11.124c-.12 2.598-.242 5.195-.363 7.792-.013.19-.037.38-.072.569-.096.577-.47.9-1 .873-.537-.027-.898-.42-.883-1.046.032-1.357.085-2.715.145-4.07.06-1.337.135-2.673.21-4.008.021-.382.04-.765.096-1.142.087-.57.489-.884 1.022-.844.495.04.835.412.857.959.011.305 0 .612 0 .918h-.012zM10.868 14.807c0-1.51-.01-3.019.005-4.528.007-.665.379-1.043.95-1.034.571.009.932.396.935 1.057.01 2.062.004 4.125.008 6.188 0 .898.005 1.796.02 2.693.013.697-.357 1.165-.95 1.175-.604.012-.97-.419-.97-1.137v-4.414h.002z"
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx("defs", {
      children: /*#__PURE__*/jsx_runtime_.jsx("clipPath", {
        id: "clip0",
        children: /*#__PURE__*/jsx_runtime_.jsx("path", {
          fill: "#fff",
          d: "M0 0h23.611v25H0z"
        })
      })
    })]
  }));
};

Bin.defaultProps = {
  width: "24",
  height: "25",
  viewBox: "0 0 24 25",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};




const TitleContainer = external_styled_components_default().div.withConfig({
  displayName: "ConfirmUserDelete__TitleContainer",
  componentId: "sc-1l5ylxc-0"
})(["display:flex;flex-direction:column;align-items:center;justify-content:center;"]);
const BodyContainer = external_styled_components_default()(TitleContainer).withConfig({
  displayName: "ConfirmUserDelete__BodyContainer",
  componentId: "sc-1l5ylxc-1"
})(["padding:0 10%;", ""], theme/* media.tablet */.BC.tablet`
  padding: 0 25%;
`);

const ConfirmUserDelete = ({
  user,
  showConfirmationModal,
  setShowConfirmationModal,
  onConfirm
}) => {
  const tablet = (0,external_react_responsive_.useMediaQuery)({
    query: `(min-width: ${theme/* sizes.tablet */.J7.tablet}px)`
  });
  return /*#__PURE__*/jsx_runtime_.jsx(ConfirmationModal/* default */.Z, {
    open: showConfirmationModal,
    onClose: () => setShowConfirmationModal(!showConfirmationModal),
    onConfirm: () => onConfirm(user),
    cancelText: tablet ? "No, keep member" : "Keep Member",
    confirmText: tablet ? "Remove memeber" : "Remove",
    title: /*#__PURE__*/(0,jsx_runtime_.jsxs)(TitleContainer, {
      children: [/*#__PURE__*/jsx_runtime_.jsx(Bin, {}), /*#__PURE__*/(0,jsx_runtime_.jsxs)(Text/* default */.ZP, {
        size: "modalTitle",
        color: "error",
        children: ["Remove ", user === null || user === void 0 ? void 0 : user.first_name, " ", user === null || user === void 0 ? void 0 : user.last_name, "?", " "]
      })]
    }),
    body: /*#__PURE__*/jsx_runtime_.jsx(BodyContainer, {
      children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
        children: "You\u2019ve chosen to remove this user from your team. Doing this will permanently delete the user\u2019s account. You can reinvite again, if you want."
      })
    }),
    warning: true
  });
};

/* harmony default export */ const admin_ConfirmUserDelete = (ConfirmUserDelete);
// EXTERNAL MODULE: external "date-fns"
var external_date_fns_ = __webpack_require__(74146);
// EXTERNAL MODULE: external "react-toastify"
var external_react_toastify_ = __webpack_require__(1187);
;// CONCATENATED MODULE: ./src/components/settings/admin/InviteItem.jsx














const Float = external_styled_components_default().div.withConfig({
  displayName: "InviteItem__Float",
  componentId: "sc-441s2r-0"
})(["position:absolute;z-index:1;right:0;margin-right:0.5rem;", ""], theme/* media.tablet */.BC.tablet`
    margin-right: initial;
  `);
const TextConatiner = external_styled_components_default().div.withConfig({
  displayName: "InviteItem__TextConatiner",
  componentId: "sc-441s2r-1"
})(["display:flex;flex-direction:column;justify-content:center;height:100%;margin:auto 0;", ""], theme/* media.tablet */.BC.tablet`
    margin: auto 0;
    margin-bottom: unset;
    width: 100%;
  `);
const InviteItemContainer = external_styled_components_default().div.withConfig({
  displayName: "InviteItem__InviteItemContainer",
  componentId: "sc-441s2r-2"
})(["display:flex;width:100%;align-items:center;flex-wrap:", ";", ""], p => p.wrap || "nowrap", theme/* media.tablet */.BC.tablet`
  flex-wrap:unset;
    width: 100%;
  `);
const AvatarContainer = external_styled_components_default().div.withConfig({
  displayName: "InviteItem__AvatarContainer",
  componentId: "sc-441s2r-3"
})(["min-width:", ";width:", ";height:", ";display:flex;align-items:center;justify-content:center;border-radius:50%;margin-right:1.5rem;background-color:", ";", ""], p => p.size || "2rem", p => p.size || "2rem", p => p.size || "2rem", p => p.theme.colors.placeholderGrey, theme/* media.tablet */.BC.tablet`
  min-width: 3rem;
  width: 3rem;
  height: 3rem;
  `);
const ActionContainer = external_styled_components_default().div.withConfig({
  displayName: "InviteItem__ActionContainer",
  componentId: "sc-441s2r-4"
})(["margin:auto 0 auto auto;width:", ";", ";"], p => p.actionWidth || "initial", theme/* media.tablet */.BC.tablet`
  justify-self: flex-end;
  `);
const Item = external_styled_components_default().button.withConfig({
  displayName: "InviteItem__Item",
  componentId: "sc-441s2r-5"
})(["border:none;height:1.5rem;outline:none;width:fit-content;padding:0 0.5rem;border-radius:10px;display:flex;justify-content:center;align-items:center;background-color:", ";", " ", ""], p => p.theme.colors.white, p => p.border && `border: 1px solid ${p => p.theme.colors.placeholderGrey};`, p => p.shadow && `box-shadow: 
      0 5px 12px 0 ${p.theme.colors[p.color]}66;`);
const List = external_styled_components_default().ul.withConfig({
  displayName: "InviteItem__List",
  componentId: "sc-441s2r-6"
})(["list-style-type:none;padding:0;display:flex;flex-direction:column;align-items:flex-end;justify-content:flex-end;& > li:not(:last-child){margin-bottom:0.5rem;}"]);
const InviteActionsContainer = external_styled_components_default().div.withConfig({
  displayName: "InviteItem__InviteActionsContainer",
  componentId: "sc-441s2r-7"
})(["position:relative;"]);

function useOutsideAlerter(ref, action) {
  (0,external_react_.useEffect)(() => {
    /**
     * Alert if clicked on outside of element
     */
    function handleClickOutside(event) {
      if (ref.current && !ref.current.contains(event.target)) {
        action(event);
      }
    } // Bind the event listener


    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      // Unbind the event listener on clean up
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [ref]);
}

const InviteActions = ({
  invite,
  handleRenewInvite,
  handleDeleteClick,
  loading,
  open,
  setOpen
}) => {
  const {
    0: showConfirmationModal,
    1: setShowConfirmationModal
  } = (0,external_react_.useState)(false);
  const containerRef = (0,external_react_.useRef)(null);

  const handleClickOutside = event => {
    if (containerRef.current && !containerRef.current.contains(event.target)) {
      setOpen(false);
    }
  };

  useOutsideAlerter(containerRef, handleClickOutside);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(InviteActionsContainer, {
    ref: containerRef,
    children: [/*#__PURE__*/jsx_runtime_.jsx(admin_ConfirmUserDelete, {
      showConfirmationModal,
      setShowConfirmationModal,
      onConfirm: handleDeleteClick,
      user: invite
    }), /*#__PURE__*/jsx_runtime_.jsx(Item, {
      onClick: () => setOpen(!open),
      border: true,
      children: loading ? /*#__PURE__*/jsx_runtime_.jsx(Spinner/* default */.Z, {
        color: "placeholderGrey",
        width: "1rem",
        margin: "0 1.15rem"
      }) : /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
        color: "placeholderGrey",
        size: "tiny",
        children: (0,external_date_fns_.isBefore)(Date.now(), new Date(invite.expires_at)) ? "Pending" : "Expired"
      })
    }), open && /*#__PURE__*/jsx_runtime_.jsx(Float, {
      children: /*#__PURE__*/jsx_runtime_.jsx(List, {
        children: (0,external_date_fns_.isBefore)(Date.now(), new Date(invite.expires_at)) ? /*#__PURE__*/jsx_runtime_.jsx("li", {
          children: /*#__PURE__*/jsx_runtime_.jsx(Item, {
            onClick: () => handleDeleteClick(invite),
            shadow: true,
            color: "red",
            children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
              color: "red",
              size: "tiny",
              children: (0,utils_text/* capitalize */.k)("remove")
            })
          })
        }) : /*#__PURE__*/jsx_runtime_.jsx("li", {
          children: /*#__PURE__*/jsx_runtime_.jsx(Item, {
            onClick: () => handleRenewInvite(invite),
            shadow: true,
            color: "blue",
            children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
              color: "blue",
              size: "tiny",
              children: "Renew"
            })
          })
        })
      })
    })]
  });
};

const InviteItem = ({
  invite,
  size,
  wrap,
  actionMargin,
  actionWidth,
  getOrganisationInvites
}) => {
  const {
    0: open,
    1: setOpen
  } = (0,external_react_.useState)(false);
  const {
    0: loading,
    1: setLoading
  } = (0,external_react_.useState)(false);
  const {
    user
  } = (0,auth/* default */.Z)();

  const handleRenewInvite = async updatedInvite => {
    setLoading(true);

    try {
      const {
        data
      } = await external_axios_default().patch(`/api/organisations/${user.organisation_id}/invites/${updatedInvite.id}`, {
        is_admin: !updatedInvite.is_admin
      });
      (0,external_react_toastify_.toast)(` 🌟 Resent invite to ${updatedInvite.email}`);
      getOrganisationInvites();
      setOpen(false);
    } catch (error) {
      (0,logger/* logError */.H)(error);
    }

    setLoading(false);
  };

  const handleDeleteClick = async deletedInvite => {
    setLoading(true);

    try {
      const {
        data
      } = await external_axios_default()["delete"](`/api/organisations/${user.organisation_id}/invites/${deletedInvite.id}`);
      (0,external_react_toastify_.toast)(`🗑️ Deleted invite for ${deletedInvite.email}`);
      getOrganisationInvites();
      setOpen(false);
    } catch (error) {
      (0,logger/* logError */.H)(error);
    }

    setLoading(false);
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(InviteItemContainer, {
    wrap: wrap,
    children: [/*#__PURE__*/jsx_runtime_.jsx(AvatarContainer, {
      size: size
    }), /*#__PURE__*/jsx_runtime_.jsx(TextConatiner, {
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
          size: "small",
          children: invite.email
        })
      })
    }), /*#__PURE__*/jsx_runtime_.jsx(ActionContainer, {
      actionMargin: actionMargin,
      actionWidth: actionWidth,
      children: /*#__PURE__*/jsx_runtime_.jsx(InviteActions, {
        handleRenewInvite,
        handleDeleteClick,
        invite,
        loading,
        open,
        setOpen
      })
    })]
  });
};

/* harmony default export */ const admin_InviteItem = (InviteItem);
// EXTERNAL MODULE: ./src/components/settings/admin/UserItem.jsx
var UserItem = __webpack_require__(32083);
;// CONCATENATED MODULE: ./src/components/settings/admin/TeamList.jsx















const TeamList_Float = external_styled_components_default().div.withConfig({
  displayName: "TeamList__Float",
  componentId: "sc-1be9alo-0"
})(["position:absolute;z-index:1;right:0;margin-right:0.5rem;", ""], theme/* media.tablet */.BC.tablet`
    margin-right: initial;
  `);
const Container = external_styled_components_default().div.withConfig({
  displayName: "TeamList__Container",
  componentId: "sc-1be9alo-1"
})(["position:relative;"]);
const TeamListContainer = external_styled_components_default().div.withConfig({
  displayName: "TeamList__TeamListContainer",
  componentId: "sc-1be9alo-2"
})(["padding-top:2rem;border-top:1px solid ", ";margin-bottom:4rem;& > *{margin:0.25rem 0;}"], p => p.theme.colors.secondaryBlue);
const TeamList_Item = external_styled_components_default().button.withConfig({
  displayName: "TeamList__Item",
  componentId: "sc-1be9alo-3"
})(["border:none;height:1.5rem;outline:none;width:fit-content;padding:0 0.5rem;border-radius:10px;display:flex;cursor:", ";justify-content:center;align-items:center;background-color:", ";", ""], p => p.userType !== "owner" ? "pointer" : "default", p => p.userType === "owner" ? p.theme.colors.progressYellow : p.userType === "admin" ? p.theme.colors.secondaryBlue : p.theme.colors.white, p => p.shadow && `box-shadow: 
      0 5px 12px 0 ${p.userType === "owner" ? p.theme.colors.progressYellow : !p.userType ? p.theme.colors.red : p.theme.colors.secondaryBlue}66;`);
const TeamList_List = external_styled_components_default().ul.withConfig({
  displayName: "TeamList__List",
  componentId: "sc-1be9alo-4"
})(["list-style-type:none;padding:0;display:flex;flex-direction:column;align-items:flex-end;justify-content:flex-end;& > li:not(:last-child){margin-bottom:0.5rem;}"]);

function TeamList_useOutsideAlerter(ref, action) {
  (0,external_react_.useEffect)(() => {
    /**
     * Alert if clicked on outside of element
     */
    function handleClickOutside(event) {
      if (ref.current && !ref.current.contains(event.target)) {
        action(event);
      }
    } // Bind the event listener


    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      // Unbind the event listener on clean up
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [ref]);
}

const UserActions = ({
  user,
  selectedUser,
  organisation,
  handleToggleAdminClick,
  handleDeleteClick,
  handleOwnerClick
}) => {
  const {
    0: loading,
    1: setLoading
  } = (0,external_react_.useState)(false);
  const {
    0: open,
    1: setOpen
  } = (0,external_react_.useState)(false);
  const {
    0: showConfirmationModal,
    1: setShowConfirmationModal
  } = (0,external_react_.useState)(false);
  const containerRef = (0,external_react_.useRef)(null);
  const userType = selectedUser.id === organisation.owner_id ? "owner" : selectedUser.is_admin ? "admin" : "member";

  const handleClickOutside = event => {
    if (containerRef.current && !containerRef.current.contains(event.target)) {
      setOpen(false);
    }
  };

  TeamList_useOutsideAlerter(containerRef, handleClickOutside);
  const userTypes = ["owner", "admin", "member"];

  const switchOnClick = (type, selectedUser) => {
    switch (type) {
      case "owner":
        return async () => {
          setLoading(true);
          await handleOwnerClick(selectedUser);
          setOpen(false);
          setLoading(false);
        };

      case "member":
      case "admin":
        return async () => {
          setLoading(true);
          await handleToggleAdminClick(selectedUser);
          setOpen(false);
          setLoading(false);
        };

      case "remove":
        return async () => {
          setLoading(true);
          setShowConfirmationModal(!showConfirmationModal);
          setOpen(false);
          setLoading(false);
        };

      default:
        break;
    }
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(Container, {
    ref: containerRef,
    children: [/*#__PURE__*/jsx_runtime_.jsx(admin_ConfirmUserDelete, {
      showConfirmationModal,
      setShowConfirmationModal,
      onConfirm: handleDeleteClick,
      user: selectedUser
    }), /*#__PURE__*/jsx_runtime_.jsx(TeamList_Item, {
      userType: userType,
      onClick: () => setOpen(!open),
      children: loading ? /*#__PURE__*/jsx_runtime_.jsx(Spinner/* default */.Z, {
        color: "blue",
        width: "1rem",
        margin: "0 1.15rem"
      }) : /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
        color: userType === "owner" ? "white" : "blue",
        size: "tiny",
        children: (0,utils_text/* capitalize */.k)(userType)
      })
    }), open && /*#__PURE__*/jsx_runtime_.jsx(TeamList_Float, {
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(TeamList_List, {
        children: [userTypes.map(type => userType === "owner" ? null : type === "owner" && user.id !== organisation.owner_id ? null : userType !== type ? /*#__PURE__*/jsx_runtime_.jsx("li", {
          children: /*#__PURE__*/jsx_runtime_.jsx(TeamList_Item, {
            userType: type,
            onClick: switchOnClick(type, selectedUser),
            shadow: true,
            children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
              color: type === "owner" ? "white" : "blue",
              size: "tiny",
              children: (0,utils_text/* capitalize */.k)(type)
            })
          })
        }, type) : null), userType !== "owner" && /*#__PURE__*/jsx_runtime_.jsx(TeamList_Item, {
          onClick: switchOnClick("remove", selectedUser),
          shadow: true,
          children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
            color: "red",
            size: "tiny",
            children: (0,utils_text/* capitalize */.k)("remove")
          })
        })]
      })
    })]
  });
};

const TeamList = ({
  organisationInvites,
  getOrganisationInvites
}) => {
  const {
    0: organisationUsers,
    1: setOrganisationUsers
  } = (0,external_react_.useState)([]);
  const {
    user,
    organisation,
    setOrganisation
  } = (0,auth/* default */.Z)();
  const {
    0: loading,
    1: setLoading
  } = (0,external_react_.useState)(false);

  const getOrganisationUsers = async () => {
    const {
      data
    } = await external_axios_default().get(`/api/organisations/${user.organisation_id}`);
    setOrganisationUsers(data.users);
  };

  const handleToggleAdminClick = async updatedUser => {
    setLoading(true);

    try {
      if (user.id === updatedUser.id) {
        throw Error("You can not remove your own admin permissions");
      }

      const {
        data
      } = await external_axios_default().patch(`/api/organisations/${user.organisation_id}/users/${updatedUser.id}`, {
        is_admin: !updatedUser.is_admin
      });
      getOrganisationUsers();
    } catch (error) {
      (0,logger/* logError */.H)(error, constants/* SETTINGS_CONTAINER_ID */.f);
    }

    setLoading(false);
  };

  const handleOwnerClick = async updatedUser => {
    setLoading(true);

    try {
      const {
        data
      } = await external_axios_default().patch(`/api/organisations/${user.organisation_id}`, {
        owner_id: updatedUser.id
      });
      setOrganisation(data);
    } catch (error) {
      (0,logger/* logError */.H)(error);
    }

    setLoading(false);
  };

  const handleDeleteClick = async deleteUser => {
    setLoading(true);

    try {
      if (user.id === deleteUser.id) {
        throw Error("You can not delete yourself");
      }

      const {
        data
      } = await external_axios_default()["delete"](`/api/organisations/${user.organisation_id}/users/${deleteUser.id}`);
      getOrganisationUsers();
    } catch (error) {
      (0,logger/* logError */.H)(error);
    }

    setLoading(false);
  };

  (0,external_react_.useEffect)(() => {
    getOrganisationUsers();
    getOrganisationInvites();
  }, []);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(TeamListContainer, {
    children: [organisationUsers.length > 0 && organisationUsers.sort((a, b) => a.id === organisation.owner_id && b.id !== organisation.owner_id ? -1 : b.id === organisation.owner_id && a.id !== organisation.owner_id ? 1 : a.is_admin && !b.is_admin ? -1 : b.is_admin && !a.is_admin ? 1 : (a === null || a === void 0 ? void 0 : a.email) < (b === null || b === void 0 ? void 0 : b.email) ? -1 : 1).map(selectedUser => /*#__PURE__*/jsx_runtime_.jsx(UserItem/* default */.Z, {
      user: selectedUser,
      actionMargin: "auto 0 auto auto",
      action: /*#__PURE__*/jsx_runtime_.jsx(UserActions, {
        user: user,
        selectedUser: selectedUser,
        organisation: organisation,
        handleToggleAdminClick: handleToggleAdminClick,
        handleDeleteClick: handleDeleteClick,
        handleOwnerClick: handleOwnerClick
      })
    }, selectedUser.id)), organisationInvites.map(invite => /*#__PURE__*/jsx_runtime_.jsx(admin_InviteItem, {
      invite: invite,
      getOrganisationInvites: getOrganisationInvites
    }))]
  });
};

/* harmony default export */ const admin_TeamList = (TeamList);

/***/ }),

/***/ 7621:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16666);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_responsive__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_common_Page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97598);
/* harmony import */ var _components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(60805);
/* harmony import */ var _components_ContentContainer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(16067);
/* harmony import */ var _components_settings_admin__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(75467);
/* harmony import */ var _components_settings_admin_ManageTeam__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(13606);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(91073);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_3__, _components_settings_admin_ManageTeam__WEBPACK_IMPORTED_MODULE_6__]);
([_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_3__, _components_settings_admin_ManageTeam__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }










var AdminSettingsIcon = function AdminSettingsIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("path", {
      d: "M24.978 12.572c-.013.328.022.734-.018 1.139-.081.812-.622 1.396-1.43 1.535-.46.08-.923.157-1.385.229-.145.023-.228.082-.277.23a6.956 6.956 0 0 1-.476 1.14c-.076.139-.07.245.026.373.28.376.547.761.82 1.142.503.7.447 1.575-.154 2.192a81.343 81.343 0 0 1-1.537 1.538c-.62.6-1.492.657-2.193.154-.39-.281-.784-.558-1.172-.842a.239.239 0 0 0-.288-.024 7.937 7.937 0 0 1-1.193.495c-.15.05-.207.128-.23.272-.069.445-.144.887-.222 1.33-.164.928-.742 1.465-1.688 1.5-.767.028-1.537.042-2.304-.014a1.652 1.652 0 0 1-1.5-1.373c-.081-.48-.16-.961-.235-1.442a.3.3 0 0 0-.233-.274 7.312 7.312 0 0 1-1.14-.475.223.223 0 0 0-.271.021c-.409.3-.821.594-1.237.88-.71.492-1.555.42-2.173-.187-.51-.5-1.015-1.003-1.515-1.512-.61-.618-.671-1.5-.162-2.206.273-.38.543-.764.822-1.14.08-.108.1-.194.031-.319a7.112 7.112 0 0 1-.502-1.185.26.26 0 0 0-.233-.203c-.45-.068-.9-.15-1.35-.226-.955-.158-1.5-.74-1.537-1.715a21.514 21.514 0 0 1 .014-2.285 1.64 1.64 0 0 1 1.322-1.486c.496-.095.995-.179 1.495-.256.14-.022.204-.088.244-.214.132-.41.294-.81.487-1.197a.265.265 0 0 0-.028-.309c-.287-.394-.57-.79-.85-1.19-.516-.743-.437-1.589.205-2.23l1.46-1.457c.634-.629 1.487-.705 2.218-.192.389.273.774.551 1.155.834.108.08.2.096.322.03.381-.2.78-.368 1.19-.5a.258.258 0 0 0 .2-.234c.063-.433.15-.862.216-1.293C9.827.644 10.364.101 11.34.04c.767-.05 1.537-.048 2.303.007.835.065 1.407.614 1.55 1.434.08.461.16.922.231 1.385.02.126.072.2.197.24.44.141.869.318 1.281.527a.247.247 0 0 0 .29-.027c.4-.29.803-.574 1.206-.86a1.647 1.647 0 0 1 2.13.153 79.24 79.24 0 0 1 1.591 1.59c.568.583.621 1.463.144 2.134-.286.4-.57.805-.862 1.203a.242.242 0 0 0-.022.289c.196.37.357.758.48 1.158.05.172.146.236.312.261.432.065.862.142 1.293.219.975.173 1.493.781 1.51 1.771.007.32.003.645.003 1.049zm-7.9 6.894a.887.887 0 0 1 .544.178c.529.378 1.06.75 1.587 1.131.1.072.177.1.276 0 .416-.423.835-.842 1.257-1.26.11-.109.11-.192.018-.318-.38-.52-.75-1.05-1.118-1.573-.23-.325-.237-.656-.036-1a7.886 7.886 0 0 0 .832-2c.105-.407.363-.64.78-.707.622-.1 1.243-.21 1.865-.308.15-.024.211-.077.209-.239a57.87 57.87 0 0 1 0-1.743c0-.14-.044-.2-.184-.22-.623-.1-1.243-.216-1.866-.313-.425-.066-.688-.293-.797-.708a7.545 7.545 0 0 0-.813-1.968c-.235-.393-.206-.75.064-1.112.369-.497.716-1.009 1.082-1.507.096-.129.082-.203-.03-.312a54.582 54.582 0 0 1-1.232-1.232c-.104-.106-.175-.116-.296-.027-.523.386-1.05.763-1.581 1.14-.31.221-.637.243-.968.05a8.374 8.374 0 0 0-2.11-.869c-.4-.104-.624-.365-.689-.773-.1-.616-.206-1.231-.304-1.85-.024-.153-.079-.221-.25-.217a40.65 40.65 0 0 1-1.687 0c-.18-.004-.25.05-.28.228-.093.611-.208 1.218-.303 1.829-.067.429-.292.704-.716.815-.69.18-1.35.458-1.963.825-.392.236-.75.2-1.112-.067-.5-.372-1.018-.725-1.523-1.093-.104-.077-.164-.065-.25.023-.42.43-.845.854-1.273 1.274-.104.1-.098.175-.017.286.374.515.737 1.04 1.112 1.555.253.347.276.692.056 1.064a7.607 7.607 0 0 0-.808 1.99c-.1.391-.342.627-.744.695-.633.108-1.267.221-1.9.32-.15.024-.2.085-.196.231a95 95 0 0 1 0 1.743c0 .15.05.207.2.23.653.105 1.305.22 1.957.333.355.061.595.27.69.61.204.742.503 1.454.889 2.119.195.336.165.666-.064.983-.374.516-.738 1.039-1.114 1.554-.086.119-.087.197.021.3.42.41.837.825 1.245 1.246.108.112.179.103.295.018.5-.365 1.011-.712 1.507-1.082.375-.279.74-.306 1.15-.071a7.615 7.615 0 0 0 1.904.774c.4.104.631.356.7.765.1.61.208 1.218.3 1.83.028.186.088.263.293.257a28.907 28.907 0 0 1 1.65 0c.197.005.256-.07.284-.246.09-.587.21-1.169.29-1.756.065-.486.325-.753.792-.873a7.36 7.36 0 0 0 1.945-.819.837.837 0 0 1 .428-.133h.002z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("path", {
      d: "M12.497 7.025c3.006 0 5.477 2.474 5.477 5.48 0 3.006-2.48 5.477-5.485 5.473-3.005-.004-5.487-2.488-5.465-5.491a5.487 5.487 0 0 1 5.473-5.462zm.005 1.7a3.789 3.789 0 0 0-3.782 3.779c0 2.068 1.705 3.772 3.773 3.773 2.067.002 3.776-1.697 3.779-3.764a3.78 3.78 0 0 0-3.77-3.787v-.001z"
    })]
  }));
};

AdminSettingsIcon.defaultProps = {
  width: "25",
  height: "25",
  viewBox: "0 0 25 25",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var ManageTeamIcon = function ManageTeamIcon(props) {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("path", {
      d: "M0 23.924a.327.327 0 0 0 .037-.126c.101-.743.417-1.44.91-2.005a3.916 3.916 0 0 1 2.406-1.342 4.19 4.19 0 0 1 .536-.046 56.185 56.185 0 0 1 3.145-.02c.352.006.704.007 1.055.041.454.044.895.18 1.295.4.955.521 1.613 1.298 1.962 2.331.093.29.15.59.17.894.015.12.016.242.003.362-.04.296-.193.492-.486.571a.498.498 0 0 0-.051.018H.574l-.125-.04a.579.579 0 0 1-.4-.39.212.212 0 0 0-.046-.098L0 23.924zm5.768-.244H10.046c.06-.005.066-.016.054-.078a2.618 2.618 0 0 0-1.43-1.651c-.376-.177-.775-.24-1.186-.241-1.082-.003-2.163 0-3.245-.003a4.075 4.075 0 0 0-.604.028c-1.072.16-1.793.759-2.17 1.774-.063.171-.058.173.123.173l4.18-.002zM14.635 25c-.021-.008-.04-.017-.062-.023-.324-.087-.478-.318-.492-.648-.012-.367.04-.734.151-1.084.338-1.108 1.032-1.92 2.063-2.44.46-.232.964-.365 1.479-.39 1.037-.056 2.074-.046 3.111-.036.41.004.82.018 1.231.043.378.027.747.12 1.092.277.452.197.862.479 1.21.829.591.596.985 1.298 1.13 2.132.01.066 0 .133.026.196v.682a.626.626 0 0 1-.477.449.159.159 0 0 0-.03.013H14.635zm5.217-1.32h4.212c.134 0 .138 0 .097-.127a2.58 2.58 0 0 0-.886-1.284c-.504-.393-1.08-.563-1.71-.563h-3.432a2.842 2.842 0 0 0-.601.05c-.982.216-1.643.8-1.989 1.742-.064.177-.06.18.13.18l4.18.002zM13.072 0c.108.019.216.036.324.057A3.195 3.195 0 0 1 15.9 2.495c.221 1.025 0 1.955-.665 2.764-.55.67-1.274 1.043-2.14 1.131a3.196 3.196 0 0 1-3.347-2.132c-.376-1.1-.2-2.132.523-3.048.544-.691 1.268-1.085 2.144-1.193a.441.441 0 0 0 .064-.016h.593zm-2.176 3.2c-.013 1.009.83 1.904 1.853 1.904 1.054 0 1.923-.86 1.926-1.902 0-1.033-.848-1.871-1.89-1.876-1.086-.006-1.9.84-1.89 1.874zM12.812 11.467H7.917a1.64 1.64 0 0 1-.382-.04.61.61 0 0 1-.497-.583 2.71 2.71 0 0 1 .029-.624 3.96 3.96 0 0 1 3.471-3.34c.223-.024.446-.029.67-.037a49.693 49.693 0 0 1 2.507-.02c.44.008.88.018 1.318.046.54.037 1.064.204 1.526.488a4.058 4.058 0 0 1 1.788 2.17c.098.28.16.572.187.868.014.116.021.234.022.35a.948.948 0 0 1-.027.208.61.61 0 0 1-.496.486 1.593 1.593 0 0 1-.338.03c-1.628-.002-3.255-.003-4.883-.002zm-.027-1.33h4.279c.067-.005.078-.019.065-.081-.006-.025-.015-.05-.023-.074a2.618 2.618 0 0 0-2.404-1.814c-.337-.01-.674-.014-1.011-.017-.92-.007-1.84-.002-2.76.015-.183 0-.366.022-.545.065-.95.242-1.583.838-1.906 1.762-.05.143-.046.144.104.144h4.201zM5.743 13.55a3.19 3.19 0 0 1 3.21 3.2 3.21 3.21 0 1 1-6.416-.004c.001-1.865 1.557-3.215 3.206-3.196zm-1.87 3.196c-.03.922.733 1.9 1.847 1.906 1.054.005 1.928-.84 1.925-1.9 0-1.154-.962-1.88-1.898-1.88-1.062.004-1.895.84-1.875 1.874zM19.827 13.55c1.736-.017 3.2 1.425 3.2 3.197 0 1.732-1.372 3.212-3.196 3.209a3.208 3.208 0 0 1-3.22-3.21c0-1.805 1.514-3.216 3.216-3.196zm.005 1.327a1.843 1.843 0 0 0-1.89 1.859c-.009 1.03.828 1.918 1.854 1.916a1.926 1.926 0 0 0 1.926-1.9 1.89 1.89 0 0 0-1.89-1.875zM13.516 14.076c0 .33.004.66 0 .99a.428.428 0 0 0 .137.333 765.29 765.29 0 0 1 1.89 1.889c.154.154.26.332.242.557-.05.625-.682.867-1.095.606a1.292 1.292 0 0 1-.22-.18l-1.546-1.552c-.123-.123-.124-.126-.247.004-.478.504-.98.99-1.472 1.483-.059.06-.122.117-.188.169-.184.14-.39.215-.627.163a.774.774 0 0 1-.587-.677.63.63 0 0 1 .1-.376c.076-.121.167-.232.27-.332a540.29 540.29 0 0 1 1.642-1.64c.025-.027.053-.05.08-.075a.46.46 0 0 0 .167-.379c-.005-.15-.004-.3-.004-.45v-1.452a1.025 1.025 0 0 1 .057-.357.727.727 0 0 1 .639-.463.709.709 0 0 1 .762.727c0 .169 0 .337.002.504v.505l-.002.003z"
    })
  }));
};

ManageTeamIcon.defaultProps = {
  width: "26",
  height: "25",
  viewBox: "0 0 26 25",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};




function ManageTeamSetting() {
  const {
    0: showMenu,
    1: setShowMenu
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const isTablet = (0,react_responsive__WEBPACK_IMPORTED_MODULE_1__.useMediaQuery)({
    query: `(min-width: ${_theme__WEBPACK_IMPORTED_MODULE_8__/* .sizes.tablet */ .J7.tablet}px)`
  });
  const isTabletLarge = (0,react_responsive__WEBPACK_IMPORTED_MODULE_1__.useMediaQuery)({
    query: `(min-width: ${_theme__WEBPACK_IMPORTED_MODULE_8__/* .sizes.tabletLarge */ .J7.tabletLarge}px)`
  });
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_components_common_Page__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_components_ContentContainer__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
      title: "Settings",
      limitWidth: isTabletLarge,
      icon: !isTablet ? showMenu ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(AdminSettingsIcon, {}) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(ManageTeamIcon, {}) : null,
      onIconClick: () => setShowMenu(!showMenu),
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_components_settings_admin__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
        showMenu: showMenu,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_components_settings_admin_ManageTeam__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
      })
    })
  });
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)(ManageTeamSetting, true));
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 55534:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "unstable_getStaticParams": () => (/* binding */ unstable_getStaticParams),
/* harmony export */   "unstable_getStaticProps": () => (/* binding */ unstable_getStaticProps),
/* harmony export */   "unstable_getStaticPaths": () => (/* binding */ unstable_getStaticPaths),
/* harmony export */   "unstable_getServerProps": () => (/* binding */ unstable_getServerProps),
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "_app": () => (/* binding */ _app),
/* harmony export */   "renderReqToHTML": () => (/* binding */ renderReqToHTML),
/* harmony export */   "render": () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(70607);
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59450);
/* harmony import */ var private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97020);
/* harmony import */ var private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(73978);
/* harmony import */ var next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99436);

      
      
      
      

      
      const { processEnv } = __webpack_require__(85360)
      processEnv([{"path":".env","contents":"API_HOST=https://api.inhabit.eco\nNEXT_PUBLIC_CALENDLY_URL=https://calendly.com/inhabit-meet/inhabit-measurement-tutorial\nNEXT_PUBLIC_FLAGS_ENVIRONMENT_KEY=flags_pub_289425705564897805\nNEXT_PUBLIC_GOOGLE_ANALYTICS=G-1CBB78XFQ4\nNEXT_PUBLIC_INTERCOM_APP_ID=bw9p6mfd\nNEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_bQDaTEuYc10x3BZt9YcGj2cE00Gzwm4gDD\nSTRIPE_PUBLISHABLE_KEY=pk_live_bQDaTEuYc10x3BZt9YcGj2cE00Gzwm4gDD\n\n"}])
    
      
      const runtimeConfig = {}
      ;

      const documentModule = __webpack_require__(9968)

      const appMod = __webpack_require__(13724)
      let App = appMod.default || appMod.then && appMod.then(mod => mod.default);

      const compMod = __webpack_require__(7621)

      const Component = compMod.default || compMod.then && compMod.then(mod => mod.default)
      /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Component);
      const getStaticProps = compMod['getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['getStaticProp' + 's'])
      const getStaticPaths = compMod['getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['getStaticPath' + 's'])
      const getServerSideProps = compMod['getServerSideProp' + 's'] || compMod.then && compMod.then(mod => mod['getServerSideProp' + 's'])

      // kept for detecting legacy exports
      const unstable_getStaticParams = compMod['unstable_getStaticParam' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticParam' + 's'])
      const unstable_getStaticProps = compMod['unstable_getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticProp' + 's'])
      const unstable_getStaticPaths = compMod['unstable_getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticPath' + 's'])
      const unstable_getServerProps = compMod['unstable_getServerProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getServerProp' + 's'])

      let config = compMod['confi' + 'g'] || (compMod.then && compMod.then(mod => mod['confi' + 'g'])) || {}
      const _app = App

      const combinedRewrites = Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)
        ? private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg
        : []

      if (!Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)) {
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.beforeFiles */ .Dg.beforeFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.afterFiles */ .Dg.afterFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.fallback */ .Dg.fallback)
      }

      const { renderReqToHTML, render } = (0,next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__/* .getPageHandler */ .u)({
        pageModule: compMod,
        pageComponent: Component,
        pageConfig: config,
        appModule: App,
        documentModule: documentModule,
        errorModule: __webpack_require__(99651),
        notFoundModule: undefined,
        pageGetStaticProps: getStaticProps,
        pageGetStaticPaths: getStaticPaths,
        pageGetServerSideProps: getServerSideProps,

        assetPrefix: "",
        canonicalBase: "",
        generateEtags: true,
        poweredByHeader: true,
        reactRoot: false,

        runtimeConfig,
        buildManifest: private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__,
        reactLoadableManifest: private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__,

        rewrites: combinedRewrites,
        i18n: undefined,
        page: "/settings/admin/manage-team",
        buildId: "lDoX7RBEQ31kzKIJJbkVC",
        escapedBuildId: "lDoX7RBEQ31kzKIJJbkVC",
        basePath: "",
        pageIsDynamic: false,
        encodedPreviewProps: {previewModeId:"89cdc9f6073608262d43eab6d636f3f4",previewModeSigningKey:"74c7e36a2414a3f7b0ebcc67250f915f156686e1610b45a21ae9358d5b7c6c5a",previewModeEncryptionKey:"8a4c97ad9e5cf12d5a140689be08539ea52d8b27a416c2b8ae67db636b45841b"}
      })
      
    

/***/ }),

/***/ 94970:
/***/ ((module) => {

module.exports = require("@happykit/flags/client");

/***/ }),

/***/ 46411:
/***/ ((module) => {

module.exports = require("@happykit/flags/config");

/***/ }),

/***/ 48095:
/***/ ((module) => {

module.exports = require("@happykit/flags/server");

/***/ }),

/***/ 83218:
/***/ ((module) => {

module.exports = require("@hookform/error-message");

/***/ }),

/***/ 48308:
/***/ ((module) => {

module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ 85360:
/***/ ((module) => {

module.exports = require("@next/env");

/***/ }),

/***/ 64515:
/***/ ((module) => {

module.exports = require("@stripe/react-stripe-js");

/***/ }),

/***/ 20943:
/***/ ((module) => {

module.exports = require("@stripe/stripe-js");

/***/ }),

/***/ 52167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 68887:
/***/ ((module) => {

module.exports = require("copy-to-clipboard");

/***/ }),

/***/ 74146:
/***/ ((module) => {

module.exports = require("date-fns");

/***/ }),

/***/ 1043:
/***/ ((module) => {

module.exports = require("lodash.get");

/***/ }),

/***/ 51650:
/***/ ((module) => {

module.exports = require("lodash.uniqby");

/***/ }),

/***/ 54426:
/***/ ((module) => {

module.exports = require("next/dist/compiled/chalk");

/***/ }),

/***/ 40252:
/***/ ((module) => {

module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 19371:
/***/ ((module) => {

module.exports = require("next/dist/compiled/node-fetch");

/***/ }),

/***/ 97999:
/***/ ((module) => {

module.exports = require("next/dist/compiled/path-to-regexp");

/***/ }),

/***/ 60600:
/***/ ((module) => {

module.exports = require("next/dist/server/accept-header.js");

/***/ }),

/***/ 52155:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils/index.js");

/***/ }),

/***/ 90730:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils/node.js");

/***/ }),

/***/ 60562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 94140:
/***/ ((module) => {

module.exports = require("next/dist/server/get-page-files.js");

/***/ }),

/***/ 89716:
/***/ ((module) => {

module.exports = require("next/dist/server/htmlescape.js");

/***/ }),

/***/ 25071:
/***/ ((module) => {

module.exports = require("next/dist/server/render-result.js");

/***/ }),

/***/ 33100:
/***/ ((module) => {

module.exports = require("next/dist/server/render.js");

/***/ }),

/***/ 92779:
/***/ ((module) => {

module.exports = require("next/dist/server/request-meta.js");

/***/ }),

/***/ 79502:
/***/ ((module) => {

module.exports = require("next/dist/server/send-payload.js");

/***/ }),

/***/ 76368:
/***/ ((module) => {

module.exports = require("next/dist/server/utils.js");

/***/ }),

/***/ 56724:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 27664:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/escape-regexp.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 94957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 82374:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-locale-cookie.js");

/***/ }),

/***/ 34014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 78524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 78020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 29565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 64365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 95714:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-route-from-asset-path.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 91292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 25753:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-match.js");

/***/ }),

/***/ 99521:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/prepare-destination.js");

/***/ }),

/***/ 80979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 36052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 84226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 95566:
/***/ ((module) => {

module.exports = require("next/error");

/***/ }),

/***/ 40968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 71853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 59819:
/***/ ((module) => {

module.exports = require("querystring");

/***/ }),

/***/ 16689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 25716:
/***/ ((module) => {

module.exports = require("react-hotjar");

/***/ }),

/***/ 16666:
/***/ ((module) => {

module.exports = require("react-responsive");

/***/ }),

/***/ 1187:
/***/ ((module) => {

module.exports = require("react-toastify");

/***/ }),

/***/ 20997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 57518:
/***/ ((module) => {

module.exports = require("styled-components");

/***/ }),

/***/ 24535:
/***/ ((module) => {

module.exports = require("styled-normalize");

/***/ }),

/***/ 6153:
/***/ ((module) => {

module.exports = require("universal-cookie");

/***/ }),

/***/ 84269:
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ 75609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 61908:
/***/ ((module) => {

module.exports = import("@hookform/resolvers/yup");;

/***/ }),

/***/ 45641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [4357,9703,6114,9067,8183,9899,805,6067,1593,8294,5467,9857,1537,1476], () => (__webpack_exec__(55534)));
module.exports = __webpack_exports__;

})();