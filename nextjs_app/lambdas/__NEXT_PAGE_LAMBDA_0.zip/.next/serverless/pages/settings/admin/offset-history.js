"use strict";
(() => {
var exports = {};
exports.id = 5339;
exports.ids = [5339];
exports.modules = {

/***/ 6243:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ admin_OffsetHistory)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
// EXTERNAL MODULE: external "react-responsive"
var external_react_responsive_ = __webpack_require__(16666);
// EXTERNAL MODULE: ./src/components/button/Button.jsx
var Button = __webpack_require__(59067);
// EXTERNAL MODULE: ./src/components/common/Text.jsx
var Text = __webpack_require__(87491);
// EXTERNAL MODULE: ./src/contexts/auth.js
var auth = __webpack_require__(58368);
// EXTERNAL MODULE: ./src/theme.js
var theme = __webpack_require__(91073);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(57518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: ./src/components/settings/SettingsContainer.jsx
var SettingsContainer = __webpack_require__(89857);
// EXTERNAL MODULE: external "date-fns"
var external_date_fns_ = __webpack_require__(74146);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
;// CONCATENATED MODULE: ./src/components/settings/admin/DesktopOffsetItem.jsx







const DesktopOffsetItemContainer = external_styled_components_default().div.withConfig({
  displayName: "DesktopOffsetItem__DesktopOffsetItemContainer",
  componentId: "sc-1nk0ou3-0"
})(["display:flex;justify-content:space-between;align-items:center;height:3rem;border-bottom:1px solid ", ";"], p => p.theme.colors.secondaryBlue);
const TextContainer = external_styled_components_default().div.withConfig({
  displayName: "DesktopOffsetItem__TextContainer",
  componentId: "sc-1nk0ou3-1"
})(["width:17.5%;white-space:nowrap;"]);
const Avatar = external_styled_components_default().div.withConfig({
  displayName: "DesktopOffsetItem__Avatar",
  componentId: "sc-1nk0ou3-2"
})(["width:2rem;height:2rem;display:flex;align-items:center;justify-content:center;border-radius:50%;margin-right:1rem;background-color:", ";"], p => p.theme.colors.progressYellow);
const AvatarContainer = external_styled_components_default().div.withConfig({
  displayName: "DesktopOffsetItem__AvatarContainer",
  componentId: "sc-1nk0ou3-3"
})(["width:10%;"]);
const IconContainer = external_styled_components_default().div.withConfig({
  displayName: "DesktopOffsetItem__IconContainer",
  componentId: "sc-1nk0ou3-4"
})(["margin-right:0.75rem;& > svg{width:1.25rem;height:1.75rem;}"]);

const DesktopOffsetItem = ({
  offset
}) => {
  const desktopLarge = (0,external_react_responsive_.useMediaQuery)({
    query: `(min-width: ${theme/* sizes.desktopLarge */.J7.desktopLarge}px)`
  });
  const desktop = (0,external_react_responsive_.useMediaQuery)({
    query: `(min-width: ${theme/* sizes.desktop */.J7.desktop}px)`
  });
  const wideScreen = (0,external_react_responsive_.useMediaQuery)({
    query: `(min-width: ${theme/* sizes.wideScreen */.J7.wideScreen}px)`
  });
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(DesktopOffsetItemContainer, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(TextContainer, {
      children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
        size: "small",
        children: (0,external_date_fns_.format)(new Date(offset.created_at), "do MMM yyyy")
      })
    }), /*#__PURE__*/jsx_runtime_.jsx(TextContainer, {
      children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
        size: "small",
        children: `${offset.tonnes} ${offset.tonnes !== 1 ? "tonnes" : "tonne"}`
      })
    }), /*#__PURE__*/jsx_runtime_.jsx(TextContainer, {
      children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
        size: "small",
        children: `£${(offset.price_per_tonne * offset.tonnes / 100).toFixed(2)}`
      })
    })]
  });
};

/* harmony default export */ const admin_DesktopOffsetItem = (DesktopOffsetItem);
// EXTERNAL MODULE: ./src/styles.jsx
var styles = __webpack_require__(72994);
;// CONCATENATED MODULE: ./src/components/settings/admin/MobileOffsetItem.jsx








const MobileOffsetItemContainer = external_styled_components_default().div.withConfig({
  displayName: "MobileOffsetItem__MobileOffsetItemContainer",
  componentId: "np21w5-0"
})(["display:flex;flex-direction:column;justify-content:space-between;align-items:flex-start;padding:1rem;background-color:", ";", ""], p => p.theme.colors.white, styles/* borderRadius */.E);
const MobileOffsetItem_TextContainer = external_styled_components_default().div.withConfig({
  displayName: "MobileOffsetItem__TextContainer",
  componentId: "np21w5-1"
})(["width:100%;display:flex;"]);
const LabelContainer = external_styled_components_default().div.withConfig({
  displayName: "MobileOffsetItem__LabelContainer",
  componentId: "np21w5-2"
})(["margin-bottom:0.5rem;"]);
const TextColumn = external_styled_components_default().div.withConfig({
  displayName: "MobileOffsetItem__TextColumn",
  componentId: "np21w5-3"
})(["white-space:nowrap;display:inline-block;width:20%;margin-right:3rem;"]);
const ProjectProperty = external_styled_components_default().div.withConfig({
  displayName: "MobileOffsetItem__ProjectProperty",
  componentId: "np21w5-4"
})(["display:flex;"]);
const MobileOffsetItem_IconContainer = external_styled_components_default().div.withConfig({
  displayName: "MobileOffsetItem__IconContainer",
  componentId: "np21w5-5"
})(["margin-right:0.75rem;& > svg{width:1.25rem;height:1.75rem;}"]);
const TopContainer = external_styled_components_default().div.withConfig({
  displayName: "MobileOffsetItem__TopContainer",
  componentId: "np21w5-6"
})(["display:flex;"]);
const ProjectContainer = external_styled_components_default().div.withConfig({
  displayName: "MobileOffsetItem__ProjectContainer",
  componentId: "np21w5-7"
})(["display:flex;flex-direction:column;align-items:flex-start;"]);
const MobileOffsetItem_AvatarContainer = external_styled_components_default().div.withConfig({
  displayName: "MobileOffsetItem__AvatarContainer",
  componentId: "np21w5-8"
})(["min-width:2rem;width:2rem;height:2rem;display:flex;align-items:center;justify-content:center;border-radius:50%;margin-right:1rem;background-color:", ";"], p => p.theme.colors.progressYellow);

const MobileOffsetItem = ({
  offset
}) => {
  var _offset$user, _offset$user$first_na;

  const desktop = (0,external_react_responsive_.useMediaQuery)({
    query: `(min-width: ${theme/* sizes.desktop */.J7.desktop}px)`
  });
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(MobileOffsetItemContainer, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(TopContainer, {
      children: /*#__PURE__*/jsx_runtime_.jsx(MobileOffsetItem_AvatarContainer, {
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(Text/* default */.ZP, {
          size: desktop ? "h2" : "h3",
          color: "white",
          fontWeight: "400",
          children: [offset.user ? (_offset$user = offset.user) === null || _offset$user === void 0 ? void 0 : (_offset$user$first_na = _offset$user.first_name) === null || _offset$user$first_na === void 0 ? void 0 : _offset$user$first_na.charAt(0) : "?", " "]
        })
      })
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(MobileOffsetItem_TextContainer, {
      children: [/*#__PURE__*/jsx_runtime_.jsx(TextColumn, {
        children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
          size: "small",
          children: "Date:"
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(ProjectProperty, {
        children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
          size: "small",
          children: (0,external_date_fns_.format)(new Date(offset.created_at), "do MMM yyyy")
        })
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(MobileOffsetItem_TextContainer, {
      children: [/*#__PURE__*/jsx_runtime_.jsx(TextColumn, {
        children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
          size: "small",
          children: "Amount:"
        })
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(ProjectProperty, {
        children: [/*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
          size: "small",
          children: `${offset.tonnes} ${offset.tonnes !== 1 ? "tonnes" : "tonne"}`
        }), " "]
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(MobileOffsetItem_TextContainer, {
      children: [/*#__PURE__*/jsx_runtime_.jsx(TextColumn, {
        children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
          size: "small",
          children: "Price:"
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(ProjectProperty, {
        children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
          size: "small",
          children: `£${(offset.price_per_tonne * offset.tonnes / 100).toFixed(2)}`
        })
      })]
    })]
  });
};

/* harmony default export */ const admin_MobileOffsetItem = (MobileOffsetItem);
;// CONCATENATED MODULE: ./src/components/settings/admin/OffsetHistory.jsx













const OffsetHistoryContainer = external_styled_components_default().div.withConfig({
  displayName: "OffsetHistory__OffsetHistoryContainer",
  componentId: "cn7brv-0"
})(["", ""], theme/* media.tabletLarge */.BC.tabletLarge`
`);
const OffsetItemsContainer = external_styled_components_default().div.withConfig({
  displayName: "OffsetHistory__OffsetItemsContainer",
  componentId: "cn7brv-1"
})(["", ":not(:last-child){margin-bottom:2rem;}"], MobileOffsetItemContainer);
const HeadingTextContainer = external_styled_components_default().div.withConfig({
  displayName: "OffsetHistory__HeadingTextContainer",
  componentId: "cn7brv-2"
})(["width:17.5%;white-space:nowrap;"]);
const OffsetHistory_AvatarContainer = external_styled_components_default()(HeadingTextContainer).withConfig({
  displayName: "OffsetHistory__AvatarContainer",
  componentId: "cn7brv-3"
})(["width:10%;"]);
const ProjectNameContainer = external_styled_components_default()(HeadingTextContainer).withConfig({
  displayName: "OffsetHistory__ProjectNameContainer",
  componentId: "cn7brv-4"
})(["width:40%;"]);
const OffsetHistorHeadingsContainer = external_styled_components_default().div.withConfig({
  displayName: "OffsetHistory__OffsetHistorHeadingsContainer",
  componentId: "cn7brv-5"
})(["display:flex;padding-bottom:0.5rem;border-bottom:2px solid ", ";justify-content:space-between;"], p => p.theme.colors.placeholderGrey);
const ButtonContainer = external_styled_components_default().div.withConfig({
  displayName: "OffsetHistory__ButtonContainer",
  componentId: "cn7brv-6"
})(["display:flex;justify-content:flex-end;margin-top:1rem;"]);

const OffsetHistory = () => {
  const isDesktop = (0,external_react_responsive_.useMediaQuery)({
    query: `(min-width: ${theme/* sizes.desktop */.J7.desktop}px)`
  });
  const {
    organisation
  } = (0,auth/* default */.Z)();
  const {
    offsets
  } = organisation;
  const offsetsPerPage = isDesktop ? 10 : 5;
  const {
    0: activePage,
    1: setCurrentPage
  } = (0,external_react_.useState)(1);
  const {
    0: currentOffsets,
    1: setCurrentOffsets
  } = (0,external_react_.useState)([]);
  const indexOfLastOffset = activePage * offsetsPerPage;
  const indexOfFirstOffset = indexOfLastOffset - offsetsPerPage;
  const offsetsPage = offsets ? offsets.slice(indexOfFirstOffset, indexOfLastOffset) : [];
  (0,external_react_.useEffect)(() => {
    setCurrentOffsets([...currentOffsets, ...offsetsPage].sort((a, b) => new Date(b.created_at) <= new Date(a.created_at) ? 1 : -1));
  }, [indexOfLastOffset]);
  return /*#__PURE__*/jsx_runtime_.jsx(SettingsContainer/* default */.Z, {
    title: "Offset History",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(OffsetHistoryContainer, {
      children: [isDesktop ? /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(OffsetHistorHeadingsContainer, {
          children: [/*#__PURE__*/jsx_runtime_.jsx(HeadingTextContainer, {
            children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
              size: "tiny",
              children: "Date"
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(HeadingTextContainer, {
            children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
              size: "tiny",
              children: "CO2e"
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(HeadingTextContainer, {
            children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
              size: "tiny",
              children: "Price"
            })
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx(OffsetItemsContainer, {
          children: currentOffsets.map(offset => /*#__PURE__*/jsx_runtime_.jsx(admin_DesktopOffsetItem, {
            offset: offset
          }, offset.id))
        })]
      }) : /*#__PURE__*/jsx_runtime_.jsx(OffsetItemsContainer, {
        children: currentOffsets.map((offset, index) => /*#__PURE__*/jsx_runtime_.jsx(admin_MobileOffsetItem, {
          offset: offset
        }, `${offset.id}-${index}`))
      }), currentOffsets.length !== offsets.length && /*#__PURE__*/jsx_runtime_.jsx(ButtonContainer, {
        children: /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.ZP, {
          small: true,
          onClick: () => setCurrentPage(activePage + 1),
          children: "See more"
        })
      })]
    })
  });
};

/* harmony default export */ const admin_OffsetHistory = (OffsetHistory);

/***/ }),

/***/ 37207:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16666);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_responsive__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_common_Page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97598);
/* harmony import */ var _components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(60805);
/* harmony import */ var _components_ContentContainer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(16067);
/* harmony import */ var _components_settings_admin__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(75467);
/* harmony import */ var _components_settings_admin_OffsetHistory__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6243);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(91073);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_3__]);
_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }










var AdminSettingsIcon = function AdminSettingsIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("path", {
      d: "M24.978 12.572c-.013.328.022.734-.018 1.139-.081.812-.622 1.396-1.43 1.535-.46.08-.923.157-1.385.229-.145.023-.228.082-.277.23a6.956 6.956 0 0 1-.476 1.14c-.076.139-.07.245.026.373.28.376.547.761.82 1.142.503.7.447 1.575-.154 2.192a81.343 81.343 0 0 1-1.537 1.538c-.62.6-1.492.657-2.193.154-.39-.281-.784-.558-1.172-.842a.239.239 0 0 0-.288-.024 7.937 7.937 0 0 1-1.193.495c-.15.05-.207.128-.23.272-.069.445-.144.887-.222 1.33-.164.928-.742 1.465-1.688 1.5-.767.028-1.537.042-2.304-.014a1.652 1.652 0 0 1-1.5-1.373c-.081-.48-.16-.961-.235-1.442a.3.3 0 0 0-.233-.274 7.312 7.312 0 0 1-1.14-.475.223.223 0 0 0-.271.021c-.409.3-.821.594-1.237.88-.71.492-1.555.42-2.173-.187-.51-.5-1.015-1.003-1.515-1.512-.61-.618-.671-1.5-.162-2.206.273-.38.543-.764.822-1.14.08-.108.1-.194.031-.319a7.112 7.112 0 0 1-.502-1.185.26.26 0 0 0-.233-.203c-.45-.068-.9-.15-1.35-.226-.955-.158-1.5-.74-1.537-1.715a21.514 21.514 0 0 1 .014-2.285 1.64 1.64 0 0 1 1.322-1.486c.496-.095.995-.179 1.495-.256.14-.022.204-.088.244-.214.132-.41.294-.81.487-1.197a.265.265 0 0 0-.028-.309c-.287-.394-.57-.79-.85-1.19-.516-.743-.437-1.589.205-2.23l1.46-1.457c.634-.629 1.487-.705 2.218-.192.389.273.774.551 1.155.834.108.08.2.096.322.03.381-.2.78-.368 1.19-.5a.258.258 0 0 0 .2-.234c.063-.433.15-.862.216-1.293C9.827.644 10.364.101 11.34.04c.767-.05 1.537-.048 2.303.007.835.065 1.407.614 1.55 1.434.08.461.16.922.231 1.385.02.126.072.2.197.24.44.141.869.318 1.281.527a.247.247 0 0 0 .29-.027c.4-.29.803-.574 1.206-.86a1.647 1.647 0 0 1 2.13.153 79.24 79.24 0 0 1 1.591 1.59c.568.583.621 1.463.144 2.134-.286.4-.57.805-.862 1.203a.242.242 0 0 0-.022.289c.196.37.357.758.48 1.158.05.172.146.236.312.261.432.065.862.142 1.293.219.975.173 1.493.781 1.51 1.771.007.32.003.645.003 1.049zm-7.9 6.894a.887.887 0 0 1 .544.178c.529.378 1.06.75 1.587 1.131.1.072.177.1.276 0 .416-.423.835-.842 1.257-1.26.11-.109.11-.192.018-.318-.38-.52-.75-1.05-1.118-1.573-.23-.325-.237-.656-.036-1a7.886 7.886 0 0 0 .832-2c.105-.407.363-.64.78-.707.622-.1 1.243-.21 1.865-.308.15-.024.211-.077.209-.239a57.87 57.87 0 0 1 0-1.743c0-.14-.044-.2-.184-.22-.623-.1-1.243-.216-1.866-.313-.425-.066-.688-.293-.797-.708a7.545 7.545 0 0 0-.813-1.968c-.235-.393-.206-.75.064-1.112.369-.497.716-1.009 1.082-1.507.096-.129.082-.203-.03-.312a54.582 54.582 0 0 1-1.232-1.232c-.104-.106-.175-.116-.296-.027-.523.386-1.05.763-1.581 1.14-.31.221-.637.243-.968.05a8.374 8.374 0 0 0-2.11-.869c-.4-.104-.624-.365-.689-.773-.1-.616-.206-1.231-.304-1.85-.024-.153-.079-.221-.25-.217a40.65 40.65 0 0 1-1.687 0c-.18-.004-.25.05-.28.228-.093.611-.208 1.218-.303 1.829-.067.429-.292.704-.716.815-.69.18-1.35.458-1.963.825-.392.236-.75.2-1.112-.067-.5-.372-1.018-.725-1.523-1.093-.104-.077-.164-.065-.25.023-.42.43-.845.854-1.273 1.274-.104.1-.098.175-.017.286.374.515.737 1.04 1.112 1.555.253.347.276.692.056 1.064a7.607 7.607 0 0 0-.808 1.99c-.1.391-.342.627-.744.695-.633.108-1.267.221-1.9.32-.15.024-.2.085-.196.231a95 95 0 0 1 0 1.743c0 .15.05.207.2.23.653.105 1.305.22 1.957.333.355.061.595.27.69.61.204.742.503 1.454.889 2.119.195.336.165.666-.064.983-.374.516-.738 1.039-1.114 1.554-.086.119-.087.197.021.3.42.41.837.825 1.245 1.246.108.112.179.103.295.018.5-.365 1.011-.712 1.507-1.082.375-.279.74-.306 1.15-.071a7.615 7.615 0 0 0 1.904.774c.4.104.631.356.7.765.1.61.208 1.218.3 1.83.028.186.088.263.293.257a28.907 28.907 0 0 1 1.65 0c.197.005.256-.07.284-.246.09-.587.21-1.169.29-1.756.065-.486.325-.753.792-.873a7.36 7.36 0 0 0 1.945-.819.837.837 0 0 1 .428-.133h.002z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("path", {
      d: "M12.497 7.025c3.006 0 5.477 2.474 5.477 5.48 0 3.006-2.48 5.477-5.485 5.473-3.005-.004-5.487-2.488-5.465-5.491a5.487 5.487 0 0 1 5.473-5.462zm.005 1.7a3.789 3.789 0 0 0-3.782 3.779c0 2.068 1.705 3.772 3.773 3.773 2.067.002 3.776-1.697 3.779-3.764a3.78 3.78 0 0 0-3.77-3.787v-.001z"
    })]
  }));
};

AdminSettingsIcon.defaultProps = {
  width: "25",
  height: "25",
  viewBox: "0 0 25 25",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var OffsetHistoryIcon = function OffsetHistoryIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("path", {
      d: "M23.47 13.725c-.239-4.608-2.346-8.003-6.57-10-1.46-.69-3.019-.953-4.63-.923-.194.004-.266.067-.252.258.008.163.008.326 0 .489-.009.425-.384.653-.766.449-.402-.215-.791-.457-1.185-.69-.434-.253-.869-.507-1.3-.768-.477-.288-.474-.726.007-1.011.792-.471 1.586-.94 2.38-1.409.48-.282.864-.059.864.5 0 .625 0 .635.6.647 2.264.047 4.388.61 6.317 1.798 3.184 1.962 5.21 4.784 5.85 8.476.773 4.472-.571 8.31-3.863 11.421-1.967 1.858-4.345 2.926-7.046 3.207-3.693.383-6.945-.671-9.718-3.129C1.94 21.077.588 18.598.153 15.677-.415 11.87.574 8.481 3.082 5.546c.808-.947 1.764-1.717 2.805-2.386.42-.27.876-.197 1.124.178.254.386.144.845-.29 1.116-1.45.907-2.64 2.075-3.542 3.53a10.683 10.683 0 0 0-1.59 4.83c-.228 2.835.51 5.395 2.248 7.64 1.797 2.323 4.173 3.735 7.083 4.131 3.644.496 6.806-.58 9.408-3.185 1.725-1.729 2.703-3.849 3.045-6.264.066-.464.075-.929.096-1.411z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("path", {
      d: "M21.084 13.739c0 4.619-3.676 8.582-8.569 8.59-4.838.01-8.6-3.866-8.597-8.583.004-4.788 3.89-8.56 8.597-8.575 4.714-.014 8.567 3.856 8.569 8.568zm-4.09-3.715c-.566 0-.935-.633-.66-1.137.105-.195.272-.337.428-.487.11-.107.112-.18-.016-.275-.955-.713-2.015-1.175-3.198-1.348-.193-.028-.299.018-.277.24.01.13.01.263 0 .394a.753.753 0 0 1-.596.71c-.524.118-.951-.26-.955-.847-.004-.564.062-.555-.528-.447-1.078.197-2.042.66-2.929 1.296-.134.097-.142.174-.017.29.158.147.324.288.425.488a.768.768 0 0 1-.203.964.749.749 0 0 1-.964-.033 3.949 3.949 0 0 1-.347-.344c-.109-.122-.183-.095-.275.022-.753.965-1.188 2.059-1.368 3.262-.022.152.036.214.19.209.163-.008.326-.006.488.006a.772.772 0 0 1 .71.735c.016.376-.245.695-.627.781-.192.043-.386.03-.578.03-.14 0-.2.055-.179.197a7.096 7.096 0 0 0 1.387 3.283c.087.114.145.104.235.012.136-.138.262-.287.426-.394.316-.203.728-.176.969.064a.753.753 0 0 1 .081.998 2.511 2.511 0 0 1-.359.393c-.13.119-.134.197.015.305.973.715 2.047 1.182 3.248 1.343.14.019.203-.031.203-.174s-.006-.295.003-.441c.028-.449.38-.78.806-.765.426.015.736.355.745.798.002.124.007.248 0 .372-.011.173.05.237.23.206.337-.053.67-.127.997-.221a7.627 7.627 0 0 0 2.212-1.111c.165-.117.171-.21.019-.339a2.362 2.362 0 0 1-.293-.298c-.282-.34-.262-.791.04-1.07.303-.278.767-.264 1.077.028.104.093.202.192.295.296.109.127.187.102.27-.024.152-.225.318-.44.46-.67.456-.76.76-1.601.89-2.477.044-.276.01-.31-.27-.311-.17 0-.34.004-.507-.037a.79.79 0 0 1-.59-.675c-.036-.282.145-.604.412-.75.204-.109.42-.092.636-.093.35 0 .369-.026.308-.374a6.971 6.971 0 0 0-1.187-2.874c-.336-.476-.258-.39-.594-.058-.2.191-.405.342-.688.352z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("path", {
      d: "M13.89 14.532h-1.256c-.44 0-.738-.179-.913-.607-.584-1.425-1.19-2.842-1.783-4.263-.21-.502-.01-.956.47-1.098.373-.111.752.078.92.47.51 1.189 1.017 2.378 1.523 3.568.196.457.112.371.568.375.636.006 1.269-.004 1.906.006a.754.754 0 0 1 .728.549.781.781 0 0 1-.273.831c-.174.137-.38.168-.591.169-.432.002-.866 0-1.3 0z"
    })]
  }));
};

OffsetHistoryIcon.defaultProps = {
  width: "25",
  height: "27",
  viewBox: "0 0 25 27",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};




function OffsetHistorySetting() {
  const {
    0: showMenu,
    1: setShowMenu
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const isTablet = (0,react_responsive__WEBPACK_IMPORTED_MODULE_1__.useMediaQuery)({
    query: `(min-width: ${_theme__WEBPACK_IMPORTED_MODULE_8__/* .sizes.tablet */ .J7.tablet}px)`
  });
  const isTabletLarge = (0,react_responsive__WEBPACK_IMPORTED_MODULE_1__.useMediaQuery)({
    query: `(min-width: ${_theme__WEBPACK_IMPORTED_MODULE_8__/* .sizes.tabletLarge */ .J7.tabletLarge}px)`
  });
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_components_common_Page__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_components_ContentContainer__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
      title: "Settings",
      limitWidth: isTabletLarge,
      icon: !isTablet ? showMenu ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(AdminSettingsIcon, {}) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(OffsetHistoryIcon, {}) : null,
      onIconClick: () => setShowMenu(!showMenu),
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_components_settings_admin__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
        showMenu: showMenu,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_components_settings_admin_OffsetHistory__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
      })
    })
  });
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)(OffsetHistorySetting, true));
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 39620:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "unstable_getStaticParams": () => (/* binding */ unstable_getStaticParams),
/* harmony export */   "unstable_getStaticProps": () => (/* binding */ unstable_getStaticProps),
/* harmony export */   "unstable_getStaticPaths": () => (/* binding */ unstable_getStaticPaths),
/* harmony export */   "unstable_getServerProps": () => (/* binding */ unstable_getServerProps),
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "_app": () => (/* binding */ _app),
/* harmony export */   "renderReqToHTML": () => (/* binding */ renderReqToHTML),
/* harmony export */   "render": () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(70607);
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59450);
/* harmony import */ var private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97020);
/* harmony import */ var private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(73978);
/* harmony import */ var next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99436);

      
      
      
      

      
      const { processEnv } = __webpack_require__(85360)
      processEnv([{"path":".env","contents":"API_HOST=https://api.inhabit.eco\nNEXT_PUBLIC_CALENDLY_URL=https://calendly.com/inhabit-meet/inhabit-measurement-tutorial\nNEXT_PUBLIC_FLAGS_ENVIRONMENT_KEY=flags_pub_289425705564897805\nNEXT_PUBLIC_GOOGLE_ANALYTICS=G-1CBB78XFQ4\nNEXT_PUBLIC_INTERCOM_APP_ID=bw9p6mfd\nNEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_bQDaTEuYc10x3BZt9YcGj2cE00Gzwm4gDD\nSTRIPE_PUBLISHABLE_KEY=pk_live_bQDaTEuYc10x3BZt9YcGj2cE00Gzwm4gDD\n\n"}])
    
      
      const runtimeConfig = {}
      ;

      const documentModule = __webpack_require__(9968)

      const appMod = __webpack_require__(13724)
      let App = appMod.default || appMod.then && appMod.then(mod => mod.default);

      const compMod = __webpack_require__(37207)

      const Component = compMod.default || compMod.then && compMod.then(mod => mod.default)
      /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Component);
      const getStaticProps = compMod['getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['getStaticProp' + 's'])
      const getStaticPaths = compMod['getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['getStaticPath' + 's'])
      const getServerSideProps = compMod['getServerSideProp' + 's'] || compMod.then && compMod.then(mod => mod['getServerSideProp' + 's'])

      // kept for detecting legacy exports
      const unstable_getStaticParams = compMod['unstable_getStaticParam' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticParam' + 's'])
      const unstable_getStaticProps = compMod['unstable_getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticProp' + 's'])
      const unstable_getStaticPaths = compMod['unstable_getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticPath' + 's'])
      const unstable_getServerProps = compMod['unstable_getServerProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getServerProp' + 's'])

      let config = compMod['confi' + 'g'] || (compMod.then && compMod.then(mod => mod['confi' + 'g'])) || {}
      const _app = App

      const combinedRewrites = Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)
        ? private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg
        : []

      if (!Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)) {
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.beforeFiles */ .Dg.beforeFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.afterFiles */ .Dg.afterFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.fallback */ .Dg.fallback)
      }

      const { renderReqToHTML, render } = (0,next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__/* .getPageHandler */ .u)({
        pageModule: compMod,
        pageComponent: Component,
        pageConfig: config,
        appModule: App,
        documentModule: documentModule,
        errorModule: __webpack_require__(99651),
        notFoundModule: undefined,
        pageGetStaticProps: getStaticProps,
        pageGetStaticPaths: getStaticPaths,
        pageGetServerSideProps: getServerSideProps,

        assetPrefix: "",
        canonicalBase: "",
        generateEtags: true,
        poweredByHeader: true,
        reactRoot: false,

        runtimeConfig,
        buildManifest: private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__,
        reactLoadableManifest: private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__,

        rewrites: combinedRewrites,
        i18n: undefined,
        page: "/settings/admin/offset-history",
        buildId: "lDoX7RBEQ31kzKIJJbkVC",
        escapedBuildId: "lDoX7RBEQ31kzKIJJbkVC",
        basePath: "",
        pageIsDynamic: false,
        encodedPreviewProps: {previewModeId:"89cdc9f6073608262d43eab6d636f3f4",previewModeSigningKey:"74c7e36a2414a3f7b0ebcc67250f915f156686e1610b45a21ae9358d5b7c6c5a",previewModeEncryptionKey:"8a4c97ad9e5cf12d5a140689be08539ea52d8b27a416c2b8ae67db636b45841b"}
      })
      
    

/***/ }),

/***/ 94970:
/***/ ((module) => {

module.exports = require("@happykit/flags/client");

/***/ }),

/***/ 46411:
/***/ ((module) => {

module.exports = require("@happykit/flags/config");

/***/ }),

/***/ 48095:
/***/ ((module) => {

module.exports = require("@happykit/flags/server");

/***/ }),

/***/ 83218:
/***/ ((module) => {

module.exports = require("@hookform/error-message");

/***/ }),

/***/ 48308:
/***/ ((module) => {

module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ 85360:
/***/ ((module) => {

module.exports = require("@next/env");

/***/ }),

/***/ 64515:
/***/ ((module) => {

module.exports = require("@stripe/react-stripe-js");

/***/ }),

/***/ 20943:
/***/ ((module) => {

module.exports = require("@stripe/stripe-js");

/***/ }),

/***/ 52167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 74146:
/***/ ((module) => {

module.exports = require("date-fns");

/***/ }),

/***/ 1043:
/***/ ((module) => {

module.exports = require("lodash.get");

/***/ }),

/***/ 51650:
/***/ ((module) => {

module.exports = require("lodash.uniqby");

/***/ }),

/***/ 54426:
/***/ ((module) => {

module.exports = require("next/dist/compiled/chalk");

/***/ }),

/***/ 40252:
/***/ ((module) => {

module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 19371:
/***/ ((module) => {

module.exports = require("next/dist/compiled/node-fetch");

/***/ }),

/***/ 97999:
/***/ ((module) => {

module.exports = require("next/dist/compiled/path-to-regexp");

/***/ }),

/***/ 60600:
/***/ ((module) => {

module.exports = require("next/dist/server/accept-header.js");

/***/ }),

/***/ 52155:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils/index.js");

/***/ }),

/***/ 90730:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils/node.js");

/***/ }),

/***/ 60562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 94140:
/***/ ((module) => {

module.exports = require("next/dist/server/get-page-files.js");

/***/ }),

/***/ 89716:
/***/ ((module) => {

module.exports = require("next/dist/server/htmlescape.js");

/***/ }),

/***/ 25071:
/***/ ((module) => {

module.exports = require("next/dist/server/render-result.js");

/***/ }),

/***/ 33100:
/***/ ((module) => {

module.exports = require("next/dist/server/render.js");

/***/ }),

/***/ 92779:
/***/ ((module) => {

module.exports = require("next/dist/server/request-meta.js");

/***/ }),

/***/ 79502:
/***/ ((module) => {

module.exports = require("next/dist/server/send-payload.js");

/***/ }),

/***/ 76368:
/***/ ((module) => {

module.exports = require("next/dist/server/utils.js");

/***/ }),

/***/ 56724:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 27664:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/escape-regexp.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 94957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 82374:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-locale-cookie.js");

/***/ }),

/***/ 34014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 78524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 78020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 29565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 64365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 95714:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-route-from-asset-path.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 91292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 25753:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-match.js");

/***/ }),

/***/ 99521:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/prepare-destination.js");

/***/ }),

/***/ 80979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 36052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 84226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 95566:
/***/ ((module) => {

module.exports = require("next/error");

/***/ }),

/***/ 40968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 71853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 59819:
/***/ ((module) => {

module.exports = require("querystring");

/***/ }),

/***/ 16689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 25716:
/***/ ((module) => {

module.exports = require("react-hotjar");

/***/ }),

/***/ 16666:
/***/ ((module) => {

module.exports = require("react-responsive");

/***/ }),

/***/ 1187:
/***/ ((module) => {

module.exports = require("react-toastify");

/***/ }),

/***/ 20997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 57518:
/***/ ((module) => {

module.exports = require("styled-components");

/***/ }),

/***/ 24535:
/***/ ((module) => {

module.exports = require("styled-normalize");

/***/ }),

/***/ 6153:
/***/ ((module) => {

module.exports = require("universal-cookie");

/***/ }),

/***/ 84269:
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ 75609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 61908:
/***/ ((module) => {

module.exports = import("@hookform/resolvers/yup");;

/***/ }),

/***/ 45641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [4357,9703,6114,9067,8183,9899,805,6067,1593,8294,5467,9857], () => (__webpack_exec__(39620)));
module.exports = __webpack_exports__;

})();