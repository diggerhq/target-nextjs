"use strict";
(() => {
var exports = {};
exports.id = 6543;
exports.ids = [6543];
exports.modules = {

/***/ 54251:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export labelStyles */
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const labelStyles = (0,styled_components__WEBPACK_IMPORTED_MODULE_0__.css)(["color:", ";font-weight:", ";font-size:", ";"], p => p.color ? p.color : p.theme.colors.label, p => p.fontWeight || p.theme.body.weight, p => p.theme.tiny.size);
const Label = styled_components__WEBPACK_IMPORTED_MODULE_0___default().label.withConfig({
  displayName: "Label",
  componentId: "l08cxq-0"
})(["", " margin:", ";", ""], labelStyles, p => p.margin || " 0 0.125rem 0.1rem", p => p.block && "display:block;");
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Label);

/***/ }),

/***/ 35611:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _stripe_react_stripe_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(64515);
/* harmony import */ var _stripe_react_stripe_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_stripe_react_stripe_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(74146);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(date_fns__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var lodash_get__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1043);
/* harmony import */ var lodash_get__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(lodash_get__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(45641);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1187);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _button_Button__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(59067);
/* harmony import */ var _button_CTAButtons__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(13508);
/* harmony import */ var _common_CardSection__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(48580);
/* harmony import */ var _common_Divider__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6459);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(87491);
/* harmony import */ var _common_TextLink__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(33843);
/* harmony import */ var _form_Label__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(54251);
/* harmony import */ var _contexts_auth__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(58368);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(72994);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(91073);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(11098);
/* harmony import */ var _utils_text__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(88703);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(92107);
/* harmony import */ var _SettingsContainer__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(89857);
/* harmony import */ var _InvoiceList__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(39588);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_5__, _common_CardSection__WEBPACK_IMPORTED_MODULE_9__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_5__, _common_CardSection__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


















var PoweredByStripe = function PoweredByStripe(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx("defs", {
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxs)("style", {
        children: [".cls-1", `{`, "fill:#635bff", `}`]
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx("title", {
      children: "Powered by Stripe - blurple"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx("path", {
      className: "cls-1",
      d: "M146 0H3.73A3.73 3.73 0 0 0 0 3.73v26.54A3.73 3.73 0 0 0 3.73 34H146a4 4 0 0 0 4-4V4a4 4 0 0 0-4-4zm3 30a3 3 0 0 1-3 3H3.73A2.74 2.74 0 0 1 1 30.27V3.73A2.74 2.74 0 0 1 3.73 1H146a3 3 0 0 1 3 3z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx("path", {
      className: "cls-1",
      d: "M17.07 11.24h-4.3V22h1.92v-4.16h2.38c2.4 0 3.9-1.16 3.9-3.3s-1.5-3.3-3.9-3.3zm-.1 5h-2.28v-3.3H17c1.38 0 2.11.59 2.11 1.65s-.76 1.6-2.11 1.6zM25.1 14a3.77 3.77 0 0 0-3.8 4.09 3.81 3.81 0 1 0 7.59 0A3.76 3.76 0 0 0 25.1 14zm0 6.67c-1.22 0-2-1-2-2.58s.76-2.58 2-2.58 2 1 2 2.58-.79 2.57-2 2.57zM36.78 19.35l-1.41-5.22h-1.48l-1.4 5.22-1.42-5.22h-1.85l2.37 7.88h1.56l1.44-5.16 1.44 5.16h1.56l2.37-7.88h-1.78l-1.4 5.22zM44 14a3.83 3.83 0 0 0-3.75 4.09 3.79 3.79 0 0 0 3.83 4.09A3.47 3.47 0 0 0 47.49 20L46 19.38a1.78 1.78 0 0 1-1.83 1.26A2.12 2.12 0 0 1 42 18.47h5.52v-.6C47.54 15.71 46.32 14 44 14zm-1.93 3.13A1.92 1.92 0 0 1 44 15.5a1.56 1.56 0 0 1 1.69 1.62zM50.69 15.3v-1.17h-1.8V22h1.8v-4.13a1.89 1.89 0 0 1 2-2 4.68 4.68 0 0 1 .66 0v-1.8h-.51a2.29 2.29 0 0 0-2.15 1.23zM57.48 14a3.83 3.83 0 0 0-3.75 4.09 3.79 3.79 0 0 0 3.83 4.09A3.47 3.47 0 0 0 60.93 20l-1.54-.59a1.78 1.78 0 0 1-1.83 1.26 2.12 2.12 0 0 1-2.1-2.17H61v-.6c0-2.19-1.24-3.9-3.52-3.9zm-1.93 3.13a1.92 1.92 0 0 1 1.92-1.62 1.56 1.56 0 0 1 1.69 1.62zM67.56 15a2.85 2.85 0 0 0-2.26-1c-2.21 0-3.47 1.85-3.47 4.09s1.26 4.09 3.47 4.09a2.82 2.82 0 0 0 2.26-1V22h1.8V11.24h-1.8zm0 3.35a2 2 0 0 1-2 2.28c-1.31 0-2-1-2-2.52s.7-2.52 2-2.52c1.11 0 2 .81 2 2.29zM79.31 14A2.88 2.88 0 0 0 77 15v-3.76h-1.8V22H77v-.83a2.86 2.86 0 0 0 2.27 1c2.2 0 3.46-1.86 3.46-4.09S81.51 14 79.31 14zM79 20.6a2 2 0 0 1-2-2.28v-.47c0-1.48.84-2.29 2-2.29 1.3 0 2 1 2 2.52s-.75 2.52-2 2.52zM86.93 19.66L85 14.13h-1.9l2.9 7.59-.3.74a1 1 0 0 1-1.14.79 4.12 4.12 0 0 1-.6 0v1.51a4.62 4.62 0 0 0 .73.05 2.67 2.67 0 0 0 2.78-2l3.24-8.62h-1.89zM125 12.43a3 3 0 0 0-2.13.87l-.14-.69h-2.39v12.92l2.72-.59v-3.13a3 3 0 0 0 1.93.7c1.94 0 3.72-1.59 3.72-5.11 0-3.22-1.8-4.97-3.71-4.97zm-.65 7.63a1.61 1.61 0 0 1-1.28-.52v-4.11a1.64 1.64 0 0 1 1.3-.55c1 0 1.68 1.13 1.68 2.58s-.69 2.6-1.7 2.6zM133.73 12.43c-2.62 0-4.21 2.26-4.21 5.11 0 3.37 1.88 5.08 4.56 5.08a6.12 6.12 0 0 0 3-.73v-2.25a5.79 5.79 0 0 1-2.7.62c-1.08 0-2-.39-2.14-1.7h5.38v-1c.09-2.87-1.27-5.13-3.89-5.13zm-1.47 4.07c0-1.26.77-1.79 1.45-1.79s1.4.53 1.4 1.79zM113 13.36l-.17-.82h-2.32v9.71h2.68v-6.58a1.87 1.87 0 0 1 2.05-.58v-2.55a1.8 1.8 0 0 0-2.24.82zM99.46 15.46c0-.44.36-.61.93-.61a5.9 5.9 0 0 1 2.7.72v-2.63a7 7 0 0 0-2.7-.51c-2.21 0-3.68 1.18-3.68 3.16 0 3.1 4.14 2.6 4.14 3.93 0 .52-.44.69-1 .69a6.78 6.78 0 0 1-3-.9V22a7.38 7.38 0 0 0 3 .64c2.26 0 3.82-1.15 3.82-3.16-.05-3.36-4.21-2.76-4.21-4.02zM107.28 10.24l-2.65.58v8.93a2.77 2.77 0 0 0 2.82 2.87 4.16 4.16 0 0 0 1.91-.37V20c-.35.15-2.06.66-2.06-1v-4h2.06v-2.34h-2.06zM116.25 11.7l2.73-.57V8.97l-2.73.57v2.16zM116.25 12.61h2.73v9.64h-2.73z"
    })]
  }));
};

PoweredByStripe.defaultProps = {
  id: "Layer_1",
  'data-name': "Layer 1",
  xmlns: "http://www.w3.org/2000/svg",
  viewBox: "0 0 150 34"
};











const CardFormContainer = styled_components__WEBPACK_IMPORTED_MODULE_19___default().div.withConfig({
  displayName: "Billing__CardFormContainer",
  componentId: "sc-18oy87p-0"
})(["width:100%;display:flex;align-items:center;flex-direction:column;", ""], _theme__WEBPACK_IMPORTED_MODULE_17__/* .media.tabletLarge */ .BC.tabletLarge`
    flex-direction: row;
    
    ${p => p.updating && (0,styled_components__WEBPACK_IMPORTED_MODULE_19__.css)(["align-items:flex-start;flex-direction:column;"])}
  `);
const PoweredByStripeIcon = styled_components__WEBPACK_IMPORTED_MODULE_19___default()(PoweredByStripe).withConfig({
  displayName: "Billing__PoweredByStripeIcon",
  componentId: "sc-18oy87p-1"
})(["margin:1rem 0 0;width:8rem;"]);
const Container = styled_components__WEBPACK_IMPORTED_MODULE_19___default().div.withConfig({
  displayName: "Billing__Container",
  componentId: "sc-18oy87p-2"
})(["display:flex;flex-direction:column;align-items:center;", ""], _theme__WEBPACK_IMPORTED_MODULE_17__/* .media.tabletLarge */ .BC.tabletLarge`
    flex-direction: row;
    justify-content: space-between;
  `);
const PlanContainer = styled_components__WEBPACK_IMPORTED_MODULE_19___default().div.withConfig({
  displayName: "Billing__PlanContainer",
  componentId: "sc-18oy87p-3"
})(["", " display:flex;align-items:flex-start;flex-direction:column;padding:0.75rem 0 1rem;"], _styles__WEBPACK_IMPORTED_MODULE_16__/* .borderRadius */ .E);
const PlanTitleContainer = styled_components__WEBPACK_IMPORTED_MODULE_19___default().div.withConfig({
  displayName: "Billing__PlanTitleContainer",
  componentId: "sc-18oy87p-4"
})(["margin-bottom:0.75rem;"]);
const Form = styled_components__WEBPACK_IMPORTED_MODULE_19___default().form.withConfig({
  displayName: "Billing__Form",
  componentId: "sc-18oy87p-5"
})(["width:100%;height:auto;display:flex;justify-content:space-between;align-items:flex-end;flex-direction:column;", " ", ""], _theme__WEBPACK_IMPORTED_MODULE_17__/* .media.tabletLarge */ .BC.tabletLarge`
  justify-content: flex-start;

  `, p => p.maxWidth && `
    ${_theme__WEBPACK_IMPORTED_MODULE_17__/* .media.tabletLarge */ .BC.tabletLarge`
      max-width: 240px;
   `}
   `);
const FormGroup = styled_components__WEBPACK_IMPORTED_MODULE_19___default().div.withConfig({
  displayName: "Billing__FormGroup",
  componentId: "sc-18oy87p-6"
})(["width:100%;display:flex;flex-direction:column;align-items:stretch;margin-bottom:2rem;", ""], _theme__WEBPACK_IMPORTED_MODULE_17__/* .media.tablet */ .BC.tablet`
      max-width: 20rem;
   `);
const UpdateButtonContainer = styled_components__WEBPACK_IMPORTED_MODULE_19___default().div.withConfig({
  displayName: "Billing__UpdateButtonContainer",
  componentId: "sc-18oy87p-7"
})(["display:flex;margin:0.5rem 0;justify-content:center;", ""], _theme__WEBPACK_IMPORTED_MODULE_17__/* .media.tabletLarge */ .BC.tabletLarge`
    justify-content: flex-start;
    margin-left: 2rem;
  `);

const Billing = () => {
  var _organisation$subscri, _organisation$subscri2, _organisation$subscri3;

  const {
    0: updating,
    1: setUpdating
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    0: invoices,
    1: setInvoices
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
  const stripe = (0,_stripe_react_stripe_js__WEBPACK_IMPORTED_MODULE_1__.useStripe)();
  const elements = (0,_stripe_react_stripe_js__WEBPACK_IMPORTED_MODULE_1__.useElements)();
  const {
    user,
    organisation,
    setOrganisation
  } = (0,_contexts_auth__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z)();
  const {
    0: updateLoading,
    1: setUpdateLoading
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);

  const getInvoices = async () => {
    try {
      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_2___default().get(`/api/organisations/${user.organisation_id}/invoices`);
      setInvoices(data);
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_18__/* .logError */ .H)(error, _constants__WEBPACK_IMPORTED_MODULE_22__/* .SETTINGS_CONTAINER_ID */ .f);
    }
  };

  const handleSubmitCard = async values => {
    try {
      setUpdateLoading(true);

      if (!stripe || !elements) {
        return;
      }

      const {
        data: {
          client_secret,
          organisation
        }
      } = await axios__WEBPACK_IMPORTED_MODULE_2___default().post(`/api/organisations/${user.organisation_id}/subscriptions/setup-intent`);
      const cardElement = elements.getElement(_stripe_react_stripe_js__WEBPACK_IMPORTED_MODULE_1__.CardElement);
      const {
        setupIntent,
        error
      } = await stripe.confirmCardSetup(client_secret, {
        payment_method: {
          card: cardElement,
          billing_details: _objectSpread({
            email: user.email
          }, user.first_name && user.last_name ? {
            name: `${user.first_name} ${user.last_name}`
          } : {})
        }
      });

      if (error) {
        console.error(error);
        throw error;
      } else {
        const paymentMethodId = setupIntent.payment_method;
        const isSubscribed = organisation.stripe_account && organisation.stripe_account.subscription_id && organisation.subscription.status === "active";
        const {
          data: {
            organisation: subscribedOrganisation,
            paymentIntent
          }
        } = await axios__WEBPACK_IMPORTED_MODULE_2___default()({
          url: `/api/organisations/${user.organisation_id}/subscriptions`,
          method: isSubscribed ? "PATCH" : "POST",
          data: {
            paymentMethodId
          }
        });
        checkSubscription(paymentIntent, subscribedOrganisation, paymentMethodId);
      }
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_18__/* .logError */ .H)(error, _constants__WEBPACK_IMPORTED_MODULE_22__/* .SETTINGS_CONTAINER_ID */ .f);
      setUpdateLoading(false);
    }
  };

  const handleSuccess = organisation => {
    setOrganisation(organisation);
    setUpdating(false);
    setUpdateLoading(false);
    react_toastify__WEBPACK_IMPORTED_MODULE_6__.toast.success("Payment details updated!", {
      containerId: _constants__WEBPACK_IMPORTED_MODULE_22__/* .SETTINGS_CONTAINER_ID */ .f
    });
  };

  const checkSubscription = (paymentIntent, organisation, paymentMethod) => {
    if (organisation && organisation.subscription.status === "active") {
      handleSuccess(organisation);
    } else if (paymentIntent) {
      switch (paymentIntent.status) {
        case "succeeded":
          handleSuccess(organisation);
          break;

        case "requires_payment_method":
          (0,_utils_logger__WEBPACK_IMPORTED_MODULE_18__/* .logError */ .H)({
            message: lodash_get__WEBPACK_IMPORTED_MODULE_4___default()(paymentIntent, "last_payment_error.message", "Could no make the payment please check your card and try again")
          }, _constants__WEBPACK_IMPORTED_MODULE_22__/* .SETTINGS_CONTAINER_ID */ .f);
          break;

        case "requires_action":
          authenticateCard(paymentIntent, paymentMethod, organisation);
          break;

        default:
          react_toastify__WEBPACK_IMPORTED_MODULE_6__.toast.info("Something seems to have gone wrong please get in contact with us");
          break;
      }
    }
  };

  const authenticateCard = async (paymentIntent, paymentMethod) => {
    const {
      paymentIntent: newPaymentIntent,
      error
    } = await stripe.confirmCardPayment(paymentIntent.client_secret, {
      payment_method: paymentMethod
    });
    const {
      data: organisation
    } = await axios__WEBPACK_IMPORTED_MODULE_2___default().get(`/api/organisations/${user.organisation_id}`);

    if (error) {
      throw error;
    } else {
      checkSubscription(newPaymentIntent, organisation, paymentMethod);
    }
  };

  const methods = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_5__.useForm)();
  const last4 = lodash_get__WEBPACK_IMPORTED_MODULE_4___default()(organisation, "card.last4", null);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    (organisation === null || organisation === void 0 ? void 0 : organisation.subscription) && getInvoices();
  }, []);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_SettingsContainer__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {
    title: "Billing",
    cta: updating && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_button_CTAButtons__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
      onDiscard: () => {
        setUpdating(false);
      },
      loading: updateLoading,
      onSave: methods.handleSubmit(handleSubmitCard)
    }),
    children: organisation !== null && organisation !== void 0 && organisation.subscription ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.Fragment, {
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxs)(Container, {
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxs)(PlanContainer, {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(PlanTitleContainer, {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .ZP, {
              size: "meta",
              children: "Your plan:"
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx("div", {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .ZP, {
              size: "subtitle1",
              children: `${(0,_utils_text__WEBPACK_IMPORTED_MODULE_23__/* .capitalize */ .k)(organisation === null || organisation === void 0 ? void 0 : (_organisation$subscri = organisation.subscription) === null || _organisation$subscri === void 0 ? void 0 : _organisation$subscri.interval)}ly: £${(organisation === null || organisation === void 0 ? void 0 : (_organisation$subscri2 = organisation.subscription) === null || _organisation$subscri2 === void 0 ? void 0 : _organisation$subscri2.unit_amount) / 100}/${organisation === null || organisation === void 0 ? void 0 : (_organisation$subscri3 = organisation.subscription) === null || _organisation$subscri3 === void 0 ? void 0 : _organisation$subscri3.interval}`
            })
          })]
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxs)(PlanContainer, {
          backgroundColor: "white",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(PlanTitleContainer, {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .ZP, {
              size: "tiny",
              children: "Next billing date:"
            })
          }), organisation.next_payment_date && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx("div", {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .ZP, {
              size: "subtitle1",
              children: (0,date_fns__WEBPACK_IMPORTED_MODULE_3__.format)(new Date(organisation.next_payment_date * 1000), "do MMMM yyyy")
            })
          })]
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxs)(PlanContainer, {
          backgroundColor: "white",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(PlanTitleContainer, {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .ZP, {
              size: "tiny",
              children: "Change plan:"
            })
          }), organisation.next_payment_date && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx("div", {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_common_TextLink__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
              href: "mailto:team@inhabit.eco",
              children: "Contact us"
            })
          })]
        })]
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_common_Divider__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
        margin: "1.25rem 0"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_5__.FormProvider, _objectSpread(_objectSpread({}, methods), {}, {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(Form, {
          maxWidth: true,
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxs)(CardFormContainer, {
            updating: updating,
            children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxs)(PlanContainer, {
              backgroundColor: "white",
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(PlanTitleContainer, {
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .ZP, {
                  size: "tiny",
                  children: " Payment method:"
                })
              }), organisation.next_payment_date && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx("div", {
                children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxs)(_common_Text__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .ZP, {
                  size: "subtitle1",
                  children: ["**** **** **** ", last4]
                })
              })]
            }), !updating && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(UpdateButtonContainer, {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
                onClick: () => setUpdating(!updating),
                children: "Update"
              })
            }), updating && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxs)(FormGroup, {
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx("div", {
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .ZP, {
                  color: "black",
                  children: "Please enter you card details:"
                })
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_common_CardSection__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(PoweredByStripeIcon, {})]
            })]
          })
        })
      })), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_common_Divider__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {}), !updating && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.Fragment, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_form_Label__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
          children: "Invoices:"
        }), invoices.length > 0 && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_InvoiceList__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .Z, {
          invoices: invoices
        })]
      })]
    }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .ZP, {
      children: "Organisation not live - add in payment details to activate"
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Billing);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 39588:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ admin_InvoiceList)
});

// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(57518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: external "date-fns"
var external_date_fns_ = __webpack_require__(74146);
// EXTERNAL MODULE: ./src/components/button/Button.jsx
var Button = __webpack_require__(59067);
// EXTERNAL MODULE: ./src/components/common/Text.jsx
var Text = __webpack_require__(87491);
// EXTERNAL MODULE: ./src/theme.js
var theme = __webpack_require__(91073);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
;// CONCATENATED MODULE: ./src/components/settings/admin/InvoiceItem.jsx







const Container = external_styled_components_default().div.withConfig({
  displayName: "InvoiceItem__Container",
  componentId: "sc-35iwto-0"
})(["display:flex;width:100%;margin:0.5rem 0;"]);
const DateContainer = external_styled_components_default().div.withConfig({
  displayName: "InvoiceItem__DateContainer",
  componentId: "sc-35iwto-1"
})(["width:26%;", " ", " ", ""], theme/* media.mobileModern */.BC.mobileModern`
  width: 29%;
  `, theme/* media.tablet */.BC.tablet`
  width: 35%;
  `, theme/* media.tabletLarge */.BC.tabletLarge`
  width: 40%;
  `);
const PaidContainer = external_styled_components_default().div.withConfig({
  displayName: "InvoiceItem__PaidContainer",
  componentId: "sc-35iwto-2"
})(["width:15%;display:flex;justify-content:center;", " ", ""], theme/* media.mobileModern */.BC.mobileModern`
    width: 20%;
  `, theme/* media.tablet */.BC.tablet`
  width: 15%;
  `);
const AmountContainer = external_styled_components_default().div.withConfig({
  displayName: "InvoiceItem__AmountContainer",
  componentId: "sc-35iwto-3"
})(["width:22%;display:flex;justify-content:center;", " ", ""], theme/* media.mobileModern */.BC.mobileModern`
    width: 20%;
  `, theme/* media.tabletLarge */.BC.tabletLarge`
  width: 20%;
  `);
const ButtonContainer = external_styled_components_default().div.withConfig({
  displayName: "InvoiceItem__ButtonContainer",
  componentId: "sc-35iwto-4"
})(["width:37.5%;", " ", " ", ""], theme/* media.mobileModern */.BC.mobileModern`    
   width: 30%;
  `, theme/* media.tablet */.BC.tablet`
  width: 10%;
  `, theme/* media.tabletLarge */.BC.tabletLarge`
  width: 25%;
  `);

const InvoiceItem = ({
  invoice
}) => /*#__PURE__*/(0,jsx_runtime_.jsxs)(Container, {
  children: [/*#__PURE__*/jsx_runtime_.jsx(DateContainer, {
    children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
      children: (0,external_date_fns_.format)(new Date(invoice.created * 1000), "do MMM yyyy")
    })
  }), /*#__PURE__*/jsx_runtime_.jsx(PaidContainer, {
    children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
      children: "Paid"
    })
  }), /*#__PURE__*/jsx_runtime_.jsx(AmountContainer, {
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(Text/* default */.ZP, {
      children: ["\xA3", (invoice.amount_paid / 100).toFixed(2)]
    })
  }), /*#__PURE__*/jsx_runtime_.jsx(ButtonContainer, {
    children: /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.ZP, {
      small: true,
      href: invoice.invoice_pdf,
      external: true,
      children: "See Invoice"
    })
  })]
});

/* harmony default export */ const admin_InvoiceItem = (InvoiceItem);
;// CONCATENATED MODULE: ./src/components/settings/admin/InvoiceList.jsx



const InvoiceList_Container = external_styled_components_default().div.withConfig({
  displayName: "InvoiceList__Container",
  componentId: "sc-1qmpdf8-0"
})(["width:100%;"]);

const InvoiceList = ({
  invoices
}) => /*#__PURE__*/jsx_runtime_.jsx(InvoiceList_Container, {
  children: invoices.map(invoice => /*#__PURE__*/jsx_runtime_.jsx(admin_InvoiceItem, {
    invoice: invoice
  }))
});

/* harmony default export */ const admin_InvoiceList = (InvoiceList);

/***/ }),

/***/ 76975:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16666);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_responsive__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_common_Page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97598);
/* harmony import */ var _components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(60805);
/* harmony import */ var _components_ContentContainer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(16067);
/* harmony import */ var _components_settings_admin__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(75467);
/* harmony import */ var _components_settings_admin_Billing__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(35611);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(91073);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_3__, _components_settings_admin_Billing__WEBPACK_IMPORTED_MODULE_6__]);
([_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_3__, _components_settings_admin_Billing__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }










var AdminSettingsIcon = function AdminSettingsIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("path", {
      d: "M24.978 12.572c-.013.328.022.734-.018 1.139-.081.812-.622 1.396-1.43 1.535-.46.08-.923.157-1.385.229-.145.023-.228.082-.277.23a6.956 6.956 0 0 1-.476 1.14c-.076.139-.07.245.026.373.28.376.547.761.82 1.142.503.7.447 1.575-.154 2.192a81.343 81.343 0 0 1-1.537 1.538c-.62.6-1.492.657-2.193.154-.39-.281-.784-.558-1.172-.842a.239.239 0 0 0-.288-.024 7.937 7.937 0 0 1-1.193.495c-.15.05-.207.128-.23.272-.069.445-.144.887-.222 1.33-.164.928-.742 1.465-1.688 1.5-.767.028-1.537.042-2.304-.014a1.652 1.652 0 0 1-1.5-1.373c-.081-.48-.16-.961-.235-1.442a.3.3 0 0 0-.233-.274 7.312 7.312 0 0 1-1.14-.475.223.223 0 0 0-.271.021c-.409.3-.821.594-1.237.88-.71.492-1.555.42-2.173-.187-.51-.5-1.015-1.003-1.515-1.512-.61-.618-.671-1.5-.162-2.206.273-.38.543-.764.822-1.14.08-.108.1-.194.031-.319a7.112 7.112 0 0 1-.502-1.185.26.26 0 0 0-.233-.203c-.45-.068-.9-.15-1.35-.226-.955-.158-1.5-.74-1.537-1.715a21.514 21.514 0 0 1 .014-2.285 1.64 1.64 0 0 1 1.322-1.486c.496-.095.995-.179 1.495-.256.14-.022.204-.088.244-.214.132-.41.294-.81.487-1.197a.265.265 0 0 0-.028-.309c-.287-.394-.57-.79-.85-1.19-.516-.743-.437-1.589.205-2.23l1.46-1.457c.634-.629 1.487-.705 2.218-.192.389.273.774.551 1.155.834.108.08.2.096.322.03.381-.2.78-.368 1.19-.5a.258.258 0 0 0 .2-.234c.063-.433.15-.862.216-1.293C9.827.644 10.364.101 11.34.04c.767-.05 1.537-.048 2.303.007.835.065 1.407.614 1.55 1.434.08.461.16.922.231 1.385.02.126.072.2.197.24.44.141.869.318 1.281.527a.247.247 0 0 0 .29-.027c.4-.29.803-.574 1.206-.86a1.647 1.647 0 0 1 2.13.153 79.24 79.24 0 0 1 1.591 1.59c.568.583.621 1.463.144 2.134-.286.4-.57.805-.862 1.203a.242.242 0 0 0-.022.289c.196.37.357.758.48 1.158.05.172.146.236.312.261.432.065.862.142 1.293.219.975.173 1.493.781 1.51 1.771.007.32.003.645.003 1.049zm-7.9 6.894a.887.887 0 0 1 .544.178c.529.378 1.06.75 1.587 1.131.1.072.177.1.276 0 .416-.423.835-.842 1.257-1.26.11-.109.11-.192.018-.318-.38-.52-.75-1.05-1.118-1.573-.23-.325-.237-.656-.036-1a7.886 7.886 0 0 0 .832-2c.105-.407.363-.64.78-.707.622-.1 1.243-.21 1.865-.308.15-.024.211-.077.209-.239a57.87 57.87 0 0 1 0-1.743c0-.14-.044-.2-.184-.22-.623-.1-1.243-.216-1.866-.313-.425-.066-.688-.293-.797-.708a7.545 7.545 0 0 0-.813-1.968c-.235-.393-.206-.75.064-1.112.369-.497.716-1.009 1.082-1.507.096-.129.082-.203-.03-.312a54.582 54.582 0 0 1-1.232-1.232c-.104-.106-.175-.116-.296-.027-.523.386-1.05.763-1.581 1.14-.31.221-.637.243-.968.05a8.374 8.374 0 0 0-2.11-.869c-.4-.104-.624-.365-.689-.773-.1-.616-.206-1.231-.304-1.85-.024-.153-.079-.221-.25-.217a40.65 40.65 0 0 1-1.687 0c-.18-.004-.25.05-.28.228-.093.611-.208 1.218-.303 1.829-.067.429-.292.704-.716.815-.69.18-1.35.458-1.963.825-.392.236-.75.2-1.112-.067-.5-.372-1.018-.725-1.523-1.093-.104-.077-.164-.065-.25.023-.42.43-.845.854-1.273 1.274-.104.1-.098.175-.017.286.374.515.737 1.04 1.112 1.555.253.347.276.692.056 1.064a7.607 7.607 0 0 0-.808 1.99c-.1.391-.342.627-.744.695-.633.108-1.267.221-1.9.32-.15.024-.2.085-.196.231a95 95 0 0 1 0 1.743c0 .15.05.207.2.23.653.105 1.305.22 1.957.333.355.061.595.27.69.61.204.742.503 1.454.889 2.119.195.336.165.666-.064.983-.374.516-.738 1.039-1.114 1.554-.086.119-.087.197.021.3.42.41.837.825 1.245 1.246.108.112.179.103.295.018.5-.365 1.011-.712 1.507-1.082.375-.279.74-.306 1.15-.071a7.615 7.615 0 0 0 1.904.774c.4.104.631.356.7.765.1.61.208 1.218.3 1.83.028.186.088.263.293.257a28.907 28.907 0 0 1 1.65 0c.197.005.256-.07.284-.246.09-.587.21-1.169.29-1.756.065-.486.325-.753.792-.873a7.36 7.36 0 0 0 1.945-.819.837.837 0 0 1 .428-.133h.002z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("path", {
      d: "M12.497 7.025c3.006 0 5.477 2.474 5.477 5.48 0 3.006-2.48 5.477-5.485 5.473-3.005-.004-5.487-2.488-5.465-5.491a5.487 5.487 0 0 1 5.473-5.462zm.005 1.7a3.789 3.789 0 0 0-3.782 3.779c0 2.068 1.705 3.772 3.773 3.773 2.067.002 3.776-1.697 3.779-3.764a3.78 3.78 0 0 0-3.77-3.787v-.001z"
    })]
  }));
};

AdminSettingsIcon.defaultProps = {
  width: "25",
  height: "25",
  viewBox: "0 0 25 25",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var CardChipIcon = function CardChipIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("path", {
      d: "M12.506.006h9.5c1.466 0 2.622.944 2.922 2.37.044.207.067.418.068.63.004 3.82.004 7.64 0 11.46-.003 1.47-1.012 2.673-2.435 2.923a4.676 4.676 0 0 1-.804.06c-6.17.003-12.34.005-18.511.005-1.235 0-2.234-.418-2.877-1.517A2.65 2.65 0 0 1 0 14.585V2.856C.002 1.354 1.275.05 2.782.014 3.867-.01 4.952.006 6.04.006h6.467zm0 6.936H1.51c-.182 0-.306 0-.305.25.008 2.448 0 4.897.007 7.346a1.69 1.69 0 0 0 .507 1.21c.41.42.93.513 1.482.513h18.365c.188 0 .374-.024.56-.034.911-.051 1.658-.812 1.644-1.868-.03-2.35-.01-4.702-.01-7.052 0-.364 0-.364-.358-.364H12.505v-.001zm-.016-3.905h10.525c.18 0 .36-.006.538 0 .165.008.217-.067.207-.22a1.65 1.65 0 0 0-.306-.865c-.402-.572-.984-.741-1.644-.741H5.41c-.775 0-1.55-.007-2.325 0-1.017.012-1.68.547-1.847 1.472-.06.337-.048.35.287.35l10.965.004zm-.008 1.209H1.76a1.974 1.974 0 0 1-.245 0c-.229-.029-.327.051-.31.296.02.268.005.538.006.807 0 .385 0 .385.382.385H23.38c.049-.002.098-.002.147 0 .187.022.24-.07.235-.244-.008-.294 0-.587 0-.881 0-.362 0-.363-.36-.363h-10.92z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("path", {
      d: "M21.143 11.399v1.958c0 .444-.231.68-.678.682-1.265.005-2.53.005-3.794 0-.453 0-.696-.247-.697-.7a870.154 870.154 0 0 1 0-3.892c0-.416.195-.64.606-.686.22-.02.44-.026.66-.02 1.003-.002 2.006-.002 3.01 0 .13-.002.26.009.389.03.315.056.5.273.503.596.004.678 0 1.355 0 2.032zm-1.208-.013h.01c0-.391-.003-.783 0-1.174.003-.159-.042-.24-.22-.24-.765.005-1.532.005-2.298 0-.156 0-.22.06-.219.216.004.79.004 1.58 0 2.371 0 .167.062.231.23.23.759-.005 1.516-.005 2.274 0 .174 0 .228-.067.225-.232-.007-.389-.002-.78-.002-1.17zM8.534 10.852H4.619a1.349 1.349 0 0 1-.411-.043.601.601 0 0 1-.433-.562.604.604 0 0 1 .429-.589 1.29 1.29 0 0 1 .385-.045h7.9c.13-.004.26.012.385.048a.615.615 0 0 1 .423.571.61.61 0 0 1-.42.573 1.302 1.302 0 0 1-.41.048H8.534zM7.39 12.541c.977 0 1.956-.003 2.934 0 .386 0 .662.264.657.607-.005.335-.273.582-.648.598-.082.003-.163 0-.244 0h-4.11c-.53 0-1.059 0-1.589-.003a.588.588 0 0 1-.552-.34.57.57 0 0 1 .044-.604c.135-.202.338-.263.573-.263.978.007 1.956.005 2.934.005z"
    })]
  }));
};

CardChipIcon.defaultProps = {
  viewBox: "0 0 25 18",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};




function BillingSetting() {
  const {
    0: showMenu,
    1: setShowMenu
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const isTablet = (0,react_responsive__WEBPACK_IMPORTED_MODULE_1__.useMediaQuery)({
    query: `(min-width: ${_theme__WEBPACK_IMPORTED_MODULE_8__/* .sizes.tablet */ .J7.tablet}px)`
  });
  const isTabletLarge = (0,react_responsive__WEBPACK_IMPORTED_MODULE_1__.useMediaQuery)({
    query: `(min-width: ${_theme__WEBPACK_IMPORTED_MODULE_8__/* .sizes.tabletLarge */ .J7.tabletLarge}px)`
  });
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_components_common_Page__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_components_ContentContainer__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
      title: "Settings",
      limitWidth: isTabletLarge,
      icon: !isTablet ? showMenu ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(AdminSettingsIcon, {}) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(CardChipIcon, {}) : null,
      onIconClick: () => setShowMenu(!showMenu),
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_components_settings_admin__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
        showMenu: showMenu,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_components_settings_admin_Billing__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
      })
    })
  });
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)(BillingSetting, true));
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 53438:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "unstable_getStaticParams": () => (/* binding */ unstable_getStaticParams),
/* harmony export */   "unstable_getStaticProps": () => (/* binding */ unstable_getStaticProps),
/* harmony export */   "unstable_getStaticPaths": () => (/* binding */ unstable_getStaticPaths),
/* harmony export */   "unstable_getServerProps": () => (/* binding */ unstable_getServerProps),
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "_app": () => (/* binding */ _app),
/* harmony export */   "renderReqToHTML": () => (/* binding */ renderReqToHTML),
/* harmony export */   "render": () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(70607);
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59450);
/* harmony import */ var private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97020);
/* harmony import */ var private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(73978);
/* harmony import */ var next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99436);

      
      
      
      

      
      const { processEnv } = __webpack_require__(85360)
      processEnv([{"path":".env","contents":"API_HOST=https://api.inhabit.eco\nNEXT_PUBLIC_CALENDLY_URL=https://calendly.com/inhabit-meet/inhabit-measurement-tutorial\nNEXT_PUBLIC_FLAGS_ENVIRONMENT_KEY=flags_pub_289425705564897805\nNEXT_PUBLIC_GOOGLE_ANALYTICS=G-1CBB78XFQ4\nNEXT_PUBLIC_INTERCOM_APP_ID=bw9p6mfd\nNEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_bQDaTEuYc10x3BZt9YcGj2cE00Gzwm4gDD\nSTRIPE_PUBLISHABLE_KEY=pk_live_bQDaTEuYc10x3BZt9YcGj2cE00Gzwm4gDD\n\n"}])
    
      
      const runtimeConfig = {}
      ;

      const documentModule = __webpack_require__(9968)

      const appMod = __webpack_require__(13724)
      let App = appMod.default || appMod.then && appMod.then(mod => mod.default);

      const compMod = __webpack_require__(76975)

      const Component = compMod.default || compMod.then && compMod.then(mod => mod.default)
      /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Component);
      const getStaticProps = compMod['getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['getStaticProp' + 's'])
      const getStaticPaths = compMod['getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['getStaticPath' + 's'])
      const getServerSideProps = compMod['getServerSideProp' + 's'] || compMod.then && compMod.then(mod => mod['getServerSideProp' + 's'])

      // kept for detecting legacy exports
      const unstable_getStaticParams = compMod['unstable_getStaticParam' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticParam' + 's'])
      const unstable_getStaticProps = compMod['unstable_getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticProp' + 's'])
      const unstable_getStaticPaths = compMod['unstable_getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticPath' + 's'])
      const unstable_getServerProps = compMod['unstable_getServerProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getServerProp' + 's'])

      let config = compMod['confi' + 'g'] || (compMod.then && compMod.then(mod => mod['confi' + 'g'])) || {}
      const _app = App

      const combinedRewrites = Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)
        ? private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg
        : []

      if (!Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)) {
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.beforeFiles */ .Dg.beforeFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.afterFiles */ .Dg.afterFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.fallback */ .Dg.fallback)
      }

      const { renderReqToHTML, render } = (0,next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__/* .getPageHandler */ .u)({
        pageModule: compMod,
        pageComponent: Component,
        pageConfig: config,
        appModule: App,
        documentModule: documentModule,
        errorModule: __webpack_require__(99651),
        notFoundModule: undefined,
        pageGetStaticProps: getStaticProps,
        pageGetStaticPaths: getStaticPaths,
        pageGetServerSideProps: getServerSideProps,

        assetPrefix: "",
        canonicalBase: "",
        generateEtags: true,
        poweredByHeader: true,
        reactRoot: false,

        runtimeConfig,
        buildManifest: private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__,
        reactLoadableManifest: private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__,

        rewrites: combinedRewrites,
        i18n: undefined,
        page: "/settings/admin/billing",
        buildId: "lDoX7RBEQ31kzKIJJbkVC",
        escapedBuildId: "lDoX7RBEQ31kzKIJJbkVC",
        basePath: "",
        pageIsDynamic: false,
        encodedPreviewProps: {previewModeId:"89cdc9f6073608262d43eab6d636f3f4",previewModeSigningKey:"74c7e36a2414a3f7b0ebcc67250f915f156686e1610b45a21ae9358d5b7c6c5a",previewModeEncryptionKey:"8a4c97ad9e5cf12d5a140689be08539ea52d8b27a416c2b8ae67db636b45841b"}
      })
      
    

/***/ }),

/***/ 94970:
/***/ ((module) => {

module.exports = require("@happykit/flags/client");

/***/ }),

/***/ 46411:
/***/ ((module) => {

module.exports = require("@happykit/flags/config");

/***/ }),

/***/ 48095:
/***/ ((module) => {

module.exports = require("@happykit/flags/server");

/***/ }),

/***/ 83218:
/***/ ((module) => {

module.exports = require("@hookform/error-message");

/***/ }),

/***/ 48308:
/***/ ((module) => {

module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ 85360:
/***/ ((module) => {

module.exports = require("@next/env");

/***/ }),

/***/ 64515:
/***/ ((module) => {

module.exports = require("@stripe/react-stripe-js");

/***/ }),

/***/ 20943:
/***/ ((module) => {

module.exports = require("@stripe/stripe-js");

/***/ }),

/***/ 52167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 74146:
/***/ ((module) => {

module.exports = require("date-fns");

/***/ }),

/***/ 1043:
/***/ ((module) => {

module.exports = require("lodash.get");

/***/ }),

/***/ 51650:
/***/ ((module) => {

module.exports = require("lodash.uniqby");

/***/ }),

/***/ 54426:
/***/ ((module) => {

module.exports = require("next/dist/compiled/chalk");

/***/ }),

/***/ 40252:
/***/ ((module) => {

module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 19371:
/***/ ((module) => {

module.exports = require("next/dist/compiled/node-fetch");

/***/ }),

/***/ 97999:
/***/ ((module) => {

module.exports = require("next/dist/compiled/path-to-regexp");

/***/ }),

/***/ 60600:
/***/ ((module) => {

module.exports = require("next/dist/server/accept-header.js");

/***/ }),

/***/ 52155:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils/index.js");

/***/ }),

/***/ 90730:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils/node.js");

/***/ }),

/***/ 60562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 94140:
/***/ ((module) => {

module.exports = require("next/dist/server/get-page-files.js");

/***/ }),

/***/ 89716:
/***/ ((module) => {

module.exports = require("next/dist/server/htmlescape.js");

/***/ }),

/***/ 25071:
/***/ ((module) => {

module.exports = require("next/dist/server/render-result.js");

/***/ }),

/***/ 33100:
/***/ ((module) => {

module.exports = require("next/dist/server/render.js");

/***/ }),

/***/ 92779:
/***/ ((module) => {

module.exports = require("next/dist/server/request-meta.js");

/***/ }),

/***/ 79502:
/***/ ((module) => {

module.exports = require("next/dist/server/send-payload.js");

/***/ }),

/***/ 76368:
/***/ ((module) => {

module.exports = require("next/dist/server/utils.js");

/***/ }),

/***/ 56724:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 27664:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/escape-regexp.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 94957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 82374:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-locale-cookie.js");

/***/ }),

/***/ 34014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 78524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 78020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 29565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 64365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 95714:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-route-from-asset-path.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 91292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 25753:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-match.js");

/***/ }),

/***/ 99521:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/prepare-destination.js");

/***/ }),

/***/ 80979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 36052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 84226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 95566:
/***/ ((module) => {

module.exports = require("next/error");

/***/ }),

/***/ 40968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 71853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 59819:
/***/ ((module) => {

module.exports = require("querystring");

/***/ }),

/***/ 16689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 25716:
/***/ ((module) => {

module.exports = require("react-hotjar");

/***/ }),

/***/ 16666:
/***/ ((module) => {

module.exports = require("react-responsive");

/***/ }),

/***/ 1187:
/***/ ((module) => {

module.exports = require("react-toastify");

/***/ }),

/***/ 20997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 57518:
/***/ ((module) => {

module.exports = require("styled-components");

/***/ }),

/***/ 24535:
/***/ ((module) => {

module.exports = require("styled-normalize");

/***/ }),

/***/ 6153:
/***/ ((module) => {

module.exports = require("universal-cookie");

/***/ }),

/***/ 84269:
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ 75609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 61908:
/***/ ((module) => {

module.exports = import("@hookform/resolvers/yup");;

/***/ }),

/***/ 45641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [4357,9703,6114,9067,8183,9899,805,6067,1593,8294,5467,9857,3843,3508], () => (__webpack_exec__(53438)));
module.exports = __webpack_exports__;

})();