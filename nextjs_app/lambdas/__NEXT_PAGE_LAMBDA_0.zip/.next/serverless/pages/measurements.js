"use strict";
(() => {
var exports = {};
exports.id = 8080;
exports.ids = [8080];
exports.modules = {

/***/ 45486:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);



const createColor = ({
  backgroundColor,
  size,
  theme
}) => theme.colors[backgroundColor] || size && theme[size].color || theme.colors.secondaryBlue;

const Progress = styled_components__WEBPACK_IMPORTED_MODULE_0___default().progress.withConfig({
  displayName: "ProgressBar__Progress",
  componentId: "m3wjqd-0"
})(["-webkit-appearance:none;-moz-appearance:none;appearance:none;height:0.5rem;margin:1rem 0;width:100%;::-webkit-progress-bar{border-radius:10px;background:", ";}::-webkit-progress-value{border-radius:10px;background:", ";}"], createColor, p => p.theme.colors.blue);

const ProgressBar = ({
  value,
  max,
  backgroundColor
}) => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(Progress, {
    value: value,
    max: max,
    backgroundColor: backgroundColor
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProgressBar);

/***/ }),

/***/ 37820:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(74146);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(date_fns__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(16666);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_responsive__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _button_Button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(59067);
/* harmony import */ var _common_Divider__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6459);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(87491);
/* harmony import */ var _form_Error__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(26428);
/* harmony import */ var _contexts_auth__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(58368);
/* harmony import */ var _contexts_measurements__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(85238);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(72994);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(91073);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(11098);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _common_LoadingLarge__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(49899);
/* harmony import */ var _common_ButtonsContainer__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(30495);
/* harmony import */ var _DeleteMeasurementModal__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(81324);
/* harmony import */ var _utils_applicationMap__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(40516);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__);





















const InProgressMeasurementContainer = styled_components__WEBPACK_IMPORTED_MODULE_14___default().div.withConfig({
  displayName: "InprogressMeasurementItem__InProgressMeasurementContainer",
  componentId: "vr76gl-0"
})(["background:", ";width:100%;", " display:flex;padding:0.625rem 0;flex-wrap:wrap;align-items:center;justify-content:center;&:not(:last-child){margin-bottom:1rem;}", " ", ""], p => p.theme.colors.tertiaryBlue, _styles__WEBPACK_IMPORTED_MODULE_11__/* .borderRadius */ .E, _theme__WEBPACK_IMPORTED_MODULE_12__/* .media.tablet */ .BC.tablet`
      flex-wrap: initial;
  `, _theme__WEBPACK_IMPORTED_MODULE_12__/* .media.tabletLarge */ .BC.tabletLarge`
    width: 90%;
  `);
const InProgressMeasurementSection = styled_components__WEBPACK_IMPORTED_MODULE_14___default().div.withConfig({
  displayName: "InprogressMeasurementItem__InProgressMeasurementSection",
  componentId: "vr76gl-1"
})(["display:flex;justify-content:center;align-items:center;flex-direction:column;margin:0.5rem;& > div{display:flex;justify-content:center;align-items:center;}", " ", " ", ""], _theme__WEBPACK_IMPORTED_MODULE_12__/* .media.tablet */ .BC.tablet`
      margin: 0 0.5rem;
  `, _theme__WEBPACK_IMPORTED_MODULE_12__/* .media.desktop */ .BC.desktop`
      margin: 0 1rem;
  `, _theme__WEBPACK_IMPORTED_MODULE_12__/* .media.desktopLarge */ .BC.desktopLarge`
      margin: 0 1.5rem;
  `);
const AvatarContainer = styled_components__WEBPACK_IMPORTED_MODULE_14___default().div.withConfig({
  displayName: "InprogressMeasurementItem__AvatarContainer",
  componentId: "vr76gl-2"
})(["min-width:", ";width:", ";height:", ";display:flex;align-items:center;justify-content:center;border-radius:50%;background-color:", ";", ""], p => p.size || "2rem", p => p.size || "2rem", p => p.size || "2rem", p => p.theme.colors.progressYellow, _theme__WEBPACK_IMPORTED_MODULE_12__/* .media.tablet */ .BC.tablet`
  min-width: ${p => p.size || "2rem"};
  width: ${p => p.size || "2rem"};
  height: ${p => p.size || "2rem"};
  `);
const Image = styled_components__WEBPACK_IMPORTED_MODULE_14___default().img.withConfig({
  displayName: "InprogressMeasurementItem__Image",
  componentId: "vr76gl-3"
})(["width:100%;height:100%;border-radius:50%;object-fit:cover;"]);
const PeriodInProgressMeasurementSection = styled_components__WEBPACK_IMPORTED_MODULE_14___default()(InProgressMeasurementSection).withConfig({
  displayName: "InprogressMeasurementItem__PeriodInProgressMeasurementSection",
  componentId: "vr76gl-4"
})(["width:100%;", ";"], _theme__WEBPACK_IMPORTED_MODULE_12__/* .media.tablet */ .BC.tablet`
    width: 9%;
  `);
const SectionsInProgressMeasurementSection = styled_components__WEBPACK_IMPORTED_MODULE_14___default()(InProgressMeasurementSection).withConfig({
  displayName: "InprogressMeasurementItem__SectionsInProgressMeasurementSection",
  componentId: "vr76gl-5"
})(["width:30%;", ";"], _theme__WEBPACK_IMPORTED_MODULE_12__/* .media.tablet */ .BC.tablet`
    width: initial;
    margin: 0 1.5rem;
  `);
const InprogressButtonsContainer = styled_components__WEBPACK_IMPORTED_MODULE_14___default()(_common_ButtonsContainer__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z).withConfig({
  displayName: "InprogressMeasurementItem__InprogressButtonsContainer",
  componentId: "vr76gl-6"
})(["margin:0;& > *:not(:first-child){margin-left:1rem;}"]);

const InprogressMeasurementItem = ({
  measurement
}) => {
  var _measurement$user, _measurement$user2, _measurement$user3, _measurement$user4, _measurement$user5, _measurement$user5$fi;

  const {
    user
  } = (0,_contexts_auth__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)();
  const {
    0: showDeleteConfirmationModal,
    1: setShowDeleteConfirmationModal
  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)();
  const isTablet = (0,react_responsive__WEBPACK_IMPORTED_MODULE_4__.useMediaQuery)({
    query: `(min-width: ${_theme__WEBPACK_IMPORTED_MODULE_12__/* .sizes.tablet */ .J7.tablet}px)`
  });
  const isDesktop = (0,react_responsive__WEBPACK_IMPORTED_MODULE_4__.useMediaQuery)({
    query: `(min-width: ${_theme__WEBPACK_IMPORTED_MODULE_12__/* .sizes.desktop */ .J7.desktop}px)`
  });
  const {
    getMeasurements,
    loading,
    setLoading
  } = (0,_contexts_measurements__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)();
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
  const appMap = (0,_utils_applicationMap__WEBPACK_IMPORTED_MODULE_19__/* .initAppMap */ .AZ)({
    measurement
  });
  const firstIncompleteStep = (0,_utils_applicationMap__WEBPACK_IMPORTED_MODULE_19__/* .getCurrentPage */ .FZ)({
    measurement
  });

  const discardMeasurement = async () => {
    setLoading(true);

    try {
      await axios__WEBPACK_IMPORTED_MODULE_0___default()["delete"](`/api/organisations/${user.organisation_id}/measurements/${measurement.id}`);
      await getMeasurements();
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_13__/* .logError */ .H)(error);
    }

    setLoading(false);
  };

  const yearString = [...new Set([(0,date_fns__WEBPACK_IMPORTED_MODULE_1__.format)(new Date(measurement === null || measurement === void 0 ? void 0 : measurement.year, measurement === null || measurement === void 0 ? void 0 : measurement.month), "MM/yyyy"), (0,date_fns__WEBPACK_IMPORTED_MODULE_1__.format)((0,date_fns__WEBPACK_IMPORTED_MODULE_1__.subDays)((0,date_fns__WEBPACK_IMPORTED_MODULE_1__.addMonths)(new Date(measurement === null || measurement === void 0 ? void 0 : measurement.year, measurement === null || measurement === void 0 ? void 0 : measurement.month), measurement === null || measurement === void 0 ? void 0 : measurement.time_period), 1), "MM/yyyy")])].join(" - ");
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)(InProgressMeasurementContainer, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_DeleteMeasurementModal__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
      showConfirmationModal: showDeleteConfirmationModal,
      setShowConfirmationModal: setShowDeleteConfirmationModal,
      onConfirm: discardMeasurement
    }), loading && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_common_LoadingLarge__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
      loading: loading,
      text: "Deleting calculation"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)(PeriodInProgressMeasurementSection, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx("div", {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
          size: "tiny",
          children: "Period"
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx("div", {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
          size: "subtitleBold",
          color: "blue",
          children: yearString
        })
      })]
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)(SectionsInProgressMeasurementSection, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx("div", {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
          size: "tiny",
          align: "center",
          children: "Sections completed"
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx("div", {
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)(_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
          size: "subtitleBold",
          color: "blue",
          children: [(0,_utils_applicationMap__WEBPACK_IMPORTED_MODULE_19__/* .getCurrentProgress */ .rs)({
            measurement
          }), "/", (0,_utils_applicationMap__WEBPACK_IMPORTED_MODULE_19__/* .getNumberOfPages */ .VC)(appMap)]
        })
      })]
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)(InProgressMeasurementSection, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx("div", {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
          size: "tiny",
          children: "Date Started"
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx("div", {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
          size: "subtitleBold",
          color: "blue",
          children: (0,date_fns__WEBPACK_IMPORTED_MODULE_1__.format)(new Date(measurement.created_at), "dd/MM/yyyy")
        })
      })]
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)(InProgressMeasurementSection, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx("div", {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
          size: "tiny",
          children: "Started by"
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx("div", {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(AvatarContainer, {
          size: "1.5rem",
          children: (_measurement$user = measurement.user) !== null && _measurement$user !== void 0 && _measurement$user.profile_picture ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(Image, {
            src: (_measurement$user2 = measurement.user) === null || _measurement$user2 === void 0 ? void 0 : _measurement$user2.profile_picture,
            alt: `${(_measurement$user3 = measurement.user) === null || _measurement$user3 === void 0 ? void 0 : _measurement$user3.first_name} ${(_measurement$user4 = measurement.user) === null || _measurement$user4 === void 0 ? void 0 : _measurement$user4.last_name}`
          }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)(_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
            size: "body",
            color: "white",
            children: [((_measurement$user5 = measurement.user) === null || _measurement$user5 === void 0 ? void 0 : (_measurement$user5$fi = _measurement$user5.first_name) === null || _measurement$user5$fi === void 0 ? void 0 : _measurement$user5$fi.charAt(0)) || "?", " "]
          })
        })
      })]
    }), !isTablet && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_common_Divider__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
      margin: "0.5rem 2rem 0.75rem"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(InProgressMeasurementSection, {
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)(InprogressButtonsContainer, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP, {
          secondary: true,
          warning: true,
          onClick: () => setShowDeleteConfirmationModal(!showDeleteConfirmationModal),
          children: "Discard"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP, {
          disabled: !isDesktop,
          onClick: () => router.push(`/measurements/[id]/${firstIncompleteStep}`, `/measurements/${measurement.id}/${firstIncompleteStep}`),
          children: "Continue"
        })]
      })
    }), !isTablet && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_form_Error__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
      children: "Login on desktop to start a measurement."
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (InprogressMeasurementItem);

/***/ }),

/***/ 84116:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var recharts__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(36157);
/* harmony import */ var recharts__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(recharts__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(87491);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(72994);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _utils_charts__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(19343);
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(19390);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__);









const Container = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
  displayName: "MeasurementBarChart__Container",
  componentId: "sc-1qmdiry-0"
})(["", ";display:none;flex-direction:column;align-items:center;background:", ";padding:1.125rem;margin:2rem 0;", " ", " .custom-tooltip{border-radius:50%;backgroundcolor:white;}.recharts-cartesian-axis-tick{text{font-size:", ";}}"], _styles__WEBPACK_IMPORTED_MODULE_2__/* .borderRadius */ .E, p => p.theme.colors.white, _theme__WEBPACK_IMPORTED_MODULE_3__/* .media.tablet */ .BC.tablet`
    display: flex;
      width: 90%;
  `, _theme__WEBPACK_IMPORTED_MODULE_3__/* .media.desktop */ .BC.desktop`
    margin: initial;
    width: 59%;
  `, p => p.theme.small.size);
const InnerContainer = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
  displayName: "MeasurementBarChart__InnerContainer",
  componentId: "sc-1qmdiry-1"
})(["display:flex;align-items:center;text-align:center;margin:auto;height:18rem;width:100%;"]);
const Legend = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
  displayName: "MeasurementBarChart__Legend",
  componentId: "sc-1qmdiry-2"
})(["display:flex;"]);
const LegendItem = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
  displayName: "MeasurementBarChart__LegendItem",
  componentId: "sc-1qmdiry-3"
})(["display:flex;align-items:center;&:not(:last-of-type){margin-right:1.5rem;}"]);
const LegendColor = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
  displayName: "MeasurementBarChart__LegendColor",
  componentId: "sc-1qmdiry-4"
})(["background-color:", ";height:0.75rem;width:0.75rem;margin-right:0.52rem;"], p => p.color);
const StyledTooltip = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
  displayName: "MeasurementBarChart__StyledTooltip",
  componentId: "sc-1qmdiry-5"
})(["background-color:", ";border-radius:100%;height:3rem;width:3rem;display:flex;justify-content:center;align-items:center;box-shadow:0px 5px 5px rgba(46,104,241,0.5);"], p => p.theme.colors.backgroundGrey);
const TitleContainer = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
  displayName: "MeasurementBarChart__TitleContainer",
  componentId: "sc-1qmdiry-6"
})(["align-self:flex-start;display:flex;justify-content:space-between;width:100%;"]);
const SubtitleContainer = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
  displayName: "MeasurementBarChart__SubtitleContainer",
  componentId: "sc-1qmdiry-7"
})(["width:100%;"]);

const CustomTooltip = ({
  active,
  payload,
  label
}) => {
  if (active && payload && payload.length) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(StyledTooltip, {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
        children: `${payload[0].value}`
      })
    });
  }

  return null;
};

const CustomYAxisTick = props => {
  const {
    x,
    y,
    payload
  } = props;
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("g", {
    transform: `translate(${x},${y})`,
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("text", {
      x: 0,
      y: 0,
      fill: _theme__WEBPACK_IMPORTED_MODULE_3__/* ["default"].colors.black */ .ZP.colors.black,
      textAnchor: "end",
      dominantBaseline: "middle",
      children: payload.value
    })
  });
};

const MeasurementBarChart = ({
  measurement,
  height = 200,
  width = 700,
  isMonthly,
  officeId
}) => {
  var _measurement$office_m;

  const totalMeasurementResults = (0,_utils_charts__WEBPACK_IMPORTED_MODULE_7__/* .createTotalMeasurementResults */ .d)(measurement);
  const measurementResults = officeId ? measurement === null || measurement === void 0 ? void 0 : (_measurement$office_m = measurement.office_measurements.find(office => office.office_id === officeId)) === null || _measurement$office_m === void 0 ? void 0 : _measurement$office_m.measurement_result : totalMeasurementResults;

  const formatValue = value => !value ? 0 : isMonthly ? value : value / 1000;

  const data = Object.keys(measurementResults).filter(key => !_utils_constants__WEBPACK_IMPORTED_MODULE_5__/* .EXCLUDED_CHART_KEYS.includes */ .Nx.includes(key)).sort((a, b) => measurementResults[a] > measurementResults[b] ? -1 : 1).slice(0, 4).map(key => ({
    name: (0,_utils_charts__WEBPACK_IMPORTED_MODULE_7__/* .formatChartLabels */ .e)(key),
    value: parseFloat(formatValue(measurementResults[key]).toFixed(2))
  }));
  const colors = {
    "Company facilities": _theme__WEBPACK_IMPORTED_MODULE_3__/* ["default"].colors.graphBlue */ .ZP.colors.graphBlue,
    Electricity: _theme__WEBPACK_IMPORTED_MODULE_3__/* ["default"].colors.graphYellow */ .ZP.colors.graphYellow,
    other: _theme__WEBPACK_IMPORTED_MODULE_3__/* ["default"].colors.graphGreen */ .ZP.colors.graphGreen
  };
  const colorScopes = {
    scope_1: _theme__WEBPACK_IMPORTED_MODULE_3__/* ["default"].colors.graphBlue */ .ZP.colors.graphBlue,
    scope_2: _theme__WEBPACK_IMPORTED_MODULE_3__/* ["default"].colors.graphYellow */ .ZP.colors.graphYellow,
    scope_3: _theme__WEBPACK_IMPORTED_MODULE_3__/* ["default"].colors.graphGreen */ .ZP.colors.graphGreen
  };
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(Container, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(TitleContainer, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
        size: "cardHeader",
        children: "Top Emissions Sources"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(Legend, {
        children: Object.keys(colorScopes).map(key => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(LegendItem, {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(LegendColor, {
            color: colorScopes[key]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
            size: "smallBold",
            children: key.replace("_", " ").replace(/^\w/, c => c.toUpperCase())
          })]
        }, key))
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(SubtitleContainer, {
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(_common_Text__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
        align: "left",
        size: "miniscule",
        children: ["(", isMonthly ? "kgCO2e" : "tCO2e", ")"]
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(InnerContainer, {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(recharts__WEBPACK_IMPORTED_MODULE_0__.ResponsiveContainer, {
        width: "100%",
        height: "100%",
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(recharts__WEBPACK_IMPORTED_MODULE_0__.BarChart, {
          data: data,
          layout: "vertical",
          barCategoryGap: 2,
          margin: {
            top: 0,
            right: 10,
            bottom: 0,
            left: -40
          },
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(recharts__WEBPACK_IMPORTED_MODULE_0__.XAxis, {
            type: "number",
            axisLine: false,
            tickLine: false
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(recharts__WEBPACK_IMPORTED_MODULE_0__.YAxis, {
            width: 205,
            height: 25,
            type: "category",
            dataKey: "name",
            tick: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(CustomYAxisTick, {}),
            axisLine: false,
            tickLine: false
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(recharts__WEBPACK_IMPORTED_MODULE_0__.Tooltip, {
            content: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(CustomTooltip, {
              width: width
            }),
            cursor: {
              fill: _theme__WEBPACK_IMPORTED_MODULE_3__/* ["default"].colors.transparent */ .ZP.colors.transparent
            }
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(recharts__WEBPACK_IMPORTED_MODULE_0__.CartesianGrid, {
            horizontal: false
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(recharts__WEBPACK_IMPORTED_MODULE_0__.Bar, {
            dataKey: "value",
            maxBarSize: 20,
            children: data.map((entry, index) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(recharts__WEBPACK_IMPORTED_MODULE_0__.Cell, {
              fill: colors[entry.name] || colors["other"]
            }, `cell-${index}`))
          })]
        })
      })
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MeasurementBarChart);

/***/ }),

/***/ 68291:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(74146);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(date_fns__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(16666);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_responsive__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _button_Button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(59067);
/* harmony import */ var _common_Divider__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6459);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(87491);
/* harmony import */ var _contexts_auth__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(58368);
/* harmony import */ var _contexts_measurements__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(85238);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(72994);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(91073);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(11098);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _common_ButtonsContainer__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(30495);
/* harmony import */ var _DeleteMeasurementModal__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(81324);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__);



















const PendingMeasurementContainer = styled_components__WEBPACK_IMPORTED_MODULE_13___default().div.withConfig({
  displayName: "PastMeasurementItem__PendingMeasurementContainer",
  componentId: "sc-4utw9g-0"
})(["background:", ";width:100%;", " display:flex;padding:0.625rem 0;flex-wrap:wrap;align-items:center;justify-content:center;&:not(:last-child){margin-bottom:1rem;}", " ", ""], p => p.theme.colors.white, _styles__WEBPACK_IMPORTED_MODULE_10__/* .borderRadius */ .E, _theme__WEBPACK_IMPORTED_MODULE_11__/* .media.desktopLarge */ .BC.desktopLarge`
    justify-content: flex-start;
    flex-wrap: initial;
    max-width: 67.5rem;
    width: 100%;
  `, _theme__WEBPACK_IMPORTED_MODULE_11__/* .media.tabletLarge */ .BC.tabletLarge`
    width: 95%;
  `);
const PendingMeasurementSection = styled_components__WEBPACK_IMPORTED_MODULE_13___default().div.withConfig({
  displayName: "PastMeasurementItem__PendingMeasurementSection",
  componentId: "sc-4utw9g-1"
})(["display:flex;justify-content:center;align-items:center;flex-direction:column;", " ", ""], _theme__WEBPACK_IMPORTED_MODULE_11__/* .media.tablet */ .BC.tablet`
      margin: 0 0.5rem;
  `, _theme__WEBPACK_IMPORTED_MODULE_11__/* .media.desktop */ .BC.desktop`
      margin: 0 1rem;
  `);
const AvatarContainer = styled_components__WEBPACK_IMPORTED_MODULE_13___default().div.withConfig({
  displayName: "PastMeasurementItem__AvatarContainer",
  componentId: "sc-4utw9g-2"
})(["min-width:", ";width:", ";height:", ";display:flex;align-items:center;justify-content:center;border-radius:50%;background-color:", ";", ""], p => p.size || "2rem", p => p.size || "2rem", p => p.size || "2rem", p => p.theme.colors.progressYellow, _theme__WEBPACK_IMPORTED_MODULE_11__/* .media.tablet */ .BC.tablet`
  min-width: ${p => p.size || "2rem"};
  width: ${p => p.size || "2rem"};
  height: ${p => p.size || "2rem"};
  `);
const Image = styled_components__WEBPACK_IMPORTED_MODULE_13___default().img.withConfig({
  displayName: "PastMeasurementItem__Image",
  componentId: "sc-4utw9g-3"
})(["width:100%;height:100%;border-radius:50%;object-fit:cover;"]);
const PeriodPendingMeasurementSection = styled_components__WEBPACK_IMPORTED_MODULE_13___default()(PendingMeasurementSection).withConfig({
  displayName: "PastMeasurementItem__PeriodPendingMeasurementSection",
  componentId: "sc-4utw9g-4"
})(["width:100%;", ""], _theme__WEBPACK_IMPORTED_MODULE_11__/* .media.tablet */ .BC.tablet`
    width: 12%;
  `);
const InprogressButtonsContainer = styled_components__WEBPACK_IMPORTED_MODULE_13___default()(_common_ButtonsContainer__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z).withConfig({
  displayName: "PastMeasurementItem__InprogressButtonsContainer",
  componentId: "sc-4utw9g-5"
})(["margin:0;display:flex;flex-wrap:wrap;justify-content:center;& > *{margin-top:1rem;}& > *:not(:first-child):not(:last-child){margin-left:1rem;}", " ", " ", ""], _theme__WEBPACK_IMPORTED_MODULE_11__/* .media.mobileLarge */ .BC.mobileLarge`
    display: initial;

    & > * {
      margin-top: 0;
    }

    & > *:not(:first-child) {
      margin-left: 1rem;
    }
  `, _theme__WEBPACK_IMPORTED_MODULE_11__/* .media.tablet */ .BC.tablet`
    & > * {
      margin-top: 1rem;
    }
  `, _theme__WEBPACK_IMPORTED_MODULE_11__/* .media.desktopLarge */ .BC.desktopLarge`
    & > * {
      margin-top: 0;
    }
  `);
const MobileAvatarContainer = styled_components__WEBPACK_IMPORTED_MODULE_13___default().div.withConfig({
  displayName: "PastMeasurementItem__MobileAvatarContainer",
  componentId: "sc-4utw9g-6"
})(["display:flex;align-items:center;"]);
const MobilePendingMeasurementSection = styled_components__WEBPACK_IMPORTED_MODULE_13___default()(PendingMeasurementSection).withConfig({
  displayName: "PastMeasurementItem__MobilePendingMeasurementSection",
  componentId: "sc-4utw9g-7"
})(["align-items:flex-start;margin-right:1rem;"]);

const PendingMeasurementItem = ({
  measurement
}) => {
  var _measurement$user, _measurement$user2, _measurement$user3, _measurement$user4, _measurement$user5, _measurement$user5$fi, _measurement$user6, _measurement$user7, _measurement$user8, _measurement$user9, _measurement$user10, _measurement$user10$f;

  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
  const {
    user
  } = (0,_contexts_auth__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
  const {
    0: showDeleteConfirmationModal,
    1: setShowDeleteConfirmationModal
  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)();
  const {
    getMeasurements,
    setLoading
  } = (0,_contexts_measurements__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)();
  const isTablet = (0,react_responsive__WEBPACK_IMPORTED_MODULE_4__.useMediaQuery)({
    query: `(min-width: ${_theme__WEBPACK_IMPORTED_MODULE_11__/* .sizes.tablet */ .J7.tablet}px)`
  });

  const discardMeasurement = async () => {
    setLoading(true);

    try {
      await axios__WEBPACK_IMPORTED_MODULE_0___default()["delete"](`/api/organisations/${user.organisation_id}/measurements/${measurement.id}`);
      await getMeasurements();
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_12__/* .logError */ .H)(error);
    }

    setLoading(false);
  };

  const yearString = [...new Set([(0,date_fns__WEBPACK_IMPORTED_MODULE_1__.format)(new Date(measurement === null || measurement === void 0 ? void 0 : measurement.year, measurement === null || measurement === void 0 ? void 0 : measurement.month), "MM/yyyy"), (0,date_fns__WEBPACK_IMPORTED_MODULE_1__.format)((0,date_fns__WEBPACK_IMPORTED_MODULE_1__.subDays)((0,date_fns__WEBPACK_IMPORTED_MODULE_1__.addMonths)(new Date(measurement === null || measurement === void 0 ? void 0 : measurement.year, measurement === null || measurement === void 0 ? void 0 : measurement.month), measurement === null || measurement === void 0 ? void 0 : measurement.time_period), 1), "MM/yyyy")])].join(" - ");
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)(PendingMeasurementContainer, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_DeleteMeasurementModal__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
      showConfirmationModal: showDeleteConfirmationModal,
      setShowConfirmationModal: setShowDeleteConfirmationModal,
      onConfirm: discardMeasurement
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)(PeriodPendingMeasurementSection, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx("div", {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
          size: "tiny",
          children: "Period"
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx("div", {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
          size: "subtitleBold",
          color: "blue",
          children: yearString
        })
      })]
    }), isTablet ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.Fragment, {
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)(PendingMeasurementSection, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx("div", {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
            size: "tiny",
            children: "Date Submitted"
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx("div", {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
            size: "subtitleBold",
            color: "blue",
            children: (0,date_fns__WEBPACK_IMPORTED_MODULE_1__.format)(new Date(measurement.submitted_at || measurement.updated_at), "dd/MM/yyyy")
          })
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)(PendingMeasurementSection, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx("div", {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
            size: "tiny",
            children: "Started by"
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx("div", {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(AvatarContainer, {
            size: "1.5rem",
            children: (_measurement$user = measurement.user) !== null && _measurement$user !== void 0 && _measurement$user.profile_picture ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(Image, {
              src: (_measurement$user2 = measurement.user) === null || _measurement$user2 === void 0 ? void 0 : _measurement$user2.profile_picture,
              alt: `${(_measurement$user3 = measurement.user) === null || _measurement$user3 === void 0 ? void 0 : _measurement$user3.first_name} ${(_measurement$user4 = measurement.user) === null || _measurement$user4 === void 0 ? void 0 : _measurement$user4.last_name}`
            }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)(_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
              size: "body",
              color: "white",
              children: [((_measurement$user5 = measurement.user) === null || _measurement$user5 === void 0 ? void 0 : (_measurement$user5$fi = _measurement$user5.first_name) === null || _measurement$user5$fi === void 0 ? void 0 : _measurement$user5$fi.charAt(0)) || "?", " "]
            })
          })
        })]
      })]
    }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.Fragment, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_common_Divider__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
        margin: "0.5rem 2rem 0.75rem"
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)(MobilePendingMeasurementSection, {
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)("div", {
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)(_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
            size: "tiny",
            fontWeight: "400",
            children: ["Date Submitted:", " "]
          }), " ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)(_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
            size: "tiny",
            color: "blue",
            fontWeight: "400",
            children: [(0,date_fns__WEBPACK_IMPORTED_MODULE_1__.format)(new Date(measurement.submitted_at || measurement.updated_at), "dd/MM/yyyy"), " "]
          })]
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)(MobileAvatarContainer, {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
            size: "tiny",
            children: "Started by: "
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(AvatarContainer, {
            size: "1.5rem",
            children: (_measurement$user6 = measurement.user) !== null && _measurement$user6 !== void 0 && _measurement$user6.profile_picture ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(Image, {
              src: (_measurement$user7 = measurement.user) === null || _measurement$user7 === void 0 ? void 0 : _measurement$user7.profile_picture,
              alt: `${(_measurement$user8 = measurement.user) === null || _measurement$user8 === void 0 ? void 0 : _measurement$user8.first_name} ${(_measurement$user9 = measurement.user) === null || _measurement$user9 === void 0 ? void 0 : _measurement$user9.last_name}`
            }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)(_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
              size: "body",
              color: "white",
              children: [((_measurement$user10 = measurement.user) === null || _measurement$user10 === void 0 ? void 0 : (_measurement$user10$f = _measurement$user10.first_name) === null || _measurement$user10$f === void 0 ? void 0 : _measurement$user10$f.charAt(0)) || "?", " "]
            })
          })]
        })]
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(PendingMeasurementSection, {
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)(InprogressButtonsContainer, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP, {
          href: `/measurements/${measurement.id}/result`,
          children: "Result"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP, {
          secondary: true,
          onClick: () => router.push(`/measurements/[id]`, `/measurements/${measurement.id}`),
          children: "Inputs"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP, {
          secondary: true,
          warning: true,
          onClick: () => setShowDeleteConfirmationModal(!showDeleteConfirmationModal),
          children: "Delete"
        })]
      })
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PendingMeasurementItem);

/***/ }),

/***/ 97170:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(74146);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(date_fns__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16666);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_responsive__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _button_Button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(59067);
/* harmony import */ var _common_ProgressBar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(45486);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(87491);
/* harmony import */ var _form_Error__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(26428);
/* harmony import */ var _contexts_auth__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(58368);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(72994);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__);













const InProgressMeasurementContainer = styled_components__WEBPACK_IMPORTED_MODULE_9___default().div.withConfig({
  displayName: "PathToNetZero__InProgressMeasurementContainer",
  componentId: "sc-1cssmab-0"
})(["background:", ";width:100%;", " display:flex;flex-direction:column;padding:1rem 2rem;&:not(:last-child){margin-bottom:1rem;}", ""], p => p.theme.colors.white, _styles__WEBPACK_IMPORTED_MODULE_7__/* .borderRadius */ .E, _theme__WEBPACK_IMPORTED_MODULE_8__/* .media.tablet */ .BC.tablet`
    width: 90%;
  `);
const TitleContainer = styled_components__WEBPACK_IMPORTED_MODULE_9___default().div.withConfig({
  displayName: "PathToNetZero__TitleContainer",
  componentId: "sc-1cssmab-1"
})(["display:flex;justify-content:flex-start;margin-bottom:1rem;"]);
const MarkersContainer = styled_components__WEBPACK_IMPORTED_MODULE_9___default().div.withConfig({
  displayName: "PathToNetZero__MarkersContainer",
  componentId: "sc-1cssmab-2"
})(["display:flex;justify-content:space-between;"]);
const ButtonContainer = styled_components__WEBPACK_IMPORTED_MODULE_9___default().div.withConfig({
  displayName: "PathToNetZero__ButtonContainer",
  componentId: "sc-1cssmab-3"
})(["display:flex;justify-content:center;align-items:center;margin-bottom:1rem;"]);

const PathToNetZero = ({
  onCreateClick,
  measurements
}) => {
  var _measurements$, _measurements$2;

  const {
    organisation
  } = (0,_contexts_auth__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)();
  const isDesktop = (0,react_responsive__WEBPACK_IMPORTED_MODULE_1__.useMediaQuery)({
    query: `(min-width: ${_theme__WEBPACK_IMPORTED_MODULE_8__/* .sizes.desktop */ .J7.desktop}px)`
  });
  const startDate = measurements.length && (_measurements$ = measurements[0]) !== null && _measurements$ !== void 0 && _measurements$.period_start ? (_measurements$2 = measurements[0]) === null || _measurements$2 === void 0 ? void 0 : _measurements$2.period_start : organisation.created_at;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(InProgressMeasurementContainer, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(TitleContainer, {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP, {
        size: "cardHeader",
        children: measurements !== null && measurements !== void 0 && measurements.length ? "Your pathway to Net Zero" : "Start your pathway to Net zero"
      })
    }), organisation.net_zero_target ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.Fragment, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_common_ProgressBar__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        value: (0,date_fns__WEBPACK_IMPORTED_MODULE_0__.differenceInYears)(new Date(), new Date(startDate)) || 1,
        max: organisation.net_zero_target
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(MarkersContainer, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP, {
          children: (0,date_fns__WEBPACK_IMPORTED_MODULE_0__.getYear)(new Date(startDate))
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP, {
          children: (0,date_fns__WEBPACK_IMPORTED_MODULE_0__.getYear)((0,date_fns__WEBPACK_IMPORTED_MODULE_0__.addYears)(new Date(startDate), organisation.net_zero_target))
        })]
      })]
    }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(ButtonContainer, {
      children: isDesktop ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
        onClick: onCreateClick,
        disabled: true,
        children: "New Measurement"
      }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_form_Error__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
        children: "Login on desktop to start a measurement."
      })
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PathToNetZero);

/***/ }),

/***/ 51691:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(74146);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(date_fns__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(16666);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_responsive__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _button_Button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(59067);
/* harmony import */ var _common_Divider__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6459);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(87491);
/* harmony import */ var _contexts_auth__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(58368);
/* harmony import */ var _contexts_measurements__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(85238);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(72994);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(91073);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(11098);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _common_ButtonsContainer__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(30495);
/* harmony import */ var _DeleteMeasurementModal__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(81324);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__);



















const PendingMeasurementContainer = styled_components__WEBPACK_IMPORTED_MODULE_13___default().div.withConfig({
  displayName: "PendingMeasurementItem__PendingMeasurementContainer",
  componentId: "sc-77z7qy-0"
})(["background:", ";width:100%;", " display:flex;padding:0.625rem 0;flex-wrap:wrap;align-items:center;justify-content:center;&:not(:last-child){margin-bottom:1rem;}", " ", ""], p => p.theme.colors.white, _styles__WEBPACK_IMPORTED_MODULE_10__/* .borderRadius */ .E, _theme__WEBPACK_IMPORTED_MODULE_11__/* .media.tablet */ .BC.tablet`
    justify-content: flex-start;
    flex-wrap: initial;
    max-width: 60rem;
    width: 100%;
  `, _theme__WEBPACK_IMPORTED_MODULE_11__/* .media.tabletLarge */ .BC.tabletLarge`
    width: 90%;
  `);
const PendingMeasurementSection = styled_components__WEBPACK_IMPORTED_MODULE_13___default().div.withConfig({
  displayName: "PendingMeasurementItem__PendingMeasurementSection",
  componentId: "sc-77z7qy-1"
})(["display:flex;justify-content:center;align-items:center;flex-direction:column;", " ", ""], _theme__WEBPACK_IMPORTED_MODULE_11__/* .media.tablet */ .BC.tablet`
      margin: 0 0.5rem;
  `, _theme__WEBPACK_IMPORTED_MODULE_11__/* .media.desktop */ .BC.desktop`
      margin: 0 1rem;
  `);
const AvatarContainer = styled_components__WEBPACK_IMPORTED_MODULE_13___default().div.withConfig({
  displayName: "PendingMeasurementItem__AvatarContainer",
  componentId: "sc-77z7qy-2"
})(["min-width:", ";width:", ";height:", ";display:flex;align-items:center;justify-content:center;border-radius:50%;background-color:", ";", ""], p => p.size || "2rem", p => p.size || "2rem", p => p.size || "2rem", p => p.theme.colors.progressYellow, _theme__WEBPACK_IMPORTED_MODULE_11__/* .media.tablet */ .BC.tablet`
  min-width: ${p => p.size || "2rem"};
  width: ${p => p.size || "2rem"};
  height: ${p => p.size || "2rem"};
  `);
const Image = styled_components__WEBPACK_IMPORTED_MODULE_13___default().img.withConfig({
  displayName: "PendingMeasurementItem__Image",
  componentId: "sc-77z7qy-3"
})(["width:100%;height:100%;border-radius:50%;object-fit:cover;"]);
const PeriodPendingMeasurementSection = styled_components__WEBPACK_IMPORTED_MODULE_13___default()(PendingMeasurementSection).withConfig({
  displayName: "PendingMeasurementItem__PeriodPendingMeasurementSection",
  componentId: "sc-77z7qy-4"
})(["width:100%;", ""], _theme__WEBPACK_IMPORTED_MODULE_11__/* .media.tablet */ .BC.tablet`
    width: 14%;
  `);
const InprogressButtonsContainer = styled_components__WEBPACK_IMPORTED_MODULE_13___default()(_common_ButtonsContainer__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z).withConfig({
  displayName: "PendingMeasurementItem__InprogressButtonsContainer",
  componentId: "sc-77z7qy-5"
})(["margin:0;margin-top:1rem;& > *:not(:first-child){margin-left:1rem;}", ""], _theme__WEBPACK_IMPORTED_MODULE_11__/* .media.tablet */ .BC.tablet`
    margin-top: 0;
  `);
const MobileAvatarContainer = styled_components__WEBPACK_IMPORTED_MODULE_13___default().div.withConfig({
  displayName: "PendingMeasurementItem__MobileAvatarContainer",
  componentId: "sc-77z7qy-6"
})(["display:flex;align-items:center;"]);
const MobilePendingMeasurementSection = styled_components__WEBPACK_IMPORTED_MODULE_13___default()(PendingMeasurementSection).withConfig({
  displayName: "PendingMeasurementItem__MobilePendingMeasurementSection",
  componentId: "sc-77z7qy-7"
})(["align-items:flex-start;margin-right:1rem;"]);

const PendingMeasurementItem = ({
  measurement
}) => {
  var _measurement$user, _measurement$user2, _measurement$user3, _measurement$user4, _measurement$user5, _measurement$user5$fi, _measurement$user6, _measurement$user7, _measurement$user8, _measurement$user9, _measurement$user10, _measurement$user10$f;

  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
  const {
    user
  } = (0,_contexts_auth__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
  const {
    0: showDeleteConfirmationModal,
    1: setShowDeleteConfirmationModal
  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)();
  const {
    getMeasurements,
    setLoading
  } = (0,_contexts_measurements__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)();
  const isTablet = (0,react_responsive__WEBPACK_IMPORTED_MODULE_4__.useMediaQuery)({
    query: `(min-width: ${_theme__WEBPACK_IMPORTED_MODULE_11__/* .sizes.tablet */ .J7.tablet}px)`
  });

  const discardMeasurement = async () => {
    setLoading(true);

    try {
      await axios__WEBPACK_IMPORTED_MODULE_0___default()["delete"](`/api/organisations/${user.organisation_id}/measurements/${measurement.id}`);
      await getMeasurements();
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_12__/* .logError */ .H)(error);
    }

    setLoading(false);
  };

  const yearString = [...new Set([(0,date_fns__WEBPACK_IMPORTED_MODULE_1__.format)(new Date(measurement === null || measurement === void 0 ? void 0 : measurement.year, measurement === null || measurement === void 0 ? void 0 : measurement.month), "MM/yyyy"), (0,date_fns__WEBPACK_IMPORTED_MODULE_1__.format)((0,date_fns__WEBPACK_IMPORTED_MODULE_1__.subDays)((0,date_fns__WEBPACK_IMPORTED_MODULE_1__.addMonths)(new Date(measurement === null || measurement === void 0 ? void 0 : measurement.year, measurement === null || measurement === void 0 ? void 0 : measurement.month), measurement === null || measurement === void 0 ? void 0 : measurement.time_period), 1), "MM/yyyy")])].join(" - ");
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)(PendingMeasurementContainer, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_DeleteMeasurementModal__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
      showConfirmationModal: showDeleteConfirmationModal,
      setShowConfirmationModal: setShowDeleteConfirmationModal,
      onConfirm: discardMeasurement
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)(PeriodPendingMeasurementSection, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx("div", {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
          size: "tiny",
          children: "Period"
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx("div", {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
          size: "subtitleBold",
          color: "blue",
          children: yearString
        })
      })]
    }), isTablet ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.Fragment, {
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)(PendingMeasurementSection, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx("div", {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
            size: "tiny",
            children: "Date Submitted"
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx("div", {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
            size: "subtitleBold",
            color: "blue",
            children: (0,date_fns__WEBPACK_IMPORTED_MODULE_1__.format)(new Date(measurement.submitted_at || measurement.updated_at), "dd/MM/yyyy")
          })
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)(PendingMeasurementSection, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx("div", {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
            size: "tiny",
            children: "Started by"
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx("div", {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(AvatarContainer, {
            size: "1.5rem",
            children: (_measurement$user = measurement.user) !== null && _measurement$user !== void 0 && _measurement$user.profile_picture ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(Image, {
              src: (_measurement$user2 = measurement.user) === null || _measurement$user2 === void 0 ? void 0 : _measurement$user2.profile_picture,
              alt: `${(_measurement$user3 = measurement.user) === null || _measurement$user3 === void 0 ? void 0 : _measurement$user3.first_name} ${(_measurement$user4 = measurement.user) === null || _measurement$user4 === void 0 ? void 0 : _measurement$user4.last_name}`
            }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)(_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
              size: "body",
              color: "white",
              children: [((_measurement$user5 = measurement.user) === null || _measurement$user5 === void 0 ? void 0 : (_measurement$user5$fi = _measurement$user5.first_name) === null || _measurement$user5$fi === void 0 ? void 0 : _measurement$user5$fi.charAt(0)) || "?", " "]
            })
          })
        })]
      })]
    }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.Fragment, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_common_Divider__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
        margin: "0.5rem 2rem 0.75rem"
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)(MobilePendingMeasurementSection, {
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)("div", {
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)(_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
            size: "tiny",
            fontWeight: "400",
            children: ["Date Submitted:", " "]
          }), " ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)(_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
            size: "tiny",
            color: "blue",
            fontWeight: "400",
            children: [(0,date_fns__WEBPACK_IMPORTED_MODULE_1__.format)(new Date(measurement.submitted_at || measurement.updated_at), "dd/MM/yyyy"), " "]
          })]
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)(MobileAvatarContainer, {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
            size: "tiny",
            children: "Started by: "
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(AvatarContainer, {
            size: "1.5rem",
            children: (_measurement$user6 = measurement.user) !== null && _measurement$user6 !== void 0 && _measurement$user6.profile_picture ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(Image, {
              src: (_measurement$user7 = measurement.user) === null || _measurement$user7 === void 0 ? void 0 : _measurement$user7.profile_picture,
              alt: `${(_measurement$user8 = measurement.user) === null || _measurement$user8 === void 0 ? void 0 : _measurement$user8.first_name} ${(_measurement$user9 = measurement.user) === null || _measurement$user9 === void 0 ? void 0 : _measurement$user9.last_name}`
            }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)(_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
              size: "body",
              color: "white",
              children: [((_measurement$user10 = measurement.user) === null || _measurement$user10 === void 0 ? void 0 : (_measurement$user10$f = _measurement$user10.first_name) === null || _measurement$user10$f === void 0 ? void 0 : _measurement$user10$f.charAt(0)) || "?", " "]
            })
          })]
        })]
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(PendingMeasurementSection, {
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)(InprogressButtonsContainer, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP, {
          secondary: true,
          onClick: () => router.push(`/measurements/[id]`, `/measurements/${measurement.id}`),
          children: "Inputs"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP, {
          secondary: true,
          warning: true,
          onClick: () => setShowDeleteConfirmationModal(!showDeleteConfirmationModal),
          children: "Delete"
        })]
      })
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PendingMeasurementItem);

/***/ }),

/***/ 81339:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_calendly__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(40776);
/* harmony import */ var react_calendly__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_calendly__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(16666);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_responsive__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_button_Button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(59067);
/* harmony import */ var _components_common_LoadingLarge__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(49899);
/* harmony import */ var _components_common_Page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(97598);
/* harmony import */ var _components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(60805);
/* harmony import */ var _components_common_Text__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(87491);
/* harmony import */ var _components_ContentContainer__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(16067);
/* harmony import */ var _components_measurement_InprogressMeasurementItem__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(37820);
/* harmony import */ var _components_measurement_MeasurementBarChart__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(84116);
/* harmony import */ var _components_measurement_MeasurementModal__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(76296);
/* harmony import */ var _components_measurement_MeasurementPieChart__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(95411);
/* harmony import */ var _components_measurement_PastMeasurementItem__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(68291);
/* harmony import */ var _components_measurement_PathToNetZero__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(97170);
/* harmony import */ var _components_measurement_PendingMeasurementItem__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(51691);
/* harmony import */ var _contexts_auth__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(58368);
/* harmony import */ var _contexts_measurements__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(85238);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(91073);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(11098);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_8__, _components_measurement_MeasurementModal__WEBPACK_IMPORTED_MODULE_13__]);
([_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_8__, _components_measurement_MeasurementModal__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



























const InprogressMeasurementList = styled_components__WEBPACK_IMPORTED_MODULE_22___default().div.withConfig({
  displayName: "measurements__InprogressMeasurementList",
  componentId: "sc-1a328ha-0"
})(["margin:1rem 0;"]);
const MeasurementResultCharts = styled_components__WEBPACK_IMPORTED_MODULE_22___default().div.withConfig({
  displayName: "measurements__MeasurementResultCharts",
  componentId: "sc-1a328ha-1"
})(["margin:1rem 0;", ""], _theme__WEBPACK_IMPORTED_MODULE_20__/* .media.desktop */ .BC.desktop`
    display: flex;

    & > div:first-child {
      margin-right: 1%;
    }
  `);
const MostRecentTitleContainer = styled_components__WEBPACK_IMPORTED_MODULE_22___default().div.withConfig({
  displayName: "measurements__MostRecentTitleContainer",
  componentId: "sc-1a328ha-2"
})(["display:flex;align-items:center;& > *:last-child{margin-left:1rem;}"]);

const Measurement = () => {
  const {
    organisation,
    user,
    isAdmin
  } = (0,_contexts_auth__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z)();
  const {
    0: showNewMeasurementModal,
    1: setShowNewMeasurementModal
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
  const {
    getMeasurements,
    measurements,
    mostRecentMeasurementWithResult,
    loading,
    setLoading,
    setProgress
  } = (0,_contexts_measurements__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z)();
  const {
    0: createLoading,
    1: setCreateLoading
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
  const isDesktop = (0,react_responsive__WEBPACK_IMPORTED_MODULE_4__.useMediaQuery)({
    query: `(min-width: ${_theme__WEBPACK_IMPORTED_MODULE_20__/* .sizes.desktop */ .J7.desktop}px)`
  });

  const handleCreateClick = async ({
    period_end,
    period_start
  }) => {
    try {
      setCreateLoading(true);
      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_0___default().post(`/api/organisations/${organisation.id}/measurements`, _objectSpread({
        period_end,
        period_start,
        user_id: user.id
      }, organisation.net_zero_target ? {
        last_completed_step: "net_zero_target"
      } : {}));
      return router.push(`/measurements/[id]/details`, `/measurements/${data.id}/details`);
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_21__/* .logError */ .H)(error);
    }

    setCreateLoading(false);
  };

  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(() => {
    getMeasurements();
  }, []);

  const handleBookClick = () => (0,react_calendly__WEBPACK_IMPORTED_MODULE_3__.openPopupWidget)({
    url: "https://calendly.com/inhabit-meet/inhabit-measurement-tutorial",
    prefill: {
      firstName: user === null || user === void 0 ? void 0 : user.first_name,
      lastName: user === null || user === void 0 ? void 0 : user.last_name,
      email: user === null || user === void 0 ? void 0 : user.email,
      name: `${user === null || user === void 0 ? void 0 : user.first_name} ${user === null || user === void 0 ? void 0 : user.last_name}`
    }
  });

  const completeMeasurements = measurements.filter(({
    state,
    result,
    id
  }) => state === "complete" && !!result && id !== (mostRecentMeasurementWithResult === null || mostRecentMeasurementWithResult === void 0 ? void 0 : mostRecentMeasurementWithResult.id));
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(_components_common_Page__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsxs)(_components_ContentContainer__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
      title: "Carbon Measurements",
      cta: !isAdmin({
        organisation,
        user
      }) ? null : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(_components_button_Button__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP, {
        onClick: () => setShowNewMeasurementModal(!showNewMeasurementModal),
        disabled: true,
        children: "New Measurement"
      }),
      secondaryCta: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(_components_button_Button__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP, {
        onClick: handleBookClick,
        secondary: true,
        children: "Book A Call"
      }),
      children: [loading && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(_components_common_LoadingLarge__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
        loading: loading,
        text: "Initialising Measurement...",
        setProgress: setProgress
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(_components_measurement_MeasurementModal__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
        showModal: showNewMeasurementModal,
        setShowModal: setShowNewMeasurementModal,
        onConfirm: handleCreateClick,
        loading: createLoading,
        setLoading: setCreateLoading,
        confirmClose: true
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(_components_measurement_PathToNetZero__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
        measurements: measurements,
        onCreateClick: () => setShowNewMeasurementModal(!showNewMeasurementModal)
      }), !!mostRecentMeasurementWithResult && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.Fragment, {
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsxs)(MostRecentTitleContainer, {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .ZP, {
            size: "cardHeader",
            children: "Most Recent: "
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(_components_button_Button__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP, {
            secondary: true,
            href: `/measurements/${mostRecentMeasurementWithResult.id}/result`,
            children: "See breakdown"
          })]
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsxs)(MeasurementResultCharts, {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(_components_measurement_MeasurementPieChart__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
            width: "30%",
            measurement: mostRecentMeasurementWithResult,
            isMonthly: mostRecentMeasurementWithResult.time_period === 1
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(_components_measurement_MeasurementBarChart__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
            measurement: mostRecentMeasurementWithResult,
            isMonthly: mostRecentMeasurementWithResult.time_period === 1
          })]
        })]
      }), !!measurements.filter(({
        state
      }) => state === "draft").length && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.Fragment, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .ZP, {
          size: "cardHeader",
          children: "In progress:"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(InprogressMeasurementList, {
          children: measurements.filter(({
            state
          }) => state === "draft").map(measurement => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(_components_measurement_InprogressMeasurementItem__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
            measurement: measurement
          }, measurement.id))
        })]
      }), !!measurements.filter(({
        state,
        result
      }) => state === "pending" && !result).length && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.Fragment, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .ZP, {
          size: "cardHeader",
          children: "Pending measurements:"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(InprogressMeasurementList, {
          children: measurements.filter(({
            state,
            result
          }) => state === "pending" && !result).map(measurement => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(_components_measurement_PendingMeasurementItem__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
            measurement: measurement
          }, measurement.id))
        })]
      }), !!completeMeasurements.length && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.Fragment, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(_components_common_Text__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .ZP, {
          size: "cardHeader",
          children: "Past measurements:"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(InprogressMeasurementList, {
          children: completeMeasurements.map(measurement => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(_components_measurement_PastMeasurementItem__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
            measurement: measurement
          }, measurement.id))
        })]
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_components_common_ProtectRoute__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)(Measurement));
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 82591:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "unstable_getStaticParams": () => (/* binding */ unstable_getStaticParams),
/* harmony export */   "unstable_getStaticProps": () => (/* binding */ unstable_getStaticProps),
/* harmony export */   "unstable_getStaticPaths": () => (/* binding */ unstable_getStaticPaths),
/* harmony export */   "unstable_getServerProps": () => (/* binding */ unstable_getServerProps),
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "_app": () => (/* binding */ _app),
/* harmony export */   "renderReqToHTML": () => (/* binding */ renderReqToHTML),
/* harmony export */   "render": () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(70607);
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59450);
/* harmony import */ var private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97020);
/* harmony import */ var private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(73978);
/* harmony import */ var next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99436);

      
      
      
      

      
      const { processEnv } = __webpack_require__(85360)
      processEnv([{"path":".env","contents":"API_HOST=https://api.inhabit.eco\nNEXT_PUBLIC_CALENDLY_URL=https://calendly.com/inhabit-meet/inhabit-measurement-tutorial\nNEXT_PUBLIC_FLAGS_ENVIRONMENT_KEY=flags_pub_289425705564897805\nNEXT_PUBLIC_GOOGLE_ANALYTICS=G-1CBB78XFQ4\nNEXT_PUBLIC_INTERCOM_APP_ID=bw9p6mfd\nNEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_bQDaTEuYc10x3BZt9YcGj2cE00Gzwm4gDD\nSTRIPE_PUBLISHABLE_KEY=pk_live_bQDaTEuYc10x3BZt9YcGj2cE00Gzwm4gDD\n\n"}])
    
      
      const runtimeConfig = {}
      ;

      const documentModule = __webpack_require__(9968)

      const appMod = __webpack_require__(13724)
      let App = appMod.default || appMod.then && appMod.then(mod => mod.default);

      const compMod = __webpack_require__(81339)

      const Component = compMod.default || compMod.then && compMod.then(mod => mod.default)
      /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Component);
      const getStaticProps = compMod['getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['getStaticProp' + 's'])
      const getStaticPaths = compMod['getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['getStaticPath' + 's'])
      const getServerSideProps = compMod['getServerSideProp' + 's'] || compMod.then && compMod.then(mod => mod['getServerSideProp' + 's'])

      // kept for detecting legacy exports
      const unstable_getStaticParams = compMod['unstable_getStaticParam' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticParam' + 's'])
      const unstable_getStaticProps = compMod['unstable_getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticProp' + 's'])
      const unstable_getStaticPaths = compMod['unstable_getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticPath' + 's'])
      const unstable_getServerProps = compMod['unstable_getServerProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getServerProp' + 's'])

      let config = compMod['confi' + 'g'] || (compMod.then && compMod.then(mod => mod['confi' + 'g'])) || {}
      const _app = App

      const combinedRewrites = Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)
        ? private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg
        : []

      if (!Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)) {
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.beforeFiles */ .Dg.beforeFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.afterFiles */ .Dg.afterFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.fallback */ .Dg.fallback)
      }

      const { renderReqToHTML, render } = (0,next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__/* .getPageHandler */ .u)({
        pageModule: compMod,
        pageComponent: Component,
        pageConfig: config,
        appModule: App,
        documentModule: documentModule,
        errorModule: __webpack_require__(99651),
        notFoundModule: undefined,
        pageGetStaticProps: getStaticProps,
        pageGetStaticPaths: getStaticPaths,
        pageGetServerSideProps: getServerSideProps,

        assetPrefix: "",
        canonicalBase: "",
        generateEtags: true,
        poweredByHeader: true,
        reactRoot: false,

        runtimeConfig,
        buildManifest: private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__,
        reactLoadableManifest: private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__,

        rewrites: combinedRewrites,
        i18n: undefined,
        page: "/measurements",
        buildId: "lDoX7RBEQ31kzKIJJbkVC",
        escapedBuildId: "lDoX7RBEQ31kzKIJJbkVC",
        basePath: "",
        pageIsDynamic: false,
        encodedPreviewProps: {previewModeId:"89cdc9f6073608262d43eab6d636f3f4",previewModeSigningKey:"74c7e36a2414a3f7b0ebcc67250f915f156686e1610b45a21ae9358d5b7c6c5a",previewModeEncryptionKey:"8a4c97ad9e5cf12d5a140689be08539ea52d8b27a416c2b8ae67db636b45841b"}
      })
      
    

/***/ }),

/***/ 94970:
/***/ ((module) => {

module.exports = require("@happykit/flags/client");

/***/ }),

/***/ 46411:
/***/ ((module) => {

module.exports = require("@happykit/flags/config");

/***/ }),

/***/ 48095:
/***/ ((module) => {

module.exports = require("@happykit/flags/server");

/***/ }),

/***/ 83218:
/***/ ((module) => {

module.exports = require("@hookform/error-message");

/***/ }),

/***/ 37730:
/***/ ((module) => {

module.exports = require("@material-ui/core/ClickAwayListener");

/***/ }),

/***/ 26481:
/***/ ((module) => {

module.exports = require("@material-ui/core/TextField");

/***/ }),

/***/ 48308:
/***/ ((module) => {

module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ 21774:
/***/ ((module) => {

module.exports = require("@material-ui/lab/AdapterDateFns");

/***/ }),

/***/ 57229:
/***/ ((module) => {

module.exports = require("@material-ui/lab/DatePicker");

/***/ }),

/***/ 19766:
/***/ ((module) => {

module.exports = require("@material-ui/lab/LocalizationProvider");

/***/ }),

/***/ 85360:
/***/ ((module) => {

module.exports = require("@next/env");

/***/ }),

/***/ 64515:
/***/ ((module) => {

module.exports = require("@stripe/react-stripe-js");

/***/ }),

/***/ 20943:
/***/ ((module) => {

module.exports = require("@stripe/stripe-js");

/***/ }),

/***/ 52167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 74146:
/***/ ((module) => {

module.exports = require("date-fns");

/***/ }),

/***/ 1043:
/***/ ((module) => {

module.exports = require("lodash.get");

/***/ }),

/***/ 51650:
/***/ ((module) => {

module.exports = require("lodash.uniqby");

/***/ }),

/***/ 54426:
/***/ ((module) => {

module.exports = require("next/dist/compiled/chalk");

/***/ }),

/***/ 40252:
/***/ ((module) => {

module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 19371:
/***/ ((module) => {

module.exports = require("next/dist/compiled/node-fetch");

/***/ }),

/***/ 97999:
/***/ ((module) => {

module.exports = require("next/dist/compiled/path-to-regexp");

/***/ }),

/***/ 60600:
/***/ ((module) => {

module.exports = require("next/dist/server/accept-header.js");

/***/ }),

/***/ 52155:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils/index.js");

/***/ }),

/***/ 90730:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils/node.js");

/***/ }),

/***/ 60562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 94140:
/***/ ((module) => {

module.exports = require("next/dist/server/get-page-files.js");

/***/ }),

/***/ 89716:
/***/ ((module) => {

module.exports = require("next/dist/server/htmlescape.js");

/***/ }),

/***/ 25071:
/***/ ((module) => {

module.exports = require("next/dist/server/render-result.js");

/***/ }),

/***/ 33100:
/***/ ((module) => {

module.exports = require("next/dist/server/render.js");

/***/ }),

/***/ 92779:
/***/ ((module) => {

module.exports = require("next/dist/server/request-meta.js");

/***/ }),

/***/ 79502:
/***/ ((module) => {

module.exports = require("next/dist/server/send-payload.js");

/***/ }),

/***/ 76368:
/***/ ((module) => {

module.exports = require("next/dist/server/utils.js");

/***/ }),

/***/ 56724:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 27664:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/escape-regexp.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 94957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 82374:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-locale-cookie.js");

/***/ }),

/***/ 34014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 78524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 78020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 29565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 64365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 95714:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-route-from-asset-path.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 91292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 25753:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-match.js");

/***/ }),

/***/ 99521:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/prepare-destination.js");

/***/ }),

/***/ 80979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 36052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 84226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 95566:
/***/ ((module) => {

module.exports = require("next/error");

/***/ }),

/***/ 40968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 71853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 59819:
/***/ ((module) => {

module.exports = require("querystring");

/***/ }),

/***/ 16689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 40776:
/***/ ((module) => {

module.exports = require("react-calendly");

/***/ }),

/***/ 25716:
/***/ ((module) => {

module.exports = require("react-hotjar");

/***/ }),

/***/ 16666:
/***/ ((module) => {

module.exports = require("react-responsive");

/***/ }),

/***/ 1187:
/***/ ((module) => {

module.exports = require("react-toastify");

/***/ }),

/***/ 20997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 36157:
/***/ ((module) => {

module.exports = require("recharts");

/***/ }),

/***/ 57518:
/***/ ((module) => {

module.exports = require("styled-components");

/***/ }),

/***/ 24535:
/***/ ((module) => {

module.exports = require("styled-normalize");

/***/ }),

/***/ 6153:
/***/ ((module) => {

module.exports = require("universal-cookie");

/***/ }),

/***/ 84269:
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ 75609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 61908:
/***/ ((module) => {

module.exports = import("@hookform/resolvers/yup");;

/***/ }),

/***/ 45641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [4357,9703,6114,9067,8183,9899,805,6067,1233,9343,4610,5411], () => (__webpack_exec__(82591)));
module.exports = __webpack_exports__;

})();