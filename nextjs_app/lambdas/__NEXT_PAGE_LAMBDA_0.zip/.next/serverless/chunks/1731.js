"use strict";
exports.id = 1731;
exports.ids = [1731];
exports.modules = {

/***/ 21731:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16666);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_responsive__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(87491);
/* harmony import */ var _contexts_auth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(58368);
/* harmony import */ var _lib_projects__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(27898);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(72994);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(91073);
/* harmony import */ var _utils_text__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(88703);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _button_Button__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(59067);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__);











const rotateContainer = (0,styled_components__WEBPACK_IMPORTED_MODULE_6__.css)(["height:unset;", " ", ""], _theme__WEBPACK_IMPORTED_MODULE_5__/* .media.tablet */ .BC.tablet`
  height: auto;
  padding: 1rem;
  margin: 0 auto;
  `, _theme__WEBPACK_IMPORTED_MODULE_5__/* .media.tabletLarge */ .BC.tabletLarge`
    width: 313px;
  flex-direction: column;
  `);
const rotateImage = (0,styled_components__WEBPACK_IMPORTED_MODULE_6__.css)(["flex-direction:column;width:280px;height:150px;display:flex;", " ", ""], _theme__WEBPACK_IMPORTED_MODULE_5__/* .media.tablet */ .BC.tablet`
    width: 100%;;
    height: 100%;
    max-width: 50%;
  `, _theme__WEBPACK_IMPORTED_MODULE_5__/* .media.tabletLarge */ .BC.tabletLarge`
    width: 280px;
    height: 150px;
    max-width: unset;
    margin: 0 0 2rem 0;
  `);
const rotateIcons = (0,styled_components__WEBPACK_IMPORTED_MODULE_6__.css)(["width:100%;display:flex;align-items:center;flex-direction:column;max-width:unset;text-align:center;"]);
const Container = styled_components__WEBPACK_IMPORTED_MODULE_6___default().div.withConfig({
  displayName: "ProjectItem__Container",
  componentId: "hp7ddz-0"
})(["background-color:", ";display:flex;align-items:center;height:12.5rem;padding:1rem;position:relative;", " ", " ", " ", ""], p => p.theme.colors.white, _styles__WEBPACK_IMPORTED_MODULE_4__/* .borderRadius */ .E, _theme__WEBPACK_IMPORTED_MODULE_5__/* .media.tablet */ .BC.tablet`
    height: 18.5rem;
  `, _theme__WEBPACK_IMPORTED_MODULE_5__/* .media.desktop */ .BC.desktop`
    padding: 1rem;
    height: 18.5rem;
  `, p => p.rotate && rotateContainer);
const ImageContainer = styled_components__WEBPACK_IMPORTED_MODULE_6___default().div.withConfig({
  displayName: "ProjectItem__ImageContainer",
  componentId: "hp7ddz-1"
})(["height:100%;width:100%;max-width:50%;", " margin-right:1.25rem;", " ", " ", ""], _styles__WEBPACK_IMPORTED_MODULE_4__/* .borderRadius */ .E, p => p.rotate && rotateImage, _theme__WEBPACK_IMPORTED_MODULE_5__/* .media.tablet */ .BC.tablet`
  ${p => p.rotate && rotateImage}
`, _theme__WEBPACK_IMPORTED_MODULE_5__/* .media.desktop */ .BC.desktop`

  height: 16.5rem;

  width: 13.75rem;
    ${p => p.rotate && rotateImage}

  `);
const Image = styled_components__WEBPACK_IMPORTED_MODULE_6___default().img.withConfig({
  displayName: "ProjectItem__Image",
  componentId: "hp7ddz-2"
})(["width:100%;height:100%;", " object-fit:cover;"], _styles__WEBPACK_IMPORTED_MODULE_4__/* .borderRadius */ .E);
const IconsContainer = styled_components__WEBPACK_IMPORTED_MODULE_6___default().div.withConfig({
  displayName: "ProjectItem__IconsContainer",
  componentId: "hp7ddz-3"
})(["max-width:50%;display:flex;flex-direction:column;justify-content:space-between;height:100%;", ""], _theme__WEBPACK_IMPORTED_MODULE_5__/* .media.tabletLarge */ .BC.tabletLarge`
    ${p => p.rotate && rotateIcons}
  `);
const TitleContainer = styled_components__WEBPACK_IMPORTED_MODULE_6___default().div.withConfig({
  displayName: "ProjectItem__TitleContainer",
  componentId: "hp7ddz-4"
})(["max-height:4.5rem;overflow:hidden;", ""], _theme__WEBPACK_IMPORTED_MODULE_5__/* .media.tabletLarge */ .BC.tabletLarge`
      max-height: 4rem;
  `);
const TextContainer = styled_components__WEBPACK_IMPORTED_MODULE_6___default().div.withConfig({
  displayName: "ProjectItem__TextContainer",
  componentId: "hp7ddz-5"
})(["margin-top:0.5rem;", ""], _theme__WEBPACK_IMPORTED_MODULE_5__/* .media.desktop */ .BC.desktop`
    margin-top: 1.25rem;
  `);
const ButtonContainer = styled_components__WEBPACK_IMPORTED_MODULE_6___default()(TextContainer).withConfig({
  displayName: "ProjectItem__ButtonContainer",
  componentId: "hp7ddz-6"
})(["display:flex;justify-content:flex-end;& > a:first-child{margin-right:0.625rem;}"]);
const Icon = styled_components__WEBPACK_IMPORTED_MODULE_6___default().div.withConfig({
  displayName: "ProjectItem__Icon",
  componentId: "hp7ddz-7"
})(["display:inline-block;margin-right:0.5rem;& > svg{height:2rem;width:2rem;", "}"], _theme__WEBPACK_IMPORTED_MODULE_5__/* .media.desktop */ .BC.desktop`
  height: 3rem;
  width: 3rem;
  `);

const ProjectItem = ({
  project,
  rotate,
  onClick
}) => {
  const {
    user,
    organisation,
    isAdmin
  } = (0,_contexts_auth__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)();
  const tablet = (0,react_responsive__WEBPACK_IMPORTED_MODULE_0__.useMediaQuery)({
    query: `(min-width: ${_theme__WEBPACK_IMPORTED_MODULE_5__/* .sizes.tablet */ .J7.tablet}px)`
  });
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(Container, {
    onClick,
    rotate,
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(ImageContainer, {
      rotate: rotate,
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(Image, {
        src: project.image
      })
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(IconsContainer, {
      rotate: rotate,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(TitleContainer, {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
          size: "breadcrumb",
          children: (0,_utils_text__WEBPACK_IMPORTED_MODULE_9__/* .truncate */ .$)(project.title, 39)
        })
      }), tablet && (project.type || project.standard) && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(TextContainer, {
        children: [project.type && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(Icon, {
          children: (0,_lib_projects__WEBPACK_IMPORTED_MODULE_3__/* .renderTypeIcon */ .L)(project.type)
        }), project.standard && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(Icon, {
          children: (0,_lib_projects__WEBPACK_IMPORTED_MODULE_3__/* .renderStandardIcon */ .G)(project.standard)
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(TextContainer, {
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(_common_Text__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
          size: tablet ? "cardTitle" : "smallBold",
          color: "blue",
          children: ["\xA3", (project.price || 0).toFixed(2)]
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
          size: tablet ? "body" : "small",
          children: " / tonne"
        })]
      }), !rotate && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(ButtonContainer, {
        children: [tablet && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
          href: "/offset/projects/[slug]",
          as: `/offset/projects/${project.slug}`,
          width: "6rem",
          secondary: true,
          children: "More Info"
        }), isAdmin({
          user,
          organisation
        }) && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
          href: "/offset/projects/[slug]/payment",
          as: `/offset/projects/${project.slug}/payment`,
          width: "6rem",
          children: "Offset"
        })]
      })]
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProjectItem);

/***/ })

};
;