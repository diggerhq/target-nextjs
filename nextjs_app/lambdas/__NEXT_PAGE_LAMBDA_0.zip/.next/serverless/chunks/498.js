"use strict";
exports.id = 498;
exports.ids = [498];
exports.modules = {

/***/ 46675:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);



const TabContent = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "Tab__TabContent",
  componentId: "woyqbf-0"
})(["padding:1rem 0 0;"]);

const Tab = ({
  children,
  testId
}) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(TabContent, {
  "data-testid": testId,
  children: children
});

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Tab);

/***/ }),

/***/ 5021:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Text__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(87491);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);






const TabLabel = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
  displayName: "Tabs__TabLabel",
  componentId: "sc-1bvn1je-0"
})(["flex:auto;text-align:center;width:100%;border-bottom:1px solid ", ";", " padding:8px 0;align-items:center;justify-content:center;display:flex;& > span{display:inline-flex;align-items:center;}:hover{", "}"], p => p.theme.colors.secondaryBlue, p => p.isActive && (0,styled_components__WEBPACK_IMPORTED_MODULE_3__.css)(["border-bottom:2px solid ", ";"], p => p.theme.colors.blue), p => !p.isActive && (0,styled_components__WEBPACK_IMPORTED_MODULE_3__.css)(["border-bottom:1px solid ", ";"], p => p.theme.colors.black));
const TabLabels = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
  displayName: "Tabs__TabLabels",
  componentId: "sc-1bvn1je-1"
})(["display:flex;align-items:stretch;cursor:pointer;border-top:1px solid ", ";"], p => p.theme.colors.secondaryBlue);
const TabContent = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
  displayName: "Tabs__TabContent",
  componentId: "sc-1bvn1je-2"
})(["", ""], p => p.isActive ? "" : "display:none;");

const Tabs = ({
  children
}) => {
  const {
    0: tabs,
    1: setTabs
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(children.length > 1 ? children : [children]);
  const {
    0: activeTab,
    1: setActiveTab
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(children.length > 1 ? children[0].props.id : children.props.id);
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
    setTabs(children);
  }, [children]);
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_0__.useRouter)();
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
    router.query.tabId && setActiveTab(router.query.tabId);
  }, [router]);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(TabLabels, {
      children: tabs.map(it => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(TabLabel, {
        isActive: it.props.id === activeTab,
        id: it.props.id,
        onClick: () => setActiveTab(it.props.id),
        labelColor: it.props.labelColor,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_Text__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
          color: it.props.id === activeTab ? "blue" : "black",
          size: "subtitle",
          children: it.props.label
        })
      }, it.props.id))
    }), tabs.map(it => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(TabContent, {
      isActive: it.props.id === activeTab,
      children: it
    }, it.props.id))]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Tabs);

/***/ })

};
;