"use strict";
exports.id = 4610;
exports.ids = [4610];
exports.modules = {

/***/ 81356:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _hookform_error_message__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(83218);
/* harmony import */ var _hookform_error_message__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_hookform_error_message__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core_ClickAwayListener__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(37730);
/* harmony import */ var _material_ui_core_ClickAwayListener__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_ClickAwayListener__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(48308);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_core_TextField__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(26481);
/* harmony import */ var _material_ui_core_TextField__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_TextField__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _material_ui_lab_AdapterDateFns__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(21774);
/* harmony import */ var _material_ui_lab_AdapterDateFns__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_material_ui_lab_AdapterDateFns__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _material_ui_lab_DatePicker__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(57229);
/* harmony import */ var _material_ui_lab_DatePicker__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_material_ui_lab_DatePicker__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _material_ui_lab_LocalizationProvider__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(19766);
/* harmony import */ var _material_ui_lab_LocalizationProvider__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_material_ui_lab_LocalizationProvider__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(45641);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(91073);
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(16170);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _Error__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(26428);
/* harmony import */ var _Input__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(18183);
/* harmony import */ var _Label__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(54251);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_8__, _Input__WEBPACK_IMPORTED_MODULE_12__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_8__, _Input__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
const _excluded = ["field"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }


















const StyledTextField = (0,_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_2__.styled)((_material_ui_core_TextField__WEBPACK_IMPORTED_MODULE_3___default()))`
  ${_Input__WEBPACK_IMPORTED_MODULE_12__/* .inputStyles */ .T}

  fieldset {
    border: none
  }

  input {
    font-weight: 500;
    padding: 0;
  }
  label {
    color: ${p => p.theme.colors.placeholderGrey};
    font-weight: ${p => p.theme.input.fontWeight};
  }
`;
const Container = styled_components__WEBPACK_IMPORTED_MODULE_10___default().div.withConfig({
  displayName: "DateInput__Container",
  componentId: "sc-1xpepu7-0"
})(["width:100%;margin-bottom:2rem;"]);
const Overlay = styled_components__WEBPACK_IMPORTED_MODULE_10___default().div.withConfig({
  displayName: "DateInput__Overlay",
  componentId: "sc-1xpepu7-1"
})(["display:", ";visibility:", ";position:fixed;overflow:scroll;z-index:10;left:0;top:0;width:100%;height:100%;background-color:rgba(0,0,0,0);"], p => p.open ? "flex" : "none", p => p.open ? "visible" : "hidden");
const InputContainer = styled_components__WEBPACK_IMPORTED_MODULE_10___default().div.withConfig({
  displayName: "DateInput__InputContainer",
  componentId: "sc-1xpepu7-2"
})(["width:100%;", " .date-picker-input{width:100%;&:disabled{background-color:white;border:none;border-bottom:0.0625rem solid ", ";}}", " ", ""], p => !p.label && "margin-top: 1.125rem;", p => p.theme.colors.black, p => p.isPlaceholder && `input {color: ${p.theme.colors.placeholderGrey};}`, p => !p.disabled && ".date-picker-input {border: 1px solid #dbdbdb;}");

const DateInput = ({
  id,
  label,
  labelColor,
  testId,
  placeholder,
  borderColor,
  disabled = false,
  width = "100%",
  minDate,
  maxDate
}) => {
  const {
    control,
    formState: {
      touchedFields,
      isValid,
      errors
    }
  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_8__.useFormContext)();
  const value = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_8__.useWatch)({
    control,
    name: id
  });

  if (errors[id]) {
    borderColor = _theme__WEBPACK_IMPORTED_MODULE_9__/* ["default"].colors.red */ .ZP.colors.red;
  }

  if (touchedFields[id] && isValid && !errors[id]) {
    borderColor = _theme__WEBPACK_IMPORTED_MODULE_9__/* ["default"].colors.green */ .ZP.colors.green;
  }

  const [isCalendarOpen, setIsCalendarOpen] = react__WEBPACK_IMPORTED_MODULE_7___default().useState(false);
  const container = (0,react__WEBPACK_IMPORTED_MODULE_7__.useRef)(null);

  const handleClose = () => setIsCalendarOpen(false);

  const toggleCalendar = () => setIsCalendarOpen(!isCalendarOpen);

  const handleClickAway = () => {
    if (isCalendarOpen) {
      setIsCalendarOpen(false);
    }
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_8__.Controller, {
    name: id,
    control: control,
    initialFocusedDate: null,
    defaultValue: null,
    render: _ref => {
      let {
        field
      } = _ref,
          rest = _objectWithoutProperties(_ref, _excluded);

      return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx((_material_ui_core_ClickAwayListener__WEBPACK_IMPORTED_MODULE_1___default()), {
        onClickAway: handleClickAway,
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)("div", {
          ref: container,
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(Overlay, {
            ref: container,
            open: isCalendarOpen,
            onClick: toggleCalendar
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx((_material_ui_lab_LocalizationProvider__WEBPACK_IMPORTED_MODULE_6___default()), {
            dateAdapter: (_material_ui_lab_AdapterDateFns__WEBPACK_IMPORTED_MODULE_4___default()),
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(styled_components__WEBPACK_IMPORTED_MODULE_10__.ThemeProvider, {
              theme: _theme__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .ZP,
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(Container, {
                "data-testid": testId,
                width: width,
                children: [label && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_Label__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                  color: labelColor,
                  htmlFor: id,
                  children: label
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(InputContainer, {
                  disabled: disabled,
                  isPlaceholder: (0,_utils_constants__WEBPACK_IMPORTED_MODULE_15__/* .isFalsy */ .X0)(value),
                  label: label,
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx((_material_ui_lab_DatePicker__WEBPACK_IMPORTED_MODULE_5___default()), _objectSpread(_objectSpread({
                    margin: "normal",
                    id: id,
                    "data-cy": id,
                    inputFormat: "dd/MM/yyyy",
                    maxDate: maxDate,
                    minDate: minDate,
                    open: isCalendarOpen,
                    onClose: handleClose,
                    onOpen: toggleCalendar,
                    PopperProps: {
                      container: container === null || container === void 0 ? void 0 : container.current
                    },
                    DialogProps: {
                      fullScreen: true
                    },
                    onChange: e => field.onChange(e),
                    renderInput: props => {
                      var _props$InputProps;

                      return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(StyledTextField, _objectSpread(_objectSpread({}, props), {}, {
                        placeholder: placeholder,
                        "data-cy": `${id}-input`,
                        onClick: handleClickAway,
                        children: (_props$InputProps = props.InputProps) === null || _props$InputProps === void 0 ? void 0 : _props$InputProps.endAdornment
                      }));
                    },
                    KeyboardButtonProps: {
                      "aria-label": "change date"
                    }
                  }, field), rest))
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_hookform_error_message__WEBPACK_IMPORTED_MODULE_0__.ErrorMessage, {
                  errors: errors,
                  name: id,
                  as: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_Error__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {})
                })]
              })
            })
          })]
        })
      });
    }
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DateInput);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 81324:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _common_ConfirmationModal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65487);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(87491);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





var Bin = function Bin(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("g", {
      clipPath: "url(#clip0)",
      fill: "#EC5F59",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("path", {
        d: "M11.768 25c-2.014 0-4.028.003-6.041 0-.49 0-.98-.006-1.467-.049-.847-.073-1.573-.835-1.622-1.719-.126-2.313-.235-4.626-.343-6.94-.16-3.384-.314-6.769-.463-10.154-.017-.38-.173-.516-.522-.489a2.16 2.16 0 0 1-.282 0C.413 5.621-.013 5.213 0 4.667c.013-.561.496-.976 1.115-.971 1.712.012 3.424.021 5.136.027 1.275 0 1.274-.005 1.486-1.298.052-.322.092-.647.176-.96.11-.42.355-.792.696-1.057.341-.264.758-.406 1.187-.403 1.335.007 2.67.026 4.007.04 1.085.01 1.81.64 1.988 1.726.083.51.174 1.019.241 1.53.04.312.18.393.49.393 2.031-.004 4.063.013 6.093.033.615.007.99.375 1 .933.008.583-.375.958-1.01.989-.786.037-.772.041-.81.872-.215 4.512-.434 9.024-.657 13.536-.048 1.032-.083 2.067-.136 3.099-.052 1.007-.8 1.796-1.778 1.804-2.484.02-4.969.007-7.453.007l-.004.033zm.063-1.96c2.163 0 4.326-.022 6.49.016.574.01.772-.193.788-.737.025-.841.087-1.682.125-2.523.202-4.474.401-8.95.598-13.424.033-.73.03-.73-.727-.724-2.389.017-4.776.046-7.164.046-2.538 0-5.077-.018-7.615-.054-.452-.006-.567.127-.545.592.22 4.512.405 9.026.628 13.538.04.823.067 1.645.105 2.467.037.769.084.804.827.804h6.49zm.093-19.338v.008c.377 0 .754.022 1.13-.004 1.061-.074 1.043-.08.887-1.179-.063-.435-.252-.576-.67-.566-.976.023-1.954.005-2.932.008-.22 0-.508-.052-.563.246-.086.46-.273.922-.13 1.4.034.113.194.09.307.089.657-.004 1.314-.003 1.971-.003v.001z"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("path", {
        d: "M8.69 18.497c0 .268.003.536 0 .803-.012.631-.339 1.023-.878 1.059-.553.037-.954-.295-1.014-.916a63.554 63.554 0 0 1-.186-2.86 598.873 598.873 0 0 1-.258-6.133c-.028-.742.278-1.15.84-1.2.6-.055.983.3 1.062 1.056.08.756.118 1.523.154 2.289.093 1.967.174 3.935.26 5.902h.02zM17.265 11.124c-.12 2.598-.242 5.195-.363 7.792-.013.19-.037.38-.072.569-.096.577-.47.9-1 .873-.537-.027-.898-.42-.883-1.046.032-1.357.085-2.715.145-4.07.06-1.337.135-2.673.21-4.008.021-.382.04-.765.096-1.142.087-.57.489-.884 1.022-.844.495.04.835.412.857.959.011.305 0 .612 0 .918h-.012zM10.868 14.807c0-1.51-.01-3.019.005-4.528.007-.665.379-1.043.95-1.034.571.009.932.396.935 1.057.01 2.062.004 4.125.008 6.188 0 .898.005 1.796.02 2.693.013.697-.357 1.165-.95 1.175-.604.012-.97-.419-.97-1.137v-4.414h.002z"
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("defs", {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("clipPath", {
        id: "clip0",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("path", {
          fill: "#fff",
          d: "M0 0h23.611v25H0z"
        })
      })
    })]
  }));
};

Bin.defaultProps = {
  width: "24",
  height: "25",
  viewBox: "0 0 24 25",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};




const TitleContainer = styled_components__WEBPACK_IMPORTED_MODULE_5___default().div.withConfig({
  displayName: "DeleteMeasurementModal__TitleContainer",
  componentId: "mi006w-0"
})(["display:flex;flex-direction:column;align-items:center;justify-content:center;"]);
const BodyContainer = styled_components__WEBPACK_IMPORTED_MODULE_5___default()(TitleContainer).withConfig({
  displayName: "DeleteMeasurementModal__BodyContainer",
  componentId: "mi006w-1"
})(["padding:0 10%;", ""], _theme__WEBPACK_IMPORTED_MODULE_4__/* .media.tablet */ .BC.tablet`
  padding: 0 25%;
`);

const DeleteMeasurementModal = ({
  showConfirmationModal,
  setShowConfirmationModal,
  onConfirm,
  loading
}) => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_common_ConfirmationModal__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
    open: showConfirmationModal,
    onClose: () => setShowConfirmationModal(!showConfirmationModal),
    onConfirm: onConfirm,
    cancelText: "No, don\u2019t delete",
    confirmText: "Confirm",
    title: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(TitleContainer, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(Bin, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
        size: "modalTitle",
        color: "error",
        children: "Are you sure?"
      })]
    }),
    body: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(BodyContainer, {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
        children: "Press confirm to delete all the data you have entered for the selected carbon calculation. This action is irreversible."
      })
    }),
    loading: loading,
    warning: true
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DeleteMeasurementModal);

/***/ }),

/***/ 76296:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(61908);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(74146);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(date_fns__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(45641);
/* harmony import */ var _common_ConfirmationModal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(65487);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(87491);
/* harmony import */ var _common_FormGroup__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(13586);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(75609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _form_DateInput__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(81356);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_1__, react_hook_form__WEBPACK_IMPORTED_MODULE_3__, _form_DateInput__WEBPACK_IMPORTED_MODULE_10__]);
([_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_1__, react_hook_form__WEBPACK_IMPORTED_MODULE_3__, _form_DateInput__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }









var CalculatorIcon = function CalculatorIcon(props) {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("g", {
      clipPath: "url(#clip0)",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("path", {
        d: "M23.737 20.248v.728c-.022.076-.013.156-.025.233a4.933 4.933 0 0 1-.267 1.01 4.392 4.392 0 0 1-.976 1.554c-.625.63-1.393.988-2.259 1.15-.157.028-.319.034-.474.077h-.727a.717.717 0 0 0-.167-.034 4.101 4.101 0 0 1-1.665-.58c-.93-.569-1.554-1.382-1.896-2.412a7.07 7.07 0 0 1-.079-.256.145.145 0 0 0-.158-.115H2.203a5.098 5.098 0 0 1-.577-.018c-.83-.095-1.452-.682-1.587-1.504a.49.49 0 0 0-.037-.134V1.667c.045-.069.04-.15.057-.226.17-.73.6-1.212 1.34-1.395.09-.022.181-.032.272-.048h19.157c.074.012.148.02.223.036.722.154 1.192.58 1.392 1.293.059.236.084.478.077.721v15.343c0 .159.054.312.152.436.054.071.111.14.165.21.426.555.727 1.167.859 1.858.018.12.02.238.041.353zM10.882 1.076c-2.52-.003-5.517.008-8.514-.006-.178 0-.356-.01-.535.005-.384.034-.649.273-.717.651a1.402 1.402 0 0 0-.02.268c.007.68-.003 1.362.012 2.043.01.424.005.847.004 1.273-.004 1.937-.004 3.874-.01 5.81-.008 2.737-.012 5.472.008 8.206 0 .174-.004.35.005.524.02.337.223.572.551.65.127.023.255.032.384.025h12.348c.175 0 .35.004.525 0 .124 0 .152-.03.159-.15.032-.616.21-1.215.517-1.749.09-.155.136-.332.134-.51V15.9 7.286c0-.11.01-.22.035-.329a.493.493 0 0 1 .39-.395c.13-.028.261-.04.393-.037h3.264c.134 0 .264.004.395.015.305.026.478.179.528.48.019.135.027.27.024.406v8.657c.004.125.002.25-.006.374a.125.125 0 0 0 .09.142c.175.06.347.13.513.212.034.018.06.005.055-.035-.004-.1-.002-.2.006-.299-.007-3.214.01-6.427-.009-9.641-.01-1.612 0-3.224 0-4.837.006-.1.006-.2 0-.3a.673.673 0 0 0-.538-.602 1.448 1.448 0 0 0-.32-.024l-9.67.003zm8.552 22.831c1.689.048 3.217-1.418 3.221-3.2.004-1.891-1.516-3.267-3.255-3.28-1.667-.01-3.227 1.367-3.228 3.212-.002 1.939 1.508 3.293 3.262 3.267v.001zM16.808 12.44v4.633c0 .034-.016.08.016.1.041.025.07-.021.1-.045.225-.157.464-.293.714-.406a4.16 4.16 0 0 1 1.368-.357c.182-.016.363-.014.545-.017.095 0 .119-.026.127-.12.002-.032 0-.064 0-.096-.003-.271-.007-.542-.008-.813a716.8 716.8 0 0 1-.003-4.3c0-1.063-.003-2.126.01-3.189.003-.178-.026-.202-.205-.202h-2.44c-.21 0-.23.019-.23.233l.006 4.58z"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("path", {
        d: "M11.27 1.73h8.678c.103-.003.207.003.31.015.297.042.46.207.487.506.008.089.014.178.014.267v2.547a1.9 1.9 0 0 1-.03.383c-.049.233-.172.357-.405.396-.084.017-.17.026-.255.026H2.519a1.59 1.59 0 0 1-.381-.038.439.439 0 0 1-.345-.355 1.768 1.768 0 0 1-.035-.394v-2.61a1.456 1.456 0 0 1 .028-.309.49.49 0 0 1 .433-.412c.08-.014.163-.02.245-.021h4.195l4.61-.002zm-.008 3.06H19.565c.09 0 .114-.03.115-.117 0-.071-.007-.142-.007-.214V3.015c0-.204 0-.204-.209-.204h-5.746L3.03 2.808c-.176 0-.2.024-.195.197v.01c.023.424.007.848.01 1.273v.353c.003.137.014.147.147.15h8.27zM15.076 9.739v2.452c.002.086-.005.172-.022.255a.493.493 0 0 1-.41.402 1.058 1.058 0 0 1-.222.024h-5.02a.99.99 0 0 1-.274-.038.478.478 0 0 1-.334-.318.726.726 0 0 1-.045-.22c-.005-.167-.012-.335-.013-.502V7.449a2.309 2.309 0 0 1 .028-.427c.056-.296.223-.446.523-.475.117-.012.234-.018.352-.018h4.602c.14-.003.278.01.414.038a.48.48 0 0 1 .386.372c.027.115.039.233.036.35-.002.816-.002 1.633-.001 2.45zm-1.077-.02V7.845c0-.211-.008-.219-.215-.219H9.965c-.086.007-.112.033-.119.12-.003.036 0 .071 0 .107V11.6c0 .184.01.191.194.191h3.756c.197 0 .205-.005.205-.202L14 9.72zM8.735 16.805v-1.962c0-.235.007-.47.012-.706a.86.86 0 0 1 .007-.096c.045-.309.21-.465.52-.502a2.52 2.52 0 0 1 .288-.015h4.74c.129-.003.257.01.382.041a.474.474 0 0 1 .353.34c.027.096.04.195.038.295v4.942a1.26 1.26 0 0 1-.021.277.516.516 0 0 1-.441.424c-.084.014-.17.022-.255.023h-4.88c-.085-.001-.17-.01-.255-.024-.255-.042-.404-.19-.46-.444a1.137 1.137 0 0 1-.018-.212c-.017-.832-.007-1.667-.01-2.38zm3.192-2.203h-1.851c-.232 0-.232 0-.232.232 0 .792.003 1.584 0 2.376 0 .442.007.884-.01 1.326-.008.205.024.232.232.232h3.7c.23 0 .23 0 .23-.232v-3.735-.075c-.005-.097-.024-.116-.123-.12h-.053l-1.893-.004zM1.758 16.684V14.33c0-.096.004-.193.013-.289.028-.295.196-.464.49-.501.079-.01.157-.015.235-.016h4.86c.086 0 .172.006.256.019a.493.493 0 0 1 .446.413c.014.066.02.134.02.202v5.062c0 .075-.007.15-.022.223a.486.486 0 0 1-.42.4c-.077.015-.155.022-.234.022H2.48c-.07 0-.142-.006-.213-.016-.298-.039-.467-.213-.492-.513a4.019 4.019 0 0 1-.014-.312c-.002-.779-.003-1.558-.002-2.34zm3.154 2.082h1.947c.117 0 .134-.02.138-.139v-.085-.984-2.76c0-.192 0-.194-.189-.194H2.924a.081.081 0 0 0-.081.072.459.459 0 0 0-.009.095c0 .134.01.27.01.406.002.521.002 1.041 0 1.561 0 .613.006 1.227-.01 1.84-.005.167.018.184.182.185l1.896.003zM8.076 9.686v2.504a1.07 1.07 0 0 1-.039.317.453.453 0 0 1-.326.323 1.04 1.04 0 0 1-.285.04H2.418c-.078-.002-.156-.01-.233-.027-.242-.048-.388-.218-.413-.48a3.112 3.112 0 0 1-.015-.288v-4.73c0-.092.006-.185.014-.277.026-.322.215-.502.539-.526.281-.022.563-.016.844-.016h4.163c.117-.003.235.01.35.036a.517.517 0 0 1 .406.5c.005.083 0 .165 0 .247l.003 2.377zm-3.153 2.106h1.915c.147 0 .158-.012.16-.158v-.065-1.005-2.75c0-.178-.009-.185-.19-.185H2.937a.09.09 0 0 0-.093.085.793.793 0 0 0-.008.118c0 .089.009.178.009.267 0 .745.004 1.49 0 2.236 0 .374.01.749-.01 1.123a1.93 1.93 0 0 0 0 .203c.005.1.032.126.13.13h1.959zM21.372 21.442c.01.47-.308 1.057-.86 1.256a.503.503 0 0 0-.06.025c-.063.032-.072.05-.06.119.004.017.01.034.013.052.031.162-.036.278-.196.312-.188.039-.379.067-.567.105-.157.031-.261-.05-.3-.204l-.005-.032c-.024-.1-.042-.116-.139-.096-.118.025-.239.041-.356.07-.223.054-.36-.042-.4-.268a24.358 24.358 0 0 1-.07-.432.577.577 0 0 1-.009-.107.232.232 0 0 1 .164-.227c.074-.025.15-.044.228-.056.401-.074.8-.147 1.199-.223a.515.515 0 0 0 .227-.089.25.25 0 0 0 .098-.284.256.256 0 0 0-.233-.19 1.084 1.084 0 0 0-.307.03c-.197.037-.391.082-.589.109-.58.08-1.063-.097-1.398-.587-.469-.685-.188-1.634.572-1.978.042-.02.085-.036.127-.057a.083.083 0 0 0 .05-.106.695.695 0 0 1-.014-.052c-.034-.17.034-.287.207-.326.184-.041.371-.07.556-.104a.319.319 0 0 1 .054-.003c.13 0 .223.07.24.198.017.153.061.16.211.134.102-.02.204-.032.308-.04.206-.008.315.064.378.258.044.14.074.283.09.429.023.21-.064.322-.276.357-.246.04-.49.082-.737.13l-.629.128a.464.464 0 0 0-.167.067.235.235 0 0 0-.112.267.257.257 0 0 0 .216.21c.078.01.157.006.234-.01.228-.044.455-.088.684-.124.818-.134 1.516.424 1.614 1.155.009.063.01.123.014.184zM18.252 13.091h.898c.05-.002.1.004.147.02a.243.243 0 0 1 .152.154.23.23 0 0 1 .015.073c0 .21.02.42-.004.63a.219.219 0 0 1-.208.208 1.54 1.54 0 0 1-.203.014h-1.605a1.31 1.31 0 0 1-.192-.014c-.122-.019-.21-.09-.223-.213a3.193 3.193 0 0 1 0-.66c.014-.127.113-.201.247-.21.075-.004.15 0 .223 0l.753-.002zM18.259 12.873h-.855a.883.883 0 0 1-.128-.005c-.143-.021-.232-.098-.248-.24a2.457 2.457 0 0 1 .008-.64.209.209 0 0 1 .173-.181.687.687 0 0 1 .16-.015h1.753c.257 0 .367.113.348.37-.01.147.012.292-.004.439-.02.188-.096.267-.287.27-.307.004-.613 0-.92 0v.002z"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("path", {
        d: "M17.156 4.567c-.103 0-.206.003-.31 0-.164-.006-.252-.085-.26-.25a5.85 5.85 0 0 1 0-.544c.01-.195.105-.278.299-.292a3.76 3.76 0 0 1 .575 0c.177.015.261.095.268.27.007.176.005.363 0 .545-.005.18-.093.267-.283.272h-.288v-.001zM15.848 4.567c-.096 0-.192.002-.288 0-.182-.006-.268-.08-.274-.258a7.53 7.53 0 0 1-.003-.576c.006-.161.086-.236.248-.25.213-.019.427-.019.64 0 .146.012.223.079.235.226.018.21.017.42-.002.629-.014.145-.09.217-.236.226-.106.006-.213 0-.32 0v.003zM18.46 4.566c-.1 0-.2.004-.299 0-.166-.007-.248-.089-.252-.254-.006-.181-.005-.362-.007-.544 0-.018.002-.036.004-.053.015-.14.082-.215.223-.23.227-.023.456-.023.682 0 .126.014.19.08.211.205.007.043.01.085.01.128v.437a.533.533 0 0 1-.01.107.24.24 0 0 1-.24.204c-.106.005-.213 0-.32 0h-.001zM11.902 9.175H13.056c.186.006.291.107.299.293.002.064-.01.128-.01.191 0 .09.007.179.009.268.004.203-.086.305-.288.324a1.212 1.212 0 0 1-.128.003h-2.096a.7.7 0 0 1-.169-.018.252.252 0 0 1-.198-.202 2.657 2.657 0 0 1 .007-.68c.018-.108.093-.165.2-.179.04-.003.08-.004.118-.003h1.101l.001.003zM11.274 18.006a.265.265 0 0 1-.186-.085c-.131-.137-.268-.268-.402-.402-.112-.11-.112-.232-.008-.352.05-.06.11-.112.166-.167l1.46-1.46c.037-.039.076-.075.118-.108.092-.07.19-.073.274.003.168.15.327.308.477.476.089.1.078.212-.019.318-.09.095-.178.184-.27.275l-1.37 1.369a.723.723 0 0 1-.097.083.257.257 0 0 1-.143.05zM10.418 15.768a.551.551 0 0 1 .567-.557c.332 0 .571.235.571.562a.56.56 0 0 1-.57.557.562.562 0 0 1-.568-.562zM12.838 18.18a.55.55 0 0 1-.561-.564.554.554 0 0 1 .57-.558.53.53 0 0 1 .55.56c-.006.377-.3.584-.56.561zM5.569 17.94a.408.408 0 0 1-.232-.096 3.104 3.104 0 0 1-.264-.25 1.125 1.125 0 0 0-.086-.08c-.056-.044-.08-.041-.13.01a2.7 2.7 0 0 0-.2.223c-.04.052-.082.1-.128.144-.122.111-.248.125-.394.05a.709.709 0 0 1-.204-.17c-.085-.097-.17-.194-.253-.291-.09-.103-.087-.208.014-.316.116-.125.239-.245.36-.365.113-.11.112-.108-.004-.22a15.472 15.472 0 0 1-.333-.332c-.122-.127-.12-.25.003-.376s.255-.259.386-.386c.13-.126.248-.123.375 0 .126.124.241.243.361.365.076.077.09.077.163 0 .12-.122.24-.243.362-.364a.425.425 0 0 1 .1-.08.188.188 0 0 1 .235.037c.095.089.185.178.275.267.063.063.127.126.187.192.092.102.097.188.013.297a1.362 1.362 0 0 1-.234.233 1.09 1.09 0 0 0-.167.15c-.07.083-.07.147 0 .23.055.06.116.115.182.163.066.05.126.105.181.166.1.12.105.24.006.357a2.348 2.348 0 0 1-.35.344.41.41 0 0 1-.224.098zM5.851 9.176c.09 0 .178-.003.268 0 .146.005.223.072.243.219.027.209.027.42 0 .63-.017.133-.079.191-.212.216a1.84 1.84 0 0 1-.31.012h-.277c-.083.003-.1.02-.102.103-.002.134 0 .264 0 .396a.99.99 0 0 1-.012.182c-.023.12-.086.19-.206.197a5.82 5.82 0 0 1-.641 0c-.121-.007-.186-.074-.21-.194a.79.79 0 0 1-.01-.138v-.418c0-.114-.014-.127-.134-.129-.12-.002-.228 0-.342 0a1.802 1.802 0 0 1-.213-.017.207.207 0 0 1-.193-.185.794.794 0 0 1-.013-.138v-.407c0-.05.005-.1.015-.148a.21.21 0 0 1 .17-.172.586.586 0 0 1 .127-.011h.45c.119 0 .13-.012.133-.128V8.64a.684.684 0 0 1 .02-.179.238.238 0 0 1 .188-.183.724.724 0 0 1 .138-.02c.143-.003.285 0 .428 0a.528.528 0 0 1 .127.019.211.211 0 0 1 .165.175c.01.05.015.1.014.15v.438c0 .127.01.134.134.137h.256v-.001z"
      })]
    })
  }));
};

CalculatorIcon.defaultProps = {
  width: "24",
  height: "25",
  viewBox: "0 0 24 25",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};





const schema = yup__WEBPACK_IMPORTED_MODULE_9__.object().shape({
  period_start: yup__WEBPACK_IMPORTED_MODULE_9__.date().max(new Date(), "Start date must be in the past").required("Please select a start date").typeError("Please select a start date").max(yup__WEBPACK_IMPORTED_MODULE_9__.ref("period_end"), "Start date can't be after end date"),
  period_end: yup__WEBPACK_IMPORTED_MODULE_9__.date().max(new Date(), "End date must be in the past").required("Please select an end date").typeError("Please select an end date").min(yup__WEBPACK_IMPORTED_MODULE_9__.ref("period_start"), "End date can't be before start date")
});
const StyledCalculatorIcon = styled_components__WEBPACK_IMPORTED_MODULE_8___default()(CalculatorIcon).withConfig({
  displayName: "MeasurementModal__StyledCalculatorIcon",
  componentId: "mlu62l-0"
})(["width:2rem;height:2rem;& > *{fill:", ";}"], p => p.theme.colors.blue);
const TitleContainer = styled_components__WEBPACK_IMPORTED_MODULE_8___default().div.withConfig({
  displayName: "MeasurementModal__TitleContainer",
  componentId: "mlu62l-1"
})(["display:flex;flex-direction:column;align-items:center;justify-content:center;"]);
const BodyContainer = styled_components__WEBPACK_IMPORTED_MODULE_8___default()(TitleContainer).withConfig({
  displayName: "MeasurementModal__BodyContainer",
  componentId: "mlu62l-2"
})(["padding:0 10%;"]);
const Form = styled_components__WEBPACK_IMPORTED_MODULE_8___default().form.withConfig({
  displayName: "MeasurementModal__Form",
  componentId: "mlu62l-3"
})(["width:100%;margin:2rem auto;"]);

const MeasurementModal = ({
  showModal,
  setShowModal,
  onConfirm,
  measurement,
  confirmClose,
  loading
}) => {
  const methods = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_3__.useForm)(_objectSpread({
    mode: "onSubmit",
    resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_1__.yupResolver)(schema)
  }, measurement && {
    defaultValues: {
      period_end: measurement.period_end,
      period_start: measurement.period_start
    }
  }));
  const {
    handleSubmit,
    watch
  } = methods;
  const periodStart = watch("period_start");
  const periodEnd = watch("period_end");
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_common_ConfirmationModal__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
    open: showModal,
    onClose: () => setShowModal(!showModal),
    onConfirm: handleSubmit(onConfirm),
    cancelText: "Cancel",
    confirmText: "Confirm",
    maxWidth: "40rem",
    width: "100%",
    loading: loading,
    confirmClose: confirmClose,
    title: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(TitleContainer, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(StyledCalculatorIcon, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP, {
        size: "modalTitle",
        children: measurement ? "Edit measurement" : "New measurement"
      })]
    }),
    body: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(BodyContainer, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP, {
        children: "Select dates of measurement:"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_3__.FormProvider, _objectSpread(_objectSpread({}, methods), {}, {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(Form, {
          onSubmit: handleSubmit(onConfirm),
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(_common_FormGroup__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_form_DateInput__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
              name: "period_start",
              id: "period_start",
              label: "Start Date",
              placeholder: "Start date: DD/MM/YYYY",
              maxDate: (0,date_fns__WEBPACK_IMPORTED_MODULE_2__.subDays)(periodEnd ? new Date(periodEnd) : new Date(), 1)
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_form_DateInput__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
              name: "period_end",
              id: "period_end",
              label: "End Date",
              placeholder: "End date: DD/MM/YYYY",
              maxDate: (0,date_fns__WEBPACK_IMPORTED_MODULE_2__.subDays)(new Date(), 1),
              minDate: (0,date_fns__WEBPACK_IMPORTED_MODULE_2__.addDays)(new Date(periodStart), 1)
            })]
          })
        })
      }))]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MeasurementModal);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 30495:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "g": () => (/* binding */ OfficeButtonsContainer),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const ButtonsContainer = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "ButtonsContainer",
  componentId: "sc-9166ss-0"
})(["display:flex;justify-content:flex-end;margin:2rem 0;"]);
const OfficeButtonsContainer = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(ButtonsContainer).withConfig({
  displayName: "ButtonsContainer__OfficeButtonsContainer",
  componentId: "sc-9166ss-1"
})(["justify-content:flex-start;& > *:not(:first-child){margin-left:1rem;}"]);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ButtonsContainer);

/***/ }),

/***/ 13586:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const FormGroup = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "FormGroup",
  componentId: "sc-5bol1t-0"
})(["display:flex;align-items:", ";margin-bottom:1rem;margin:", ";& > *{margin-bottom:0;& > div > div[class$=\"control\"]{margin-bottom:0;}}& > *:not(:first-child){margin-left:1rem;}& > span{padding:0.7rem 0;}"], p => p.align || "center", p => p.margin ? p.margin : "0.75rem 0");
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FormGroup);

/***/ })

};
;