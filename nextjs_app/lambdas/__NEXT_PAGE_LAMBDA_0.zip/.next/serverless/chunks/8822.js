"use strict";
exports.id = 8822;
exports.ids = [8822];
exports.modules = {

/***/ 64493:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);


const Container = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "DataInputContainer__Container",
  componentId: "vmaktt-0"
})(["display:flex;flex-direction:column;align-items:flex-start;width:", ";background:", ";border-radius:8px;padding:20px 40px 16px;margin-bottom:20px;position:relative;&:last-child{margin-bottom:0px;}", ";"], p => p.width || "100%", p => p.theme.colors.white, p => p.isEditing && `border: 2px solid ${p.theme.colors.blue}`);

const DataInputContainer = ({
  width,
  children,
  isEditing,
  name
}) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(Container, {
  width: width,
  isEditing: isEditing,
  "data-cy": name && `${name}-data-input-container`,
  children: children
});

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DataInputContainer);

/***/ }),

/***/ 89781:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const Form = styled_components__WEBPACK_IMPORTED_MODULE_0___default().form.withConfig({
  displayName: "Form",
  componentId: "sc-1og6h7x-0"
})(["width:100%;"]);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Form);

/***/ }),

/***/ 65220:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export handleBeforeUnload */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const handleBeforeUnload = e => {
  e.preventDefault();
  const returnValue = "Changes that you made may not be saved.";
  e.returnValue = returnValue;
  return returnValue;
};

const useWarnOnBeforeUnload = () => {
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (true) {
      window.addEventListener("beforeunload", handleBeforeUnload);
      return () => window.removeEventListener("beforeunload", handleBeforeUnload);
    }
  }, []);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useWarnOnBeforeUnload);

/***/ })

};
;