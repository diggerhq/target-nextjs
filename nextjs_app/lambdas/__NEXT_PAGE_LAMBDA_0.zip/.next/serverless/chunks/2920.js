"use strict";
exports.id = 2920;
exports.ids = [2920];
exports.modules = {

/***/ 22920:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _button_Button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(59067);
/* harmony import */ var _common_LoadingLarge__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(49899);
/* harmony import */ var _utils_applicationMap__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(40516);
/* harmony import */ var _contexts_auth__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(58368);
/* harmony import */ var _contexts_measurements__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(85238);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(91073);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(11098);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _sections_business_travel_BusinessTravel__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(77539);
/* harmony import */ var _sections_business_travel_HasBusinessTravel__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(41373);
/* harmony import */ var _sections_details_Staff__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(51186);
/* harmony import */ var _sections_expenses_Expenses__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(82774);
/* harmony import */ var _sections_offices_Commutes__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(49611);
/* harmony import */ var _sections_offices_ElectricityUtility__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(98667);
/* harmony import */ var _sections_offices_GasUtility__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(86465);
/* harmony import */ var _sections_offices_HasOffice__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(71681);
/* harmony import */ var _sections_offices_HasUtilityBills__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(76420);
/* harmony import */ var _sections_offices_OfficeDetails__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(74154);
/* harmony import */ var _sections_offices_Waste__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(23603);
/* harmony import */ var _sections_offices_WaterUtility__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(59502);
/* harmony import */ var _sections_vehicles_HasCompanyVehicles__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(47906);
/* harmony import */ var _sections_vehicles_VehicleUsage__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(45960);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_sections_business_travel_BusinessTravel__WEBPACK_IMPORTED_MODULE_10__, _sections_details_Staff__WEBPACK_IMPORTED_MODULE_12__, _sections_expenses_Expenses__WEBPACK_IMPORTED_MODULE_13__, _sections_offices_Commutes__WEBPACK_IMPORTED_MODULE_14__, _sections_offices_ElectricityUtility__WEBPACK_IMPORTED_MODULE_15__, _sections_offices_GasUtility__WEBPACK_IMPORTED_MODULE_16__, _sections_offices_OfficeDetails__WEBPACK_IMPORTED_MODULE_19__, _sections_offices_Waste__WEBPACK_IMPORTED_MODULE_20__, _sections_offices_WaterUtility__WEBPACK_IMPORTED_MODULE_21__, _sections_vehicles_VehicleUsage__WEBPACK_IMPORTED_MODULE_23__]);
([_sections_business_travel_BusinessTravel__WEBPACK_IMPORTED_MODULE_10__, _sections_details_Staff__WEBPACK_IMPORTED_MODULE_12__, _sections_expenses_Expenses__WEBPACK_IMPORTED_MODULE_13__, _sections_offices_Commutes__WEBPACK_IMPORTED_MODULE_14__, _sections_offices_ElectricityUtility__WEBPACK_IMPORTED_MODULE_15__, _sections_offices_GasUtility__WEBPACK_IMPORTED_MODULE_16__, _sections_offices_OfficeDetails__WEBPACK_IMPORTED_MODULE_19__, _sections_offices_Waste__WEBPACK_IMPORTED_MODULE_20__, _sections_offices_WaterUtility__WEBPACK_IMPORTED_MODULE_21__, _sections_vehicles_VehicleUsage__WEBPACK_IMPORTED_MODULE_23__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






























const ButtonsContainer = styled_components__WEBPACK_IMPORTED_MODULE_9___default().div.withConfig({
  displayName: "MeasurementReview__ButtonsContainer",
  componentId: "l4zvo3-0"
})(["display:flex;justify-content:flex-end;margin:2rem 0;& > *:not(:first-child){margin-left:1rem;}"]);
const SectionsContainer = styled_components__WEBPACK_IMPORTED_MODULE_9___default().div.withConfig({
  displayName: "MeasurementReview__SectionsContainer",
  componentId: "l4zvo3-1"
})(["height:100%;overflow:scroll;", " ", " &::-webkit-scrollbar{background:transparent;border-radius:10px;width:0.25rem;}::-webkit-scrollbar-thumb{background:", ";border-radius:10px;transition:visibility:0.3s;visibility:hidden;}&:hover::-webkit-scrollbar-thumb{visibility:visible;}"], _theme__WEBPACK_IMPORTED_MODULE_7__/* .media.desktop */ .BC.desktop`
    height: 80%;
  `, _theme__WEBPACK_IMPORTED_MODULE_7__/* .media.desktopLarge */ .BC.desktopLarge`
    height: 83%;
  `, p => p.theme.colors.secondaryBlue);

const MeasurementReview = ({
  disabled
}) => {
  const {
    selectedMeasurement,
    setSelectedMeasurement
  } = (0,_contexts_measurements__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)();
  const id = "reveiw";
  const {
    user
  } = (0,_contexts_auth__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)();
  const {
    0: loading,
    1: setLoading
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)();
  const {
    0: hasBusinessTravel,
    1: setHasBusinessTravel
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(!!selectedMeasurement.has_business_travel);
  const {
    0: hasVehicles,
    1: setHasVehicles
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(!!selectedMeasurement.has_company_vehicles);
  const {
    0: hasOffice,
    1: setHasOffice
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(selectedMeasurement && (!!selectedMeasurement.offices.length || !!selectedMeasurement.has_office));
  const {
    0: hasUtilityBills,
    1: setHasUtilityBills
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(selectedMeasurement && (!!selectedMeasurement.utilities.length || !!selectedMeasurement.has_utility_bills));
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();

  const submitMeasurement = async () => {
    try {
      setLoading(true);
      await axios__WEBPACK_IMPORTED_MODULE_0___default().patch(`/api/organisations/${user.organisation_id}/measurements/${selectedMeasurement.id}`, _objectSpread({
        state: "pending",
        submitted_at: new Date(),
        user_id: user.id
      }, (0,_utils_applicationMap__WEBPACK_IMPORTED_MODULE_25__/* .shouldUpdateLastCompletedStep */ ._Z)({
        step: id,
        measurement: selectedMeasurement
      }) ? {
        last_completed_step: id
      } : {})); // Wait to turn on Calculator
      // await Axios.post(
      //   `/api/organisations/${user.organisation_id}/measurements/${selectedMeasurement.id}/measurement-result`
      // );

      setSelectedMeasurement(null);
      router.push("/measurements");
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_8__/* .logError */ .H)(error);
    }

    setLoading(false);
  };

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsxs)(SectionsContainer, {
      children: [loading && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsx(_common_LoadingLarge__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
        loading: loading,
        text: "Submitting Measurement..."
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsx(_sections_details_Staff__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
        sectionDisabled: disabled
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsx(_sections_offices_HasOffice__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
        hasOffice,
        setHasOffice,
        sectionDisabled: disabled
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsx(_sections_offices_HasUtilityBills__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {
        hasUtilityBills,
        setHasUtilityBills,
        sectionDisabled: disabled
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsx(_sections_offices_GasUtility__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
        hasUtilityBills,
        sectionDisabled: disabled
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsx(_sections_offices_ElectricityUtility__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
        sectionDisabled: disabled
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsx(_sections_offices_WaterUtility__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .Z, {
        sectionDisabled: disabled
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsx(_sections_offices_OfficeDetails__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z, {
        sectionDisabled: disabled
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsx(_sections_offices_Waste__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {
        sectionDisabled: disabled
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsx(_sections_offices_Commutes__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
        sectionDisabled: disabled,
        review: true
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsx(_sections_vehicles_HasCompanyVehicles__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .Z, {
        hasVehicles,
        setHasVehicles,
        sectionDisabled: disabled
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsx(_sections_vehicles_VehicleUsage__WEBPACK_IMPORTED_MODULE_23__/* ["default"] */ .Z, {
        hasVehicles,
        sectionDisabled: disabled
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsx(_sections_business_travel_HasBusinessTravel__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
        hasBusinessTravel,
        setHasBusinessTravel,
        sectionDisabled: disabled
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsx(_sections_business_travel_BusinessTravel__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
        sectionDisabled: disabled
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsx(_sections_expenses_Expenses__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
        sectionDisabled: disabled,
        review: true
      })]
    }), !disabled && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsx(ButtonsContainer, {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP, {
        disabled: !(0,_utils_applicationMap__WEBPACK_IMPORTED_MODULE_25__/* .checkPageIsComplete */ .es)({
          page: "expenses",
          measurement: selectedMeasurement
        }),
        onClick: submitMeasurement,
        children: "Submit measurement"
      })
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MeasurementReview);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;