"use strict";
exports.id = 5411;
exports.ids = [5411];
exports.modules = {

/***/ 95411:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(74146);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(date_fns__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var recharts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(36157);
/* harmony import */ var recharts__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(recharts__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(87491);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(72994);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _utils_charts__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(19343);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }












const Container = styled_components__WEBPACK_IMPORTED_MODULE_6___default().div.withConfig({
  displayName: "MeasurementPieChart__Container",
  componentId: "pkj0fd-0"
})(["", ";display:flex;flex-direction:column;align-items:center;background:", ";padding:1.625rem;", " ", " ", " ", " .recharts-tooltip-wrapper{width:100%;height:100%;}"], _styles__WEBPACK_IMPORTED_MODULE_4__/* .borderRadius */ .E, p => p.theme.colors.white, _theme__WEBPACK_IMPORTED_MODULE_5__/* .media.tablet */ .BC.tablet`
      width: 90%;
      ${p => p.dashboard && (0,styled_components__WEBPACK_IMPORTED_MODULE_6__.css)(["width:100%;"])}
  `, p => p.dashboard && (0,styled_components__WEBPACK_IMPORTED_MODULE_6__.css)(["margin:0 0 1rem 0;"]), _theme__WEBPACK_IMPORTED_MODULE_5__/* .media.tabletLarge */ .BC.tabletLarge`
    ${p => p.dashboard && (0,styled_components__WEBPACK_IMPORTED_MODULE_6__.css)(["width:86%;"])}
  `, _theme__WEBPACK_IMPORTED_MODULE_5__/* .media.desktop */ .BC.desktop`
    width: ${p => p.width || "44%"};
    margin: initial;
    ${p => p.dashboard && (0,styled_components__WEBPACK_IMPORTED_MODULE_6__.css)(["height:100%;width:100%;margin:0 1rem 0 0;"])}
  `);
const InnerContainer = styled_components__WEBPACK_IMPORTED_MODULE_6___default().div.withConfig({
  displayName: "MeasurementPieChart__InnerContainer",
  componentId: "pkj0fd-1"
})(["display:flex;align-items:center;text-align:center;flex-direction:column;margin:auto;", ";"], _theme__WEBPACK_IMPORTED_MODULE_5__/* .media.tablet */ .BC.tablet`
    flex-direction: row;
  `);
const Legend = styled_components__WEBPACK_IMPORTED_MODULE_6___default().div.withConfig({
  displayName: "MeasurementPieChart__Legend",
  componentId: "pkj0fd-2"
})(["display:flex;margin-top:auto;"]);
const LegendItem = styled_components__WEBPACK_IMPORTED_MODULE_6___default().div.withConfig({
  displayName: "MeasurementPieChart__LegendItem",
  componentId: "pkj0fd-3"
})(["display:flex;flex-direction:column;align-items:center;&:not(:last-of-type){margin-right:1.5rem;}"]);
const LegendInnerContainer = styled_components__WEBPACK_IMPORTED_MODULE_6___default().div.withConfig({
  displayName: "MeasurementPieChart__LegendInnerContainer",
  componentId: "pkj0fd-4"
})(["display:flex;align-items:center;"]);
const LegendColor = styled_components__WEBPACK_IMPORTED_MODULE_6___default().div.withConfig({
  displayName: "MeasurementPieChart__LegendColor",
  componentId: "pkj0fd-5"
})(["background-color:", ";height:0.75rem;width:0.75rem;margin-right:0.52rem;"], p => p.color);
const LegendValue = styled_components__WEBPACK_IMPORTED_MODULE_6___default().div.withConfig({
  displayName: "MeasurementPieChart__LegendValue",
  componentId: "pkj0fd-6"
})([""]);
const StyledTooltip = styled_components__WEBPACK_IMPORTED_MODULE_6___default().div.withConfig({
  displayName: "MeasurementPieChart__StyledTooltip",
  componentId: "pkj0fd-7"
})(["background-color:", ";border-radius:100%;height:3rem;width:3rem;display:flex;justify-content:center;align-items:center;box-shadow:0px 5px 5px rgba(46,104,241,0.5);"], p => p.theme.colors.backgroundGrey);
const TitleContainer = styled_components__WEBPACK_IMPORTED_MODULE_6___default().div.withConfig({
  displayName: "MeasurementPieChart__TitleContainer",
  componentId: "pkj0fd-8"
})(["align-self:flex-start;"]);
const LabelNumber = styled_components__WEBPACK_IMPORTED_MODULE_6___default().text.withConfig({
  displayName: "MeasurementPieChart__LabelNumber",
  componentId: "pkj0fd-9"
})(["font-size:", ";font-weight:", ";"], p => p.theme.blogTitle.size, p => p.theme.blogTitle.fontWeight);
const SubtitleContainer = styled_components__WEBPACK_IMPORTED_MODULE_6___default().div.withConfig({
  displayName: "MeasurementPieChart__SubtitleContainer",
  componentId: "pkj0fd-10"
})(["width:100%;"]);

const renderActiveShape = props => {
  const RADIAN = Math.PI / 180;
  const {
    cx,
    cy,
    midAngle,
    innerRadius,
    outerRadius,
    startAngle,
    endAngle,
    fill,
    value,
    chartWidth,
    index
  } = props;
  const sin = Math.sin(-RADIAN * midAngle);
  const cos = Math.cos(-RADIAN * midAngle);
  const sx = cx + outerRadius * cos;
  const sy = cy + outerRadius * sin;
  const mx = cx + (outerRadius - 30) * cos;
  const my = cy + (outerRadius - 30) * sin;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("g", {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(recharts__WEBPACK_IMPORTED_MODULE_2__.Sector, {
      cx: cx,
      cy: cy,
      innerRadius: innerRadius,
      outerRadius: outerRadius,
      startAngle: startAngle,
      endAngle: endAngle,
      fill: fill
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("g", {
      style: {
        display: "none"
      },
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("filter", {
        id: "shadow",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("feDropShadow", {
          dx: "2",
          dy: "2",
          stdDeviation: "2",
          floodColor: _theme__WEBPACK_IMPORTED_MODULE_5__/* ["default"].colors.blue */ .ZP.colors.blue,
          floodOpacity: "0.5"
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("circle", {
        cx: sx,
        cy: sy,
        r: 5 + chartWidth / 10,
        fill: "white",
        filter: "url(#shadow)",
        id: "circle-" + index
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("text", {
        x: sx,
        y: sy,
        fill: _theme__WEBPACK_IMPORTED_MODULE_5__/* ["default"].colors.blue */ .ZP.colors.blue,
        textAnchor: "middle",
        dominantBaseline: "middle",
        style: {
          fontWeight: 700
        },
        id: "text-" + index,
        children: `${value.toFixed(2)}`
      })]
    })]
  });
};

const MeasurementPieChart = ({
  measurement,
  chartHeight = 250,
  chartWidth = 250,
  dashboard,
  width,
  isMonthly,
  officeId
}) => {
  var _measurement$office_m;

  const totalMeasurementResults = (0,_utils_charts__WEBPACK_IMPORTED_MODULE_8__/* .createTotalMeasurementResults */ .d)(measurement);
  const measurementResults = officeId ? measurement === null || measurement === void 0 ? void 0 : (_measurement$office_m = measurement.office_measurements.find(office => office.office_id === officeId)) === null || _measurement$office_m === void 0 ? void 0 : _measurement$office_m.measurement_result : totalMeasurementResults;
  const {
    0: activeIndex,
    1: setActiveIndex
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
  const CHART_KEYS = ["scope_1", "scope_2", "scope_3"];

  const formatValue = value => isMonthly ? value : value / 1000;

  const data = Object.keys(measurementResults).filter(key => CHART_KEYS.includes(key)).sort((a, b) => measurementResults[a] > measurementResults[b] ? 1 : -1).map(key => ({
    name: key,
    value: formatValue(measurementResults[key])
  }));
  const total = data.reduce((prev, curr) => prev + curr.value, 0);
  const colors = {
    scope_1: _theme__WEBPACK_IMPORTED_MODULE_5__/* ["default"].colors.graphBlue */ .ZP.colors.graphBlue,
    scope_2: _theme__WEBPACK_IMPORTED_MODULE_5__/* ["default"].colors.graphYellow */ .ZP.colors.graphYellow,
    scope_3: _theme__WEBPACK_IMPORTED_MODULE_5__/* ["default"].colors.graphGreen */ .ZP.colors.graphGreen
  };

  const onPieEnter = (_, index) => setActiveIndex(index);

  const onPieLeave = _ => setActiveIndex(null);

  const useCircle = `<use xlink:href="#circle-${activeIndex}" /><use xlink:href="#text-${activeIndex}" />`;
  const yearString = [...new Set([(0,date_fns__WEBPACK_IMPORTED_MODULE_0__.format)(new Date(measurement === null || measurement === void 0 ? void 0 : measurement.year, measurement === null || measurement === void 0 ? void 0 : measurement.month), "MM/yyyy"), (0,date_fns__WEBPACK_IMPORTED_MODULE_0__.format)((0,date_fns__WEBPACK_IMPORTED_MODULE_0__.subDays)((0,date_fns__WEBPACK_IMPORTED_MODULE_0__.addMonths)(new Date(measurement === null || measurement === void 0 ? void 0 : measurement.year, measurement === null || measurement === void 0 ? void 0 : measurement.month), measurement === null || measurement === void 0 ? void 0 : measurement.time_period), 1), "MM/yyyy")])].join(" - ");
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(Container, {
    dashboard: dashboard,
    width: width,
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(TitleContainer, {
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(_common_Text__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP, {
        size: "cardHeader",
        children: ["Operational CO2e footprint, ", yearString]
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(SubtitleContainer, {
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(_common_Text__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP, {
        align: "left",
        size: "miniscule",
        children: ["(", isMonthly ? "kgCO2e" : "tCO2e", ")"]
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(InnerContainer, {
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(recharts__WEBPACK_IMPORTED_MODULE_2__.PieChart, {
        width: chartWidth,
        height: chartHeight,
        onMouseLeave: onPieLeave,
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(recharts__WEBPACK_IMPORTED_MODULE_2__.Pie, {
          activeIndex: activeIndex,
          activeShape: props => renderActiveShape(_objectSpread(_objectSpread({}, props), {}, {
            chartWidth,
            index: activeIndex
          })),
          data: data,
          dataKey: "value",
          cx: "50%",
          cy: "50%",
          innerRadius: chartWidth / 3.5,
          outerRadius: chartWidth / 2.5,
          fill: "#8884d8",
          labelLine: false,
          onMouseEnter: onPieEnter,
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(recharts__WEBPACK_IMPORTED_MODULE_2__.Label, {
            content: props => {
              const {
                viewBox: {
                  cx,
                  cy
                }
              } = props;
              const positioningProps = {
                x: cx,
                y: cy + 15,
                textAnchor: "middle",
                verticalAnchor: "middle"
              };
              const presentationProps = {};
              return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(LabelNumber, _objectSpread(_objectSpread(_objectSpread({}, positioningProps), presentationProps), {}, {
                  children: total.toFixed(1)
                }))
              });
            }
          }), data.map((entry, index) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(recharts__WEBPACK_IMPORTED_MODULE_2__.Cell, {
            fill: colors[entry.name]
          }, `cell-${index}`))]
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("svg", {
          dangerouslySetInnerHTML: {
            __html: useCircle
          }
        })]
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(Legend, {
      children: Object.keys(colors).map(key => {
        var _data$find, _data$find$value;

        return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(LegendItem, {
            children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(LegendInnerContainer, {
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(LegendColor, {
                color: colors[key]
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP, {
                size: "smallBold",
                children: key.replace("_", " ").replace(/^\w/, c => c.toUpperCase())
              })]
            }), " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(LegendValue, {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP, {
                size: "small",
                children: (_data$find = data.find(x => x.name === key)) === null || _data$find === void 0 ? void 0 : (_data$find$value = _data$find.value) === null || _data$find$value === void 0 ? void 0 : _data$find$value.toFixed(1)
              })
            })]
          }, key)
        });
      })
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MeasurementPieChart);

/***/ })

};
;