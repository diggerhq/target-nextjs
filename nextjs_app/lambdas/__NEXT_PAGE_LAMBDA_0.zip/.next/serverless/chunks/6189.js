"use strict";
exports.id = 6189;
exports.ids = [6189];
exports.modules = {

/***/ 69490:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(45641);
/* harmony import */ var _button_Button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(59067);
/* harmony import */ var _common_Divider__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6459);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(87491);
/* harmony import */ var _common_Stack__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(45364);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var uuidv4__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(63398);
/* harmony import */ var uuidv4__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(uuidv4__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _common_DataInputContainer__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(64493);
/* harmony import */ var _BusinessTravelRow__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(13357);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_1__, _BusinessTravelRow__WEBPACK_IMPORTED_MODULE_10__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_1__, _BusinessTravelRow__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);














const Container = styled_components__WEBPACK_IMPORTED_MODULE_7___default().div.withConfig({
  displayName: "BusinessTravelEdit__Container",
  componentId: "sc-1l4zmg1-0"
})(["width:100%;position:relative;"]);
const BottomCTAs = styled_components__WEBPACK_IMPORTED_MODULE_7___default().div.withConfig({
  displayName: "BusinessTravelEdit__BottomCTAs",
  componentId: "sc-1l4zmg1-1"
})(["display:flex;width:100%;justify-content:flex-end;flex-direction:column;align-items:center;& > button:not(:last-child){margin-bottom:0.5rem;}", ""], _theme__WEBPACK_IMPORTED_MODULE_6__/* .media.tablet */ .BC.tablet`
    flex-direction: row;
    align-items: initial;
    
    & > button:not(:last-child) {
      margin: initial;
      margin-right: 0.5rem;
    }
  `);

const BusinessTravelEdit = ({
  office,
  isEditing,
  isSubmitting,
  reset
}) => {
  const {
    control
  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_1__.useFormContext)();
  const {
    fields,
    append,
    remove
  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_1__.useFieldArray)({
    control,
    name: "business_travel",
    keyName: "key_id"
  });
  const searchSessionIdsRef = react__WEBPACK_IMPORTED_MODULE_0___default().useRef([]);

  const setSearchSessionIdsRef = data => searchSessionIdsRef.current = data;

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    setSearchSessionIdsRef(fields.map(field => ({
      id: field.id,
      departure: (0,uuidv4__WEBPACK_IMPORTED_MODULE_8__.uuid)(),
      destination: (0,uuidv4__WEBPACK_IMPORTED_MODULE_8__.uuid)()
    })));
  }, []);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    const searchIds = searchSessionIdsRef === null || searchSessionIdsRef === void 0 ? void 0 : searchSessionIdsRef.current.map(({
      id
    }) => id);
    const newFields = fields.filter(field => !searchIds.includes(field.id));
    setSearchSessionIdsRef([...(searchSessionIdsRef === null || searchSessionIdsRef === void 0 ? void 0 : searchSessionIdsRef.current), ...newFields.map(field => ({
      id: field.id,
      departure: (0,uuidv4__WEBPACK_IMPORTED_MODULE_8__.uuid)(),
      destination: (0,uuidv4__WEBPACK_IMPORTED_MODULE_8__.uuid)()
    }))]);

    if (fields.length < 1) {
      append({
        id: (0,uuidv4__WEBPACK_IMPORTED_MODULE_8__.uuid)(),
        from: "",
        to: "",
        passengers: null,
        mode: null,
        round_trip: false
      }, {
        shouldFocus: false
      });
    }
  }, [fields.length]);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_common_DataInputContainer__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
    isEditing: isEditing,
    name: "businessTravel",
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_common_Stack__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP, {
        size: "subtitleBold",
        children: "Business Travel"
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_common_Stack__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
        direction: "row",
        mb: "-8px !important",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP, {
          align: "left",
          style: {
            width: "20%"
          },
          size: "meta",
          children: "From:"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP, {
          align: "left",
          style: {
            width: "20%"
          },
          size: "meta",
          children: "To:"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP, {
          align: "left",
          style: {
            width: "30%"
          },
          size: "meta",
          children: "Mode of transport:"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP, {
          align: "left",
          style: {
            width: "10%"
          },
          size: "meta",
          children: "No. of people"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP, {
          style: {
            width: "10%"
          },
          size: "meta",
          children: "Roundtrip?"
        })]
      }), fields && fields.map((business_travel, index) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(Container, {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_BusinessTravelRow__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
          business_travel,
          searchSessionIdsRef,
          index,
          remove
        })
      }, business_travel.id + index || `business_travel_${index + business_travel.key_id}`)), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
        secondary: true,
        type: "button",
        onClick: () => append({
          id: (0,uuidv4__WEBPACK_IMPORTED_MODULE_8__.uuid)(),
          from: "",
          to: "",
          passengers: null,
          mode: null,
          round_trip: false
        }),
        children: "Add more"
      })]
    }), isEditing && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.Fragment, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_common_Divider__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        margin: "20px 0"
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(BottomCTAs, {
        children: [reset && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
          type: "button",
          warning: true,
          secondary: true,
          onClick: reset,
          loading: isSubmitting,
          children: "Cancel"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
          type: "submit",
          loading: isSubmitting,
          children: "Save"
        })]
      })]
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BusinessTravelEdit);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 13357:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _common_Spinner__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16114);
/* harmony import */ var _common_DeleteButton__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(51672);
/* harmony import */ var _common_Stack__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(45364);
/* harmony import */ var _form_Checkbox_V2__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(81047);
/* harmony import */ var _form_Input__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(18183);
/* harmony import */ var _form_InputAsyncDropdown_V2__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(76135);
/* harmony import */ var _form_InputDropdown__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(51894);
/* harmony import */ var _contexts_auth__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(58368);
/* harmony import */ var _contexts_measurements__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(85238);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(11098);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(63033);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_form_Checkbox_V2__WEBPACK_IMPORTED_MODULE_5__, _form_Input__WEBPACK_IMPORTED_MODULE_6__, _form_InputAsyncDropdown_V2__WEBPACK_IMPORTED_MODULE_7__, _form_InputDropdown__WEBPACK_IMPORTED_MODULE_8__]);
([_form_Checkbox_V2__WEBPACK_IMPORTED_MODULE_5__, _form_Input__WEBPACK_IMPORTED_MODULE_6__, _form_InputAsyncDropdown_V2__WEBPACK_IMPORTED_MODULE_7__, _form_InputDropdown__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

















const Container = styled_components__WEBPACK_IMPORTED_MODULE_12___default().div.withConfig({
  displayName: "BusinessTravelRow__Container",
  componentId: "sc-1ae1h9r-0"
})(["position:relative;"]);
const Overlay = styled_components__WEBPACK_IMPORTED_MODULE_12___default().div.withConfig({
  displayName: "BusinessTravelRow__Overlay",
  componentId: "sc-1ae1h9r-1"
})(["display:", ";visibility:", ";z-index:10;width:100%;height:100%;justify-content:center;background-color:rgba(255,255,255,0.7);position:absolute;margin-right:12px;top:0;"], p => p.open ? "flex" : "none", p => p.open ? "visible" : "hidden");

const BusinessTravelRow = ({
  business_travel,
  searchSessionIdsRef,
  index,
  remove
}) => {
  const {
    organisation
  } = (0,_contexts_auth__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)();
  const {
    0: deleteLoading,
    1: setDeleteLoading
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
  const {
    dataCollectionMeasurement,
    setDataCollectionMeasurement
  } = (0,_contexts_measurements__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)();

  const deleteBusinessTravel = async () => {
    try {
      setDeleteLoading(true);

      if (Number(business_travel.id)) {
        await axios__WEBPACK_IMPORTED_MODULE_0___default()["delete"](`/api/organisations/${organisation.id}/measurements/${dataCollectionMeasurement.id}/business-travel/${business_travel.id}`);
        const {
          data
        } = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`/api/organisations/${organisation.id}/measurements/${dataCollectionMeasurement.id}`);
        setDataCollectionMeasurement(_objectSpread(_objectSpread({}, dataCollectionMeasurement), data));
      }

      remove(index);
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_11__/* .logError */ .H)(error);
    }

    setDeleteLoading(false);
  };

  const getPlaces = async ({
    input,
    id,
    type
  }) => {
    var _searchSessionIdsRef$;

    const searchSessionId = (_searchSessionIdsRef$ = searchSessionIdsRef.current) === null || _searchSessionIdsRef$ === void 0 ? void 0 : _searchSessionIdsRef$.find(searchToken => searchToken.id === id)[type];
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`/api/places/autocomplete`, {
      params: {
        input,
        searchSession: searchSessionId,
        types: "(cities)"
      }
    });
    return data.predictions.map(place => ({
      value: {
        place_id: place.place_id,
        name: place.description,
        searchSessionId
      },
      label: place.description
    }));
  };

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(Container, {
    children: [business_travel && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_form_Input__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
      name: `business_travel.${index}.id`,
      hidden: true
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(_common_Stack__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
      direction: "row",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_form_InputAsyncDropdown_V2__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
        id: `business_travel.${index}.from`,
        name: `business_travel.${index}.from`,
        testId: `business_travel.${index}.from`,
        width: "20%",
        placeholder: "Enter city",
        isRequired: true,
        loadOptions: input => getPlaces({
          input,
          id: business_travel.id,
          type: "departure"
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_form_InputAsyncDropdown_V2__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
        id: `business_travel.${index}.to`,
        name: `business_travel.${index}.to`,
        testId: `business_travel.${index}.to`,
        width: "20%",
        placeholder: "Enter city",
        loadOptions: input => getPlaces({
          input,
          id: business_travel.id,
          type: "destination"
        }),
        isRequired: true
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_form_InputDropdown__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
        id: `business_travel.${index}.mode`,
        testId: `business_travel.${index}.mode`,
        width: "30%",
        placeholder: "Select mode...",
        optionArray: _utils__WEBPACK_IMPORTED_MODULE_13__/* .BUSINESS_TRAVEL_MODES_OF_TRANSPORT */ .Ho,
        hasDefaultValue: false
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_form_Input__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
        id: `business_travel.${index}.passengers`,
        name: `business_travel.${index}.passengers`,
        testId: `business_travel.${index}.passengers`,
        width: "10%",
        type: "number",
        placeholder: "Number",
        isRequired: true,
        defaultValue: business_travel.passengers
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_form_Checkbox_V2__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
        width: "10%",
        name: `business_travel.${index}.round_trip`
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_common_DeleteButton__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        name: `business_travel.${index}`,
        onClick: deleteBusinessTravel
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(Overlay, {
      open: deleteLoading,
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_common_Spinner__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        color: "blue"
      })
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BusinessTravelRow);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 12105:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(87491);
/* harmony import */ var _common_ContainerContentSection__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(26191);
/* harmony import */ var _common_ContainerTopSection__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(58543);
/* harmony import */ var _common_DataInputContainer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(64493);
/* harmony import */ var _common_EditButton__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99224);
/* harmony import */ var _common_SectionEmissions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(47009);
/* harmony import */ var _common_Stack__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(45364);
/* harmony import */ var _common_UnorderedList__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(71313);
/* harmony import */ var _common_ViewModeDataRow__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(72441);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(63033);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__);













const BusinessTravelView = ({
  businessTravel,
  isEditing,
  reset,
  result
}) => {
  const numberOfMiles = (0,_utils__WEBPACK_IMPORTED_MODULE_9__/* .calculateNumberOfMilesBusinessTravel */ .Qd)(businessTravel);
  const travelData = (0,_utils__WEBPACK_IMPORTED_MODULE_9__/* .countViewModeTravels */ .sU)(businessTravel);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(_common_DataInputContainer__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(_common_Stack__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(_common_ContainerTopSection__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .ZP, {
          size: "subtitleBold",
          children: "Business Travel"
        }), !isEditing && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_common_EditButton__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
          name: "businessTravel",
          onClick: () => reset("businessTravel")
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(_common_ContainerContentSection__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_common_ViewModeDataRow__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
          title: "No. of trips:",
          value: businessTravel.length
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_common_UnorderedList__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
          children: travelData.map(travel => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx("li", {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_common_ViewModeDataRow__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
              title: `${travel.title}:`,
              value: travel.value,
              isBulletedList: true
            })
          }, travel.title))
        })]
      }), !!businessTravel.length && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_common_ViewModeDataRow__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
        title: "Total miles:",
        value: `${Math.round(numberOfMiles)} miles`
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_common_SectionEmissions__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
      value: result.business_travel
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BusinessTravelView);

/***/ }),

/***/ 31558:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "a": () => (/* binding */ createBusinessTravelDefaultValues),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _measurement_utils_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(19390);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(63033);
/* harmony import */ var _BusinessTravelEdit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(69490);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_BusinessTravelEdit__WEBPACK_IMPORTED_MODULE_2__]);
_BusinessTravelEdit__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const createBusinessTravelDefaultValues = office => ({
  business_travel: office.business_travel.map(businessTravel => ({
    from: {
      value: {
        place_id: businessTravel.departure_place_id || "",
        name: businessTravel.departure || ""
      },
      label: businessTravel.departure || ""
    },
    to: {
      value: {
        place_id: businessTravel.destination_place_id || "",
        name: businessTravel.destination || ""
      },
      label: businessTravel.destination || ""
    },
    mode: _utils__WEBPACK_IMPORTED_MODULE_1__/* .BUSINESS_TRAVEL_MODES_OF_TRANSPORT.find */ .Ho.find(mode => businessTravel.mode === mode.value),
    passengers: businessTravel.passengers || "",
    round_trip: businessTravel.round_trip || "",
    id: businessTravel.id || "",
    unit: _measurement_utils_constants__WEBPACK_IMPORTED_MODULE_0__/* .DISTANCE_METRICS.find */ .Kk.find(unit => businessTravel.unit === unit.value) || {
      label: businessTravel.unit || "",
      value: businessTravel.unit || ""
    }
  }))
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_BusinessTravelEdit__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 65043:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "J": () => (/* binding */ createDetailsDefaultValues),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16666);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_responsive__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _button_Button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59067);
/* harmony import */ var _common_Divider__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6459);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(87491);
/* harmony import */ var _common_DataInputContainer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(64493);
/* harmony import */ var _common_MetricNumberInput__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(61569);
/* harmony import */ var _common_Stack__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(45364);
/* harmony import */ var _form_Input__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(18183);
/* harmony import */ var _form_InputDropdown__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(51894);
/* harmony import */ var _form_Slider__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(83864);
/* harmony import */ var _measurement_utils_constants__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(19390);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _DetailsInput__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(23317);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_common_MetricNumberInput__WEBPACK_IMPORTED_MODULE_5__, _form_Input__WEBPACK_IMPORTED_MODULE_7__, _form_InputDropdown__WEBPACK_IMPORTED_MODULE_8__, _form_Slider__WEBPACK_IMPORTED_MODULE_9__]);
([_common_MetricNumberInput__WEBPACK_IMPORTED_MODULE_5__, _form_Input__WEBPACK_IMPORTED_MODULE_7__, _form_InputDropdown__WEBPACK_IMPORTED_MODULE_8__, _form_Slider__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);

















const BottomCTAs = styled_components__WEBPACK_IMPORTED_MODULE_12___default().div.withConfig({
  displayName: "DetailsEdit__BottomCTAs",
  componentId: "sc-4o779d-0"
})(["display:flex;width:100%;justify-content:flex-end;flex-direction:column;align-items:center;& > button:not(:last-child){margin-bottom:0.5rem;}", ""], _theme__WEBPACK_IMPORTED_MODULE_11__/* .media.tablet */ .BC.tablet`
    flex-direction: row;
    align-items: initial;
    
    & > button:not(:last-child) {
      margin: initial;
      margin-right: 0.5rem;
    }
  `);
const createDetailsDefaultValues = ({
  office,
  countries
}) => ({
  details: {
    name: office.details.name || "",
    country: countries.find(country => office.details.country === country.value) || "",
    size: office.details.size || "",
    unit: _measurement_utils_constants__WEBPACK_IMPORTED_MODULE_10__/* .SPACE_METRICS.find */ .X9.find(space => space.value === office.details.unit) || _measurement_utils_constants__WEBPACK_IMPORTED_MODULE_10__/* .SPACE_METRICS[0] */ .X9[0],
    number_of_staff: office.details.number_of_staff || "",
    staff_working_from_home_percentage: office.details.staff_working_from_home_percentage || ""
  }
});

const DetailsEdit = ({
  details,
  countries,
  isEditing,
  isSubmitting,
  fullyRemote,
  reset
}) => {
  const isTablet = (0,react_responsive__WEBPACK_IMPORTED_MODULE_0__.useMediaQuery)({
    query: `(min-width: ${_theme__WEBPACK_IMPORTED_MODULE_11__/* .sizes.tablet */ .J7.tablet}px)`
  });
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(_common_DataInputContainer__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
    isEditing: isEditing,
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(_common_Stack__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
      spacing: "12px",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP, {
        size: "subtitleBold",
        children: "Details"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.Fragment, {
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(_common_Stack__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
          spacing: "40px",
          direction: isTablet ? "row" : "column",
          children: [!fullyRemote && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_DetailsInput__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
            title: "Name",
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_form_Input__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
              defaultValue: details === null || details === void 0 ? void 0 : details.name,
              name: `details.name`,
              placeholder: "Enter office name...",
              width: "160px"
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_DetailsInput__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
            title: "Location",
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_form_InputDropdown__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
              id: `details.country`,
              name: `details.country`,
              testId: `details.country`,
              placeholder: "Enter country",
              width: "14rem",
              controlMargin: "0.1rem 0 1rem 0",
              isSearchable: true,
              optionArray: countries,
              isRequired: true
            })
          })]
        })
      }), !fullyRemote && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.Fragment, {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_DetailsInput__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
          title: "Office size",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_common_MetricNumberInput__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
            inputId: `details.size`,
            metricId: `details.unit`,
            name: `details.size`,
            testId: `details.size`,
            inputPlaceholder: "Number",
            metricPlaceholder: "m2",
            optionArray: _measurement_utils_constants__WEBPACK_IMPORTED_MODULE_10__/* .SPACE_METRICS */ .X9,
            defaultValue: details === null || details === void 0 ? void 0 : details.size
          })
        })
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(_common_Stack__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
        spacing: "40px",
        direction: isTablet ? "row" : "column",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_DetailsInput__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
          title: "No. of employees",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_form_Input__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
            name: `details.number_of_staff`,
            placeholder: "Enter number...",
            width: "160px"
          })
        }), !fullyRemote && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_DetailsInput__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
          title: "% working from home",
          width: isTablet ? "50%" : "100%",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_form_Slider__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
            id: `details.staff_working_from_home_percentage`,
            min: 0,
            max: 100,
            defaultValue: 0,
            margin: "0.55rem 0 1rem",
            marks: [{
              value: 0,
              label: "0%"
            }, {
              value: 25,
              label: "25%"
            }, {
              value: 50,
              label: "50%"
            }, {
              value: 75,
              label: "75%"
            }, {
              value: 100,
              label: "100%"
            }],
            valueLabelDisplay: "auto",
            step: 1
          })
        })]
      })]
    }), isEditing && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.Fragment, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_common_Divider__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        margin: "20px 0"
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(BottomCTAs, {
        children: [reset && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
          type: "button",
          warning: true,
          secondary: true,
          onClick: reset,
          loading: isSubmitting,
          children: "Cancel"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
          type: "submit",
          loading: isSubmitting,
          children: "Save"
        })]
      })]
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DetailsEdit);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 23317:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(87491);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);



const DetailsInputContainer = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "DetailsInput__DetailsInputContainer",
  componentId: "sc-1810l4s-0"
})(["width:", ";"], p => p.width);

const DetailsInput = ({
  title,
  children,
  width
}) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(DetailsInputContainer, {
  style: {
    width
  },
  children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(_common_Text__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .ZP, {
    size: "meta",
    children: [title, ": "]
  }), children]
});

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DetailsInput);

/***/ }),

/***/ 45332:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(87491);
/* harmony import */ var _common_ContainerContentSection__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(26191);
/* harmony import */ var _common_ContainerTopSection__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(58543);
/* harmony import */ var _common_DataInputContainer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(64493);
/* harmony import */ var _common_EditButton__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99224);
/* harmony import */ var _common_Stack__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(45364);
/* harmony import */ var _common_ViewModeDataRow__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(72441);
/* harmony import */ var _measurement_utils_constants__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(19390);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__);











const DetailsView = ({
  details,
  isEditing,
  countries,
  fullyRemote,
  reset
}) => {
  var _countries$find;

  const {
    name,
    country,
    size,
    unit,
    number_of_staff,
    staff_working_from_home_percentage
  } = details;
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_common_DataInputContainer__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(_common_Stack__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(_common_ContainerTopSection__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .ZP, {
          size: "subtitleBold",
          children: "Details"
        }), !isEditing && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_common_EditButton__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
          name: "details",
          onClick: () => reset("details")
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(_common_ContainerContentSection__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        children: [!fullyRemote && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_common_ViewModeDataRow__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
          title: "Office name:",
          value: name
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_common_ViewModeDataRow__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
          title: "Location:",
          value: (_countries$find = countries.find(countryObj => countryObj.value === country)) === null || _countries$find === void 0 ? void 0 : _countries$find.name
        })]
      }), !fullyRemote && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_common_ViewModeDataRow__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
        title: "Office size:",
        value: size,
        unit: _measurement_utils_constants__WEBPACK_IMPORTED_MODULE_7__/* .SPACE_METRICS.find */ .X9.find(space => space.value === unit).label
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(_common_ContainerContentSection__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_common_ViewModeDataRow__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
          title: "No. of employees:",
          value: number_of_staff
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_common_ViewModeDataRow__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
          title: "% working from home:",
          value: `${staff_working_from_home_percentage}%`
        })]
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DetailsView);

/***/ }),

/***/ 5024:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _DetailsEdit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(65043);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_DetailsEdit__WEBPACK_IMPORTED_MODULE_0__]);
_DetailsEdit__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_DetailsEdit__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 53792:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(45641);
/* harmony import */ var _button_Button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(59067);
/* harmony import */ var _common_Divider__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6459);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(87491);
/* harmony import */ var _common_DataInputContainer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(64493);
/* harmony import */ var _common_Stack__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(45364);
/* harmony import */ var _measurement_common_ButtonsContainer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(30495);
/* harmony import */ var _measurement_utils_constants__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(19390);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _EmployeeCommutesRow__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(57861);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_1__, _EmployeeCommutesRow__WEBPACK_IMPORTED_MODULE_11__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_1__, _EmployeeCommutesRow__WEBPACK_IMPORTED_MODULE_11__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
















const Container = styled_components__WEBPACK_IMPORTED_MODULE_10___default().div.withConfig({
  displayName: "EmployeeCommutesEdit__Container",
  componentId: "sc-43entp-0"
})(["width:100%;position:relative;"]);
const BottomCTAs = styled_components__WEBPACK_IMPORTED_MODULE_10___default().div.withConfig({
  displayName: "EmployeeCommutesEdit__BottomCTAs",
  componentId: "sc-43entp-1"
})(["display:flex;width:100%;justify-content:flex-end;flex-direction:column;align-items:center;& > button:not(:last-child){margin-bottom:0.5rem;}", ""], _theme__WEBPACK_IMPORTED_MODULE_9__/* .media.tablet */ .BC.tablet`
    flex-direction: row;
    align-items: initial;
    
    & > button:not(:last-child) {
      margin: initial;
      margin-right: 0.5rem;
    }
  `);

const EmployeeCommutesEdit = ({
  isEditing,
  isSubmitting,
  reset
}) => {
  const {
    control
  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_1__.useFormContext)();
  const {
    fields,
    append,
    remove
  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_1__.useFieldArray)({
    control,
    name: "employee_commutes",
    keyName: "key_id"
  });
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (fields.length < 1) {
      append({
        name: "",
        value: null,
        mode: "",
        unit: _measurement_utils_constants__WEBPACK_IMPORTED_MODULE_8__/* .DISTANCE_METRICS[0] */ .Kk[0]
      }, {
        shouldFocus: false
      });
    }
  }, [fields.length]);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_common_DataInputContainer__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
    isEditing: isEditing,
    name: "employeeCommutes",
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_common_Stack__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP, {
        size: "subtitleBold",
        children: "Employee Commutes"
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_common_Text__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP, {
        size: "tinyTitle",
        align: "left",
        children: ["Please enter the commuting distance, one way, and the primary mode of transport.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx("br", {}), "If you have a large team, a small survey of results will be averaged and projected out."]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_common_Stack__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
        direction: "row",
        spacing: "28px",
        mb: "-8px !important",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP, {
          align: "left",
          style: {
            width: "20%"
          },
          size: "meta",
          children: "Employee name:"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP, {
          align: "left",
          style: {
            width: "20%"
          },
          size: "meta",
          children: "Distance for one way:"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP, {
          align: "left",
          style: {
            width: "30%"
          },
          size: "meta",
          children: "Mode of transport:"
        })]
      }), fields && fields.map((employee_commute, index) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(Container, {
        children: /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.createElement)(_EmployeeCommutesRow__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
          employee_commute,
          remove,
          index,
          key: employee_commute.id || `employee_commute_${index}`
        })
      }, employee_commute.id + index || `employee_commute_${index + employee_commute.key_id}`)), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_measurement_common_ButtonsContainer__WEBPACK_IMPORTED_MODULE_7__/* .OfficeButtonsContainer */ .g, {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
          secondary: true,
          type: "button",
          onClick: () => append({
            name: "",
            value: null,
            mode: "",
            unit: _measurement_utils_constants__WEBPACK_IMPORTED_MODULE_8__/* .DISTANCE_METRICS[0] */ .Kk[0]
          }),
          children: "Add more"
        })
      })]
    }), isEditing && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.Fragment, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_common_Divider__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        margin: "20px 0"
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(BottomCTAs, {
        children: [reset && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
          type: "button",
          warning: true,
          secondary: true,
          onClick: reset,
          loading: isSubmitting,
          children: "Cancel"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
          type: "submit",
          loading: isSubmitting,
          children: "Save"
        })]
      })]
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EmployeeCommutesEdit);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 57861:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _common_Spinner__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16114);
/* harmony import */ var _common_DeleteButton__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(51672);
/* harmony import */ var _common_MetricNumberInput__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(61569);
/* harmony import */ var _common_Stack__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(45364);
/* harmony import */ var _form_Input__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(18183);
/* harmony import */ var _form_InputDropdown__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(51894);
/* harmony import */ var _measurement_utils_constants__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(19390);
/* harmony import */ var _contexts_auth__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(58368);
/* harmony import */ var _contexts_measurements__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(85238);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(11098);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(63033);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_common_MetricNumberInput__WEBPACK_IMPORTED_MODULE_4__, _form_Input__WEBPACK_IMPORTED_MODULE_6__, _form_InputDropdown__WEBPACK_IMPORTED_MODULE_7__]);
([_common_MetricNumberInput__WEBPACK_IMPORTED_MODULE_4__, _form_Input__WEBPACK_IMPORTED_MODULE_6__, _form_InputDropdown__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

















const Container = styled_components__WEBPACK_IMPORTED_MODULE_12___default().div.withConfig({
  displayName: "EmployeeCommutesRow__Container",
  componentId: "sc-1fbydid-0"
})(["position:relative;"]);
const Overlay = styled_components__WEBPACK_IMPORTED_MODULE_12___default().div.withConfig({
  displayName: "EmployeeCommutesRow__Overlay",
  componentId: "sc-1fbydid-1"
})(["display:", ";visibility:", ";z-index:10;width:100%;height:100%;justify-content:center;background-color:rgba(255,255,255,0.7);position:absolute;margin-right:12px;top:0;"], p => p.open ? "flex" : "none", p => p.open ? "visible" : "hidden");

const EmployeeCommutesRow = ({
  employee_commute,
  index,
  remove
}) => {
  const {
    0: deleteLoading,
    1: setDeleteLoading
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
  const {
    organisation
  } = (0,_contexts_auth__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)();
  const {
    dataCollectionMeasurement,
    setDataCollectionMeasurement
  } = (0,_contexts_measurements__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)();

  const deleteCommute = async () => {
    setDeleteLoading(true);

    try {
      if (Number(employee_commute.id)) {
        await axios__WEBPACK_IMPORTED_MODULE_0___default()["delete"](`/api/organisations/${organisation.id}/measurements/${dataCollectionMeasurement.id}/commutes/${employee_commute.id}`);
        const {
          data
        } = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`/api/organisations/${organisation.id}/measurements/${dataCollectionMeasurement.id}`);
        setDataCollectionMeasurement(_objectSpread(_objectSpread({}, dataCollectionMeasurement), data));
      }

      remove(index);
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_11__/* .logError */ .H)(error);
    }

    setDeleteLoading(false);
  };

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(Container, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(_common_Stack__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
      direction: "row",
      spacing: "28px",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_form_Input__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
        id: `employee_commutes.${index}.name`,
        name: `employee_commutes.${index}.name`,
        testId: `employee_commutes.${index}.name`,
        width: "20%",
        placeholder: "Enter name...",
        step: 0.01,
        isRequired: true
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx("div", {
        style: {
          display: "flex",
          flexDirection: "row",
          width: "20%"
        },
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_common_MetricNumberInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
          inputId: `employee_commutes.${index}.value`,
          metricId: `employee_commutes.${index}.unit`,
          name: `employee_commutes.${index}.value`,
          testId: `employee_commutes.${index}.value`,
          inputPlaceholder: "Number",
          metricPlaceholder: "km",
          optionArray: _measurement_utils_constants__WEBPACK_IMPORTED_MODULE_8__/* .DISTANCE_METRICS */ .Kk
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_form_InputDropdown__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
        id: `employee_commutes.${index}.mode`,
        testId: `employee_commutes.${index}.mode`,
        width: "30%",
        placeholder: "Select mode...",
        optionArray: _utils__WEBPACK_IMPORTED_MODULE_13__/* .EMPLOYEE_COMMUTES_MODES_OF_TRANSPORT */ .rS,
        hasDefaultValue: false
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_common_DeleteButton__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        name: `employee_commutes.${index}`,
        onClick: deleteCommute
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(Overlay, {
      open: deleteLoading,
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_common_Spinner__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        color: "blue"
      })
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EmployeeCommutesRow);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 31982:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(87491);
/* harmony import */ var _common_ContainerContentSection__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(26191);
/* harmony import */ var _common_ContainerTopSection__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(58543);
/* harmony import */ var _common_DataInputContainer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(64493);
/* harmony import */ var _common_EditButton__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(99224);
/* harmony import */ var _common_SectionEmissions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(47009);
/* harmony import */ var _common_Stack__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(45364);
/* harmony import */ var _common_ViewModeDataRow__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(72441);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(63033);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__);













const ButtonText = styled_components__WEBPACK_IMPORTED_MODULE_10___default()(_common_Text__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP).withConfig({
  displayName: "EmployeeCommutesView__ButtonText",
  componentId: "sc-15jx1a4-0"
})(["cursor:pointer;color:", ";"], p => p.theme.colors.blue);

const EmployeeCommutesView = ({
  employeeCommutes,
  isEditing,
  reset,
  result
}) => {
  const {
    0: readMore,
    1: setReadMore
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const numberOfMiles = (0,_utils__WEBPACK_IMPORTED_MODULE_9__/* .calculateNumberOfMiles */ .fc)(employeeCommutes);
  const travelData = (0,_utils__WEBPACK_IMPORTED_MODULE_9__/* .countViewModeTravels */ .sU)(employeeCommutes);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_common_DataInputContainer__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_common_ContainerTopSection__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
        size: "subtitleBold",
        children: "Employee Commutes"
      }), !isEditing && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_common_EditButton__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
        name: "employeeCommutes",
        onClick: () => reset("employeeCommutes")
      })]
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_common_Stack__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
        size: "tinyTitle",
        align: "left",
        children: "These are projected figures for the whole office."
      }), !!employeeCommutes.length && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_common_ViewModeDataRow__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
        title: "Total distance (one way):",
        value: `${Math.round(numberOfMiles)} miles`
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_common_ContainerContentSection__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        children: travelData.map(travel => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_common_ViewModeDataRow__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
          title: `${travel.title}:`,
          value: travel.value
        }, travel.title))
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_common_ContainerContentSection__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_common_ViewModeDataRow__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
          title: "Sample size:",
          value: employeeCommutes.length
        }), !!employeeCommutes.length && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_common_ViewModeDataRow__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
          title: "Sample entered:",
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_common_Stack__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
            spacing: "2px",
            children: [employeeCommutes.slice(0, readMore ? employeeCommutes.length : 5).map(travel => {
              var _EMPLOYEE_COMMUTES_MO;

              return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_common_Text__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
                size: "meta",
                align: "left",
                children: [travel.name, " -", " ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_common_Text__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
                  size: "meta",
                  children: [travel.value, " ", travel.unit, " -", " ", (_EMPLOYEE_COMMUTES_MO = _utils__WEBPACK_IMPORTED_MODULE_9__/* .EMPLOYEE_COMMUTES_MODES_OF_TRANSPORT.find */ .rS.find(el => el.value === travel.mode)) === null || _EMPLOYEE_COMMUTES_MO === void 0 ? void 0 : _EMPLOYEE_COMMUTES_MO.label]
                })]
              }, travel.id);
            }), employeeCommutes.length > 5 && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(ButtonText, {
              size: "button",
              onClick: () => setReadMore(!readMore),
              children: readMore ? "Read Less" : "Read More"
            })]
          })
        })]
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_common_SectionEmissions__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
      value: result.projected_employee_commutes
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EmployeeCommutesView);

/***/ }),

/***/ 6137:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "s": () => (/* binding */ createEmployeeCommutesDefaultValues),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _measurement_utils_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(19390);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(63033);
/* harmony import */ var _EmployeeCommutesEdit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(53792);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_EmployeeCommutesEdit__WEBPACK_IMPORTED_MODULE_2__]);
_EmployeeCommutesEdit__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const createEmployeeCommutesDefaultValues = office => ({
  employee_commutes: office.employee_commutes.map(employeeCommute => ({
    id: employeeCommute.id || "",
    value: employeeCommute.value || "",
    mode: _utils__WEBPACK_IMPORTED_MODULE_1__/* .EMPLOYEE_COMMUTES_MODES_OF_TRANSPORT.find */ .rS.find(mode => employeeCommute.mode === mode.value),
    unit: _measurement_utils_constants__WEBPACK_IMPORTED_MODULE_0__/* .DISTANCE_METRICS.find */ .Kk.find(unit => employeeCommute.unit === unit.value) || {
      label: employeeCommute.unit || "",
      value: employeeCommute.unit || ""
    },
    name: employeeCommute.name || ""
  }))
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_EmployeeCommutesEdit__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 84259:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(87491);
/* harmony import */ var _common_ContainerContentSection__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(26191);
/* harmony import */ var _common_ContainerTopSection__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(58543);
/* harmony import */ var _common_DataInputContainer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(64493);
/* harmony import */ var _common_SectionEmissions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(47009);
/* harmony import */ var _common_Stack__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(45364);
/* harmony import */ var _common_ViewModeDataRow__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(72441);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__);










const HomeworkingView = ({
  result
}) => {
  var _result$homeworking_g, _result$homeworking_e;

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(_common_DataInputContainer__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(_common_Stack__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_common_ContainerTopSection__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .ZP, {
          size: "subtitleBold",
          children: "Homeworking"
        })
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(_common_ContainerContentSection__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_common_ViewModeDataRow__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
          title: "Gas:",
          value: (result === null || result === void 0 ? void 0 : (_result$homeworking_g = result.homeworking_gas) === null || _result$homeworking_g === void 0 ? void 0 : _result$homeworking_g.toFixed(2)) || 0,
          unit: "kgCO2e"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_common_ViewModeDataRow__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
          title: "Electricity:",
          value: (result === null || result === void 0 ? void 0 : (_result$homeworking_e = result.homeworking_electricity) === null || _result$homeworking_e === void 0 ? void 0 : _result$homeworking_e.toFixed(2)) || 0,
          unit: "kgCO2e"
        })]
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_common_SectionEmissions__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
      value: result.homeworking
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HomeworkingView);

/***/ }),

/***/ 62488:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _common_ConfirmationModal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65487);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(87491);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





var Bin = function Bin(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("g", {
      clipPath: "url(#clip0)",
      fill: "#EC5F59",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("path", {
        d: "M11.768 25c-2.014 0-4.028.003-6.041 0-.49 0-.98-.006-1.467-.049-.847-.073-1.573-.835-1.622-1.719-.126-2.313-.235-4.626-.343-6.94-.16-3.384-.314-6.769-.463-10.154-.017-.38-.173-.516-.522-.489a2.16 2.16 0 0 1-.282 0C.413 5.621-.013 5.213 0 4.667c.013-.561.496-.976 1.115-.971 1.712.012 3.424.021 5.136.027 1.275 0 1.274-.005 1.486-1.298.052-.322.092-.647.176-.96.11-.42.355-.792.696-1.057.341-.264.758-.406 1.187-.403 1.335.007 2.67.026 4.007.04 1.085.01 1.81.64 1.988 1.726.083.51.174 1.019.241 1.53.04.312.18.393.49.393 2.031-.004 4.063.013 6.093.033.615.007.99.375 1 .933.008.583-.375.958-1.01.989-.786.037-.772.041-.81.872-.215 4.512-.434 9.024-.657 13.536-.048 1.032-.083 2.067-.136 3.099-.052 1.007-.8 1.796-1.778 1.804-2.484.02-4.969.007-7.453.007l-.004.033zm.063-1.96c2.163 0 4.326-.022 6.49.016.574.01.772-.193.788-.737.025-.841.087-1.682.125-2.523.202-4.474.401-8.95.598-13.424.033-.73.03-.73-.727-.724-2.389.017-4.776.046-7.164.046-2.538 0-5.077-.018-7.615-.054-.452-.006-.567.127-.545.592.22 4.512.405 9.026.628 13.538.04.823.067 1.645.105 2.467.037.769.084.804.827.804h6.49zm.093-19.338v.008c.377 0 .754.022 1.13-.004 1.061-.074 1.043-.08.887-1.179-.063-.435-.252-.576-.67-.566-.976.023-1.954.005-2.932.008-.22 0-.508-.052-.563.246-.086.46-.273.922-.13 1.4.034.113.194.09.307.089.657-.004 1.314-.003 1.971-.003v.001z"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("path", {
        d: "M8.69 18.497c0 .268.003.536 0 .803-.012.631-.339 1.023-.878 1.059-.553.037-.954-.295-1.014-.916a63.554 63.554 0 0 1-.186-2.86 598.873 598.873 0 0 1-.258-6.133c-.028-.742.278-1.15.84-1.2.6-.055.983.3 1.062 1.056.08.756.118 1.523.154 2.289.093 1.967.174 3.935.26 5.902h.02zM17.265 11.124c-.12 2.598-.242 5.195-.363 7.792-.013.19-.037.38-.072.569-.096.577-.47.9-1 .873-.537-.027-.898-.42-.883-1.046.032-1.357.085-2.715.145-4.07.06-1.337.135-2.673.21-4.008.021-.382.04-.765.096-1.142.087-.57.489-.884 1.022-.844.495.04.835.412.857.959.011.305 0 .612 0 .918h-.012zM10.868 14.807c0-1.51-.01-3.019.005-4.528.007-.665.379-1.043.95-1.034.571.009.932.396.935 1.057.01 2.062.004 4.125.008 6.188 0 .898.005 1.796.02 2.693.013.697-.357 1.165-.95 1.175-.604.012-.97-.419-.97-1.137v-4.414h.002z"
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("defs", {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("clipPath", {
        id: "clip0",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("path", {
          fill: "#fff",
          d: "M0 0h23.611v25H0z"
        })
      })
    })]
  }));
};

Bin.defaultProps = {
  width: "24",
  height: "25",
  viewBox: "0 0 24 25",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var NotifyIcon = function NotifyIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("path", {
      d: "M10.01 0C15.453-.04 20.053 4.48 20 10.09c-.052 5.348-4.374 9.902-10 9.902-5.648 0-10.05-4.6-10-10.087C.052 4.307 4.655-.043 10.01.001zm0 2.022c-4.322-.01-7.804 3.425-7.974 7.637-.183 4.51 3.372 8.232 7.82 8.303 4.559.075 8.005-3.571 8.116-7.756.114-4.396-3.417-8.183-7.964-8.184h.002z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("path", {
      d: "M11.014 8.49v2.6c0 .594-.451 1.06-1.013 1.053-.574-.009-1.018-.464-1.018-1.055-.002-1.74-.002-3.48 0-5.219 0-.58.446-1.035 1.01-1.04.573-.005 1.021.45 1.022 1.042v2.62zM11.015 14.074c.013.424-.167.747-.532.954-.342.195-.689.17-1.026-.033-.39-.235-.577-.785-.437-1.28a1.018 1.018 0 0 1 .996-.745c.476.012.858.324.977.794.026.104.018.206.022.31z"
    })]
  }));
};

NotifyIcon.defaultProps = {
  width: "20",
  height: "20",
  viewBox: "0 0 20 20",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};




const TitleContainer = styled_components__WEBPACK_IMPORTED_MODULE_5___default().div.withConfig({
  displayName: "ResetFormModal__TitleContainer",
  componentId: "sc-1o6hcw-0"
})(["display:flex;flex-direction:column;align-items:center;justify-content:center;"]);
const BodyContainer = styled_components__WEBPACK_IMPORTED_MODULE_5___default()(TitleContainer).withConfig({
  displayName: "ResetFormModal__BodyContainer",
  componentId: "sc-1o6hcw-1"
})(["padding:0 1rem;", ""], _theme__WEBPACK_IMPORTED_MODULE_4__/* .media.tablet */ .BC.tablet`
  padding: 0 1.875rem;
`);
const NoUtilityBillsContainer = styled_components__WEBPACK_IMPORTED_MODULE_5___default().div.withConfig({
  displayName: "ResetFormModal__NoUtilityBillsContainer",
  componentId: "sc-1o6hcw-2"
})(["background:", ";border-radius:4px;padding:0.5rem 1rem;display:flex;justify-content:flex-start;align-items:center;margin-top:0.5rem;& > svg{fill:", ";margin-right:0.25rem;}"], p => p.theme.colors.backgroundYellow, p => p.theme.colors.black);

const ResetFormModal = ({
  showConfirmationModal,
  setShowConfirmationModal,
  onConfirm,
  loading,
  officeName
}) => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_common_ConfirmationModal__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
    open: showConfirmationModal,
    onClose: () => setShowConfirmationModal(!showConfirmationModal),
    onConfirm: onConfirm,
    cancelText: "Go back",
    confirmText: "Remove",
    maxWidth: "32.5rem",
    title: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(TitleContainer, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(Bin, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
        size: "modalTitle",
        color: "error",
        children: "Reset all offices"
      })]
    }),
    body: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(BodyContainer, {
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(NoUtilityBillsContainer, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(NotifyIcon, {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(_common_Text__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
          size: "alert",
          align: "left",
          children: ["This deletes all progress on on ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("u", {
            children: "all"
          }), " offices and is irreversible."]
        })]
      })
    }),
    loading: loading,
    warning: true
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ResetFormModal);

/***/ }),

/***/ 52069:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D": () => (/* binding */ createWasteAndUtilitiesDefaultValues),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(45641);
/* harmony import */ var _button_Button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(59067);
/* harmony import */ var _common_Divider__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6459);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(87491);
/* harmony import */ var _common_DataInputContainer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(64493);
/* harmony import */ var _common_MetricNumberInput__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(61569);
/* harmony import */ var _UtilityInput__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(18151);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(63033);
/* harmony import */ var _measurement_utils_constants__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(19390);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_1__, _common_MetricNumberInput__WEBPACK_IMPORTED_MODULE_6__, _UtilityInput__WEBPACK_IMPORTED_MODULE_7__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_1__, _common_MetricNumberInput__WEBPACK_IMPORTED_MODULE_6__, _UtilityInput__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
















const LeftContainer = styled_components__WEBPACK_IMPORTED_MODULE_11___default().div.withConfig({
  displayName: "UtilitiesEdit__LeftContainer",
  componentId: "sc-1hifeuo-0"
})(["min-width:40%;margin-right:1.25rem;"]);
const RightContainer = styled_components__WEBPACK_IMPORTED_MODULE_11___default().div.withConfig({
  displayName: "UtilitiesEdit__RightContainer",
  componentId: "sc-1hifeuo-1"
})(["min-width:60%;"]);
const SubtitleContainer = styled_components__WEBPACK_IMPORTED_MODULE_11___default().div.withConfig({
  displayName: "UtilitiesEdit__SubtitleContainer",
  componentId: "sc-1hifeuo-2"
})(["margin-bottom:0.75rem;"]);
const WasteUtility = styled_components__WEBPACK_IMPORTED_MODULE_11___default().div.withConfig({
  displayName: "UtilitiesEdit__WasteUtility",
  componentId: "sc-1hifeuo-3"
})(["display:flex;width:100%;align-items:center;&:not(:first-child){margin-top:12px;}"]);
const BottomCTAs = styled_components__WEBPACK_IMPORTED_MODULE_11___default().div.withConfig({
  displayName: "UtilitiesEdit__BottomCTAs",
  componentId: "sc-1hifeuo-4"
})(["display:flex;width:100%;justify-content:flex-end;flex-direction:column;align-items:center;& > button:not(:last-child){margin-bottom:0.5rem;}", ""], _theme__WEBPACK_IMPORTED_MODULE_10__/* .media.tablet */ .BC.tablet`
    flex-direction: row;
    align-items: initial;
    
    & > button:not(:last-child) {
      margin: initial;
      margin-right: 0.5rem;
    }
  `);

const generateUtilityInfo = annual => {
  const time = annual ? "year" : "month";
  const timePeriod = annual ? "annual" : "monthly";
  return {
    gas: {
      title: `Do you know your ${timePeriod} gas consumption?`,
      labels: [`Gas consumption per ${time}:`],
      optionArray: _measurement_utils_constants__WEBPACK_IMPORTED_MODULE_9__/* .GAS_ELECTRICTY_METRICS */ .Qj
    },
    electricity: {
      title: `Do you know your ${timePeriod} electricity consumption?`,
      labels: [`Electricity consumption per ${time}:`],
      optionArray: _measurement_utils_constants__WEBPACK_IMPORTED_MODULE_9__/* .GAS_ELECTRICTY_METRICS */ .Qj
    },
    water: {
      title: `Do you know your ${timePeriod} water usage?`,
      labels: [`Water usage per ${time}:`],
      optionArray: _measurement_utils_constants__WEBPACK_IMPORTED_MODULE_9__/* .WATER_METRICS */ .Se
    },
    waste: {
      title: `Do you know your ${timePeriod} waste generated?`,
      labels: {
        recycling: `Recycling waste generation per ${time}:`,
        landfill: `General waste generation per ${time}:`
      },
      optionArray: _utils__WEBPACK_IMPORTED_MODULE_8__/* .WASTE_UNITS */ .L8
    }
  };
};

const createWasteAndUtilitiesDefaultValues = office => !office.details.fully_remote ? {
  landfill: office.waste.find(waste => {
    if (waste.type === "landfill") {
      return {
        known: waste.known,
        value: waste.value,
        unit: _utils__WEBPACK_IMPORTED_MODULE_8__/* .WASTE_UNITS.find */ .L8.find(wasteMetric => wasteMetric.value === waste.unit) || _utils__WEBPACK_IMPORTED_MODULE_8__/* .WASTE_UNITS[0] */ .L8[0]
      };
    }
  }) || {},
  recycling: office.waste.find(waste => {
    if (waste.type === "recycling") {
      return {
        known: waste.known,
        value: waste.value,
        unit: _utils__WEBPACK_IMPORTED_MODULE_8__/* .WASTE_UNITS.find */ .L8.find(wasteMetric => wasteMetric.value === waste.unit) || _utils__WEBPACK_IMPORTED_MODULE_8__/* .WASTE_UNITS[0] */ .L8[0]
      };
    }
  }) || {},
  utilities: office.utilities.map(utility => ({
    id: utility.id || "",
    type: utility.type || "",
    value: utility.value || null,
    known: utility.known || "",
    unit: utility.type === "water" ? _measurement_utils_constants__WEBPACK_IMPORTED_MODULE_9__/* .WATER_METRICS.find */ .Se.find(unit => unit.value === utility.unit) || _measurement_utils_constants__WEBPACK_IMPORTED_MODULE_9__/* .WATER_METRICS[0] */ .Se[0] : _measurement_utils_constants__WEBPACK_IMPORTED_MODULE_9__/* .GAS_ELECTRICTY_METRICS.find */ .Qj.find(unit => unit.value === utility.unit) || _measurement_utils_constants__WEBPACK_IMPORTED_MODULE_9__/* .GAS_ELECTRICTY_METRICS[0] */ .Qj[0]
  })),
  waste: office.waste.map(waste => ({
    id: waste.id || "",
    type: waste.type || "",
    value: waste.value || null,
    known: waste.known || "",
    unit: _utils__WEBPACK_IMPORTED_MODULE_8__/* .WASTE_UNITS.find */ .L8.find(wasteMetric => wasteMetric.value === waste.unit) || _utils__WEBPACK_IMPORTED_MODULE_8__/* .WASTE_UNITS[0] */ .L8[0],
    name: waste.name || ""
  }))
} : {};

const UtilitiesEdit = ({
  isEditing,
  isSubmitting,
  reset,
  annual
}) => {
  const {
    getValues
  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_1__.useFormContext)();
  const utilities = getValues("utilities");
  const waste = getValues("waste");
  const UTILITY_INFO = generateUtilityInfo(annual);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_common_DataInputContainer__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
    isEditing: isEditing,
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP, {
      size: "subtitleBold",
      children: "Utilities"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(SubtitleContainer, {
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_common_Text__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP, {
        size: "tinyTitle",
        align: "left",
        children: ["By entering ‘No’, assumptions will be used to calculate values.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx("br", {}), "Entering ‘Not used’ will result in a value of 0."]
      })
    }), utilities && utilities.sort((a, b) => _utils__WEBPACK_IMPORTED_MODULE_8__/* .utilitiesOrderArray.indexOf */ .XM.indexOf(a.type) - _utils__WEBPACK_IMPORTED_MODULE_8__/* .utilitiesOrderArray.indexOf */ .XM.indexOf(b.type)).map((utility, index) => {
      const {
        type
      } = utility;
      return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_UtilityInput__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
          type: "utilities",
          index: index,
          title: UTILITY_INFO[type].title,
          canChooseNotUsed: type === "gas",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(LeftContainer, {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP, {
              size: "meta",
              children: UTILITY_INFO[type].labels[0]
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(RightContainer, {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_common_MetricNumberInput__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
              inputId: `utilities.[${index}].value`,
              metricId: `utilities.[${index}].unit`,
              name: `utilities.[${index}].value`,
              testId: `utilities.[${index}].name`,
              inputPlaceholder: "Number",
              metricPlaceholder: UTILITY_INFO[type].optionArray[0].label,
              optionArray: UTILITY_INFO[type].optionArray,
              defaultValue: UTILITY_INFO[type].optionArray[0]
            })
          })]
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_common_Divider__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
          secondary: true,
          margin: "12px 0"
        })]
      }, type);
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_UtilityInput__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
      type: "waste",
      title: UTILITY_INFO.waste.title,
      index: 0,
      column: true,
      children: waste.sort((a, b) => _utils__WEBPACK_IMPORTED_MODULE_8__/* .wasteOrderArray.indexOf */ .dh.indexOf(a.type) - _utils__WEBPACK_IMPORTED_MODULE_8__/* .wasteOrderArray.indexOf */ .dh.indexOf(b.type)).map((waste, index) => {
        const {
          type
        } = waste;
        return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(WasteUtility, {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(LeftContainer, {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP, {
              size: "meta",
              children: UTILITY_INFO.waste.labels[type]
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(RightContainer, {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_common_MetricNumberInput__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
              inputId: `waste.[${index}].value`,
              metricId: `waste.[${index}].unit`,
              name: `waste.[${index}].value`,
              testId: `waste.[${index}].name`,
              inputPlaceholder: "Number",
              metricPlaceholder: UTILITY_INFO.waste.optionArray[0].label,
              optionArray: UTILITY_INFO.waste.optionArray
            })
          })]
        }, type);
      })
    }), isEditing && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.Fragment, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_common_Divider__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        margin: "20px 0"
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(BottomCTAs, {
        children: [reset && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
          type: "button",
          warning: true,
          secondary: true,
          onClick: reset,
          loading: isSubmitting,
          children: "Cancel"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
          type: "submit",
          loading: isSubmitting,
          children: "Save"
        })]
      })]
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (UtilitiesEdit);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6778:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(87491);
/* harmony import */ var _common_ContainerContentSection__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(26191);
/* harmony import */ var _common_ContainerTopSection__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(58543);
/* harmony import */ var _common_DataInputContainer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(64493);
/* harmony import */ var _common_EditButton__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99224);
/* harmony import */ var _common_SectionEmissions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(47009);
/* harmony import */ var _common_Stack__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(45364);
/* harmony import */ var _common_UnorderedList__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(71313);
/* harmony import */ var _common_ViewModeDataRow__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(72441);
/* harmony import */ var _utils_text__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(88703);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(63033);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__);














function UtilitiesView({
  utilities,
  waste,
  isEditing,
  reset,
  result
}) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(_common_DataInputContainer__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(_common_ContainerTopSection__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .ZP, {
        size: "subtitleBold",
        children: "Utilities"
      }), !isEditing && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_common_EditButton__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
        name: "utilities",
        onClick: () => reset("utilities")
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_common_Stack__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
      mt: 0.5,
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(_common_ContainerContentSection__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        children: [utilities.sort((a, b) => _utils__WEBPACK_IMPORTED_MODULE_9__/* .utilitiesOrderArray.indexOf */ .XM.indexOf(a.type) - _utils__WEBPACK_IMPORTED_MODULE_9__/* .utilitiesOrderArray.indexOf */ .XM.indexOf(b.type)).map(utility => {
          var _result$utility$type;

          return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_common_ViewModeDataRow__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
            title: `${(0,_utils_text__WEBPACK_IMPORTED_MODULE_11__/* .capitalize */ .k)(utility.type)}:`,
            value: ((_result$utility$type = result[utility.type]) === null || _result$utility$type === void 0 ? void 0 : _result$utility$type.toFixed(2)) || 0,
            unit: "kgCO2e"
          }, utility.id);
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .ZP, {
          size: "meta",
          align: "left",
          children: "Waste:"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_common_UnorderedList__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
          children: waste.sort((a, b) => _utils__WEBPACK_IMPORTED_MODULE_9__/* .wasteOrderArray.indexOf */ .dh.indexOf(a.type) - _utils__WEBPACK_IMPORTED_MODULE_9__/* .wasteOrderArray.indexOf */ .dh.indexOf(b.type)).map(waste => {
            var _result$;

            return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx("li", {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_common_ViewModeDataRow__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                title: `${(0,_utils_text__WEBPACK_IMPORTED_MODULE_11__/* .capitalize */ .k)(waste.type)}:`,
                value: ((_result$ = result[`waste_${waste.type}`]) === null || _result$ === void 0 ? void 0 : _result$.toFixed(2)) || 0,
                unit: "kgCO2e",
                isBulletedList: true
              })
            }, waste.id);
          })
        })]
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_common_SectionEmissions__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
      value: result.utilities
    })]
  });
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (UtilitiesView);

/***/ }),

/***/ 18151:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _hookform_error_message__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(83218);
/* harmony import */ var _hookform_error_message__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_hookform_error_message__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(45641);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16666);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_responsive__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _button_Button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(59067);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(87491);
/* harmony import */ var _common_Stack__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(45364);
/* harmony import */ var _form_Error__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(26428);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_1__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];











const MainContainer = styled_components__WEBPACK_IMPORTED_MODULE_8___default().div.withConfig({
  displayName: "UtilityInput__MainContainer",
  componentId: "sc-1ubol4v-0"
})(["display:flex;width:100%;align-items:center;flex-direction:column;", ""], _theme__WEBPACK_IMPORTED_MODULE_7__/* .media.tablet */ .BC.tablet`
    flex-direction: row;  
    ${p => p.column && "flex-direction: column;"}
  `);
const LeftContainer = styled_components__WEBPACK_IMPORTED_MODULE_8___default().div.withConfig({
  displayName: "UtilityInput__LeftContainer",
  componentId: "sc-1ubol4v-1"
})(["min-width:40%;margin-right:1.25rem;"]);
const UtilityInputButton = styled_components__WEBPACK_IMPORTED_MODULE_8___default()(_button_Button__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP).withConfig({
  displayName: "UtilityInput__UtilityInputButton",
  componentId: "sc-1ubol4v-2"
})(["padding:0.5rem 0.25rem;"]);

const UtilityInput = ({
  title,
  children,
  index,
  type,
  column,
  canChooseNotUsed = false
}) => {
  const isTablet = (0,react_responsive__WEBPACK_IMPORTED_MODULE_2__.useMediaQuery)({
    query: `(min-width: ${_theme__WEBPACK_IMPORTED_MODULE_7__/* .sizes.tablet */ .J7.tablet}px)`
  });
  const {
    setValue,
    getValues,
    watch,
    formState
  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_1__.useFormContext)();
  const {
    errors
  } = formState;
  const value = watch(`${type}.[${index}].known`);

  const isInactive = string => string !== value;

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(_common_Stack__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
    spacing: "12px",
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(MainContainer, {
      "data-cy": `cy-${type === "utilities" ? getValues(`${type}.[${index}].type`) : type}-row`,
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(LeftContainer, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP, {
          size: "meta",
          children: title
        }), errors && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("div", {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_hookform_error_message__WEBPACK_IMPORTED_MODULE_0__.ErrorMessage, {
            errors: errors,
            name: `${type}.[${index}].known`,
            render: () => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_form_Error__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
              children: `Please select a value for ${type === "utilities" ? getValues(`${type}.[${index}].type`) : type}`
            })
          })
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(_common_Stack__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
        direction: isTablet ? "row" : "column",
        spacing: "20px",
        width: "60%",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(UtilityInputButton, {
          type: "button",
          secondary: isInactive("yes"),
          onClick: () => setValue(`${type}.[${index}].known`, "yes", {
            shouldValidate: true
          }),
          width: "100px",
          children: "Yes"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(UtilityInputButton, {
          type: "button",
          secondary: isInactive("no"),
          onClick: () => setValue(`${type}.[${index}].known`, "no", {
            shouldValidate: true,
            shouldDirty: true,
            shouldTouch: true
          }),
          width: "100px",
          children: "No"
        }), canChooseNotUsed && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(UtilityInputButton, {
          type: "button",
          secondary: isInactive("not_used"),
          onClick: () => setValue(`${type}.[${index}].known`, "not_used", {
            shouldValidate: true
          }),
          width: "100px",
          children: "Not used"
        })]
      })]
    }), getValues(`${type}.[${index}].known`) === "yes" && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(MainContainer, {
      column: column,
      children: children
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (UtilityInput);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 42088:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _UtilitiesEdit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52069);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_UtilitiesEdit__WEBPACK_IMPORTED_MODULE_0__]);
_UtilitiesEdit__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_UtilitiesEdit__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 87936:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(45641);
/* harmony import */ var _button_Button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(59067);
/* harmony import */ var _common_Divider__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6459);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(87491);
/* harmony import */ var _common_Stack__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(45364);
/* harmony import */ var _measurement_utils_constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(19390);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var uuidv4__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(63398);
/* harmony import */ var uuidv4__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(uuidv4__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _common_DataInputContainer__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(64493);
/* harmony import */ var _VehicleUsageRow__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(92623);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_1__, _VehicleUsageRow__WEBPACK_IMPORTED_MODULE_11__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_1__, _VehicleUsageRow__WEBPACK_IMPORTED_MODULE_11__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);















const Container = styled_components__WEBPACK_IMPORTED_MODULE_8___default().div.withConfig({
  displayName: "VehicleUsageEdit__Container",
  componentId: "n5qv3w-0"
})(["width:100%;position:relative;"]);
const BottomCTAs = styled_components__WEBPACK_IMPORTED_MODULE_8___default().div.withConfig({
  displayName: "VehicleUsageEdit__BottomCTAs",
  componentId: "n5qv3w-1"
})(["display:flex;width:100%;justify-content:flex-end;flex-direction:column;align-items:center;& > button:not(:last-child){margin-bottom:0.5rem;}", ""], _theme__WEBPACK_IMPORTED_MODULE_7__/* .media.tablet */ .BC.tablet`
    flex-direction: row;
    align-items: initial;
    
    & > button:not(:last-child) {
      margin: initial;
      margin-right: 0.5rem;
    }
  `);

const VehicleUsageEdit = ({
  office,
  isEditing,
  isSubmitting,
  reset
}) => {
  const {
    control
  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_1__.useFormContext)();
  const {
    fields,
    append,
    remove
  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_1__.useFieldArray)({
    control,
    name: "vehicle_usage",
    keyName: "key_id"
  });
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (fields.length < 1) {
      append({
        id: (0,uuidv4__WEBPACK_IMPORTED_MODULE_9__.uuid)(),
        value: null,
        mode: "",
        unit: _measurement_utils_constants__WEBPACK_IMPORTED_MODULE_6__/* .DISTANCE_METRICS[0] */ .Kk[0],
        registration_number: ""
      }, {
        shouldFocus: false
      });
    }
  }, [fields.length]);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_common_DataInputContainer__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
    isEditing: isEditing,
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_common_Stack__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP, {
        size: "subtitleBold",
        children: "Vehicle Usage"
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_common_Stack__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
        direction: "row",
        mb: "-8px !important",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP, {
          align: "left",
          style: {
            width: "20%"
          },
          size: "meta",
          children: "Registration No:"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP, {
          align: "left",
          style: {
            width: "20%"
          },
          size: "meta",
          children: "Distance:"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP, {
          align: "left",
          style: {
            width: "30%"
          },
          size: "meta",
          children: "Type of vehicle:"
        })]
      }), fields && fields.map((vehicle_usage, index) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(Container, {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_VehicleUsageRow__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
          vehicle_usage,
          index,
          remove
        })
      }, vehicle_usage.id + index || `vehicle_usage_${index + vehicle_usage.key_id}`)), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
        secondary: true,
        type: "button",
        onClick: () => append({
          id: (0,uuidv4__WEBPACK_IMPORTED_MODULE_9__.uuid)(),
          value: null,
          mode: "",
          unit: _measurement_utils_constants__WEBPACK_IMPORTED_MODULE_6__/* .DISTANCE_METRICS[0] */ .Kk[0],
          registration_number: ""
        }),
        children: "Add more"
      })]
    }), isEditing && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.Fragment, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_common_Divider__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        margin: "20px 0"
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(BottomCTAs, {
        children: [reset && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
          type: "button",
          warning: true,
          secondary: true,
          onClick: reset,
          loading: isSubmitting,
          children: "Cancel"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
          type: "submit",
          loading: isSubmitting,
          children: "Save"
        })]
      })]
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (VehicleUsageEdit);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 92623:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _common_Spinner__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16114);
/* harmony import */ var _common_DeleteButton__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(51672);
/* harmony import */ var _common_MetricNumberInput__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(61569);
/* harmony import */ var _common_Stack__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(45364);
/* harmony import */ var _form_Input__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(18183);
/* harmony import */ var _form_InputDropdown__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(51894);
/* harmony import */ var _measurement_utils_constants__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(19390);
/* harmony import */ var _contexts_auth__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(58368);
/* harmony import */ var _contexts_measurements__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(85238);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(11098);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(63033);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_common_MetricNumberInput__WEBPACK_IMPORTED_MODULE_4__, _form_Input__WEBPACK_IMPORTED_MODULE_6__, _form_InputDropdown__WEBPACK_IMPORTED_MODULE_7__]);
([_common_MetricNumberInput__WEBPACK_IMPORTED_MODULE_4__, _form_Input__WEBPACK_IMPORTED_MODULE_6__, _form_InputDropdown__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

















const Container = styled_components__WEBPACK_IMPORTED_MODULE_12___default().div.withConfig({
  displayName: "VehicleUsageRow__Container",
  componentId: "sc-19p78ch-0"
})(["position:relative;"]);
const Overlay = styled_components__WEBPACK_IMPORTED_MODULE_12___default().div.withConfig({
  displayName: "VehicleUsageRow__Overlay",
  componentId: "sc-19p78ch-1"
})(["display:", ";visibility:", ";z-index:10;width:100%;height:100%;justify-content:center;background-color:rgba(255,255,255,0.7);position:absolute;margin-right:12px;top:0;"], p => p.open ? "flex" : "none", p => p.open ? "visible" : "hidden");

const VehicleUsageRow = ({
  vehicle_usage,
  searchSessionIdsRef,
  index,
  remove
}) => {
  const {
    organisation
  } = (0,_contexts_auth__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)();
  const {
    0: deleteLoading,
    1: setDeleteLoading
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
  const {
    dataCollectionMeasurement,
    setDataCollectionMeasurement
  } = (0,_contexts_measurements__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)();

  const deleteVehicleUsage = async () => {
    try {
      setDeleteLoading(true);

      if (Number(vehicle_usage.id)) {
        await axios__WEBPACK_IMPORTED_MODULE_0___default()["delete"](`/api/organisations/${organisation.id}/measurements/${dataCollectionMeasurement.id}/vehicle-usage/${vehicle_usage.id}`);
        const {
          data
        } = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`/api/organisations/${organisation.id}/measurements/${dataCollectionMeasurement.id}`);
        setDataCollectionMeasurement(_objectSpread(_objectSpread({}, dataCollectionMeasurement), data));
      }

      remove(index);
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_11__/* .logError */ .H)(error);
    }

    setDeleteLoading(false);
  };

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(Container, {
    children: [vehicle_usage && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_form_Input__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
      name: `vehicle_usage.${index}.id`,
      hidden: true
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(_common_Stack__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
      direction: "row",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_form_Input__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
        id: `vehicle_usage.${index}.registration_number`,
        name: `vehicle_usage.${index}.registration_number`,
        testId: `vehicle_usage.${index}.registration_number`,
        width: "20%",
        placeholder: "Enter registration number...",
        step: 0.01,
        isRequired: true
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx("div", {
        style: {
          display: "flex",
          flexDirection: "row",
          width: "20%"
        },
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_common_MetricNumberInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
          inputId: `vehicle_usage.${index}.value`,
          metricId: `vehicle_usage.${index}.unit`,
          name: `vehicle_usage.${index}.value`,
          testId: `vehicle_usage.${index}.value`,
          inputPlaceholder: "Number",
          metricPlaceholder: "km",
          optionArray: _measurement_utils_constants__WEBPACK_IMPORTED_MODULE_8__/* .DISTANCE_METRICS */ .Kk
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_form_InputDropdown__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
        id: `vehicle_usage.${index}.mode`,
        width: "30%",
        placeholder: "Select mode...",
        optionArray: _utils__WEBPACK_IMPORTED_MODULE_13__/* .VEHICLE_USAGE_MODES_OF_TRANSPORT */ .Kh,
        hasDefaultValue: false
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_common_DeleteButton__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        name: `vehicle_usage.${index}`,
        onClick: deleteVehicleUsage
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(Overlay, {
      open: deleteLoading,
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_common_Spinner__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        color: "blue"
      })
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (VehicleUsageRow);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 61891:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(87491);
/* harmony import */ var _common_ContainerContentSection__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(26191);
/* harmony import */ var _common_ContainerTopSection__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(58543);
/* harmony import */ var _common_DataInputContainer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(64493);
/* harmony import */ var _common_EditButton__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(99224);
/* harmony import */ var _common_SectionEmissions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(47009);
/* harmony import */ var _common_Stack__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(45364);
/* harmony import */ var _common_UnorderedList__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(71313);
/* harmony import */ var _common_ViewModeDataRow__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(72441);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(63033);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__);















const ButtonText = styled_components__WEBPACK_IMPORTED_MODULE_11___default()(_common_Text__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP).withConfig({
  displayName: "VehicleUsageView__ButtonText",
  componentId: "wa5f9p-0"
})(["cursor:pointer;color:", ";"], p => p.theme.colors.blue);

const VehicleUsageView = ({
  vehicleUsage,
  isEditing,
  reset,
  result
}) => {
  const {
    0: readMore,
    1: setReadMore
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const numberOfMiles = (0,_utils__WEBPACK_IMPORTED_MODULE_10__/* .calculateNumberOfMiles */ .fc)(vehicleUsage);
  const vehicleData = (0,_utils__WEBPACK_IMPORTED_MODULE_10__/* .countViewModeVehicleUsage */ .LB)(vehicleUsage);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_common_DataInputContainer__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_common_Stack__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_common_ContainerTopSection__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
          size: "subtitleBold",
          children: "Vehicle Usage"
        }), !isEditing && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_common_EditButton__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
          name: "vehicleUsage",
          onClick: () => reset("vehicleUsage")
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_common_ContainerContentSection__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_common_ViewModeDataRow__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
          title: "No. of vehicles:",
          value: vehicleUsage.length
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_common_UnorderedList__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
          children: vehicleData.map(vehicle => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx("li", {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_common_ViewModeDataRow__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
              title: `${vehicle.title}:`,
              value: vehicle.value,
              isBulletedList: true
            })
          }, vehicle.title))
        })]
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_common_ContainerContentSection__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_common_ViewModeDataRow__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
          title: "Vehicles entered:",
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_common_Stack__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
            spacing: "2px",
            children: [vehicleUsage.slice(0, readMore ? vehicleUsage.length : 5).map(vehicle => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_common_Text__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
              size: "meta",
              align: "left",
              children: [vehicle.registration_number, " -", " ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_common_Text__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
                size: "meta",
                children: [vehicle.value, " ", vehicle.unit, " -", " ", _utils__WEBPACK_IMPORTED_MODULE_10__/* .VEHICLE_USAGE_MODES_OF_TRANSPORT.find */ .Kh.find(el => el.value === vehicle.mode).label]
              })]
            }, vehicle.id)), vehicleUsage.length > 5 && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(ButtonText, {
              size: "button",
              onClick: () => setReadMore(!readMore),
              children: readMore ? "Read Less" : "Read More"
            })]
          })
        })
      }), !!vehicleUsage.length && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_common_ViewModeDataRow__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
        title: "Total miles:",
        value: `${Math.round(numberOfMiles)} miles`
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_common_SectionEmissions__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
      value: result.vehicle_usage
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (VehicleUsageView);

/***/ }),

/***/ 59663:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$5": () => (/* reexport safe */ _VehicleUsageEdit__WEBPACK_IMPORTED_MODULE_2__.Z),
/* harmony export */   "qx": () => (/* reexport safe */ _VehicleUsageView__WEBPACK_IMPORTED_MODULE_3__.Z),
/* harmony export */   "wr": () => (/* binding */ createVehicleUsageDefaultValues)
/* harmony export */ });
/* harmony import */ var _measurement_utils_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(19390);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(63033);
/* harmony import */ var _VehicleUsageEdit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(87936);
/* harmony import */ var _VehicleUsageView__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(61891);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_VehicleUsageEdit__WEBPACK_IMPORTED_MODULE_2__]);
_VehicleUsageEdit__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const createVehicleUsageDefaultValues = office => ({
  vehicle_usage: office.vehicle_usage.map(vehicleUsage => ({
    id: vehicleUsage.id || "",
    value: vehicleUsage.value || null,
    mode: _utils__WEBPACK_IMPORTED_MODULE_1__/* .VEHICLE_USAGE_MODES_OF_TRANSPORT.find */ .Kh.find(mode => vehicleUsage.mode === mode.value),
    unit: _measurement_utils_constants__WEBPACK_IMPORTED_MODULE_0__/* .DISTANCE_METRICS.find */ .Kk.find(unit => vehicleUsage.unit === unit.value) || {
      label: vehicleUsage.unit || "",
      value: vehicleUsage.unit || ""
    },
    registration_number: vehicleUsage.registration_number || ""
  }))
});
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 26191:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const ContainerContentSection = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "ContainerContentSection",
  componentId: "sc-7mni9c-0"
})(["width:100%;"]);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ContainerContentSection);

/***/ }),

/***/ 58543:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const ContainerTopSection = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "ContainerTopSection",
  componentId: "tkypuv-0"
})(["display:flex;width:100%;justify-content:space-between;"]);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ContainerTopSection);

/***/ }),

/***/ 51672:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



var DeleteButtonImage = function DeleteButtonImage(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("circle", {
      cx: "15",
      cy: "15",
      r: "14",
      strokeWidth: "2"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("path", {
      strokeWidth: "2",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      d: "M19.607 10.414l-9.193 9.193M20.192 19.607L11 10.414"
    })]
  }));
};

DeleteButtonImage.defaultProps = {
  width: "30",
  height: "30",
  viewBox: "0 0 30 30",
  fill: "none",
  stroke: "#FCD5D4",
  xmlns: "http://www.w3.org/2000/svg"
};



const Button = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(DeleteButtonImage).withConfig({
  displayName: "DeleteButton__Button",
  componentId: "sc-1y4x5hu-0"
})(["stroke:", ";cursor:pointer;align-self:flex-start;&:hover{stroke:", ";}"], p => p.theme.colors.secondaryRed, p => p.theme.colors.red);

const DeleteButton = ({
  onClick,
  name
}) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(Button, {
  "data-cy": `delete-button-${name}`,
  onClick: onClick
});

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DeleteButton);

/***/ }),

/***/ 99224:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



var EditButtonImage = function EditButtonImage(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("path", {
      d: "M16.885.152a.515.515 0 0 0-.731 0L7.036 9.309a.52.52 0 0 0-.147.294l-.484 3.405a.52.52 0 0 0 .575.588l3.448-.43a.516.516 0 0 0 .302-.147l9.119-9.157a.52.52 0 0 0 0-.734L16.885.152zm-6.76 12.007l-2.6.324.364-2.562 5.748-5.774L15.87 6.39l-5.745 5.77zM16.6 5.655l-2.233-2.242 2.152-2.16 2.232 2.242-2.151 2.16z",
      fill: "#2E68F1"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("path", {
      d: "M17.392 16.957a.433.433 0 0 1-.277.41.441.441 0 0 1-.172.03H3.063a.446.446 0 0 1-.42-.269.438.438 0 0 1-.035-.17V3.853a.448.448 0 0 1 .454-.451h7.442V2.4H3.062a1.468 1.468 0 0 0-1.35.897 1.447 1.447 0 0 0-.112.557v13.103a1.437 1.437 0 0 0 .904 1.336c.177.072.367.108.558.107h13.881a1.455 1.455 0 0 0 1.031-.42 1.44 1.44 0 0 0 .426-1.023V9.042h-1.008v7.915z",
      fill: "#2E68F1"
    })]
  }));
};

EditButtonImage.defaultProps = {
  width: "20",
  height: "20",
  viewBox: "0 0 20 20",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};



const Icon = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(EditButtonImage).withConfig({
  displayName: "EditButton__Icon",
  componentId: "ogqc05-0"
})([""]);
const Button = styled_components__WEBPACK_IMPORTED_MODULE_2___default().button.withConfig({
  displayName: "EditButton__Button",
  componentId: "ogqc05-1"
})(["cursor:pointer;display:flex;align-items:center;justify-content:center;height:36px;width:36px;border:0.5px solid rgba(46,104,241,0.25);border-radius:10px;background:", ";position:absolute;top:12px;right:12px;&:hover{background:", ";}&:hover ", "{stroke:", ";}"], p => p.theme.colors.white, p => p.theme.colors.blue, Icon, p => p.theme.colors.white);

const EditButton = ({
  onClick,
  name
}) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(Button, {
  onClick: onClick,
  "data-cy": `edit-section-${name}`,
  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(Icon, {})
});

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EditButton);

/***/ }),

/***/ 61569:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Stack__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(45364);
/* harmony import */ var _form_Input__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18183);
/* harmony import */ var _form_InputDropdown__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(51894);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_form_Input__WEBPACK_IMPORTED_MODULE_1__, _form_InputDropdown__WEBPACK_IMPORTED_MODULE_2__]);
([_form_Input__WEBPACK_IMPORTED_MODULE_1__, _form_InputDropdown__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const MetricNumberInput = ({
  inputId,
  metricId,
  name,
  inputPlaceholder,
  metricPlaceholder,
  optionArray,
  defaultValue,
  testId
}) => {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(_Stack__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z, {
    spacing: "8px",
    direction: "row",
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_form_Input__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
      id: inputId,
      name: name,
      testId: testId,
      placeholder: inputPlaceholder,
      type: "number",
      width: "100px",
      step: "0.1"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_form_InputDropdown__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
      id: metricId,
      testId: metricId,
      width: "90px",
      placeholder: metricPlaceholder,
      optionArray: optionArray,
      defaultValue: defaultValue,
      hasDefaultValue: !!defaultValue
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MetricNumberInput);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 47009:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(87491);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);





const SectionEmmisionsContainer = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "SectionEmissions__SectionEmmisionsContainer",
  componentId: "sc-1of7ll5-0"
})(["display:flex;& > span{line-height:22px;}margin-top:1rem;", ""], _theme__WEBPACK_IMPORTED_MODULE_1__/* .media.tablet */ .BC.tablet`
    justify-content: flex-end;
    margin: initial;
    position: absolute;
    bottom: 1rem;
    right: 0.75rem;
  `);

const SectionEmissions = ({
  value = "XX"
}) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(SectionEmmisionsContainer, {
  children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(_common_Text__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .ZP, {
    size: "meta",
    children: ["Total emissions:", " ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(_common_Text__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .ZP, {
      size: "subtitle",
      children: [Number(value === null || value === void 0 ? void 0 : value.toFixed(2)).toLocaleString(), " "]
    }), " ", "kgCO2e", " "]
  })
});

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SectionEmissions);

/***/ }),

/***/ 45364:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8130);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);
const _excluded = ["children", "width", "spacing"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }




const Stack = _ref => {
  let {
    children,
    width,
    spacing
  } = _ref,
      rest = _objectWithoutProperties(_ref, _excluded);

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_0__.Stack, _objectSpread(_objectSpread({
    width: width || "100%",
    spacing: spacing || "12px",
    alignItems: "flex-start",
    justifyContent: "flex-start"
  }, rest), {}, {
    children: children
  }));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Stack);

/***/ }),

/***/ 71313:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const UnorderedList = styled_components__WEBPACK_IMPORTED_MODULE_0___default().ul.withConfig({
  displayName: "UnorderedList",
  componentId: "sc-3hkh34-0"
})(["margin:0;padding-left:30px;"]);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (UnorderedList);

/***/ }),

/***/ 72441:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(87491);
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(16170);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(91073);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);






const MainContainer = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "ViewModeDataRow__MainContainer",
  componentId: "sc-166jb4q-0"
})(["display:flex;flex-direction:row;width:100%;", ""], _theme__WEBPACK_IMPORTED_MODULE_2__/* .media.tablet */ .BC.tablet`
    align-items: flex-start;
  `);
const TitleContainer = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "ViewModeDataRow__TitleContainer",
  componentId: "sc-166jb4q-1"
})(["margin-right:auto;", ""], _theme__WEBPACK_IMPORTED_MODULE_2__/* .media.tablet */ .BC.tablet`
    margin: initial;
    min-width: ${p => p.isBulletedList ? "220px" : "250px"};
`);
const UnitText = styled_components__WEBPACK_IMPORTED_MODULE_1___default()(_common_Text__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .ZP).withConfig({
  displayName: "ViewModeDataRow__UnitText",
  componentId: "sc-166jb4q-2"
})(["margin-left:4px;"]);
const ValueContainer = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "ViewModeDataRow__ValueContainer",
  componentId: "sc-166jb4q-3"
})([""]);

const ViewModeDataRow = ({
  title,
  value,
  unit,
  isBulletedList,
  children
}) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(MainContainer, {
  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(TitleContainer, {
    isBulletedList: isBulletedList,
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .ZP, {
      size: "meta",
      children: title
    })
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(ValueContainer, {
    children: [(0,_utils_constants__WEBPACK_IMPORTED_MODULE_4__/* .isTruthy */ .fQ)(value) && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .ZP, {
      size: "meta",
      children: !Number.isNaN(value) ? value : Number(value).toLocaleString()
    }), " ", unit && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(UnitText, {
      size: "meta",
      children: unit
    }), children]
  })]
});

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ViewModeDataRow);

/***/ }),

/***/ 29645:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const parseFormData = form => {
  var _details$country, _details$unit;

  const {
    details,
    employee_commutes,
    business_travel,
    waste,
    utilities,
    vehicle_usage
  } = form;
  const detailsSanitised = {
    name: details.name,
    country: (_details$country = details.country) === null || _details$country === void 0 ? void 0 : _details$country.value,
    size: Number(details.size),
    unit: (_details$unit = details.unit) === null || _details$unit === void 0 ? void 0 : _details$unit.value,
    number_of_staff: Number(details.number_of_staff),
    staff_working_from_home_percentage: Number(details.staff_working_from_home_percentage)
  };
  const commutesSanitised = [];
  employee_commutes === null || employee_commutes === void 0 ? void 0 : employee_commutes.forEach(commute => {
    var _commute$mode;

    if (!commute.value) {
      return;
    }

    const sanitisedObject = _objectSpread(_objectSpread({}, Number(commute.id) ? {
      id: commute.id
    } : {}), {}, {
      name: commute.name,
      value: Number(commute.value),
      unit: commute.unit.value,
      mode: (_commute$mode = commute.mode) === null || _commute$mode === void 0 ? void 0 : _commute$mode.value
    });

    commutesSanitised.push(sanitisedObject);
  });
  const travelSanitised = [];
  business_travel === null || business_travel === void 0 ? void 0 : business_travel.forEach(travel => {
    var _to$value, _from$value, _from$value2, _to$value2, _from$value3, _to$value3;

    const {
      to,
      from,
      round_trip,
      mode,
      passengers,
      id
    } = travel;

    if (!to || !from) {
      return;
    }

    const sanitisedObject = _objectSpread(_objectSpread({}, Number(id) ? {
      id
    } : {}), {}, {
      to: to === null || to === void 0 ? void 0 : (_to$value = to.value) === null || _to$value === void 0 ? void 0 : _to$value.name,
      from: from === null || from === void 0 ? void 0 : (_from$value = from.value) === null || _from$value === void 0 ? void 0 : _from$value.name,
      round_trip,
      mode: mode === null || mode === void 0 ? void 0 : mode.value,
      passengers: Number(passengers),
      departure_place_id: from === null || from === void 0 ? void 0 : (_from$value2 = from.value) === null || _from$value2 === void 0 ? void 0 : _from$value2.place_id,
      destination_place_id: to === null || to === void 0 ? void 0 : (_to$value2 = to.value) === null || _to$value2 === void 0 ? void 0 : _to$value2.place_id,
      departure_search_session: from === null || from === void 0 ? void 0 : (_from$value3 = from.value) === null || _from$value3 === void 0 ? void 0 : _from$value3.searchSessionId,
      destination_search_session: to === null || to === void 0 ? void 0 : (_to$value3 = to.value) === null || _to$value3 === void 0 ? void 0 : _to$value3.searchSessionId
    });

    travelSanitised.push(sanitisedObject);
  });
  const vehicleUsageSanitised = [];
  vehicle_usage === null || vehicle_usage === void 0 ? void 0 : vehicle_usage.forEach(vehicle => {
    var _vehicle$unit, _vehicle$mode;

    if (!vehicle.value) {
      return;
    }

    const sanitisedObject = _objectSpread(_objectSpread({}, Number(vehicle.id) ? {
      id: vehicle.id
    } : {}), {}, {
      registration_number: vehicle.registration_number,
      value: Number(vehicle.value),
      unit: (_vehicle$unit = vehicle.unit) === null || _vehicle$unit === void 0 ? void 0 : _vehicle$unit.value,
      mode: (_vehicle$mode = vehicle.mode) === null || _vehicle$mode === void 0 ? void 0 : _vehicle$mode.value
    });

    vehicleUsageSanitised.push(sanitisedObject);
  });

  const sanitiseUtilities = it => {
    var _it$unit;

    return {
      id: it.id,
      type: it === null || it === void 0 ? void 0 : it.type,
      value: (it === null || it === void 0 ? void 0 : it.known) === "yes" ? Number(it === null || it === void 0 ? void 0 : it.value) : 0,
      unit: it === null || it === void 0 ? void 0 : (_it$unit = it.unit) === null || _it$unit === void 0 ? void 0 : _it$unit.value,
      known: it === null || it === void 0 ? void 0 : it.known
    };
  };

  const sanitiseWaste = it => {
    var _waste$, _it$unit2, _waste$2;

    return {
      id: it.id,
      type: it === null || it === void 0 ? void 0 : it.type,
      value: ((_waste$ = waste[0]) === null || _waste$ === void 0 ? void 0 : _waste$.known) === "yes" ? Number(it === null || it === void 0 ? void 0 : it.value) : 0,
      unit: it === null || it === void 0 ? void 0 : (_it$unit2 = it.unit) === null || _it$unit2 === void 0 ? void 0 : _it$unit2.value,
      known: (_waste$2 = waste[0]) === null || _waste$2 === void 0 ? void 0 : _waste$2.known
    };
  };

  return {
    details: detailsSanitised,
    employee_commutes: commutesSanitised,
    business_travel: travelSanitised,
    utilities: utilities === null || utilities === void 0 ? void 0 : utilities.map(sanitiseUtilities),
    vehicle_usage: vehicleUsageSanitised,
    waste: waste === null || waste === void 0 ? void 0 : waste.map(sanitiseWaste)
  };
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (parseFormData);

/***/ }),

/***/ 30495:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "g": () => (/* binding */ OfficeButtonsContainer),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const ButtonsContainer = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "ButtonsContainer",
  componentId: "sc-9166ss-0"
})(["display:flex;justify-content:flex-end;margin:2rem 0;"]);
const OfficeButtonsContainer = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(ButtonsContainer).withConfig({
  displayName: "ButtonsContainer__OfficeButtonsContainer",
  componentId: "sc-9166ss-1"
})(["justify-content:flex-start;& > *:not(:first-child){margin-left:1rem;}"]);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ButtonsContainer);

/***/ }),

/***/ 9258:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D": () => (/* binding */ usePrevious)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

function usePrevious(value) {
  const ref = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    ref.current = value;
  }, [value]);
  return ref.current;
}

/***/ })

};
;