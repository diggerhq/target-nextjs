"use strict";
exports.id = 1476;
exports.ids = [1476];
exports.modules = {

/***/ 71476:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ button_CopyButton)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "copy-to-clipboard"
var external_copy_to_clipboard_ = __webpack_require__(68887);
var external_copy_to_clipboard_default = /*#__PURE__*/__webpack_require__.n(external_copy_to_clipboard_);
;// CONCATENATED MODULE: ./src/utils/useCopyToClipboard.js


function useCopyToClipboard(resetInterval = null) {
  const [isCopied, setCopied] = external_react_default().useState(false);
  const handleCopy = external_react_default().useCallback(text => {
    if (typeof text === "string" || typeof text == "number") {
      external_copy_to_clipboard_default()(text.toString());
      setCopied(true);
    } else {
      setCopied(false);
      console.error(`Cannot copy typeof ${typeof text} to clipboard, must be a string or number.`);
    }
  }, []);
  external_react_default().useEffect(() => {
    let timeout;

    if (isCopied && resetInterval) {
      timeout = setTimeout(() => setCopied(false), resetInterval);
    }

    return () => {
      clearTimeout(timeout);
    };
  }, [isCopied, resetInterval]);
  return [isCopied, handleCopy];
}
// EXTERNAL MODULE: ./src/components/button/Button.jsx
var Button = __webpack_require__(59067);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
;// CONCATENATED MODULE: ./src/components/button/CopyButton.jsx





const CopyButton = ({
  code,
  buttonPadding,
  width,
  text = "Copy"
}) => {
  const [isCopied, handleCopy] = useCopyToClipboard(3000);
  return /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.ZP, {
    onClick: () => handleCopy(code),
    padding: buttonPadding,
    width: width,
    minWidth: width,
    cursor: "pointer",
    children: isCopied ? "Copied" : text
  });
};

/* harmony default export */ const button_CopyButton = (CopyButton);

/***/ })

};
;