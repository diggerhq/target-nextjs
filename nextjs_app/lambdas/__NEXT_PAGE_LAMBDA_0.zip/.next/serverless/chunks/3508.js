"use strict";
exports.id = 3508;
exports.ids = [3508];
exports.modules = {

/***/ 13508:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16666);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_responsive__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _common_Divider__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6459);
/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(59067);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);







const Container = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "CTAButtons__Container",
  componentId: "dbw710-0"
})(["position:fixed;height:5rem;bottom:0;left:0;right:0;background:", ";width:100%;z-index:2;", " ", " ", " ", ""], p => p.theme.colors.backgroundGrey, _theme__WEBPACK_IMPORTED_MODULE_1__/* .media.mobileLandscape */ .BC.mobileLandscape`
    max-width: 1200px;
  `, _theme__WEBPACK_IMPORTED_MODULE_1__/* .media.tablet */ .BC.tablet`
    position: absolute;
  `, _theme__WEBPACK_IMPORTED_MODULE_1__/* .media.tabletLarge */ .BC.tabletLarge`
   
    width: 90%;
  `, _theme__WEBPACK_IMPORTED_MODULE_1__/* .media.desktop */ .BC.desktop`
  
  `);
const ButtonsContainer = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "CTAButtons__ButtonsContainer",
  componentId: "dbw710-1"
})(["display:flex;justify-content:space-between;align-items:center;padding:0 1.25rem;", " ", ""], _theme__WEBPACK_IMPORTED_MODULE_1__/* .media.mobileLandscape */ .BC.mobileLandscape`
justify-content: space-between;
  & > button:not(:last-of-type) {
margin-right: 2.25rem;
  }
  `, _theme__WEBPACK_IMPORTED_MODULE_1__/* .media.tablet */ .BC.tablet`
    padding: 0 2rem;
    justify-content: flex-end;
  `);

const CTAButtons = ({
  onDiscard,
  onSave,
  loading
}) => {
  const tablet = (0,react_responsive__WEBPACK_IMPORTED_MODULE_0__.useMediaQuery)({
    query: `(min-width: ${_theme__WEBPACK_IMPORTED_MODULE_1__/* .sizes.tablet */ .J7.tablet}px)`
  });
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(Container, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_common_Divider__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(ButtonsContainer, {
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(_Button__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP, {
        secondary: true,
        type: "button",
        onClick: onDiscard,
        width: "11.875rem",
        disabled: loading,
        children: ["Discard ", tablet && "Changes"]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(_Button__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP, {
        type: onSave ? "button" : "submit",
        onClick: onSave,
        width: "11.875rem",
        loading: loading,
        children: ["Save ", tablet && "Changes"]
      })]
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CTAButtons);

/***/ })

};
;