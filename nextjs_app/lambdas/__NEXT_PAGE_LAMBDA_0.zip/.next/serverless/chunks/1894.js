"use strict";
exports.id = 1894;
exports.ids = [1894];
exports.modules = {

/***/ 51894:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _hookform_error_message__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(83218);
/* harmony import */ var _hookform_error_message__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_hookform_error_message__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(45641);
/* harmony import */ var react_select__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(61929);
/* harmony import */ var react_select__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_select__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _common_Tooltip__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(39891);
/* harmony import */ var _Error__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(26428);
/* harmony import */ var _Label__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(54251);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_2__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
const _excluded = ["children", "src"],
      _excluded2 = ["autoComplete"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }






var DownArrow = function DownArrow(props) {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("path", {
      d: "M225.923 354.706c-8.098 0-16.195-3.092-22.369-9.263L9.27 151.157c-12.359-12.359-12.359-32.397 0-44.751 12.354-12.354 32.388-12.354 44.748 0l171.905 171.915 171.906-171.909c12.359-12.354 32.391-12.354 44.744 0 12.365 12.354 12.365 32.392 0 44.751L248.292 345.449c-6.177 6.172-14.274 9.257-22.369 9.257z"
    })
  }));
};

DownArrow.defaultProps = {
  xmlns: "http://www.w3.org/2000/svg",
  width: "451.847",
  height: "451.847",
  viewBox: "0 0 451.847 451.847"
};







const Container = styled_components__WEBPACK_IMPORTED_MODULE_6___default().div.withConfig({
  displayName: "InputDropdown__Container",
  componentId: "sc-11vwhot-0"
})(["width:", ";"], p => p.width || "100%");
const StyledDownArrow = styled_components__WEBPACK_IMPORTED_MODULE_6___default()(DownArrow).withConfig({
  displayName: "InputDropdown__StyledDownArrow",
  componentId: "sc-11vwhot-1"
})(["width:1rem;height:1rem;margin-right:0.25rem;fill:", ";transition:transform 0.3s ease-out;cursor:pointer;"], p => p.disabled ? p.theme.colors.placeholderGrey : p.theme.colors.blue);

const DropdownIndicator = _ref => {
  let {
    children,
    src
  } = _ref,
      props = _objectWithoutProperties(_ref, _excluded);

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(react_select__WEBPACK_IMPORTED_MODULE_3__.components.DropdownIndicator, _objectSpread(_objectSpread({}, props), {}, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(StyledDownArrow, {
      disabled: props.isDisabled
    })
  }));
};

const Input = _ref2 => {
  let {
    autoComplete
  } = _ref2,
      props = _objectWithoutProperties(_ref2, _excluded2);

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(react_select__WEBPACK_IMPORTED_MODULE_3__.components.Input, _objectSpread(_objectSpread({}, props), {}, {
    autoComplete: "no"
  }));
};

const InputDropdown = ({
  id,
  label,
  labelColor,
  ariaLabel,
  optionArray,
  testId,
  color,
  tooltip,
  borderColor,
  isMulti,
  disabled = false,
  width = "100%",
  isClearable = false,
  isSearchable = false,
  placeholder = "Select",
  controlMargin = "0 0 1rem 0",
  defaultValue,
  hasDefaultValue = true,
  isRequired
}) => {
  const {
    control,
    formState: {
      touchedFields,
      errors
    }
  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_2__.useFormContext)() || {
    formState: {
      errors: {}
    }
  };

  if (errors[id]) {
    color = `${_theme__WEBPACK_IMPORTED_MODULE_5__/* ["default"].colors.red */ .ZP.colors.red}40`;
  }

  if (isRequired && touchedFields[id] && !errors[id]) {
    borderColor = _theme__WEBPACK_IMPORTED_MODULE_5__/* ["default"].colors.green */ .ZP.colors.green;
  }

  const customStyle = {
    indicatorSeparator: base => _objectSpread(_objectSpread({}, base), {}, {
      display: "none"
    }),
    control: base => _objectSpread(_objectSpread({}, base), {}, {
      borderColor: borderColor ? borderColor : _theme__WEBPACK_IMPORTED_MODULE_5__/* ["default"].colors.secondaryBlue */ .ZP.colors.secondaryBlue,
      backgroundColor: color ? color : _theme__WEBPACK_IMPORTED_MODULE_5__/* ["default"].colors.white */ .ZP.colors.white,
      border: disabled ? `1.5px solid ${_theme__WEBPACK_IMPORTED_MODULE_5__/* ["default"].colors.placeholderGrey */ .ZP.colors.placeholderGrey}` : !disabled && borderColor ? `1.5px solid ${_theme__WEBPACK_IMPORTED_MODULE_5__/* ["default"].colors */ .ZP.colors[borderColor]}` : `1.5px solid ${_theme__WEBPACK_IMPORTED_MODULE_5__/* ["default"].colors.secondaryBlue */ .ZP.colors.secondaryBlue}`,
      borderRadius: "4px",
      boxShadow: "none",
      cursor: "pointer",
      height: "2.05rem",
      minHeight: "2.05rem",
      margin: controlMargin,
      // FIXME: could cause breaking style changes
      // marginBottom: "1rem",
      ":hover": {
        borderColor: _theme__WEBPACK_IMPORTED_MODULE_5__/* ["default"].colors.secondaryBlue */ .ZP.colors.secondaryBlue,
        cursor: "pointer"
      },
      ":active": {
        borderColor: _theme__WEBPACK_IMPORTED_MODULE_5__/* ["default"].colors["default"] */ .ZP.colors["default"]
      }
    }),
    valueContainer: (provided, state) => _objectSpread(_objectSpread({}, provided), {}, {
      position: "initial"
    }),
    menu: base => _objectSpread(_objectSpread({}, base), {}, {
      boxShadow: `0 0 0 1px ${_theme__WEBPACK_IMPORTED_MODULE_5__/* ["default"].colors.secondaryBlue */ .ZP.colors.secondaryBlue},0 2px 4px ${_theme__WEBPACK_IMPORTED_MODULE_5__/* ["default"].colors.secondaryBlue */ .ZP.colors.secondaryBlue}`,
      borderColor: _theme__WEBPACK_IMPORTED_MODULE_5__/* ["default"].colors.active */ .ZP.colors.active,
      backgroundColor: _theme__WEBPACK_IMPORTED_MODULE_5__/* ["default"].colors.white */ .ZP.colors.white,
      borderStyle: "solid",
      borderWidth: "1px",
      borderRadius: "4px",
      padding: "10px 0",
      border: "none",
      marginTop: "12px"
    }),
    option: base => _objectSpread(_objectSpread({}, base), {}, {
      color: _theme__WEBPACK_IMPORTED_MODULE_5__/* ["default"].colors.black */ .ZP.colors.black,
      backgroundColor: _theme__WEBPACK_IMPORTED_MODULE_5__/* ["default"].colors.transparent */ .ZP.colors.transparent,
      ":hover": {
        backgroundColor: _theme__WEBPACK_IMPORTED_MODULE_5__/* ["default"].colors.admin */ .ZP.colors.admin,
        color: _theme__WEBPACK_IMPORTED_MODULE_5__/* ["default"].colors.white */ .ZP.colors.white,
        cursor: "pointer"
      }
    }),
    menuList: base => _objectSpread(_objectSpread({}, base), {}, {
      "&::-webkit-scrollbar": {
        background: _theme__WEBPACK_IMPORTED_MODULE_5__/* ["default"].colors.lightGrey */ .ZP.colors.lightGrey,
        borderRadius: "10px",
        width: "0.25rem"
      },
      "::-webkit-scrollbar-thumb": {
        background: _theme__WEBPACK_IMPORTED_MODULE_5__/* ["default"].colors.secondaryBlue */ .ZP.colors.secondaryBlue,
        borderRadius: "10px"
      }
    }),
    indicatorsContainer: base => _objectSpread({}, base),
    placeholder: base => _objectSpread(_objectSpread({}, base), {}, {
      fontSize: "12px",
      fontWeight: "lighter",
      color: _theme__WEBPACK_IMPORTED_MODULE_5__/* ["default"].colors.placeholderGrey */ .ZP.colors.placeholderGrey
    })
  };
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(styled_components__WEBPACK_IMPORTED_MODULE_6__.ThemeProvider, {
    theme: _theme__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP,
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(Container, {
      "data-testid": testId,
      width: width,
      children: [label && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(_Label__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
        color: labelColor,
        htmlFor: id,
        children: [label, " ", tooltip && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_common_Tooltip__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
          content: tooltip,
          direction: "right"
        })]
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.Controller, {
        id: id,
        render: ({
          field
        }, ...rest) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx((react_select__WEBPACK_IMPORTED_MODULE_3___default()), _objectSpread(_objectSpread(_objectSpread({
          id: id,
          instanceId: id,
          isDisabled: disabled,
          options: optionArray,
          placeholder: placeholder,
          styles: customStyle,
          isMulti: isMulti,
          components: {
            DropdownIndicator,
            Input
          },
          isClearable: isClearable,
          isSearchable: isSearchable
        }, ariaLabel ? {
          "aria-label": ariaLabel
        } : {}), {}, {
          theme: selectTheme => _objectSpread(_objectSpread({}, selectTheme), {}, {
            colors: _objectSpread(_objectSpread({}, selectTheme.colors), {}, {
              primary: _theme__WEBPACK_IMPORTED_MODULE_5__/* ["default"].colors.active */ .ZP.colors.active
            })
          }),
          "data-cy": id
        }, field), rest)),
        name: id,
        defaultValue: defaultValue ? defaultValue : hasDefaultValue ? optionArray[0] : null,
        control: control,
        shouldUnregister: true
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_hookform_error_message__WEBPACK_IMPORTED_MODULE_0__.ErrorMessage, {
        errors: errors,
        name: id,
        as: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_Error__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {})
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (InputDropdown);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;