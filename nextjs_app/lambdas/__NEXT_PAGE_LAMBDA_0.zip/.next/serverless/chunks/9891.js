"use strict";
exports.id = 9891;
exports.ids = [9891];
exports.modules = {

/***/ 39891:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Text__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(87491);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




var InfoIcon = function InfoIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fillRule: "evenodd",
      clipRule: "evenodd",
      d: "M29.974 60C13.402 60 0 46.596 0 30.023 0 13.4 13.402 0 29.974 0 46.598 0 60 13.399 60 30.023 60 46.596 46.598 60 29.974 60zm.003-3C44.938 57 57 44.936 57 30.02 57 15.06 44.938 3 29.977 3 15.062 3 3 15.059 3 30.02 3 44.937 15.062 57 29.977 57z",
      fill: "#000"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fillRule: "evenodd",
      clipRule: "evenodd",
      d: "M30.5 14c-1.421 0-2.5 1.105-2.5 2.5 0 1.421 1.079 2.5 2.5 2.5 1.395 0 2.5-1.079 2.5-2.5 0-1.395-1.105-2.5-2.5-2.5z",
      fill: "#000"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
      fill: "#000",
      d: "M29 22h3v24h-3z"
    })]
  }));
};

InfoIcon.defaultProps = {
  width: "60",
  height: "60",
  viewBox: "0 0 60 60",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};



const StyledInfoIcon = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(InfoIcon).withConfig({
  displayName: "Tooltip__StyledInfoIcon",
  componentId: "w1t1j6-0"
})(["height:0.75rem;width:0.75rem;"]);
const TooltipWrapper = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
  displayName: "Tooltip__TooltipWrapper",
  componentId: "w1t1j6-1"
})(["display:inline-block;position:relative;cursor:pointer;"]);
const TooltipTip = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
  displayName: "Tooltip__TooltipTip",
  componentId: "w1t1j6-2"
})(["position:absolute;left:50%;transform:translateX(-50%);padding:6px;color:var(--tooltip-text-color);background:var(--tooltip-background-color);font-size:14px;line-height:1;z-index:100;max-width:600px;min-width:320px;&:before{content:\" \";left:50%;border:solid transparent;height:0;width:0;position:absolute;pointer-events:none;border-width:var(--tooltip-arrow-size);margin-left:calc(var(--tooltip-arrow-size) * -1);}&.top{top:calc(var(--tooltip-margin) * -1);&::before{top:100%;border-top-color:var(--tooltip-background-color);}}&.right{left:calc(100% + var(--tooltip-margin));top:50%;transform:translateX(0) translateY(-50%);&::before{left:calc(var(--tooltip-arrow-size) * -1);top:50%;transform:translateX(0) translateY(-50%);border-right-color:var(--tooltip-background-color);}}&.bottom{bottom:calc(var(--tooltip-margin) * -1);&::before{bottom:100%;border-bottom-color:var(--tooltip-background-color);}}&.left{left:auto;right:calc(100% + var(--tooltip-margin));top:50%;transform:translateX(0) translateY(-50%);::before{left:auto;right:calc(var(--tooltip-arrow-size) * -2);top:50%;transform:translateX(0) translateY(-50%);border-left-color:var(--tooltip-background-color);}}"]);

const Tooltip = props => {
  let timeout;
  const {
    0: active,
    1: setActive
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);

  const showTip = () => {
    timeout = setTimeout(() => {
      setActive(true);
    }, props.delay || 300);
  };

  const hideTip = () => {
    clearInterval(timeout);
    setActive(false);
  };

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(TooltipWrapper, {
    className: "Tooltip-Wrapper",
    onMouseEnter: showTip,
    onMouseLeave: hideTip,
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(StyledInfoIcon, {}), active && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(TooltipTip, {
      className: `Tooltip-Tip ${props.direction || "top"}`,
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_Text__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
        size: "meta",
        color: "white",
        display: "flex",
        align: "left",
        children: props.content
      })
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Tooltip);

/***/ })

};
;