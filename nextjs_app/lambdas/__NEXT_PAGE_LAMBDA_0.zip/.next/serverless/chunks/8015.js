"use strict";
exports.id = 8015;
exports.ids = [8015];
exports.modules = {

/***/ 85964:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);


const FeaturesContainer = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "FeaturesContainer",
  componentId: "op4w60-0"
})(["max-width:", ";&::-webkit-scrollbar{display:none;}::-webkit-scrollbar-thumb{background:", ";border-radius:10px;}", ""], p => p.maxWidth ? p.maxWidth : "75rem", p => p.theme.colors.secondaryBlue, _theme__WEBPACK_IMPORTED_MODULE_0__/* .media.tabletLarge */ .BC.tabletLarge`
    padding: 0 0.75rem;
    
    &::-webkit-scrollbar {
      background: transparent;
      border-radius: 10px;
      width: 0.5rem;
    }

    ::-webkit-scrollbar-thumb {
      background: ${p => p.theme.colors.secondaryBlue};
      border-radius: 10px;
    }
  `);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FeaturesContainer);

/***/ }),

/***/ 4261:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "S3": () => (/* binding */ Author),
/* harmony export */   "Af": () => (/* binding */ TimeStamps),
/* harmony export */   "iz": () => (/* binding */ Divider)
/* harmony export */ });
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(72994);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);



const Author = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "common__Author",
  componentId: "sc-28xuki-0"
})(["display:flex;flex-direction:row;align-items:center;"]);
const TimeStamps = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "common__TimeStamps",
  componentId: "sc-28xuki-1"
})(["display:none;", ""], _theme__WEBPACK_IMPORTED_MODULE_1__/* .media.tabletLarge */ .BC.tabletLarge`
    display: flex;
    flex-direction: row;
    align-items: center;

    & > * {
        line-height: 1;
    }
  `);
const Divider = styled_components__WEBPACK_IMPORTED_MODULE_2___default().hr.withConfig({
  displayName: "common__Divider",
  componentId: "sc-28xuki-2"
})(["", " width:4.5rem;border:1px solid ", ";text-align:left;margin:0.625rem 0;", ""], _styles__WEBPACK_IMPORTED_MODULE_0__/* .borderRadius */ .E, p => p.theme.colors.blue, _theme__WEBPACK_IMPORTED_MODULE_1__/* .media.tabletLarge */ .BC.tabletLarge`
    margin: 1rem 0;
  `);

/***/ })

};
;