"use strict";
exports.id = 8391;
exports.ids = [8391];
exports.modules = {

/***/ 28067:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _button_Button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59067);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(87491);
/* harmony import */ var _contexts_measurements__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(85238);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(91073);
/* harmony import */ var _utils_custom_hooks_useLoading__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(68037);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(11098);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _utils_applicationMap__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(40516);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__);












const Container = styled_components__WEBPACK_IMPORTED_MODULE_7___default().div.withConfig({
  displayName: "MeasurementSection__Container",
  componentId: "sc-68n3mh-0"
})(["display:flex;flex-direction:column;justify-content:space-between;align-items:flex-start;width:100%;padding:2.5rem 0;border-bottom:1px solid ", ";", " ", ""], p => p.theme.colors.secondaryBlue, p => p.closedContent && "flex-wrap: wrap;", _theme__WEBPACK_IMPORTED_MODULE_4__/* .media.tablet */ .BC.tablet`
    flex-direction: ${p => p.open ? "column" : "row"};
    align-items: initial;
  `);
const SectionTitleContainer = styled_components__WEBPACK_IMPORTED_MODULE_7___default().div.withConfig({
  displayName: "MeasurementSection__SectionTitleContainer",
  componentId: "sc-68n3mh-1"
})([""]);
const EditContainer = styled_components__WEBPACK_IMPORTED_MODULE_7___default().div.withConfig({
  displayName: "MeasurementSection__EditContainer",
  componentId: "sc-68n3mh-2"
})(["background:", ";border-radius:10px;padding:0.625rem;display:flex;align-items:center;margin-top:0.5rem;", ""], p => p.theme.colors.white, _theme__WEBPACK_IMPORTED_MODULE_4__/* .media.tablet */ .BC.tablet`
    align-self: center;
    margin-top: initial;
  `);
const ValueContainer = styled_components__WEBPACK_IMPORTED_MODULE_7___default().div.withConfig({
  displayName: "MeasurementSection__ValueContainer",
  componentId: "sc-68n3mh-3"
})(["margin-right:1.25rem;"]);
const ButtonsContainer = styled_components__WEBPACK_IMPORTED_MODULE_7___default().div.withConfig({
  displayName: "MeasurementSection__ButtonsContainer",
  componentId: "sc-68n3mh-4"
})(["display:flex;justify-content:flex-end;& > button:last-child{margin-left:1rem;}"]);

const MeasurementSection = ({
  id,
  title,
  value,
  children,
  onNextClick,
  sectionDisabled,
  closedContent,
  defaultOpen,
  close,
  setClose,
  nextDisabled,
  required
}) => {
  const {
    selectedMeasurement,
    updateLastCompletedStep
  } = (0,_contexts_measurements__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)();
  const isNextStep = (0,_utils_applicationMap__WEBPACK_IMPORTED_MODULE_9__/* .checkStepIsNextStep */ .JM)({
    step: id,
    measurement: selectedMeasurement
  });
  const {
    0: open,
    1: setOpen
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(!!defaultOpen || !!isNextStep);
  const fieldRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const {
    loading,
    setLoading
  } = (0,_utils_custom_hooks_useLoading__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)();
  const {
    0: skipLoading,
    1: setSkipLoading
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const isCompleteStep = (0,_utils_applicationMap__WEBPACK_IMPORTED_MODULE_9__/* .stepIsCompleted */ .Nb)({
    step: id,
    measurement: selectedMeasurement
  });
  const disabled = !isNextStep && !isCompleteStep;
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (!disabled) {
      fieldRef.current && fieldRef.current.scrollIntoView({
        behavior: "smooth",
        block: "center",
        inline: "start"
      });
    }
  }, [disabled]);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (isNextStep) {
      setOpen(true);
    }
  }, [isNextStep]);

  const handleNextClick = async () => {
    try {
      setLoading(true);
      await onNextClick(() => {
        setOpen(!open);
      });
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_6__/* .logError */ .H)(error);
    }

    setLoading(false);
  };

  const handleSkipClick = async () => {
    try {
      setSkipLoading(true);
      await updateLastCompletedStep(id);
      setOpen(!open);
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_6__/* .logError */ .H)(error);
    }

    setSkipLoading(false);
  };

  const isOpen = open && !close;
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.Fragment, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(Container, {
      open: isOpen,
      closedContent: !!closedContent,
      ref: fieldRef,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(SectionTitleContainer, {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
          size: "subheader",
          color: disabled ? "placeholderGrey" : "blue",
          children: title
        })
      }), !disabled && (!isOpen ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.Fragment, {
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(EditContainer, {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(ValueContainer, {
            children: typeof value === "string" ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
              size: "subtitle",
              color: "blue",
              children: value
            }) : value
          }), !sectionDisabled && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
            small: true,
            "data-cy": `${title.replace(" ", "-").toLowerCase()}-edit`,
            onClick: () => {
              setOpen(true);
              setClose && setClose(false);
            },
            children: "Edit"
          })]
        })
      }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.Fragment, {
        children: [children, onNextClick && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(ButtonsContainer, {
          children: [!required && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
            onClick: handleSkipClick,
            loading: skipLoading,
            disabled: loading,
            secondary: true,
            "data-cy": `${title.replace(" ", "-").toLowerCase()}-skip`,
            children: "Skip"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
            onClick: handleNextClick,
            loading: loading,
            disabled: nextDisabled || skipLoading,
            "data-cy": `${title.replace(" ", "-").toLowerCase()}-next`,
            children: "Next"
          })]
        })]
      })), !isOpen && closedContent]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MeasurementSection);

/***/ }),

/***/ 79397:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const Form = styled_components__WEBPACK_IMPORTED_MODULE_0___default().form.withConfig({
  displayName: "Form",
  componentId: "sc-1mu1ljj-0"
})(["width:100%;"]);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Form);

/***/ })

};
;