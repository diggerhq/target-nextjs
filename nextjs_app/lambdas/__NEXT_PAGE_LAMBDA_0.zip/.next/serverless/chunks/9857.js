"use strict";
exports.id = 9857;
exports.ids = [9857];
exports.modules = {

/***/ 89857:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(87491);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _common_FormToastContainer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(41593);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(92107);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);







const Container = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "SettingsContainer__Container",
  componentId: "sc-1vu86z0-0"
})(["width:100%;", " ", ""], _theme__WEBPACK_IMPORTED_MODULE_1__/* .media.tablet */ .BC.tablet`
    min-width: 55%;
    max-width: 55%;
    padding: 0px 1rem 3rem 1rem;
  `, _theme__WEBPACK_IMPORTED_MODULE_1__/* .media.desktop */ .BC.desktop`
    padding: 0 3rem 3rem;
    min-width: ${p => p.width || "65%"};
    max-width: ${p => p.width || "65%"};
  `);
const TitleContainer = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "SettingsContainer__TitleContainer",
  componentId: "sc-1vu86z0-1"
})(["margin-bottom:2rem;"]);
const InnerContainer = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "SettingsContainer__InnerContainer",
  componentId: "sc-1vu86z0-2"
})(["overflow-y:scroll;&::-webkit-scrollbar{scrollbar-width:none;-ms-overflow-style:none;display:none;}", ""], _theme__WEBPACK_IMPORTED_MODULE_1__/* .media.tablet */ .BC.tablet`
    width: 100%;
    padding: 0 0 3rem;
  `);

const SettingsContainer = ({
  title,
  children,
  cta,
  width
}) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(Container, {
  width: width,
  children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(InnerContainer, {
    ctaActive: !!cta,
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(TitleContainer, {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .ZP, {
        size: "subheader",
        children: title
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_common_FormToastContainer__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
      containerId: _constants__WEBPACK_IMPORTED_MODULE_5__/* .SETTINGS_CONTAINER_ID */ .f
    }), children]
  }), cta]
});

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SettingsContainer);

/***/ }),

/***/ 92107:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "f": () => (/* binding */ SETTINGS_CONTAINER_ID)
/* harmony export */ });
const SETTINGS_CONTAINER_ID = "settings";

/***/ })

};
;