"use strict";
exports.id = 9899;
exports.ids = [9899];
exports.modules = {

/***/ 49899:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Spinner__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16114);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(72994);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);






const Container = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
  displayName: "LoadingLarge__Container",
  componentId: "k6rsnr-0"
})(["visibility:", ";opacity:", ";max-height:", ";display:flex;", " position:fixed;overflow:scroll;z-index:15;left:0;top:0;width:100%;height:100%;background-color:rgba(255,255,255,0.4);"], p => p.open ? "visible" : "hidden", p => p.open ? 1 : 0, p => p.open ? "100%" : "0%", p => !p.open && "transition-delay: 1s;");
const ModalContent = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
  displayName: "LoadingLarge__ModalContent",
  componentId: "k6rsnr-1"
})(["", " max-width:100%;width:fit-content;height:fit-content;margin:0 auto;margin-top:4.875rem;display:flex;flex-direction:column;align-items:center;justify-content:center;", ""], _styles__WEBPACK_IMPORTED_MODULE_2__/* .borderRadius */ .E, _theme__WEBPACK_IMPORTED_MODULE_3__/* .media.mobileModern */ .BC.mobileModern`
    margin: auto;
    width: 27rem;
    height: auto;

    max-width: 27rem;
  `);

const LoadingLarge = ({
  loading
}) => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(Container, {
    open: loading,
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(ModalContent, {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_Spinner__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        width: "5rem",
        color: "blue"
      })
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LoadingLarge);

/***/ })

};
;