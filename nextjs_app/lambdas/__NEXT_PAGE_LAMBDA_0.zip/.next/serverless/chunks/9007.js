"use strict";
exports.id = 9007;
exports.ids = [9007];
exports.modules = {

/***/ 49007:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ MeasurementContainer)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var date_fns_format__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(14384);
/* harmony import */ var date_fns_format__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(date_fns_format__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(16666);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_responsive__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _button_Button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(59067);
/* harmony import */ var _common_LoadingLarge__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(49899);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(87491);
/* harmony import */ var _contexts_auth__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(58368);
/* harmony import */ var _contexts_measurements__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(85238);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(91073);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(11098);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _common_Page__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(97598);
/* harmony import */ var _nav_LogoLink__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(95273);
/* harmony import */ var _DeleteMeasurementModal__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(81324);
/* harmony import */ var _MeasurementModal__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(76296);
/* harmony import */ var _RedirectMeasurementModal__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(24179);
/* harmony import */ var _SidebarProgress__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(68962);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_MeasurementModal__WEBPACK_IMPORTED_MODULE_16__]);
_MeasurementModal__WEBPACK_IMPORTED_MODULE_16__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






















const Container = styled_components__WEBPACK_IMPORTED_MODULE_12___default().div.withConfig({
  displayName: "MeasurementContainer__Container",
  componentId: "sc-1lxtzer-0"
})(["padding:1.25rem 1.25rem 3rem;position:relative;background:", ";height:100vh;width:100vw;max-width:1440px;margin:0 auto;box-shadow:0 3px 6px 0 rgba(0,0,0,0.16);min-height:100%;max-height:100%;overflow-y:hidden;", " ", "  ", ""], p => p.theme.colors.backgroundGrey, _theme__WEBPACK_IMPORTED_MODULE_10__/* .media.tablet */ .BC.tablet`
    padding: 1.25rem;
   `, _theme__WEBPACK_IMPORTED_MODULE_10__/* .media.tabletLarge */ .BC.tabletLarge`
    padding: ${p => p.padding || "1rem 7rem"};  
  `, _theme__WEBPACK_IMPORTED_MODULE_10__/* .media.desktopLarge */ .BC.desktopLarge`
        padding: ${p => p.padding || "2rem 7rem"};
    `);
const Content = styled_components__WEBPACK_IMPORTED_MODULE_12___default().div.withConfig({
  displayName: "MeasurementContainer__Content",
  componentId: "sc-1lxtzer-1"
})(["display:flex;width:100%;height:calc(100vh - 9.75rem);"]);
const TitleContainer = styled_components__WEBPACK_IMPORTED_MODULE_12___default().div.withConfig({
  displayName: "MeasurementContainer__TitleContainer",
  componentId: "sc-1lxtzer-2"
})(["position:relative;border-bottom:2px solid #bed1ff;height:7.25rem;", ";"], _theme__WEBPACK_IMPORTED_MODULE_10__/* .media.tabletLarge */ .BC.tabletLarge`
    padding-bottom: 1rem;
    display: block;
  `);
const TextContainer = styled_components__WEBPACK_IMPORTED_MODULE_12___default().div.withConfig({
  displayName: "MeasurementContainer__TextContainer",
  componentId: "sc-1lxtzer-3"
})(["", ""], _theme__WEBPACK_IMPORTED_MODULE_10__/* .media.tablet */ .BC.tablet`
    margin-bottom: 0.625rem;
    line-height: normal;
  `);
const TitleTextContainer = styled_components__WEBPACK_IMPORTED_MODULE_12___default()(TextContainer).withConfig({
  displayName: "MeasurementContainer__TitleTextContainer",
  componentId: "sc-1lxtzer-4"
})(["justify-content:space-between;display:flex;", ";", ""], p => p.description || !p.cta ? "margin-bottom: 2rem" : "margin-bottom: 0", _theme__WEBPACK_IMPORTED_MODULE_10__/* .media.tabletLarge */ .BC.tabletLarge`
    ${p => p.description ? "margin-bottom: 1rem" : "margin-bottom: 0"};
  `);
const CTAButtonContainer = styled_components__WEBPACK_IMPORTED_MODULE_12___default().div.withConfig({
  displayName: "MeasurementContainer__CTAButtonContainer",
  componentId: "sc-1lxtzer-5"
})(["margin-left:1rem;"]);
const DescriptionTextContainer = styled_components__WEBPACK_IMPORTED_MODULE_12___default()(TextContainer).withConfig({
  displayName: "MeasurementContainer__DescriptionTextContainer",
  componentId: "sc-1lxtzer-6"
})(["line-height:1;", ""], _theme__WEBPACK_IMPORTED_MODULE_10__/* .media.tabletLarge */ .BC.tabletLarge`
    max-width: 70%;
  `);
const IconContainer = styled_components__WEBPACK_IMPORTED_MODULE_12___default().div.withConfig({
  displayName: "MeasurementContainer__IconContainer",
  componentId: "sc-1lxtzer-7"
})(["margin-right:0.75rem;background:", ";", ";border-radius:10px;width:3rem;height:3rem;display:flex;align-items:center;justify-content:center;", " transition:box-shadow 0.3s;& > svg{fill:", ";width:1.5rem;height:1.75rem;}&:hover{", "}"], p => p.theme.colors.blue, p => p.iconBorder && `border: 0.5px solid ${p.theme.colors.tertiaryBlue}`, p => p.onClick && "cursor: pointer;", p => p.theme.colors.white, p => p.onClick && `
        background-color: ${p => p.theme.colors.secondaryBlue};
        box-shadow: ${p => `0 5px 5px 0 ${p.theme.colors.blue}40`};
      `);
const LinkIconContainer = styled_components__WEBPACK_IMPORTED_MODULE_12___default()(IconContainer).withConfig({
  displayName: "MeasurementContainer__LinkIconContainer",
  componentId: "sc-1lxtzer-8"
})(["margin-left:2rem;background:", ";"], p => p.theme.colors.transparent);
const TitleInnerContainer = styled_components__WEBPACK_IMPORTED_MODULE_12___default().div.withConfig({
  displayName: "MeasurementContainer__TitleInnerContainer",
  componentId: "sc-1lxtzer-9"
})(["display:flex;align-items:center;"]);
const DesktopCTAs = styled_components__WEBPACK_IMPORTED_MODULE_12___default().div.withConfig({
  displayName: "MeasurementContainer__DesktopCTAs",
  componentId: "sc-1lxtzer-10"
})(["display:flex;align-items:flex-end;"]);
const ContentContainer = styled_components__WEBPACK_IMPORTED_MODULE_12___default().div.withConfig({
  displayName: "MeasurementContainer__ContentContainer",
  componentId: "sc-1lxtzer-11"
})(["width:80%;height:", ";padding:0 2.5rem;overflow-y:scroll;&::-webkit-scrollbar{background:transparent;border-radius:10px;width:0.5rem;}::-webkit-scrollbar-thumb{background:", ";border-radius:10px;}"], p => p.height || "90%", p => p.theme.colors.secondaryBlue);
function MeasurementContainer({
  breadcrumb,
  description,
  children,
  cta,
  href,
  as,
  limit,
  limitWidth,
  icon,
  iconBorder,
  onIconClick,
  secondaryCta,
  contentHeight
}) {
  const isTabletLarge = (0,react_responsive__WEBPACK_IMPORTED_MODULE_4__.useMediaQuery)({
    query: `(min-width: ${_theme__WEBPACK_IMPORTED_MODULE_10__/* .sizes.tabletLarge */ .J7.tabletLarge}px)`
  });
  const {
    selectedMeasurement,
    setSelectedMeasurement,
    setLoading,
    loading
  } = (0,_contexts_measurements__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)();
  const {
    user
  } = (0,_contexts_auth__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
  const hasCTAs = !!cta || !!secondaryCta;
  const {
    0: showDeleteConfirmationModal,
    1: setShowDeleteConfirmationModal
  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)();
  const {
    0: editLoading,
    1: setEditLoading
  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)();
  const {
    0: deleteLoading,
    1: setDeleteLoading
  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)();
  const {
    0: showRedirectConfirmationModal,
    1: setShowRedirectConfirmationModal
  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)();
  const {
    0: showEditConfirmationModal,
    1: setShowEditConfirmationModal
  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)();

  const discardMeasurement = async () => {
    try {
      setDeleteLoading(true);
      await axios__WEBPACK_IMPORTED_MODULE_0___default()["delete"](`/api/organisations/${user.organisation_id}/measurements/${selectedMeasurement.id}`);
      setSelectedMeasurement(null);
      router.push("/measurements");
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_11__/* .logError */ .H)(error);
      setDeleteLoading(false);
    }
  };

  const redirectMeasurement = async () => {
    try {
      setLoading(true);
      router.push("/measurements");
      setSelectedMeasurement(null);
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_11__/* .logError */ .H)(error);
      setLoading(false);
    }
  };

  const editMeasurement = async ({
    period_end,
    period_start
  }) => {
    try {
      setEditLoading(true);
      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_0___default().patch(`/api/organisations/${user.organisation_id}/measurements/${selectedMeasurement.id}`, {
        period_end,
        period_start
      });
      setSelectedMeasurement(data);
      setEditLoading(false);
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_11__/* .logError */ .H)(error);
    }
  };

  (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(() => {
    return () => {
      setSelectedMeasurement(null);
    };
  }, []);

  if (selectedMeasurement.state === "pending") {
    router.push("/measurements");
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(_common_LoadingLarge__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
      loading: true,
      text: "This calculation is currently already being processed"
    });
  }

  if (loading && selectedMeasurement === null) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(_common_LoadingLarge__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
      loading: true,
      text: "Returning to dashboard"
    });
  }

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.Fragment, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(_DeleteMeasurementModal__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
      showConfirmationModal: showDeleteConfirmationModal,
      setShowConfirmationModal: setShowDeleteConfirmationModal,
      onConfirm: discardMeasurement,
      loading: deleteLoading
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(_RedirectMeasurementModal__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
      showConfirmationModal: showRedirectConfirmationModal,
      setShowConfirmationModal: setShowRedirectConfirmationModal,
      onConfirm: redirectMeasurement
    }), showEditConfirmationModal && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(_MeasurementModal__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
      showModal: showEditConfirmationModal,
      setShowModal: setShowEditConfirmationModal,
      onConfirm: editMeasurement,
      measurement: selectedMeasurement,
      loading: loading || editLoading
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsxs)(Container, {
      limit: limit,
      limitWidth: limitWidth,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(_common_Page__WEBPACK_IMPORTED_MODULE_13__/* .GlobalStyle */ .ZL, {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsxs)(TitleContainer, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(_nav_LogoLink__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
          href: "/",
          width: "96px"
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsxs)(TitleTextContainer, {
          cta: hasCTAs,
          description: description,
          breadcrumb: breadcrumb,
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsxs)(TitleInnerContainer, {
            children: [icon && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(IconContainer, {
              iconBorder: iconBorder,
              onClick: onIconClick,
              children: icon
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsxs)(_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
              size: "cardTitle",
              align: "left",
              color: "blue",
              children: ["Measurement Period:", " ", date_fns_format__WEBPACK_IMPORTED_MODULE_1___default()(new Date(selectedMeasurement.period_start), "dd/MM/yyyy"), " ", "-", " ", date_fns_format__WEBPACK_IMPORTED_MODULE_1___default()(new Date(selectedMeasurement.period_end), "dd/MM/yyyy")]
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(LinkIconContainer, {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP, {
                small: true,
                onClick: () => setShowEditConfirmationModal(!showEditConfirmationModal),
                children: "Change"
              })
            })]
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsxs)(DesktopCTAs, {
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(CTAButtonContainer, {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP, {
                secondary: true,
                href: href,
                as: as,
                onClick: () => setShowDeleteConfirmationModal(!showDeleteConfirmationModal),
                warning: true,
                children: "Discard entry"
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(CTAButtonContainer, {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP, {
                href: href,
                as: as,
                onClick: () => setShowRedirectConfirmationModal(!showRedirectConfirmationModal),
                children: "Complete later"
              })
            })]
          })]
        }), description && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(DescriptionTextContainer, {
          align: "center",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
            size: isTabletLarge ? "body" : "tiny",
            children: description
          })
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsxs)(Content, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(_SidebarProgress__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(ContentContainer, {
          containerId: "flowers",
          height: contentHeight,
          children: children
        })]
      })]
    })]
  });
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 24179:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16666);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_responsive__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _common_ConfirmationModal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65487);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(87491);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






var CalculatorIcon = function CalculatorIcon(props) {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("g", {
      clipPath: "url(#clip0)",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("path", {
        d: "M23.737 20.248v.728c-.022.076-.013.156-.025.233a4.933 4.933 0 0 1-.267 1.01 4.392 4.392 0 0 1-.976 1.554c-.625.63-1.393.988-2.259 1.15-.157.028-.319.034-.474.077h-.727a.717.717 0 0 0-.167-.034 4.101 4.101 0 0 1-1.665-.58c-.93-.569-1.554-1.382-1.896-2.412a7.07 7.07 0 0 1-.079-.256.145.145 0 0 0-.158-.115H2.203a5.098 5.098 0 0 1-.577-.018c-.83-.095-1.452-.682-1.587-1.504a.49.49 0 0 0-.037-.134V1.667c.045-.069.04-.15.057-.226.17-.73.6-1.212 1.34-1.395.09-.022.181-.032.272-.048h19.157c.074.012.148.02.223.036.722.154 1.192.58 1.392 1.293.059.236.084.478.077.721v15.343c0 .159.054.312.152.436.054.071.111.14.165.21.426.555.727 1.167.859 1.858.018.12.02.238.041.353zM10.882 1.076c-2.52-.003-5.517.008-8.514-.006-.178 0-.356-.01-.535.005-.384.034-.649.273-.717.651a1.402 1.402 0 0 0-.02.268c.007.68-.003 1.362.012 2.043.01.424.005.847.004 1.273-.004 1.937-.004 3.874-.01 5.81-.008 2.737-.012 5.472.008 8.206 0 .174-.004.35.005.524.02.337.223.572.551.65.127.023.255.032.384.025h12.348c.175 0 .35.004.525 0 .124 0 .152-.03.159-.15.032-.616.21-1.215.517-1.749.09-.155.136-.332.134-.51V15.9 7.286c0-.11.01-.22.035-.329a.493.493 0 0 1 .39-.395c.13-.028.261-.04.393-.037h3.264c.134 0 .264.004.395.015.305.026.478.179.528.48.019.135.027.27.024.406v8.657c.004.125.002.25-.006.374a.125.125 0 0 0 .09.142c.175.06.347.13.513.212.034.018.06.005.055-.035-.004-.1-.002-.2.006-.299-.007-3.214.01-6.427-.009-9.641-.01-1.612 0-3.224 0-4.837.006-.1.006-.2 0-.3a.673.673 0 0 0-.538-.602 1.448 1.448 0 0 0-.32-.024l-9.67.003zm8.552 22.831c1.689.048 3.217-1.418 3.221-3.2.004-1.891-1.516-3.267-3.255-3.28-1.667-.01-3.227 1.367-3.228 3.212-.002 1.939 1.508 3.293 3.262 3.267v.001zM16.808 12.44v4.633c0 .034-.016.08.016.1.041.025.07-.021.1-.045.225-.157.464-.293.714-.406a4.16 4.16 0 0 1 1.368-.357c.182-.016.363-.014.545-.017.095 0 .119-.026.127-.12.002-.032 0-.064 0-.096-.003-.271-.007-.542-.008-.813a716.8 716.8 0 0 1-.003-4.3c0-1.063-.003-2.126.01-3.189.003-.178-.026-.202-.205-.202h-2.44c-.21 0-.23.019-.23.233l.006 4.58z"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("path", {
        d: "M11.27 1.73h8.678c.103-.003.207.003.31.015.297.042.46.207.487.506.008.089.014.178.014.267v2.547a1.9 1.9 0 0 1-.03.383c-.049.233-.172.357-.405.396-.084.017-.17.026-.255.026H2.519a1.59 1.59 0 0 1-.381-.038.439.439 0 0 1-.345-.355 1.768 1.768 0 0 1-.035-.394v-2.61a1.456 1.456 0 0 1 .028-.309.49.49 0 0 1 .433-.412c.08-.014.163-.02.245-.021h4.195l4.61-.002zm-.008 3.06H19.565c.09 0 .114-.03.115-.117 0-.071-.007-.142-.007-.214V3.015c0-.204 0-.204-.209-.204h-5.746L3.03 2.808c-.176 0-.2.024-.195.197v.01c.023.424.007.848.01 1.273v.353c.003.137.014.147.147.15h8.27zM15.076 9.739v2.452c.002.086-.005.172-.022.255a.493.493 0 0 1-.41.402 1.058 1.058 0 0 1-.222.024h-5.02a.99.99 0 0 1-.274-.038.478.478 0 0 1-.334-.318.726.726 0 0 1-.045-.22c-.005-.167-.012-.335-.013-.502V7.449a2.309 2.309 0 0 1 .028-.427c.056-.296.223-.446.523-.475.117-.012.234-.018.352-.018h4.602c.14-.003.278.01.414.038a.48.48 0 0 1 .386.372c.027.115.039.233.036.35-.002.816-.002 1.633-.001 2.45zm-1.077-.02V7.845c0-.211-.008-.219-.215-.219H9.965c-.086.007-.112.033-.119.12-.003.036 0 .071 0 .107V11.6c0 .184.01.191.194.191h3.756c.197 0 .205-.005.205-.202L14 9.72zM8.735 16.805v-1.962c0-.235.007-.47.012-.706a.86.86 0 0 1 .007-.096c.045-.309.21-.465.52-.502a2.52 2.52 0 0 1 .288-.015h4.74c.129-.003.257.01.382.041a.474.474 0 0 1 .353.34c.027.096.04.195.038.295v4.942a1.26 1.26 0 0 1-.021.277.516.516 0 0 1-.441.424c-.084.014-.17.022-.255.023h-4.88c-.085-.001-.17-.01-.255-.024-.255-.042-.404-.19-.46-.444a1.137 1.137 0 0 1-.018-.212c-.017-.832-.007-1.667-.01-2.38zm3.192-2.203h-1.851c-.232 0-.232 0-.232.232 0 .792.003 1.584 0 2.376 0 .442.007.884-.01 1.326-.008.205.024.232.232.232h3.7c.23 0 .23 0 .23-.232v-3.735-.075c-.005-.097-.024-.116-.123-.12h-.053l-1.893-.004zM1.758 16.684V14.33c0-.096.004-.193.013-.289.028-.295.196-.464.49-.501.079-.01.157-.015.235-.016h4.86c.086 0 .172.006.256.019a.493.493 0 0 1 .446.413c.014.066.02.134.02.202v5.062c0 .075-.007.15-.022.223a.486.486 0 0 1-.42.4c-.077.015-.155.022-.234.022H2.48c-.07 0-.142-.006-.213-.016-.298-.039-.467-.213-.492-.513a4.019 4.019 0 0 1-.014-.312c-.002-.779-.003-1.558-.002-2.34zm3.154 2.082h1.947c.117 0 .134-.02.138-.139v-.085-.984-2.76c0-.192 0-.194-.189-.194H2.924a.081.081 0 0 0-.081.072.459.459 0 0 0-.009.095c0 .134.01.27.01.406.002.521.002 1.041 0 1.561 0 .613.006 1.227-.01 1.84-.005.167.018.184.182.185l1.896.003zM8.076 9.686v2.504a1.07 1.07 0 0 1-.039.317.453.453 0 0 1-.326.323 1.04 1.04 0 0 1-.285.04H2.418c-.078-.002-.156-.01-.233-.027-.242-.048-.388-.218-.413-.48a3.112 3.112 0 0 1-.015-.288v-4.73c0-.092.006-.185.014-.277.026-.322.215-.502.539-.526.281-.022.563-.016.844-.016h4.163c.117-.003.235.01.35.036a.517.517 0 0 1 .406.5c.005.083 0 .165 0 .247l.003 2.377zm-3.153 2.106h1.915c.147 0 .158-.012.16-.158v-.065-1.005-2.75c0-.178-.009-.185-.19-.185H2.937a.09.09 0 0 0-.093.085.793.793 0 0 0-.008.118c0 .089.009.178.009.267 0 .745.004 1.49 0 2.236 0 .374.01.749-.01 1.123a1.93 1.93 0 0 0 0 .203c.005.1.032.126.13.13h1.959zM21.372 21.442c.01.47-.308 1.057-.86 1.256a.503.503 0 0 0-.06.025c-.063.032-.072.05-.06.119.004.017.01.034.013.052.031.162-.036.278-.196.312-.188.039-.379.067-.567.105-.157.031-.261-.05-.3-.204l-.005-.032c-.024-.1-.042-.116-.139-.096-.118.025-.239.041-.356.07-.223.054-.36-.042-.4-.268a24.358 24.358 0 0 1-.07-.432.577.577 0 0 1-.009-.107.232.232 0 0 1 .164-.227c.074-.025.15-.044.228-.056.401-.074.8-.147 1.199-.223a.515.515 0 0 0 .227-.089.25.25 0 0 0 .098-.284.256.256 0 0 0-.233-.19 1.084 1.084 0 0 0-.307.03c-.197.037-.391.082-.589.109-.58.08-1.063-.097-1.398-.587-.469-.685-.188-1.634.572-1.978.042-.02.085-.036.127-.057a.083.083 0 0 0 .05-.106.695.695 0 0 1-.014-.052c-.034-.17.034-.287.207-.326.184-.041.371-.07.556-.104a.319.319 0 0 1 .054-.003c.13 0 .223.07.24.198.017.153.061.16.211.134.102-.02.204-.032.308-.04.206-.008.315.064.378.258.044.14.074.283.09.429.023.21-.064.322-.276.357-.246.04-.49.082-.737.13l-.629.128a.464.464 0 0 0-.167.067.235.235 0 0 0-.112.267.257.257 0 0 0 .216.21c.078.01.157.006.234-.01.228-.044.455-.088.684-.124.818-.134 1.516.424 1.614 1.155.009.063.01.123.014.184zM18.252 13.091h.898c.05-.002.1.004.147.02a.243.243 0 0 1 .152.154.23.23 0 0 1 .015.073c0 .21.02.42-.004.63a.219.219 0 0 1-.208.208 1.54 1.54 0 0 1-.203.014h-1.605a1.31 1.31 0 0 1-.192-.014c-.122-.019-.21-.09-.223-.213a3.193 3.193 0 0 1 0-.66c.014-.127.113-.201.247-.21.075-.004.15 0 .223 0l.753-.002zM18.259 12.873h-.855a.883.883 0 0 1-.128-.005c-.143-.021-.232-.098-.248-.24a2.457 2.457 0 0 1 .008-.64.209.209 0 0 1 .173-.181.687.687 0 0 1 .16-.015h1.753c.257 0 .367.113.348.37-.01.147.012.292-.004.439-.02.188-.096.267-.287.27-.307.004-.613 0-.92 0v.002z"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("path", {
        d: "M17.156 4.567c-.103 0-.206.003-.31 0-.164-.006-.252-.085-.26-.25a5.85 5.85 0 0 1 0-.544c.01-.195.105-.278.299-.292a3.76 3.76 0 0 1 .575 0c.177.015.261.095.268.27.007.176.005.363 0 .545-.005.18-.093.267-.283.272h-.288v-.001zM15.848 4.567c-.096 0-.192.002-.288 0-.182-.006-.268-.08-.274-.258a7.53 7.53 0 0 1-.003-.576c.006-.161.086-.236.248-.25.213-.019.427-.019.64 0 .146.012.223.079.235.226.018.21.017.42-.002.629-.014.145-.09.217-.236.226-.106.006-.213 0-.32 0v.003zM18.46 4.566c-.1 0-.2.004-.299 0-.166-.007-.248-.089-.252-.254-.006-.181-.005-.362-.007-.544 0-.018.002-.036.004-.053.015-.14.082-.215.223-.23.227-.023.456-.023.682 0 .126.014.19.08.211.205.007.043.01.085.01.128v.437a.533.533 0 0 1-.01.107.24.24 0 0 1-.24.204c-.106.005-.213 0-.32 0h-.001zM11.902 9.175H13.056c.186.006.291.107.299.293.002.064-.01.128-.01.191 0 .09.007.179.009.268.004.203-.086.305-.288.324a1.212 1.212 0 0 1-.128.003h-2.096a.7.7 0 0 1-.169-.018.252.252 0 0 1-.198-.202 2.657 2.657 0 0 1 .007-.68c.018-.108.093-.165.2-.179.04-.003.08-.004.118-.003h1.101l.001.003zM11.274 18.006a.265.265 0 0 1-.186-.085c-.131-.137-.268-.268-.402-.402-.112-.11-.112-.232-.008-.352.05-.06.11-.112.166-.167l1.46-1.46c.037-.039.076-.075.118-.108.092-.07.19-.073.274.003.168.15.327.308.477.476.089.1.078.212-.019.318-.09.095-.178.184-.27.275l-1.37 1.369a.723.723 0 0 1-.097.083.257.257 0 0 1-.143.05zM10.418 15.768a.551.551 0 0 1 .567-.557c.332 0 .571.235.571.562a.56.56 0 0 1-.57.557.562.562 0 0 1-.568-.562zM12.838 18.18a.55.55 0 0 1-.561-.564.554.554 0 0 1 .57-.558.53.53 0 0 1 .55.56c-.006.377-.3.584-.56.561zM5.569 17.94a.408.408 0 0 1-.232-.096 3.104 3.104 0 0 1-.264-.25 1.125 1.125 0 0 0-.086-.08c-.056-.044-.08-.041-.13.01a2.7 2.7 0 0 0-.2.223c-.04.052-.082.1-.128.144-.122.111-.248.125-.394.05a.709.709 0 0 1-.204-.17c-.085-.097-.17-.194-.253-.291-.09-.103-.087-.208.014-.316.116-.125.239-.245.36-.365.113-.11.112-.108-.004-.22a15.472 15.472 0 0 1-.333-.332c-.122-.127-.12-.25.003-.376s.255-.259.386-.386c.13-.126.248-.123.375 0 .126.124.241.243.361.365.076.077.09.077.163 0 .12-.122.24-.243.362-.364a.425.425 0 0 1 .1-.08.188.188 0 0 1 .235.037c.095.089.185.178.275.267.063.063.127.126.187.192.092.102.097.188.013.297a1.362 1.362 0 0 1-.234.233 1.09 1.09 0 0 0-.167.15c-.07.083-.07.147 0 .23.055.06.116.115.182.163.066.05.126.105.181.166.1.12.105.24.006.357a2.348 2.348 0 0 1-.35.344.41.41 0 0 1-.224.098zM5.851 9.176c.09 0 .178-.003.268 0 .146.005.223.072.243.219.027.209.027.42 0 .63-.017.133-.079.191-.212.216a1.84 1.84 0 0 1-.31.012h-.277c-.083.003-.1.02-.102.103-.002.134 0 .264 0 .396a.99.99 0 0 1-.012.182c-.023.12-.086.19-.206.197a5.82 5.82 0 0 1-.641 0c-.121-.007-.186-.074-.21-.194a.79.79 0 0 1-.01-.138v-.418c0-.114-.014-.127-.134-.129-.12-.002-.228 0-.342 0a1.802 1.802 0 0 1-.213-.017.207.207 0 0 1-.193-.185.794.794 0 0 1-.013-.138v-.407c0-.05.005-.1.015-.148a.21.21 0 0 1 .17-.172.586.586 0 0 1 .127-.011h.45c.119 0 .13-.012.133-.128V8.64a.684.684 0 0 1 .02-.179.238.238 0 0 1 .188-.183.724.724 0 0 1 .138-.02c.143-.003.285 0 .428 0a.528.528 0 0 1 .127.019.211.211 0 0 1 .165.175c.01.05.015.1.014.15v.438c0 .127.01.134.134.137h.256v-.001z"
      })]
    })
  }));
};

CalculatorIcon.defaultProps = {
  width: "24",
  height: "25",
  viewBox: "0 0 24 25",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};




const TitleContainer = styled_components__WEBPACK_IMPORTED_MODULE_6___default().div.withConfig({
  displayName: "RedirectMeasurementModal__TitleContainer",
  componentId: "nyq61q-0"
})(["display:flex;flex-direction:column;align-items:center;justify-content:center;"]);
const BodyContainer = styled_components__WEBPACK_IMPORTED_MODULE_6___default()(TitleContainer).withConfig({
  displayName: "RedirectMeasurementModal__BodyContainer",
  componentId: "nyq61q-1"
})(["padding:0 10%;", ""], _theme__WEBPACK_IMPORTED_MODULE_5__/* .media.tablet */ .BC.tablet`
  padding: 2.5% 25%;
`);
const StyledCalculatorIcon = styled_components__WEBPACK_IMPORTED_MODULE_6___default()(CalculatorIcon).withConfig({
  displayName: "RedirectMeasurementModal__StyledCalculatorIcon",
  componentId: "nyq61q-2"
})(["width:2rem;height:2rem;& > *{fill:", ";}"], p => p.theme.colors.blue);

const RedirectMeasurementModal = ({
  showConfirmationModal,
  setShowConfirmationModal,
  onConfirm,
  loading
}) => {
  const tablet = (0,react_responsive__WEBPACK_IMPORTED_MODULE_1__.useMediaQuery)({
    query: `(min-width: ${_theme__WEBPACK_IMPORTED_MODULE_5__/* .sizes.tablet */ .J7.tablet}px)`
  });
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_common_ConfirmationModal__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
    open: showConfirmationModal,
    onClose: () => setShowConfirmationModal(!showConfirmationModal),
    onConfirm: onConfirm,
    cancelText: "Cancel",
    confirmText: "To Dashboard",
    title: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(TitleContainer, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(StyledCalculatorIcon, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP, {
        size: "modalTitle",
        color: "blue",
        children: "Go back to dashboard"
      })]
    }),
    body: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(BodyContainer, {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP, {
        children: "Please make sure you have fully completed each section as any incomplete sections will not be saved."
      })
    }),
    loading: loading
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RedirectMeasurementModal);

/***/ }),

/***/ 68962:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(41664);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(87491);
/* harmony import */ var _utils_applicationMap__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(40516);
/* harmony import */ var _contexts_measurements__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(85238);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _common_LoadingLarge__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(49899);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }








var CarIcon = function CarIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("path", {
      d: "M15.018 18.503h-6.75c-.357 0-.358 0-.358.365v2.118c-.003 1.015-.675 1.695-1.685 1.702-1.055.005-2.11.005-3.165 0-1.014-.004-1.695-.682-1.695-1.695V11.5c-.009-.464.076-.925.251-1.354.07-.162.05-.221-.125-.267C.555 9.635.004 8.916.006 7.949c0-.356-.027-.714.031-1.07.156-.964.899-1.624 1.876-1.638.899-.011 1.797-.011 2.694 0 .222.003.321-.073.392-.28.337-1 .69-1.992 1.038-2.989C6.47.73 7.475.002 8.792.002 12.89 0 16.988 0 21.086.002c1.263 0 2.153.604 2.67 1.751.486 1.081.967 2.165 1.44 3.252.073.167.167.236.354.234.81-.009 1.622-.006 2.433-.003 1.214.008 2.017.81 2.017 2.017v.759c0 .894-.545 1.624-1.402 1.854-.192.051-.209.13-.15.294.134.397.198.814.189 1.233-.005 3.209-.005 6.417 0 9.625 0 .98-.674 1.663-1.658 1.669-1.072.006-2.144.006-3.217 0-.974-.007-1.642-.683-1.643-1.65v-2.171c0-.365 0-.365-.377-.365l-6.724.002zM15 16.586c3.801 0 7.602.002 11.404.005.254 0 .325-.075.323-.325-.01-1.632-.007-3.264-.005-4.891 0-.565-.194-1.035-.64-1.397a14.717 14.717 0 0 1-.77-.668.816.816 0 0 0-.612-.225c-3.295.025-6.59-.006-9.886.03-3.025.034-6.05.017-9.076.013-.284 0-.521.052-.748.234-.314.251-.646.474-.975.704-.48.335-.712.783-.707 1.376.011 1.596.004 3.191.004 4.787 0 .357 0 .357.362.357H15zm.138-9.415h8.527c.359 0 .36 0 .213-.337-.628-1.42-1.256-2.838-1.877-4.259-.181-.416-.482-.614-.936-.614-4.08.003-8.16.004-12.24.003-.523 0-.78.183-.96.68-.508 1.4-1.013 2.802-1.514 4.205-.115.32-.112.322.236.322h8.551zm10.225 13.6h1.148c.137 0 .212-.04.211-.191-.003-.628-.003-1.254 0-1.879 0-.146-.062-.201-.204-.2a343.8 343.8 0 0 1-2.27 0c-.16 0-.213.067-.213.22.005.608.006 1.218 0 1.827 0 .171.066.23.232.226.365-.006.731 0 1.096-.001v-.001zm-20.72-2.268c-.357 0-.714.007-1.068 0-.188-.005-.266.058-.263.251.008.591.007 1.183 0 1.774 0 .175.054.251.24.251.722-.006 1.443-.006 2.165 0 .176 0 .25-.054.25-.238-.006-.6-.006-1.2 0-1.8 0-.189-.08-.24-.25-.237-.362.004-.718 0-1.075 0zM3.108 7.156h-.575c-.653.014-.578-.125-.588.605 0 .189.063.27.259.265.366-.008.732 0 1.098 0 .434 0 .753-.261.863-.684.038-.142.004-.188-.143-.188-.305.007-.61.003-.914.002zm23.998 0v-.008h-.784c-.063 0-.147-.02-.137.1.032.377.448.76.83.76h.47c.691-.014.587.126.596-.616V7.34c.007-.135-.062-.189-.188-.185-.264.004-.525.001-.787.001z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("path", {
      d: "M7.24 10.156c1.488.01 2.716 1.24 2.714 2.719 0 1.5-1.275 2.767-2.755 2.743-1.536-.025-2.721-1.248-2.71-2.798.01-1.487 1.238-2.674 2.752-2.664zm-.066 3.515a.803.803 0 0 0 .815-.773.827.827 0 0 0-.811-.82.785.785 0 0 0-.792.799c.003.464.327.788.788.792v.002zM22.825 10.155a2.706 2.706 0 0 1 2.73 2.716 2.736 2.736 0 0 1-2.737 2.747c-1.484-.004-2.735-1.26-2.73-2.741a2.74 2.74 0 0 1 2.736-2.722zm.011 1.963c-.462-.004-.793.314-.801.771-.008.468.324.817.786.823a.811.811 0 0 0 .816-.779.8.8 0 0 0-.8-.815zM15.002 11.932h2.743c.413 0 .698.204.867.564.175.37.096.716-.16 1.022a.928.928 0 0 1-.741.327c-1.803.004-3.605.008-5.408 0-.518-.003-.862-.303-.974-.786-.09-.387.125-.82.502-1.028.16-.089.332-.097.506-.098h2.665v-.001z"
    })]
  }));
};

CarIcon.defaultProps = {
  width: "30",
  height: "23",
  viewBox: "0 0 30 23",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var ExpensesIcon = function ExpensesIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("path", {
      d: "M23.283 12.496v11.477c0 .54-.297.909-.805 1.011-.256.051-.479-.027-.695-.154-.924-.54-1.848-1.072-2.764-1.624-.198-.119-.341-.116-.535 0-.896.542-1.804 1.063-2.7 1.602-.399.241-.775.225-1.165-.007-.918-.547-1.842-1.085-2.759-1.634-.136-.081-.239-.09-.38-.005-.892.534-1.798 1.047-2.682 1.591-.473.291-.898.304-1.378 0-.88-.553-1.786-1.063-2.675-1.601-.163-.099-.285-.09-.443.005-.904.541-1.814 1.073-2.72 1.61-.777.458-1.563.024-1.579-.877-.007-.427 0-.855 0-1.283V1.16C.003.59.24.203.682.064.879 0 1.084 0 1.292 0H22.08c.126 0 .25.008.375.024.513.07.828.43.828.948v11.524zm-1.932-.36V2.342c0-.35 0-.35-.35-.35H2.358c-.067 0-.133 0-.2.002-.107 0-.163.054-.165.163V22.059c.005.211.024.222.211.114.602-.343 1.206-.683 1.803-1.034.402-.237.784-.236 1.187.006.915.552 1.841 1.085 2.757 1.636.148.09.257.085.4 0 .873-.523 1.761-1.02 2.622-1.56.5-.316.942-.309 1.437 0 .873.54 1.764 1.042 2.643 1.57.142.085.242.075.378-.007.917-.548 1.842-1.084 2.76-1.634.407-.244.795-.251 1.204 0 .56.343 1.13.668 1.694.999.072.041.145.143.23.086.069-.044.03-.154.03-.23.003-3.29.003-6.579.002-9.867v-.001z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("path", {
      d: "M7.908 13.595c-.133 0-.265.004-.398 0-.228-.01-.369-.12-.348-.338.04-.444-.045-.699-.551-.864-.634-.206-1-.755-1.098-1.438-.044-.311.088-.465.397-.476.243-.008.487-.005.73 0 .202.005.348.085.415.295a.38.38 0 0 0 .386.276c.265.003.53.007.795 0 .364-.013.677-.308.68-.63a.699.699 0 0 0-.694-.716c-.323-.014-.648.017-.97-.045-1.533-.292-2.364-1.985-1.567-3.3.272-.462.71-.803 1.226-.953.157-.048.217-.123.207-.28a4.232 4.232 0 0 1 0-.442c.012-.257.13-.384.382-.394.253-.01.501-.01.752 0 .268.01.405.14.384.404-.033.41.019.667.513.82.66.213 1.043.77 1.14 1.478.039.278-.102.44-.38.449a15.55 15.55 0 0 1-.774 0c-.185-.004-.324-.084-.386-.272-.068-.209-.22-.302-.436-.3-.236 0-.472-.005-.707.002-.38.012-.69.305-.69.64 0 .404.285.696.691.709.308.01.616-.006.924.034 1.394.184 2.277 1.703 1.722 2.993a2.133 2.133 0 0 1-1.364 1.237c-.162.051-.228.13-.214.298.008.132.008.265 0 .398-.008.302-.12.41-.416.417h-.354l.003-.002zM11.68 17.619H6.263c-.26 0-.498-.052-.703-.216a.954.954 0 0 1-.308-1.055.947.947 0 0 1 .88-.66c.383-.008.766-.003 1.15-.003h9.836c.558 0 .98.36 1.024.867a.963.963 0 0 1-.962 1.06c-.884.01-1.768.004-2.653.004l-2.849.003zM15.04 10.608c.677 0 1.355-.006 2.032 0 .69.008 1.144.525 1.033 1.162-.083.473-.488.785-1.053.792-.604.008-1.208 0-1.811 0h-2.208c-.335 0-.646-.074-.868-.351-.252-.315-.317-.663-.145-1.033.184-.398.523-.565.945-.571.69-.004 1.383 0 2.075 0zM15.037 5.558h2.079c.584.003.996.396 1.004.95.009.54-.42.976-.985.976-1.415.006-2.83.006-4.245 0a.959.959 0 0 1-.844-1.422.986.986 0 0 1 .48-.438.996.996 0 0 1 .41-.069c.7.003 1.401.004 2.101.003z"
    })]
  }));
};

ExpensesIcon.defaultProps = {
  width: "24",
  height: "25",
  viewBox: "0 0 24 25",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var OfficeIcon = function OfficeIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("path", {
      d: "M12.499 24.999H1.292c-.44 0-.811-.13-1.069-.504-.25-.363-.299-.746-.101-1.147.203-.41.533-.645.994-.664.32-.014.642-.01.963-.004.148.003.213-.05.203-.202-.006-.076 0-.152 0-.23 0-6.981-.003-13.962-.01-20.943C2.272.613 2.742 0 3.571 0c5.95.005 11.9.006 17.852.004.837 0 1.319.492 1.319 1.332v20.831c.004.076.004.153 0 .229-.027.219.06.3.283.288.274-.017.55-.009.825 0 .63.014 1.134.507 1.15 1.111a1.166 1.166 0 0 1-1.085 1.2c-.106.008-.213.005-.32.005L12.499 25zM4.597 12.515v9.853c0 .31 0 .31.319.31h1.581c.317 0 .318 0 .318-.31v-5.36a1.129 1.129 0 0 1 .99-1.111c.175-.02.35-.03.526-.03 2.414-.003 4.827-.003 7.24 0 .436 0 .872-.007 1.307 0 .86.013 1.324.488 1.324 1.346 0 1.724.003 3.452-.004 5.178 0 .215.054.299.282.292.518-.015 1.038-.005 1.558-.005.355 0 .355 0 .355-.346V2.696c0-.352 0-.352-.355-.352h-15.1c-.341 0-.342 0-.342.34l.001 9.83zm7.89 10.163c1.038 0 2.079-.004 3.115.005.203 0 .264-.07.263-.266a380.502 380.502 0 0 1 0-3.94c0-.214-.076-.274-.281-.274-2.063.006-4.125.006-6.187 0-.193 0-.27.051-.269.258.008 1.322.008 2.643 0 3.963 0 .203.068.26.266.259 1.035-.009 2.064-.005 3.094-.005h-.001z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("path", {
      d: "M18.204 6.311c-.014.227.029.503-.035.775a1.159 1.159 0 0 1-1.19.906 1.139 1.139 0 0 1-1.09-.995 6.16 6.16 0 0 1-.005-1.416c.067-.623.615-1.079 1.195-1.039a1.188 1.188 0 0 1 1.124 1.172c.005.184 0 .367 0 .597zM18.203 11.942c0 .176.003.352 0 .527-.01.646-.498 1.166-1.122 1.198a1.162 1.162 0 0 1-1.201-1.06 6.363 6.363 0 0 1 .005-1.369 1.153 1.153 0 0 1 1.206-1.021 1.174 1.174 0 0 1 1.11 1.132c.01.198 0 .397 0 .595l.002-.002zM9.134 6.287c0 .19.005.381 0 .572a1.166 1.166 0 0 1-1.173 1.134 1.15 1.15 0 0 1-1.143-1.155c0-.382-.003-.763 0-1.145A1.166 1.166 0 0 1 7.97 4.54c.6-.004 1.145.523 1.163 1.129.007.206.001.412.001.618zM6.817 11.942v-.573a1.152 1.152 0 0 1 1.96-.827c.22.212.347.502.355.807.009.396.01.793 0 1.19-.014.606-.564 1.133-1.166 1.13a1.167 1.167 0 0 1-1.152-1.155l.003-.572zM11.353 6.248v-.526c0-.65.485-1.158 1.12-1.18.601-.022 1.16.48 1.191 1.1.021.418.02.84 0 1.258-.028.635-.573 1.116-1.212 1.093a1.15 1.15 0 0 1-1.1-1.15v-.595zM11.352 11.92v-.548a1.148 1.148 0 0 1 1.116-1.158 1.163 1.163 0 0 1 1.197 1.11c.015.406.015.812 0 1.213-.022.63-.58 1.154-1.185 1.13a1.16 1.16 0 0 1-1.128-1.174v-.572z"
    })]
  }));
};

OfficeIcon.defaultProps = {
  width: "25",
  height: "25",
  viewBox: "0 0 25 25",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var PlaneIcon = function PlaneIcon(props) {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("path", {
      d: "M25 2.056v.522a.398.398 0 0 0-.007.048c-.01.234-.035.466-.075.697a5.3 5.3 0 0 1-1.19 2.61c-.524.62-1.078 1.211-1.624 1.81l-.867.949a.371.371 0 0 0-.107.28l.008.211c.006.228 0 .455-.008.683-.005.103.016.119.118.119.116-.003.232.003.346.02.395.068.703.274.95.585.413.52.468 1.142.151 1.704a2.872 2.872 0 0 1-.41.52l-1.087 1.177a.182.182 0 0 0-.057.144c.004.04.02.061.062.06.097 0 .194.008.29.025.46.068.844.267 1.116.656.187.267.31.556.319.886.009.381-.13.714-.37 1.002-.35.417-.716.82-1.102 1.203a.864.864 0 0 0-.278.673c.009.258.011.52.012.782 0 .494-.005.988 0 1.483.007.297-.088.589-.27.825-.465.63-.921 1.268-1.383 1.903-.123.17-.237.35-.377.508a.766.766 0 0 1-1.28-.185 1.28 1.28 0 0 1-.076-.216l-.443-1.813a9545.223 9545.223 0 0 0-1.916-7.833c-.02-.079-.02-.079-.079-.025l-.72.673a2411.12 2411.12 0 0 0-4.616 4.35.37.37 0 0 0-.13.321c.024.251.045.503.068.753.034.392.07.782.108 1.173.034.363.073.725.103 1.087.033.387-.062.736-.357 1.002-.318.285-.615.59-.91.897-.188.194-.377.381-.654.44H8.01a1.11 1.11 0 0 1-.207-.08.987.987 0 0 1-.39-.43l-.776-1.5c-.192-.372-.38-.744-.577-1.113-.108-.204-.213-.235-.416-.13a5.97 5.97 0 0 1-1.883.619c-.233.036-.466.077-.703.043-.238-.033-.439-.145-.552-.372a.955.955 0 0 1-.095-.524c.03-.286.073-.57.13-.851.102-.555.287-1.09.548-1.59.037-.068.033-.076-.041-.11l-2.075-.939c-.171-.078-.349-.144-.508-.246-.244-.155-.398-.366-.393-.668.005-.237.11-.431.277-.598.396-.393.79-.789 1.184-1.185a.787.787 0 0 1 .624-.251c.268.014.537.025.805.037l.614.029 1.17.058c.263.013.525.023.787.043a.195.195 0 0 0 .178-.07l.821-.905 2.059-2.264c.487-.534.977-1.064 1.466-1.595.07-.076.07-.078-.028-.1a5800.132 5800.132 0 0 0-8.372-2.005c-.353-.084-.71-.155-1.06-.259a.84.84 0 0 1-.458-.3.892.892 0 0 1-.139-.35v-.223a.83.83 0 0 1 .155-.347c.089-.107.192-.201.306-.28.707-.498 1.409-1.004 2.105-1.516.215-.162.478-.249.747-.247.87.003 1.742 0 2.613.004a.466.466 0 0 0 .359-.15c.391-.404.789-.802 1.192-1.194.378-.369.828-.549 1.356-.469.652.099 1.087.473 1.303 1.097.067.21.091.43.072.65-.004.057.024.073.073.07a.234.234 0 0 0 .163-.079c.42-.422.84-.846 1.264-1.264.383-.376.84-.547 1.378-.477a1.582 1.582 0 0 1 1.345 1.735c-.004.051.014.074.067.082.216.038.439.03.651-.025.318-.089.562-.288.77-.531.415-.486.845-.961 1.302-1.408A11.333 11.333 0 0 1 19.318.945C20.16.44 21.053.08 22.045.014c.471-.033.94-.012 1.397.119.724.207 1.224.652 1.452 1.382.053.177.088.358.106.541zM5.495 17.292l.04-.018c.237-.121.481-.23.73-.326.277-.103.554-.21.846-.262.328-.059.595.126.656.446.03.158 0 .31-.03.465a6.1 6.1 0 0 1-.872 2.162c-.006.01-.018.018-.009.036a2.564 2.564 0 0 0 .602-.385c.256-.22.49-.466.732-.697.743-.718 1.49-1.43 2.243-2.137a1904.114 1904.114 0 0 0 5.987-5.593c.724-.674 1.448-1.347 2.173-2.017.626-.578 1.258-1.15 1.888-1.724a.489.489 0 0 0 .164-.44c-.014-.13-.03-.26-.045-.389a1.784 1.784 0 0 0-.624-1.19c-.375-.32-.816-.507-1.293-.62a6.609 6.609 0 0 0-1.012-.135.168.168 0 0 0-.121.041 1.01 1.01 0 0 0-.091.085c-.505.53-1.015 1.055-1.515 1.59a3160.417 3160.417 0 0 0-5.18 5.548 858.49 858.49 0 0 1-3.3 3.535 33.01 33.01 0 0 1-1.512 1.525c-.167.153-.32.32-.459.5h.002zm14.165-2.063V9.617c0-.022.012-.052-.01-.064-.023-.012-.035.017-.049.03-.93.872-1.862 1.747-2.803 2.61a.371.371 0 0 0-.118.405c.1.385.193.77.287 1.156l1.249 5.07.733 2.969c.005.021 0 .052.025.059.026.007.034-.025.047-.042.16-.198.314-.4.478-.596a.69.69 0 0 0 .164-.465 1611.33 1611.33 0 0 1-.005-5.52h.002zM2.599 6.704l.81.196 5.836 1.41c.768.186 1.535.374 2.301.564a.378.378 0 0 0 .4-.124 563.169 563.169 0 0 1 2.412-2.581c.022-.023.065-.049.052-.077-.013-.028-.06-.011-.092-.011H3.574a.255.255 0 0 0-.173.054c-.084.064-.173.121-.26.183-.179.124-.355.25-.544.386h.002zm17.338-4.027c-.288-.007-.43.075-.565.269a.662.662 0 0 1-.096.103c-.14.129-.264.274-.414.39-.012.01-.032.02-.024.039.007.02.028.012.044.013.027.003.052.003.08.008.214.04.423.1.624.181.448.154.86.394 1.216.707.452.41.735.92.888 1.507.02.072.021.072.073.022.217-.213.422-.438.626-.664.169-.185.184-.128.125-.426-.1-.503-.303-.957-.658-1.335-.519-.551-1.18-.778-1.92-.814zm3.376 1.022a.035.035 0 0 0 .02-.032c.069-.29.107-.585.113-.883a3.687 3.687 0 0 0-.051-.809c-.052-.245-.165-.355-.414-.398a3.17 3.17 0 0 0-.748-.027c-.322.02-.64.083-.946.185-.017.005-.038.005-.047.035.965.346 1.638 1.01 2.073 1.928V3.7zM6.385 18.14l-.084.037c-.354.172-.7.362-1.034.57a2.26 2.26 0 0 0-.483.396c-.35.377-.546.832-.673 1.324-.014.058.022.034.044.027.3-.076.582-.21.832-.39.63-.462 1.066-1.071 1.345-1.798a.692.692 0 0 0 .053-.166zm2.26 4.197a672.626 672.626 0 0 0-.202-2.19c0-.026 0-.063-.018-.074-.018-.011-.044.023-.062.04-.281.262-.58.5-.928.668-.056.027-.06.051-.033.103.134.25.264.502.395.753.18.345.36.691.54 1.04.027.052.046.052.083.012.064-.07.125-.143.182-.22a.167.167 0 0 0 .043-.132zm-6.001-5.939c-.184-.013-.323.075-.444.199-.047.047-.046.051.014.08l1.728.786c.048.022.069.011.09-.033.078-.16.17-.314.272-.459.11-.155.227-.3.35-.443.011-.011.03-.023.023-.04-.007-.018-.029-.01-.045-.012-.089-.004-.178-.01-.266-.011-.281-.005-.563-.008-.844-.015a13.444 13.444 0 0 1-.879-.052zm5.34-11.455a.19.19 0 0 0 .135-.047c.197-.17.357-.373.533-.562a.158.158 0 0 0 .01-.015c.008-.011.012-.023 0-.034a.026.026 0 0 0-.038 0 .758.758 0 0 0-.036.034c-.128.13-.255.258-.382.39-.072.073-.142.148-.223.234zm12.853 11.44l.548-.545c.018-.018.032-.043.007-.065-.024-.022-.047 0-.063.017-.143.142-.282.29-.437.42a.167.167 0 0 0-.056.172zm-8.64-11.46l.012.02a.149.149 0 0 0 .137-.048 2.13 2.13 0 0 1 .08-.086l.438-.466c.015-.016.043-.036.025-.056-.018-.02-.043.006-.062.02a166.03 166.03 0 0 1-.472.468c-.05.05-.104.098-.157.147h-.001zm8.623 7.222h.018a278.478 278.478 0 0 0 .555-.557.038.038 0 0 0 .002-.033.038.038 0 0 0-.01-.014c-.022-.02-.04 0-.052.013-.145.138-.29.276-.433.416a.285.285 0 0 0-.08.175z"
    })
  }));
};

PlaneIcon.defaultProps = {
  width: "25",
  height: "25",
  viewBox: "0 0 25 25",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var ReviewIcon = function ReviewIcon(props) {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("path", {
      d: "M24.994 1.67c.04.405-.146.744-.395 1.06l-3.535 4.472-9.527 12.046c-.713.903-1.423 1.807-2.13 2.714-.632.808-1.942.821-2.577.017-2.14-2.706-4.278-5.414-6.415-8.123-.397-.505-.552-1.057-.274-1.668.297-.65.821-1.01 1.526-1.058.525-.037.957.202 1.28.608 1.67 2.105 3.335 4.211 4.998 6.32.162.204.163.204.326 0l13.34-16.862c.152-.193.3-.39.456-.579.434-.525.98-.723 1.65-.563.614.145 1.343.832 1.277 1.616z"
    })
  }));
};

ReviewIcon.defaultProps = {
  width: "25",
  height: "23",
  viewBox: "0 0 25 23",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var YourDetailsIcon = function YourDetailsIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("path", {
      d: "M22.102 12.516v8.722c.004.881-.31 1.734-.885 2.402a3.712 3.712 0 0 1-2.026 1.252 3.56 3.56 0 0 1-.7.096c-.437.018-.875.01-1.313.01H5.066c-.433 0-.865.006-1.3-.004-.723-.016-1.402-.188-2.013-.586a4.005 4.005 0 0 1-1.046-1.014 3.589 3.589 0 0 1-.67-1.646 3.725 3.725 0 0 1-.035-.509c-.003-5.782-.003-11.565 0-17.347 0-.814.203-1.574.67-2.251A3.836 3.836 0 0 1 2.266.331 3.56 3.56 0 0 1 3.508.02a6.99 6.99 0 0 1 .506-.02h12.912c.424 0 .847-.004 1.273.003.814.015 1.582.212 2.264.679.682.466 1.139 1.095 1.411 1.867.16.45.24.923.237 1.4-.004 2.856-.004 5.713 0 8.57l-.01-.004zm-20.085-.02v8.74c-.005.326.087.646.262.92.343.53.831.815 1.463.82.802.007 1.605.003 2.407.003H18.31c.072 0 .143-.003.213-.011.633-.087 1.087-.418 1.364-.992.157-.326.2-.68.2-1.035.003-5.693.003-11.385 0-17.078a1.939 1.939 0 0 0-.036-.407c-.13-.611-.473-1.05-1.054-1.292a1.951 1.951 0 0 0-.753-.13H3.896a2.55 2.55 0 0 0-.516.045 1.713 1.713 0 0 0-1.364 1.669v1.399l.001 7.348z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("path", {
      d: "M13.42 13.524h-3.05c-.332 0-.63-.097-.846-.363-.24-.295-.317-.635-.183-.996a.99.99 0 0 1 .784-.662 2.32 2.32 0 0 1 .437-.034h3.323c.61 0 1.225 0 1.838.003.22 0 .44.023.629.144.338.216.544.517.532.934-.014.498-.47.952-.964.967-.948.024-1.897 0-2.5.007zM13.08 18.792h-2.767c-.544 0-.949-.375-1.025-.914-.074-.53.38-1.069.894-1.11.161-.013.32-.022.482-.022h5.043c.17-.003.338.022.5.074.402.137.707.593.678 1.018a1.03 1.03 0 0 1-.91.944c-.275.027-.55.011-.825.012h-2.07v-.002zM13.076 8.253h-2.698c-.261 0-.503-.061-.712-.229a1.013 1.013 0 0 1 .496-1.797c.121-.016.243-.024.365-.023h5.235c.264 0 .517.056.723.231.653.555.462 1.448-.272 1.739a1.133 1.133 0 0 1-.418.078h-2.719zM6.4 8.253a1.3 1.3 0 0 1-.57-.096c-.51-.218-.872-.978-.366-1.573.141-.168.333-.286.546-.337.302-.076.62-.065.916.034.472.152.88.752.586 1.37-.162.341-.429.53-.797.59a2.05 2.05 0 0 1-.314.012zM6.47 18.793a1.59 1.59 0 0 1-.617-.099c-.337-.134-.556-.373-.614-.737-.062-.385.05-.712.36-.96.269-.218.58-.282.916-.255.244.012.48.093.678.233.382.286.57.792.265 1.313-.193.33-.489.48-.86.504-.043.003-.086 0-.129 0zM6.51 13.525c-.254-.003-.475-.024-.685-.114a.967.967 0 0 1-.51-1.316c.15-.328.405-.509.747-.587.316-.072.646-.044.945.078.347.138.505.423.58.764.094.422-.203 1.054-.826 1.153a1.485 1.485 0 0 1-.25.022z"
    })]
  }));
};

YourDetailsIcon.defaultProps = {
  width: "23",
  height: "25",
  viewBox: "0 0 23 25",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};





const IconContainer = styled_components__WEBPACK_IMPORTED_MODULE_6___default().div.withConfig({
  displayName: "SidebarProgress__IconContainer",
  componentId: "sc-1aw4uqo-0"
})(["background:", ";border:2px solid ", ";border-radius:100px;min-width:3rem;width:3rem;height:3rem;display:inline-flex;align-items:center;justify-content:center;", " transition:box-shadow 0.3s;position:relative;& > svg{fill:", ";width:1.5rem;height:1.75rem;}&:hover{", "}"], p => p.active ? p.theme.colors.backgroundGrey : p.complete ? p.theme.colors.blue : p.theme.colors.backgroundGrey, p => p.active || p.complete ? p.theme.colors.blue : p.theme.colors.placeholderGrey, p => p.onClick && "cursor: pointer;", p => p.active ? p.theme.colors.blue : p.complete ? p.theme.colors.white : p.theme.colors.placeholderGrey, p => p.onClick && `
        background-color: ${p => p.theme.colors.secondaryBlue};
        box-shadow: ${p => `0 5px 5px 0 ${p.theme.colors.blue}40`};
      `);
const MenuItemContainer = styled_components__WEBPACK_IMPORTED_MODULE_6___default().div.withConfig({
  displayName: "SidebarProgress__MenuItemContainer",
  componentId: "sc-1aw4uqo-1"
})(["max-width:12rem;display:flex;align-items:center;margin-bottom:3rem;", " ", ""], p => !p.disabled && "cursor: pointer;", p => p.showLine && (0,styled_components__WEBPACK_IMPORTED_MODULE_6__.css)(["", ":after{content:\"\";width:0;height:90%;position:absolute;border:1px solid ", ";bottom:112.5%;}"], IconContainer, p => p.theme.colors.secondaryBlue));
const Menu = styled_components__WEBPACK_IMPORTED_MODULE_6___default().div.withConfig({
  displayName: "SidebarProgress__Menu",
  componentId: "sc-1aw4uqo-2"
})(["border-right:2px solid ", ";padding:1rem 2rem;"], p => p.theme.colors.secondaryBlue);
const TextContainer = styled_components__WEBPACK_IMPORTED_MODULE_6___default().div.withConfig({
  displayName: "SidebarProgress__TextContainer",
  componentId: "sc-1aw4uqo-3"
})(["width:60%;margin-right:1rem;"]);

const MenuItem = ({
  page
}) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(MenuItemContainer, {
  disabled: page.disabled,
  showLine: page.href !== "details",
  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(TextContainer, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP, {
      size: "subtitleBold",
      color: page.active ? "black" : page.complete ? "secondaryBlue" : "placeholderGrey",
      children: page.title
    })
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(IconContainer, {
    complete: page.complete,
    active: page.active,
    children: page.icon
  })]
});

const SidebarProgress = () => {
  const {
    selectedMeasurement
  } = (0,_contexts_measurements__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)();
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
  const path = router.pathname.split("/")[router.pathname.split("/").length - 1];

  const isActive = href => path === href;

  const isComplete = page => (0,_utils_applicationMap__WEBPACK_IMPORTED_MODULE_8__/* .checkPageIsComplete */ .es)({
    page,
    measurement: selectedMeasurement
  });

  const pages = [{
    title: "Your Details",
    icon: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(YourDetailsIcon, {}),
    complete: isComplete("details"),
    active: isActive("details"),
    href: "details"
  }, {
    title: "Your Office",
    icon: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(OfficeIcon, {}),
    complete: isComplete("offices"),
    active: isActive("offices"),
    href: "offices",
    disabled: !isComplete("details")
  }, {
    title: "Company Vehicles",
    icon: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(CarIcon, {}),
    complete: isComplete("vehicles"),
    href: "vehicles",
    active: isActive("vehicles"),
    disabled: !isComplete("offices")
  }, {
    title: "Business Travel",
    icon: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(PlaneIcon, {}),
    complete: isComplete("business-travel"),
    href: "business-travel",
    active: isActive("business-travel"),
    disabled: !isComplete("vehicles")
  }, {
    title: "Expenses",
    icon: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(ExpensesIcon, {}),
    href: "expenses",
    active: isActive("expenses"),
    complete: isComplete("expenses"),
    disabled: !isComplete("business-travel")
  }, {
    title: "Review",
    icon: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(ReviewIcon, {}),
    href: "review",
    active: isActive("review"),
    disabled: !(isComplete("expenses") && isComplete("business-travel") && isComplete("vehicles") && isComplete("offices") && isComplete("details")),
    complete: isComplete("expenses") && isComplete("business-travel") && isComplete("vehicles") && isComplete("offices") && isComplete("details")
  }];

  if (!(0,_utils_applicationMap__WEBPACK_IMPORTED_MODULE_8__/* .checkPreviousPageIsComplete */ .$X)({
    path,
    measurement: selectedMeasurement
  })) {
    const firstIncompletePage = (0,_utils_applicationMap__WEBPACK_IMPORTED_MODULE_8__/* .getCurrentPage */ .FZ)({
      measurement
    });
    router.push(`/measurements/[id]/${firstIncompletePage}`, `/measurements/${selectedMeasurement.id}/${firstIncompletePage}`);
  }

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(Menu, {
    children: [!(0,_utils_applicationMap__WEBPACK_IMPORTED_MODULE_8__/* .checkPreviousPageIsComplete */ .$X)({
      path,
      measurement: selectedMeasurement
    }) && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_common_LoadingLarge__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
      loading: true,
      text: "Getting last page"
    }), pages.map(page => page.disabled ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(MenuItem, {
      page
    }, page.href) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
      href: `/measurements/[id]/${page.href}`,
      as: `/measurements/${selectedMeasurement.id}/${page.href}`,
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("div", {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(MenuItem, {
          page
        })
      })
    }, page.href))]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SidebarProgress);

/***/ })

};
;