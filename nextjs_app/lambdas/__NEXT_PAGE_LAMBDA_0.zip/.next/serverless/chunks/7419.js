"use strict";
exports.id = 7419;
exports.ids = [7419];
exports.modules = {

/***/ 94789:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _hookform_error_message__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(83218);
/* harmony import */ var _hookform_error_message__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_hookform_error_message__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(45641);
/* harmony import */ var react_select__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(61929);
/* harmony import */ var react_select__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_select__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_select_async__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(23618);
/* harmony import */ var react_select_async__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_select_async__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(91073);
/* harmony import */ var _utils_debounce__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(97985);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _Error__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(26428);
/* harmony import */ var _Label__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(54251);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_2__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
const _excluded = ["children", "src"],
      _excluded2 = ["autoComplete"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }







var DownArrow = function DownArrow(props) {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("path", {
      d: "M225.923 354.706c-8.098 0-16.195-3.092-22.369-9.263L9.27 151.157c-12.359-12.359-12.359-32.397 0-44.751 12.354-12.354 32.388-12.354 44.748 0l171.905 171.915 171.906-171.909c12.359-12.354 32.391-12.354 44.744 0 12.365 12.354 12.365 32.392 0 44.751L248.292 345.449c-6.177 6.172-14.274 9.257-22.369 9.257z"
    })
  }));
};

DownArrow.defaultProps = {
  xmlns: "http://www.w3.org/2000/svg",
  width: "451.847",
  height: "451.847",
  viewBox: "0 0 451.847 451.847"
};







const Container = styled_components__WEBPACK_IMPORTED_MODULE_7___default().div.withConfig({
  displayName: "InputAsyncDropdown__Container",
  componentId: "sc-1rm739u-0"
})(["width:", ";"], p => p.width || "100%");
const StyledDownArrow = styled_components__WEBPACK_IMPORTED_MODULE_7___default()(DownArrow).withConfig({
  displayName: "InputAsyncDropdown__StyledDownArrow",
  componentId: "sc-1rm739u-1"
})(["width:1rem;height:1rem;fill:", ";transition:transform 0.3s ease-out;cursor:pointer;display:none;"], p => p.theme.colors.blue);

const DropdownIndicator = _ref => {
  let {
    children,
    src
  } = _ref,
      props = _objectWithoutProperties(_ref, _excluded);

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(react_select__WEBPACK_IMPORTED_MODULE_3__.components.DropdownIndicator, _objectSpread(_objectSpread({}, props), {}, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(StyledDownArrow, {})
  }));
};

const Input = _ref2 => {
  let {
    autoComplete
  } = _ref2,
      props = _objectWithoutProperties(_ref2, _excluded2);

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(react_select__WEBPACK_IMPORTED_MODULE_3__.components.Input, _objectSpread(_objectSpread({}, props), {}, {
    autoComplete: "no"
  }));
};

const InputAsyncDropdown = ({
  id,
  label,
  labelColor,
  color,
  borderColor,
  ariaLabel,
  disabled,
  value,
  defaultValue,
  width = "14rem",
  complete = false,
  error = false,
  placeholder = "Select",
  loadOptions
}) => {
  const {
    0: defaultOptions,
    1: setDefaultOptions
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
  const {
    0: searched,
    1: setSearched
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
  const debouncedLoadOptions = react__WEBPACK_IMPORTED_MODULE_1___default().useCallback((0,_utils_debounce__WEBPACK_IMPORTED_MODULE_10__/* .debounce */ .D)(async (input, callback) => {
    setSearched(true);
    const options = await loadOptions(input);
    callback(options);
    setDefaultOptions(options);
  }, 1000), []);

  if (error) {
    borderColor = _theme__WEBPACK_IMPORTED_MODULE_6__/* ["default"].colors.red */ .ZP.colors.red;
  } else if (complete) {
    borderColor = _theme__WEBPACK_IMPORTED_MODULE_6__/* ["default"].colors.green */ .ZP.colors.green;
  }

  const {
    control,
    formState: {
      touchedFields,
      isValid,
      errors
    }
  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_2__.useFormContext)();

  if (errors[id]) {
    borderColor = _theme__WEBPACK_IMPORTED_MODULE_6__/* ["default"].colors.red */ .ZP.colors.red;
  }

  if (touchedFields[id] && isValid && !errors[id]) {
    borderColor = _theme__WEBPACK_IMPORTED_MODULE_6__/* ["default"].colors.green */ .ZP.colors.green;
  }

  const customStyle = {
    indicatorSeparator: base => _objectSpread(_objectSpread({}, base), {}, {
      display: "none"
    }),
    control: base => _objectSpread(_objectSpread({}, base), {}, {
      borderColor: borderColor ? borderColor : _theme__WEBPACK_IMPORTED_MODULE_6__/* ["default"].colors["default"] */ .ZP.colors["default"],
      backgroundColor: color ? color : errors[id] && borderColor ? _theme__WEBPACK_IMPORTED_MODULE_6__/* ["default"].colors.error */ .ZP.colors.error : _theme__WEBPACK_IMPORTED_MODULE_6__/* ["default"].colors.secondaryBlue */ .ZP.colors.secondaryBlue,
      border: !disabled && borderColor ? `1px solid ${borderColor}` : "none",
      borderBottom: disabled && `1px solid ${_theme__WEBPACK_IMPORTED_MODULE_6__/* ["default"].colors.black */ .ZP.colors.black}`,
      borderRadius: "4px",
      boxShadow: "none",
      height: "2.25rem",
      minHeight: "2.25rem",
      marginBottom: "1rem",
      ":active": {
        borderColor: _theme__WEBPACK_IMPORTED_MODULE_6__/* ["default"].colors["default"] */ .ZP.colors["default"]
      }
    }),
    menu: base => _objectSpread(_objectSpread({}, base), {}, {
      boxShadow: `0 0 0 1px ${_theme__WEBPACK_IMPORTED_MODULE_6__/* ["default"].colors.secondaryBlue */ .ZP.colors.secondaryBlue},0 2px 4px ${_theme__WEBPACK_IMPORTED_MODULE_6__/* ["default"].colors.secondaryBlue */ .ZP.colors.secondaryBlue}`,
      borderColor: _theme__WEBPACK_IMPORTED_MODULE_6__/* ["default"].colors.active */ .ZP.colors.active,
      backgroundColor: _theme__WEBPACK_IMPORTED_MODULE_6__/* ["default"].colors.white */ .ZP.colors.white,
      borderStyle: "solid",
      borderWidth: "1px",
      borderRadius: "4px",
      padding: "10px 0",
      border: "none",
      marginTop: "12px"
    }),
    option: base => _objectSpread(_objectSpread({}, base), {}, {
      color: _theme__WEBPACK_IMPORTED_MODULE_6__/* ["default"].colors.black */ .ZP.colors.black,
      backgroundColor: _theme__WEBPACK_IMPORTED_MODULE_6__/* ["default"].colors.transparent */ .ZP.colors.transparent,
      ":hover": {
        backgroundColor: _theme__WEBPACK_IMPORTED_MODULE_6__/* ["default"].colors.admin */ .ZP.colors.admin,
        color: _theme__WEBPACK_IMPORTED_MODULE_6__/* ["default"].colors.white */ .ZP.colors.white,
        cursor: "pointer"
      }
    }),
    indicatorContainer: base => _objectSpread(_objectSpread({}, base), {}, {
      paddingRight: "0.75rem"
    }),
    loadingIndicator: base => _objectSpread(_objectSpread({}, base), {}, {
      span: {
        width: "0.25rem",
        height: "0.25rem",
        ":not(:first-child)": {
          marginLeft: "0.25rem"
        }
      }
    }),
    placeholder: base => _objectSpread(_objectSpread({}, base), {}, {
      fontSize: "12px",
      fontWeight: "lighter",
      color: _theme__WEBPACK_IMPORTED_MODULE_6__/* ["default"].colors.placeholderGrey */ .ZP.colors.placeholderGrey
    })
  };
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(styled_components__WEBPACK_IMPORTED_MODULE_7__.ThemeProvider, {
    theme: _theme__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .ZP,
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(Container, {
      width: width,
      children: [label && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_Label__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
        color: labelColor,
        htmlFor: id,
        children: label
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.Controller, {
        render: ({
          field
        }, ...rest) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx((react_select_async__WEBPACK_IMPORTED_MODULE_4___default()), _objectSpread(_objectSpread(_objectSpread(_objectSpread({
          instanceId: id,
          value: value,
          placeholder: placeholder,
          styles: customStyle,
          cacheOptions: true,
          id: id,
          openMenuOnFocus: searched,
          openMenuOnClick: searched,
          defaultOptions: defaultOptions,
          loadOptions: debouncedLoadOptions,
          defaultValue: defaultValue ? defaultValue : null,
          isDisabled: disabled,
          components: {
            DropdownIndicator,
            Input
          }
        }, ariaLabel ? {
          "aria-label": ariaLabel
        } : {}), {}, {
          theme: selectTheme => _objectSpread(_objectSpread({}, selectTheme), {}, {
            colors: _objectSpread(_objectSpread({}, selectTheme.colors), {}, {
              primary: _theme__WEBPACK_IMPORTED_MODULE_6__/* ["default"].colors.active */ .ZP.colors.active
            })
          })
        }, field), rest), {}, {
          "data-cy": name
        })),
        name: id,
        control: control
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_hookform_error_message__WEBPACK_IMPORTED_MODULE_0__.ErrorMessage, {
        errors: errors,
        name: id,
        as: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_Error__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {})
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (InputAsyncDropdown);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 77539:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61908);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(45641);
/* harmony import */ var _button_Button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(59067);
/* harmony import */ var _common_Divider__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6459);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(87491);
/* harmony import */ var _form_Checkbox_V2__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(81047);
/* harmony import */ var _form_Input__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(18183);
/* harmony import */ var _form_InputAsyncDropdown__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(94789);
/* harmony import */ var _form_InputAsyncDropdown_V2__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(76135);
/* harmony import */ var _form_InputDropdown__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(51894);
/* harmony import */ var _common_ButtonsContainer__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(30495);
/* harmony import */ var _common_Form__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(79397);
/* harmony import */ var _common_FormGroup__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(13586);
/* harmony import */ var _MeasurementArraySection__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(98782);
/* harmony import */ var _MeasurementSection__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(28067);
/* harmony import */ var _contexts_auth__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(58368);
/* harmony import */ var _contexts_measurements__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(85238);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(11098);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var uuidv4__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(63398);
/* harmony import */ var uuidv4__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(uuidv4__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(75609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var _data_collection_utils__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(63033);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__, react_hook_form__WEBPACK_IMPORTED_MODULE_3__, _form_Checkbox_V2__WEBPACK_IMPORTED_MODULE_7__, _form_Input__WEBPACK_IMPORTED_MODULE_8__, _form_InputAsyncDropdown__WEBPACK_IMPORTED_MODULE_9__, _form_InputAsyncDropdown_V2__WEBPACK_IMPORTED_MODULE_10__, _form_InputDropdown__WEBPACK_IMPORTED_MODULE_11__]);
([_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__, react_hook_form__WEBPACK_IMPORTED_MODULE_3__, _form_Checkbox_V2__WEBPACK_IMPORTED_MODULE_7__, _form_Input__WEBPACK_IMPORTED_MODULE_8__, _form_InputAsyncDropdown__WEBPACK_IMPORTED_MODULE_9__, _form_InputAsyncDropdown_V2__WEBPACK_IMPORTED_MODULE_10__, _form_InputDropdown__WEBPACK_IMPORTED_MODULE_11__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




























const schema = yup__WEBPACK_IMPORTED_MODULE_22__.object().shape({
  business_travel: yup__WEBPACK_IMPORTED_MODULE_22__.array().of(yup__WEBPACK_IMPORTED_MODULE_22__.object().shape({
    departure: yup__WEBPACK_IMPORTED_MODULE_22__.object().shape({
      label: yup__WEBPACK_IMPORTED_MODULE_22__.string(),
      value: yup__WEBPACK_IMPORTED_MODULE_22__.object().shape({
        name: yup__WEBPACK_IMPORTED_MODULE_22__.string().required("Departure city is required"),
        place_id: yup__WEBPACK_IMPORTED_MODULE_22__.string().required("Departure city is required")
      })
    }).required("Departure city is required"),
    destination: yup__WEBPACK_IMPORTED_MODULE_22__.object().shape({
      label: yup__WEBPACK_IMPORTED_MODULE_22__.string(),
      value: yup__WEBPACK_IMPORTED_MODULE_22__.object().shape({
        name: yup__WEBPACK_IMPORTED_MODULE_22__.string().required("Destination city is required"),
        place_id: yup__WEBPACK_IMPORTED_MODULE_22__.string().required("Destination city is required")
      })
    }).required("Destination city is required"),
    passengers: yup__WEBPACK_IMPORTED_MODULE_22__.number().required("Number of passengers is required").min(1, "There must be a minimum 1 passenger per trip").typeError("Please enter the number of passengers")
  }))
});
const RoundTripContainer = styled_components__WEBPACK_IMPORTED_MODULE_20___default().div.withConfig({
  displayName: "BusinessTravel__RoundTripContainer",
  componentId: "sc-10f38u-0"
})(["margin-left:1rem;"]);

const BusinessTravel = ({
  sectionDisabled
}) => {
  const {
    user
  } = (0,_contexts_auth__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z)();
  const {
    selectedMeasurement,
    setSelectedMeasurement,
    updateLastCompletedStep
  } = (0,_contexts_measurements__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z)();
  const {
    0: deleteLoading,
    1: setDeleteLoading
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)();
  const id = "business_travel";
  const methods = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_3__.useForm)({
    resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__.yupResolver)(schema),
    shouldUnregister: false,
    defaultValues: {
      business_travel: selectedMeasurement.business_travel.map(businessTravel => {
        var _businessTravel$round;

        return {
          id: businessTravel.id,
          departure: {
            label: businessTravel.departure,
            value: {
              place_id: businessTravel.departure_place_id,
              name: businessTravel.departure
            }
          },
          destination: {
            label: businessTravel.destination,
            value: {
              place_id: businessTravel.destination_place_id,
              name: businessTravel.destination
            }
          },
          passengers: businessTravel.passengers,
          round_trip: (_businessTravel$round = businessTravel.round_trip) === null || _businessTravel$round === void 0 ? void 0 : _businessTravel$round.toString(),
          mode: _data_collection_utils__WEBPACK_IMPORTED_MODULE_23__/* .BUSINESS_TRAVEL_MODES_OF_TRANSPORT.find */ .Ho.find(mode => mode.value === businessTravel.mode) || _data_collection_utils__WEBPACK_IMPORTED_MODULE_23__/* .BUSINESS_TRAVEL_MODES_OF_TRANSPORT[0] */ .Ho[0]
        };
      })
    }
  });
  const {
    control
  } = methods;
  const {
    fields,
    append,
    remove
  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_3__.useFieldArray)({
    control,
    name: "business_travel"
  });

  const deleteBusinessTravel = async (id, index) => {
    setDeleteLoading(true);

    try {
      await axios__WEBPACK_IMPORTED_MODULE_1___default()["delete"](`/api/organisations/${user.organisation_id}/measurements/${selectedMeasurement.id}/business-travel/${id}`);
      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`/api/organisations/${user.organisation_id}/measurements/${selectedMeasurement.id}`);
      setSelectedMeasurement(data);
      remove(index);
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_19__/* .logError */ .H)(error);
    }

    setDeleteLoading(false);
  };

  const upsertBusinessTravel = async ({
    business_travel
  }, cb) => {
    try {
      const newBusinessTravel = [];
      const existingBusinessTravel = [];
      business_travel.filter(({
        departure,
        destination,
        passengers
      }) => !!departure && !!destination && !!passengers).forEach(businessTravel => {
        if (selectedMeasurement.business_travel.find(mBusinessTravel => businessTravel.id === mBusinessTravel.id)) {
          return existingBusinessTravel.push(businessTravel);
        }

        newBusinessTravel.push(businessTravel);
      });
      await axios__WEBPACK_IMPORTED_MODULE_1___default().post(`/api/organisations/${user.organisation_id}/measurements/${selectedMeasurement.id}/business-travel/batch`, {
        create: newBusinessTravel.map(({
          id,
          departure,
          destination,
          passengers,
          round_trip,
          mode
        }) => {
          var _departure$value, _departure$value2, _destination$value, _destination$value2, _searchSessionIdsRef$, _searchSessionIdsRef$2, _searchSessionIdsRef$3, _searchSessionIdsRef$4;

          return {
            departure: departure === null || departure === void 0 ? void 0 : (_departure$value = departure.value) === null || _departure$value === void 0 ? void 0 : _departure$value.name,
            departure_place_id: departure === null || departure === void 0 ? void 0 : (_departure$value2 = departure.value) === null || _departure$value2 === void 0 ? void 0 : _departure$value2.place_id,
            destination: destination === null || destination === void 0 ? void 0 : (_destination$value = destination.value) === null || _destination$value === void 0 ? void 0 : _destination$value.name,
            destination_place_id: destination === null || destination === void 0 ? void 0 : (_destination$value2 = destination.value) === null || _destination$value2 === void 0 ? void 0 : _destination$value2.place_id,
            passengers: parseInt(passengers),
            round_trip: round_trip === "true",
            mode: mode.value,
            departureSearchSession: (_searchSessionIdsRef$ = searchSessionIdsRef.current) === null || _searchSessionIdsRef$ === void 0 ? void 0 : (_searchSessionIdsRef$2 = _searchSessionIdsRef$.find(searchToken => searchToken.id === id)) === null || _searchSessionIdsRef$2 === void 0 ? void 0 : _searchSessionIdsRef$2.departure,
            destinationSearchSession: (_searchSessionIdsRef$3 = searchSessionIdsRef.current) === null || _searchSessionIdsRef$3 === void 0 ? void 0 : (_searchSessionIdsRef$4 = _searchSessionIdsRef$3.find(searchToken => searchToken.id === id)) === null || _searchSessionIdsRef$4 === void 0 ? void 0 : _searchSessionIdsRef$4.destination
          };
        }),
        update: existingBusinessTravel.map(({
          id,
          departure,
          destination,
          passengers,
          round_trip,
          mode
        }) => {
          var _departure$value3, _departure$value4, _destination$value3, _destination$value4, _searchSessionIdsRef$5, _searchSessionIdsRef$6, _searchSessionIdsRef$7, _searchSessionIdsRef$8;

          return {
            id,
            departure: departure === null || departure === void 0 ? void 0 : (_departure$value3 = departure.value) === null || _departure$value3 === void 0 ? void 0 : _departure$value3.name,
            departure_place_id: departure === null || departure === void 0 ? void 0 : (_departure$value4 = departure.value) === null || _departure$value4 === void 0 ? void 0 : _departure$value4.place_id,
            destination: destination === null || destination === void 0 ? void 0 : (_destination$value3 = destination.value) === null || _destination$value3 === void 0 ? void 0 : _destination$value3.name,
            destination_place_id: destination === null || destination === void 0 ? void 0 : (_destination$value4 = destination.value) === null || _destination$value4 === void 0 ? void 0 : _destination$value4.place_id,
            passengers: parseInt(passengers),
            round_trip: round_trip === "true",
            mode: mode.value,
            departureSearchSession: (_searchSessionIdsRef$5 = searchSessionIdsRef.current) === null || _searchSessionIdsRef$5 === void 0 ? void 0 : (_searchSessionIdsRef$6 = _searchSessionIdsRef$5.find(searchToken => searchToken.id === id)) === null || _searchSessionIdsRef$6 === void 0 ? void 0 : _searchSessionIdsRef$6.departure,
            destinationSearchSession: (_searchSessionIdsRef$7 = searchSessionIdsRef.current) === null || _searchSessionIdsRef$7 === void 0 ? void 0 : (_searchSessionIdsRef$8 = _searchSessionIdsRef$7.find(searchToken => searchToken.id === id)) === null || _searchSessionIdsRef$8 === void 0 ? void 0 : _searchSessionIdsRef$8.destination
          };
        })
      });
      const data = await updateLastCompletedStep(id);
      methods.reset({
        business_travel: data.business_travel.map(businessTravel => {
          var _businessTravel$round2;

          return {
            id: businessTravel.id,
            departure: {
              label: businessTravel.departure,
              value: {
                place_id: businessTravel.departure_place_id,
                name: businessTravel.departure
              }
            },
            destination: {
              label: businessTravel.destination,
              value: {
                place_id: businessTravel.destination_place_id,
                name: businessTravel.destination
              }
            },
            passengers: businessTravel.passengers,
            round_trip: (_businessTravel$round2 = businessTravel.round_trip) === null || _businessTravel$round2 === void 0 ? void 0 : _businessTravel$round2.toString(),
            mode: _data_collection_utils__WEBPACK_IMPORTED_MODULE_23__/* .BUSINESS_TRAVEL_MODES_OF_TRANSPORT.find */ .Ho.find(mode => mode.value === businessTravel.mode) || _data_collection_utils__WEBPACK_IMPORTED_MODULE_23__/* .BUSINESS_TRAVEL_MODES_OF_TRANSPORT[0] */ .Ho[0]
          };
        })
      });
      cb();
    } catch (error) {
      console.error(error);
      throw error;
    }
  };

  const searchSessionIdsRef = react__WEBPACK_IMPORTED_MODULE_2___default().useRef([]);

  const setSearchSessionIdsRef = data => searchSessionIdsRef.current = data;

  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(() => {
    if (!selectedMeasurement.business_travel.length && !fields.length) {
      append({
        departure: "",
        destination: "",
        passengers: null,
        mode: _data_collection_utils__WEBPACK_IMPORTED_MODULE_23__/* .BUSINESS_TRAVEL_MODES_OF_TRANSPORT[0] */ .Ho[0],
        round_trip: "false"
      });
    }
  }, []);
  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(() => {
    setSearchSessionIdsRef(fields.map(field => ({
      id: field.id,
      departure: (0,uuidv4__WEBPACK_IMPORTED_MODULE_21__.uuid)(),
      destination: (0,uuidv4__WEBPACK_IMPORTED_MODULE_21__.uuid)()
    })));
  }, []);
  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(() => {
    const searchIds = searchSessionIdsRef === null || searchSessionIdsRef === void 0 ? void 0 : searchSessionIdsRef.current.map(({
      id
    }) => id);
    const newFields = fields.filter(field => !searchIds.includes(field.id));
    setSearchSessionIdsRef([...(searchSessionIdsRef === null || searchSessionIdsRef === void 0 ? void 0 : searchSessionIdsRef.current), ...newFields.map(field => ({
      id: field.id,
      departure: (0,uuidv4__WEBPACK_IMPORTED_MODULE_21__.uuid)(),
      destination: (0,uuidv4__WEBPACK_IMPORTED_MODULE_21__.uuid)()
    }))]);
  }, [fields.length]);

  const getPlaces = async ({
    input,
    id,
    type
  }) => {
    var _searchSessionIdsRef$9;

    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`/api/places/autocomplete`, {
      params: {
        input,
        searchSession: (_searchSessionIdsRef$9 = searchSessionIdsRef.current) === null || _searchSessionIdsRef$9 === void 0 ? void 0 : _searchSessionIdsRef$9.find(searchToken => searchToken.id === id)[type],
        types: "(cities)"
      }
    });
    const options = data.predictions.map(place => ({
      value: {
        place_id: place.place_id,
        name: place.description
      },
      label: place.description
    }));
    return options;
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsx(_MeasurementSection__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
    id: id,
    title: "Business Travel",
    onNextClick: methods.handleSubmit(upsertBusinessTravel),
    sectionDisabled: sectionDisabled,
    value: `${selectedMeasurement.business_travel.length} ${selectedMeasurement.business_travel.length === 1 ? "trip" : "trips"}`,
    nextDisabled: !fields.length,
    required: selectedMeasurement.has_business_travel,
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsx(_common_Form__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
      onSubmit: methods.handleSubmit(upsertBusinessTravel),
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsxs)(react_hook_form__WEBPACK_IMPORTED_MODULE_3__.FormProvider, _objectSpread(_objectSpread({}, methods), {}, {
        children: [fields && fields.map((business_travel, index) => {
          var _business_travel$depa, _business_travel$dest, _business_travel$mode;

          return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsx("div", {
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsxs)(_MeasurementArraySection__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
              title: `Trip ${index + 1}`,
              value: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.Fragment, {
                children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsxs)(_common_Text__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .ZP, {
                  size: "subtitle",
                  color: "blue",
                  children: [(_business_travel$depa = business_travel.departure) === null || _business_travel$depa === void 0 ? void 0 : _business_travel$depa.label, " -", " ", (_business_travel$dest = business_travel.destination) === null || _business_travel$dest === void 0 ? void 0 : _business_travel$dest.label, ",", " ", (_business_travel$mode = business_travel.mode) === null || _business_travel$mode === void 0 ? void 0 : _business_travel$mode.label, ","]
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsx("br", {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsxs)(_common_Text__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .ZP, {
                  size: "subtitle",
                  color: "blue",
                  children: [business_travel.passengers, " passengers", business_travel.round_trip === "true" ? ", Round Trip" : ""]
                })]
              }),
              closeLoading: deleteLoading,
              onClose: async () => Number.isInteger(business_travel.id) ? await deleteBusinessTravel(business_travel.id, index) : remove(index),
              defaultOpen: !business_travel.destination,
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsx("input", {
                name: `id`,
                disabled: true,
                hidden: true,
                defaultValue: business_travel.id
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsxs)(_common_FormGroup__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                align: "flex-start",
                margin: "-1rem 0 1rem",
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .ZP, {
                  children: "From: "
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsx(_form_InputAsyncDropdown_V2__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                  id: `business_travel.${index}.departure`,
                  name: `business_travel.${index}.departure`,
                  width: "20%",
                  placeholder: "Enter city",
                  isRequired: true,
                  loadOptions: input => getPlaces({
                    input,
                    id: business_travel.id,
                    type: "departure"
                  }),
                  defaultValue: {
                    label: business_travel.departure.label,
                    value: business_travel.departure.value
                  }
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .ZP, {
                  children: "To: "
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsx(_form_InputAsyncDropdown__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                  id: `business_travel.${index}.destination`,
                  name: `business_travel.${index}.destination`,
                  testId: `business_travel.${index}.destination`,
                  width: "20%",
                  placeholder: "Enter city",
                  loadOptions: input => getPlaces({
                    input,
                    id: business_travel.id,
                    type: "destination"
                  }),
                  isRequired: true,
                  defaultValue: {
                    label: business_travel.destination.label,
                    value: business_travel.departure.value
                  }
                })]
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsxs)(_common_FormGroup__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsx(_form_InputDropdown__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                  id: `business_travel.${index}.mode`,
                  width: "50%",
                  placeholder: "Select mode of transport...",
                  optionArray: _data_collection_utils__WEBPACK_IMPORTED_MODULE_23__/* .BUSINESS_TRAVEL_MODES_OF_TRANSPORT */ .Ho,
                  defaultValue: business_travel.mode,
                  hasDefaultValue: false
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsx(RoundTripContainer, {
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .ZP, {
                    children: "Round Trip: "
                  })
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsx(_form_Checkbox_V2__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                  name: `business_travel.${index}.round_trip`,
                  value: "true",
                  defaultChecked: business_travel.round_trip === "true"
                })]
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsxs)(_common_FormGroup__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                align: "flex-start",
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .ZP, {
                  children: "Passengers: "
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsx(_form_Input__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                  id: `business_travel.${index}.passengers`,
                  name: `business_travel.${index}.passengers`,
                  testId: `business_travel.${index}.passengers`,
                  width: "20%",
                  type: "number",
                  placeholder: "Enter number",
                  isRequired: true,
                  defaultValue: business_travel.passengers
                })]
              })]
            })
          }, business_travel.id);
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsx(_common_Divider__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
          margin: "0.5rem 0 2rem",
          width: "50%"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsx(_common_ButtonsContainer__WEBPACK_IMPORTED_MODULE_12__/* .OfficeButtonsContainer */ .g, {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_24__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP, {
            type: "button",
            onClick: () => append({
              id: (0,uuidv4__WEBPACK_IMPORTED_MODULE_21__.uuid)(),
              departure: "",
              destination: "",
              passengers: null,
              mode: null,
              round_trip: "false"
            }),
            children: "Add more"
          })
        })]
      }))
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BusinessTravel);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 41373:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _button_Button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(59067);
/* harmony import */ var _common_ButtonsContainer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(30495);
/* harmony import */ var _MeasurementSection__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(28067);
/* harmony import */ var _utils_applicationMap__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(40516);
/* harmony import */ var _contexts_auth__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(58368);
/* harmony import */ var _contexts_measurements__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(85238);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(11098);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }













const HasBusinessTravel = ({
  hasBusinessTravel,
  setHasBusinessTravel,
  sectionDisabled
}) => {
  const {
    user
  } = (0,_contexts_auth__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)();
  const {
    selectedMeasurement,
    setSelectedMeasurement
  } = (0,_contexts_measurements__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)();
  const id = "has_business_travel";
  const {
    0: close,
    1: setClose
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
  const {
    0: loading,
    1: setLoading
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
  const {
    0: loadingFalse,
    1: setLoadingFalse
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);

  const updateMeasurementHasBusinessTravel = async value => {
    try {
      value ? setLoading(true) : setLoadingFalse(true);
      const {
        data: measurement
      } = await axios__WEBPACK_IMPORTED_MODULE_0___default().patch(`/api/organisations/${user.organisation_id}/measurements/${selectedMeasurement.id}`, _objectSpread({
        has_business_travel: value
      }, (0,_utils_applicationMap__WEBPACK_IMPORTED_MODULE_9__/* .shouldUpdateLastCompletedStep */ ._Z)({
        step: id,
        measurement: selectedMeasurement
      }) ? {
        last_completed_step: id
      } : {}));
      setSelectedMeasurement(measurement);
      setHasBusinessTravel(!!measurement.has_business_travel);
      setClose(!close);
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_7__/* .logError */ .H)(error);
    }

    value ? setLoading(false) : setLoadingFalse(false);
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_MeasurementSection__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
    id: id,
    title: "Was there any business travel during the period?",
    value: hasBusinessTravel ? "Yes" : "No",
    sectionDisabled: sectionDisabled,
    defaultOpen: selectedMeasurement.has_business_travel === null && !sectionDisabled,
    close: close,
    setClose: setClose,
    required: true,
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(_common_ButtonsContainer__WEBPACK_IMPORTED_MODULE_3__/* .OfficeButtonsContainer */ .g, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
        onClick: () => updateMeasurementHasBusinessTravel(true),
        loading: loading,
        disabled: loadingFalse,
        children: "Yes"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
        onClick: () => updateMeasurementHasBusinessTravel(false),
        loading: loadingFalse,
        disabled: loading,
        children: "No"
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HasBusinessTravel);

/***/ })

};
;