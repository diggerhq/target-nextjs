"use strict";
exports.id = 290;
exports.ids = [290];
exports.modules = {

/***/ 37928:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const BreadcrumbLink = styled_components__WEBPACK_IMPORTED_MODULE_0___default().a.withConfig({
  displayName: "BreadcrumbLink",
  componentId: "sc-1fywp6v-0"
})(["cursor:pointer;text-decoration:none;"]);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BreadcrumbLink);

/***/ }),

/***/ 14414:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(45641);
/* harmony import */ var _button_Button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(59067);
/* harmony import */ var _common_Divider__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6459);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(87491);
/* harmony import */ var _data_collection_BusinessTravel__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(31558);
/* harmony import */ var _data_collection_BusinessTravel_BusinessTravelView__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(12105);
/* harmony import */ var _data_collection_common_DataInputContainer__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(64493);
/* harmony import */ var _data_collection_Details__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5024);
/* harmony import */ var _data_collection_Details_DetailsEdit__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(65043);
/* harmony import */ var _data_collection_Details_DetailsView__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(45332);
/* harmony import */ var _data_collection_EmployeeCommutes__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(6137);
/* harmony import */ var _data_collection_EmployeeCommutes_EmployeeCommutesView__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(31982);
/* harmony import */ var _data_collection_Homeworking_HomeworkingView__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(84259);
/* harmony import */ var _data_collection_Utilities__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(42088);
/* harmony import */ var _data_collection_Utilities_UtilitiesEdit__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(52069);
/* harmony import */ var _data_collection_Utilities_UtilitiesView__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(6778);
/* harmony import */ var _data_collection_utils_parseFormData__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(29645);
/* harmony import */ var _data_collection_VehicleUsage__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(59663);
/* harmony import */ var _form_Form__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(89781);
/* harmony import */ var _contexts_auth__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(58368);
/* harmony import */ var _contexts_measurements__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(85238);
/* harmony import */ var _hooks_usePrevious__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(9258);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(11098);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var _contexts_config__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(33742);
/* harmony import */ var _DeleteOfficeModal__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(84974);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_3__, _data_collection_BusinessTravel__WEBPACK_IMPORTED_MODULE_7__, _data_collection_Details__WEBPACK_IMPORTED_MODULE_10__, _data_collection_Details_DetailsEdit__WEBPACK_IMPORTED_MODULE_11__, _data_collection_EmployeeCommutes__WEBPACK_IMPORTED_MODULE_13__, _data_collection_Utilities__WEBPACK_IMPORTED_MODULE_16__, _data_collection_Utilities_UtilitiesEdit__WEBPACK_IMPORTED_MODULE_17__, _data_collection_VehicleUsage__WEBPACK_IMPORTED_MODULE_19__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_3__, _data_collection_BusinessTravel__WEBPACK_IMPORTED_MODULE_7__, _data_collection_Details__WEBPACK_IMPORTED_MODULE_10__, _data_collection_Details_DetailsEdit__WEBPACK_IMPORTED_MODULE_11__, _data_collection_EmployeeCommutes__WEBPACK_IMPORTED_MODULE_13__, _data_collection_Utilities__WEBPACK_IMPORTED_MODULE_16__, _data_collection_Utilities_UtilitiesEdit__WEBPACK_IMPORTED_MODULE_17__, _data_collection_VehicleUsage__WEBPACK_IMPORTED_MODULE_19__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




 // import { yupResolver } from '@hookform/resolvers/yup';





 // import { schema } from "src/components/data-collection/DataCollectionSchema";
























const MeasurementsSection = styled_components__WEBPACK_IMPORTED_MODULE_25___default().div.withConfig({
  displayName: "DataCollectionForm__MeasurementsSection",
  componentId: "kbf28d-0"
})(["display:flex;flex-direction:column;width:100%;"]);
const TotalFootprint = styled_components__WEBPACK_IMPORTED_MODULE_25___default()(_common_Text__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .ZP).withConfig({
  displayName: "DataCollectionForm__TotalFootprint",
  componentId: "kbf28d-1"
})([""]);
const BottomCTAs = styled_components__WEBPACK_IMPORTED_MODULE_25___default().div.withConfig({
  displayName: "DataCollectionForm__BottomCTAs",
  componentId: "kbf28d-2"
})(["display:flex;width:100%;justify-content:space-between;"]);

const DataCollectionForm = ({
  measurement,
  onDeleteOffice,
  countries,
  office,
  activeOfficeForm,
  setActiveOfficeForm,
  isActive,
  isLastOffice
}) => {
  var _office$details, _office$details2, _office$measurement_r, _office$measurement_r2, _office$details3, _office$details4, _office$details5, _office$details6;

  const {
    organisation
  } = (0,_contexts_auth__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .Z)();
  const {
    0: showDeleteConfirmationModal,
    1: setShowDeleteConfirmationModal
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
  const {
    0: isEditing,
    1: setIsEditing
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(null);
  const previousOfficeId = (0,_hooks_usePrevious__WEBPACK_IMPORTED_MODULE_23__/* .usePrevious */ .D)(office.id);
  const {
    setSelectedMeasurement
  } = (0,_contexts_measurements__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .Z)();

  const formDefaultValues = _objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread({}, (0,_data_collection_Details_DetailsEdit__WEBPACK_IMPORTED_MODULE_11__/* .createDetailsDefaultValues */ .J)({
    office,
    countries
  })), (0,_data_collection_Utilities_UtilitiesEdit__WEBPACK_IMPORTED_MODULE_17__/* .createWasteAndUtilitiesDefaultValues */ .D)(office)), (0,_data_collection_EmployeeCommutes__WEBPACK_IMPORTED_MODULE_13__/* .createEmployeeCommutesDefaultValues */ .s)(office)), (0,_data_collection_BusinessTravel__WEBPACK_IMPORTED_MODULE_7__/* .createBusinessTravelDefaultValues */ .a)(office)), (0,_data_collection_VehicleUsage__WEBPACK_IMPORTED_MODULE_19__/* .createVehicleUsageDefaultValues */ .wr)(office));

  const {
    pageContainer
  } = (0,_contexts_config__WEBPACK_IMPORTED_MODULE_26__/* ["default"] */ .Z)();
  const methods = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_3__.useForm)({
    defaultValues: formDefaultValues
  });
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
  const {
    handleSubmit,
    formState: {
      isSubmitting
    }
  } = methods;
  const isNotLastPage = measurement.office_measurements.length > activeOfficeForm + 1;

  const handleMeasurementsSubmit = async values => {
    const parsedValues = (0,_data_collection_utils_parseFormData__WEBPACK_IMPORTED_MODULE_29__/* ["default"] */ .Z)(values);

    try {
      var _pageContainer$curren;

      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_0___default().patch(`/api/organisations/${organisation.id}/data-collection/measurements/${measurement.id}/office/${office.office_id}`, _objectSpread({}, parsedValues));

      const newDataCollectionMeasurement = _objectSpread(_objectSpread({}, measurement), data);

      setSelectedMeasurement(newDataCollectionMeasurement);
      setIsEditing(null);
      isNotLastPage && setActiveOfficeForm(activeOfficeForm + 1);
      pageContainer === null || pageContainer === void 0 ? void 0 : (_pageContainer$curren = pageContainer.current) === null || _pageContainer$curren === void 0 ? void 0 : _pageContainer$curren.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_24__/* .logError */ .H)(error);
    }
  };

  const resetForm = (name = null) => {
    methods.reset(formDefaultValues);
    setIsEditing(name);
  };

  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(() => {
    if (previousOfficeId && previousOfficeId !== office.id) {
      resetForm();
    }
  }, [office]);
  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(() => {
    var _pageContainer$curren2;

    pageContainer && (pageContainer === null || pageContainer === void 0 ? void 0 : (_pageContainer$curren2 = pageContainer.current) === null || _pageContainer$curren2 === void 0 ? void 0 : _pageContainer$curren2.scrollTo({
      top: 0,
      behavior: "smooth"
    }));
  }, [activeOfficeForm]);
  return isActive ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxs)(MeasurementsSection, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_DeleteOfficeModal__WEBPACK_IMPORTED_MODULE_27__/* ["default"] */ .Z, {
      showConfirmationModal: showDeleteConfirmationModal,
      setShowConfirmationModal: setShowDeleteConfirmationModal,
      onConfirm: async () => {
        activeOfficeForm > 0 && setActiveOfficeForm(activeOfficeForm - 1);
        await onDeleteOffice();
      },
      officeName: (office === null || office === void 0 ? void 0 : (_office$details = office.details) === null || _office$details === void 0 ? void 0 : _office$details.name) || `Office ${activeOfficeForm + 1}`
    }), office.measurement_result && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_data_collection_common_DataInputContainer__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxs)(TotalFootprint, {
        size: "sectionTitle",
        align: "left",
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxs)(_common_Text__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .ZP, {
          size: "subtitleBold",
          children: [measurement.time_period === 12 ? "Annual" : "Monthly", " emissions for ", (_office$details2 = office.details) === null || _office$details2 === void 0 ? void 0 : _office$details2.name, ":", " "]
        }), Number((_office$measurement_r = office.measurement_result) === null || _office$measurement_r === void 0 ? void 0 : (_office$measurement_r2 = _office$measurement_r.total) === null || _office$measurement_r2 === void 0 ? void 0 : _office$measurement_r2.toFixed(1)).toLocaleString(), " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .ZP, {
          size: "meta",
          children: "kgCO2e"
        })]
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_form_Form__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {
      onSubmit: handleSubmit(handleMeasurementsSubmit),
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_3__.FormProvider, _objectSpread(_objectSpread({}, methods), {}, {
        children: !office.measurement_result ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.Fragment, {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_data_collection_Details__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
            fullyRemote: office === null || office === void 0 ? void 0 : (_office$details3 = office.details) === null || _office$details3 === void 0 ? void 0 : _office$details3.fully_remote,
            countries: countries,
            isEditing: isEditing === "details",
            isSubmitting: isSubmitting
          }), !office.details.fully_remote && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.Fragment, {
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_data_collection_Utilities__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
              annual: measurement.time_period === 12,
              isEditing: isEditing === "utilities",
              isSubmitting: isSubmitting
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_data_collection_EmployeeCommutes__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
              isEditing: isEditing === "employeeCommutes",
              isSubmitting: isSubmitting
            })]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_data_collection_BusinessTravel__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
            office,
            isEditing: isEditing === "businessTravel",
            isSubmitting: isSubmitting
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_data_collection_VehicleUsage__WEBPACK_IMPORTED_MODULE_19__/* .VehicleUsageEdit */ .$5, {
            office,
            isEditing: isEditing === "vehicleUsage",
            isSubmitting: isSubmitting,
            reset: resetForm
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_common_Divider__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
            margin: "20px 0"
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxs)(BottomCTAs, {
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP, {
              type: "button",
              secondary: true,
              warning: true,
              disabled: isLastOffice,
              loading: false,
              onClick: async () => setShowDeleteConfirmationModal(!showDeleteConfirmationModal),
              children: "Remove office"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP, {
              type: "submit",
              loading: isSubmitting,
              children: isNotLastPage ? "Next office" : "Submit"
            })]
          })]
        }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.Fragment, {
          children: [isEditing === "details" ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_data_collection_Details__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
            fullyRemote: office === null || office === void 0 ? void 0 : (_office$details4 = office.details) === null || _office$details4 === void 0 ? void 0 : _office$details4.fully_remote,
            countries: countries,
            isEditing: isEditing === "details",
            isSubmitting: isSubmitting,
            reset: resetForm
          }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_data_collection_Details_DetailsView__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
            result: office.measurement_result,
            fullyRemote: office === null || office === void 0 ? void 0 : (_office$details5 = office.details) === null || _office$details5 === void 0 ? void 0 : _office$details5.fully_remote,
            countries: countries,
            details: office.details,
            isEditing: isEditing === "details",
            reset: resetForm
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_data_collection_Homeworking_HomeworkingView__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
            result: office.measurement_result,
            fullyRemote: office === null || office === void 0 ? void 0 : (_office$details6 = office.details) === null || _office$details6 === void 0 ? void 0 : _office$details6.fully_remote,
            countries: countries,
            details: office.details,
            isEditing: isEditing === "details",
            reset: resetForm
          }), !office.details.fully_remote ? isEditing === "utilities" ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_data_collection_Utilities__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
            isEditing: isEditing === "utilities",
            isSubmitting: isSubmitting,
            reset: resetForm
          }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_data_collection_Utilities_UtilitiesView__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {
            result: office.measurement_result,
            utilities: office.utilities,
            waste: office.waste,
            isEditing: isEditing === "utilities",
            reset: resetForm
          }) : null, !office.details.fully_remote ? isEditing === "employeeCommutes" ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_data_collection_EmployeeCommutes__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
            isEditing: isEditing === "employeeCommutes",
            isSubmitting: isSubmitting,
            reset: resetForm
          }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_data_collection_EmployeeCommutes_EmployeeCommutesView__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
            result: office.measurement_result,
            employeeCommutes: office.employee_commutes,
            isEditing: isEditing === "employeeCommutes",
            reset: resetForm
          }) : null, isEditing === "businessTravel" ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_data_collection_BusinessTravel__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
            office,
            isEditing: isEditing === "businessTravel",
            isSubmitting: isSubmitting,
            reset: resetForm
          }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_data_collection_BusinessTravel_BusinessTravelView__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
            businessTravel: office.business_travel,
            isEditing: isEditing === "businessTravel",
            reset: resetForm,
            result: office.measurement_result
          }), isEditing === "vehicleUsage" ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_data_collection_VehicleUsage__WEBPACK_IMPORTED_MODULE_19__/* .VehicleUsageEdit */ .$5, {
            office,
            isEditing: isEditing === "vehicleUsage",
            isSubmitting: isSubmitting,
            reset: resetForm
          }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_28__.jsx(_data_collection_VehicleUsage__WEBPACK_IMPORTED_MODULE_19__/* .VehicleUsageView */ .qx, {
            vehicleUsage: office.vehicle_usage,
            isEditing: isEditing === "vehicleUsage",
            reset: resetForm,
            result: office.measurement_result
          })]
        })
      }))
    })]
  }) : null;
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DataCollectionForm);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 84974:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _common_ConfirmationModal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65487);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(87491);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





var Bin = function Bin(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("g", {
      clipPath: "url(#clip0)",
      fill: "#EC5F59",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("path", {
        d: "M11.768 25c-2.014 0-4.028.003-6.041 0-.49 0-.98-.006-1.467-.049-.847-.073-1.573-.835-1.622-1.719-.126-2.313-.235-4.626-.343-6.94-.16-3.384-.314-6.769-.463-10.154-.017-.38-.173-.516-.522-.489a2.16 2.16 0 0 1-.282 0C.413 5.621-.013 5.213 0 4.667c.013-.561.496-.976 1.115-.971 1.712.012 3.424.021 5.136.027 1.275 0 1.274-.005 1.486-1.298.052-.322.092-.647.176-.96.11-.42.355-.792.696-1.057.341-.264.758-.406 1.187-.403 1.335.007 2.67.026 4.007.04 1.085.01 1.81.64 1.988 1.726.083.51.174 1.019.241 1.53.04.312.18.393.49.393 2.031-.004 4.063.013 6.093.033.615.007.99.375 1 .933.008.583-.375.958-1.01.989-.786.037-.772.041-.81.872-.215 4.512-.434 9.024-.657 13.536-.048 1.032-.083 2.067-.136 3.099-.052 1.007-.8 1.796-1.778 1.804-2.484.02-4.969.007-7.453.007l-.004.033zm.063-1.96c2.163 0 4.326-.022 6.49.016.574.01.772-.193.788-.737.025-.841.087-1.682.125-2.523.202-4.474.401-8.95.598-13.424.033-.73.03-.73-.727-.724-2.389.017-4.776.046-7.164.046-2.538 0-5.077-.018-7.615-.054-.452-.006-.567.127-.545.592.22 4.512.405 9.026.628 13.538.04.823.067 1.645.105 2.467.037.769.084.804.827.804h6.49zm.093-19.338v.008c.377 0 .754.022 1.13-.004 1.061-.074 1.043-.08.887-1.179-.063-.435-.252-.576-.67-.566-.976.023-1.954.005-2.932.008-.22 0-.508-.052-.563.246-.086.46-.273.922-.13 1.4.034.113.194.09.307.089.657-.004 1.314-.003 1.971-.003v.001z"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("path", {
        d: "M8.69 18.497c0 .268.003.536 0 .803-.012.631-.339 1.023-.878 1.059-.553.037-.954-.295-1.014-.916a63.554 63.554 0 0 1-.186-2.86 598.873 598.873 0 0 1-.258-6.133c-.028-.742.278-1.15.84-1.2.6-.055.983.3 1.062 1.056.08.756.118 1.523.154 2.289.093 1.967.174 3.935.26 5.902h.02zM17.265 11.124c-.12 2.598-.242 5.195-.363 7.792-.013.19-.037.38-.072.569-.096.577-.47.9-1 .873-.537-.027-.898-.42-.883-1.046.032-1.357.085-2.715.145-4.07.06-1.337.135-2.673.21-4.008.021-.382.04-.765.096-1.142.087-.57.489-.884 1.022-.844.495.04.835.412.857.959.011.305 0 .612 0 .918h-.012zM10.868 14.807c0-1.51-.01-3.019.005-4.528.007-.665.379-1.043.95-1.034.571.009.932.396.935 1.057.01 2.062.004 4.125.008 6.188 0 .898.005 1.796.02 2.693.013.697-.357 1.165-.95 1.175-.604.012-.97-.419-.97-1.137v-4.414h.002z"
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("defs", {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("clipPath", {
        id: "clip0",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("path", {
          fill: "#fff",
          d: "M0 0h23.611v25H0z"
        })
      })
    })]
  }));
};

Bin.defaultProps = {
  width: "24",
  height: "25",
  viewBox: "0 0 24 25",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var NotifyIcon = function NotifyIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("path", {
      d: "M10.01 0C15.453-.04 20.053 4.48 20 10.09c-.052 5.348-4.374 9.902-10 9.902-5.648 0-10.05-4.6-10-10.087C.052 4.307 4.655-.043 10.01.001zm0 2.022c-4.322-.01-7.804 3.425-7.974 7.637-.183 4.51 3.372 8.232 7.82 8.303 4.559.075 8.005-3.571 8.116-7.756.114-4.396-3.417-8.183-7.964-8.184h.002z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("path", {
      d: "M11.014 8.49v2.6c0 .594-.451 1.06-1.013 1.053-.574-.009-1.018-.464-1.018-1.055-.002-1.74-.002-3.48 0-5.219 0-.58.446-1.035 1.01-1.04.573-.005 1.021.45 1.022 1.042v2.62zM11.015 14.074c.013.424-.167.747-.532.954-.342.195-.689.17-1.026-.033-.39-.235-.577-.785-.437-1.28a1.018 1.018 0 0 1 .996-.745c.476.012.858.324.977.794.026.104.018.206.022.31z"
    })]
  }));
};

NotifyIcon.defaultProps = {
  width: "20",
  height: "20",
  viewBox: "0 0 20 20",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};




const TitleContainer = styled_components__WEBPACK_IMPORTED_MODULE_5___default().div.withConfig({
  displayName: "DeleteOfficeModal__TitleContainer",
  componentId: "rizcdk-0"
})(["display:flex;flex-direction:column;align-items:center;justify-content:center;"]);
const BodyContainer = styled_components__WEBPACK_IMPORTED_MODULE_5___default()(TitleContainer).withConfig({
  displayName: "DeleteOfficeModal__BodyContainer",
  componentId: "rizcdk-1"
})(["padding:0 1rem;", ""], _theme__WEBPACK_IMPORTED_MODULE_4__/* .media.tablet */ .BC.tablet`
  padding: 0 1.875rem;
`);
const NoUtilityBillsContainer = styled_components__WEBPACK_IMPORTED_MODULE_5___default().div.withConfig({
  displayName: "DeleteOfficeModal__NoUtilityBillsContainer",
  componentId: "rizcdk-2"
})(["background:", ";border-radius:4px;padding:0.5rem 1rem;display:flex;justify-content:flex-start;align-items:center;margin-top:0.5rem;& > svg{fill:", ";margin-right:0.25rem;}"], p => p.theme.colors.backgroundYellow, p => p.theme.colors.black);

const DeleteOfficeModal = ({
  showConfirmationModal,
  setShowConfirmationModal,
  onConfirm,
  loading,
  officeName
}) => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_common_ConfirmationModal__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
    open: showConfirmationModal,
    onClose: () => setShowConfirmationModal(!showConfirmationModal),
    onConfirm: onConfirm,
    cancelText: "Go back",
    confirmText: "Remove",
    maxWidth: "32.5rem",
    title: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(TitleContainer, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(Bin, {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(_common_Text__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
        size: "modalTitle",
        color: "error",
        children: ["Remove ", officeName]
      })]
    }),
    body: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(BodyContainer, {
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(NoUtilityBillsContainer, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(NotifyIcon, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
          size: "alert",
          align: "left",
          children: "This deletes all progress on this office and is irreversible."
        })]
      })
    }),
    loading: loading,
    warning: true
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DeleteOfficeModal);

/***/ }),

/***/ 51138:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(45641);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(16666);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_responsive__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _button_Button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(59067);
/* harmony import */ var _common_InputDropdown__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(31217);
/* harmony import */ var _common_LoadingLarge__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(49899);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(87491);
/* harmony import */ var _data_collection_common_DataInputContainer__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(64493);
/* harmony import */ var _form_Form__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(89781);
/* harmony import */ var _form_InputDropdown__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(51894);
/* harmony import */ var _contexts_auth__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(58368);
/* harmony import */ var _contexts_measurements__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(85238);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(91073);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(11098);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _DataCollectionForm__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(14414);
/* harmony import */ var _SidebarOffices__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(84185);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_3__, _form_InputDropdown__WEBPACK_IMPORTED_MODULE_11__, _DataCollectionForm__WEBPACK_IMPORTED_MODULE_17__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_3__, _form_InputDropdown__WEBPACK_IMPORTED_MODULE_11__, _DataCollectionForm__WEBPACK_IMPORTED_MODULE_17__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }























const FormGroup = styled_components__WEBPACK_IMPORTED_MODULE_16___default().div.withConfig({
  displayName: "OperationalData__FormGroup",
  componentId: "sc-1t7n8ny-0"
})(["display:flex;flex-direction:row;margin-top:20px;& > div{margin-bottom:0px;&:not(:last-child){margin-right:20px;}& > div > div[class$=\"control\"]{margin-bottom:0;}}"]);
const MainContainer = styled_components__WEBPACK_IMPORTED_MODULE_16___default().div.withConfig({
  displayName: "OperationalData__MainContainer",
  componentId: "sc-1t7n8ny-1"
})(["display:flex;flex-direction:column;", ""], _theme__WEBPACK_IMPORTED_MODULE_14__/* .media.tablet */ .BC.tablet`
    flex-direction: row;
  `);
const numberOfOffices = [{
  label: "Fully Remote",
  value: 0
}, ...Array.from({
  length: 9
}, (_, i) => ({
  label: i + 1,
  value: i + 1
})), {
  label: "10+",
  value: 10
}];

const OperationalData = ({
  measurement,
  countries
}) => {
  var _measurement$office_m, _measurement$office_m2, _measurement$office_m3;

  const {
    organisation
  } = (0,_contexts_auth__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z)();
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
  const {
    loading,
    setSelectedMeasurement
  } = (0,_contexts_measurements__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z)();
  const {
    0: activeOfficeForm,
    1: setActiveOfficeForm
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(0);
  const {
    0: deleteLoading,
    1: setDeleteLoading
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
  const {
    0: resetLoading,
    1: setResetLoading
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
  const methods = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_3__.useForm)({
    defaultValues: {
      number_of_offices: numberOfOffices[0]
    }
  });
  const isTablet = (0,react_responsive__WEBPACK_IMPORTED_MODULE_4__.useMediaQuery)({
    query: `(min-width: ${_theme__WEBPACK_IMPORTED_MODULE_14__/* .sizes.tablet */ .J7.tablet}px)`
  });
  const {
    handleSubmit,
    formState: {
      isSubmitting
    }
  } = methods;

  const onOfficesSubmit = async ({
    number_of_offices
  }) => {
    try {
      const officesNumber = number_of_offices.value;

      if (measurement) {
        const {
          data
        } = await axios__WEBPACK_IMPORTED_MODULE_0___default().post(`/api/organisations/${organisation.id}/data-collection/measurements/${measurement.id}/office`, {
          number_of_offices: Number(officesNumber)
        });
        setSelectedMeasurement(data);
      } else {
        const {
          data
        } = await axios__WEBPACK_IMPORTED_MODULE_0___default().post(`/api/organisations/${organisation.id}/data-collection`, {
          number_of_offices: Number(officesNumber)
        });
        setSelectedMeasurement(data);
      }
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_15__/* .logError */ .H)(error);
    }
  };

  const handleAddOffice = async () => {
    try {
      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_0___default().post(`/api/organisations/${organisation.id}/data-collection/measurements/${measurement.id}/office`);
      setSelectedMeasurement(_objectSpread(_objectSpread({}, measurement), data));
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_15__/* .logError */ .H)(error);
    }
  };

  const handleDeleteOffice = async () => {
    try {
      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_0___default()["delete"](`/api/organisations/${organisation.id}/data-collection/measurements/${measurement.id}/office/${measurement.office_measurements[activeOfficeForm].office_id}`);
      setSelectedMeasurement(_objectSpread(_objectSpread({}, measurement), data));
    } catch (error) {
      setDeleteLoading(false);
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_15__/* .logError */ .H)(error);
    }
  };

  const handleResetForm = async () => {
    try {
      setResetLoading(true);
      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_0___default()["delete"](`/api/organisations/${organisation.id}/data-collection/measurements/${measurement.id}/office`, {
        data: {
          office_ids: measurement === null || measurement === void 0 ? void 0 : measurement.office_measurements.map(office_measurement => office_measurement.office_id)
        }
      });
      setSelectedMeasurement(_objectSpread(_objectSpread({}, measurement), data));
      setActiveOfficeForm(0);
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_15__/* .logError */ .H)(error);
    }

    setResetLoading(false);
  };

  const isActiveOffice = index => activeOfficeForm === index;

  const optionArray = measurement === null || measurement === void 0 ? void 0 : (_measurement$office_m = measurement.office_measurements) === null || _measurement$office_m === void 0 ? void 0 : _measurement$office_m.map((office, index) => {
    var _office$details;

    return {
      label: ((_office$details = office.details) === null || _office$details === void 0 ? void 0 : _office$details.name) || `Office ${index + 1}`,
      value: index
    };
  });
  const year = new Date().getFullYear();
  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(() => {
    window.scrollTo({
      top: 0,
      behavior: "smooth"
    });
  }, [activeOfficeForm]);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx("div", {
    children: resetLoading || loading ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(_common_LoadingLarge__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
      loading: resetLoading || loading
    }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.Fragment, {
      children: [!measurement || (measurement === null || measurement === void 0 ? void 0 : (_measurement$office_m2 = measurement.office_measurements) === null || _measurement$office_m2 === void 0 ? void 0 : _measurement$office_m2.length) === 0 && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsxs)(_data_collection_common_DataInputContainer__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
        width: "50%",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .ZP, {
          size: "subtitleBold",
          children: "How many offices do you have?"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(_form_Form__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
          onSubmit: handleSubmit(onOfficesSubmit),
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_3__.FormProvider, _objectSpread(_objectSpread({}, methods), {}, {
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsxs)(FormGroup, {
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(_form_InputDropdown__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                id: "number_of_offices",
                placeholder: "Enter value",
                width: "160px",
                optionArray: numberOfOffices
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP, {
                type: "submit",
                loading: isSubmitting,
                children: "Start measuring"
              })]
            })
          }))
        })]
      }), measurement && (measurement === null || measurement === void 0 ? void 0 : (_measurement$office_m3 = measurement.office_measurements) === null || _measurement$office_m3 === void 0 ? void 0 : _measurement$office_m3.length) > 0 && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsxs)(MainContainer, {
        children: [isTablet ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(_SidebarOffices__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {
          measurement,
          handleAddOffice,
          activeOfficeForm,
          setActiveOfficeForm,
          isActiveOffice,
          handleResetForm,
          countries
        }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(_common_InputDropdown__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
          optionArray: optionArray,
          defaultValue: optionArray.find(({
            value
          }) => value === activeOfficeForm) || (optionArray === null || optionArray === void 0 ? void 0 : optionArray[0]),
          onChange: ({
            value
          }) => setActiveOfficeForm(value),
          width: "100%",
          controlMargin: "0 0 1rem 0"
        }), measurement === null || measurement === void 0 ? void 0 : measurement.office_measurements.map((office, index) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(_DataCollectionForm__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
          isLastOffice: (measurement === null || measurement === void 0 ? void 0 : measurement.office_measurements.length) <= 1,
          onDeleteOffice: handleDeleteOffice,
          isActive: isActiveOffice(index),
          index,
          isActiveOffice,
          office,
          countries,
          measurement,
          activeOfficeForm,
          setActiveOfficeForm
        }))]
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (OperationalData);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 84185:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _button_Button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59067);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(87491);
/* harmony import */ var _data_collection_ResetFormModal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(62488);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }







var CircleTickIcon = function CircleTickIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("circle", {
      cx: "12",
      cy: "12",
      r: "11",
      stroke: "#71E69E",
      strokeWidth: "2"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("path", {
      d: "M18.497 7.335c.02.203-.073.372-.198.53L16.532 10.1l-4.764 6.023c-.356.451-.71.904-1.065 1.357-.316.404-.97.41-1.288.009l-3.208-4.062c-.198-.253-.276-.529-.136-.834a.857.857 0 0 1 .763-.529c.262-.018.478.101.64.304.834 1.052 1.667 2.106 2.498 3.16.081.102.082.102.164 0l6.67-8.431c.075-.097.15-.195.228-.29.216-.262.49-.361.824-.28.307.072.672.415.64.807z",
      fill: "#71E69E"
    })]
  }));
};

CircleTickIcon.defaultProps = {
  width: "24",
  height: "24",
  viewBox: "0 0 24 24",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var TabEmptyIcon = function TabEmptyIcon(props) {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("circle", {
      cx: "12",
      cy: "12",
      r: "11",
      stroke: "#BBB",
      strokeWidth: "2"
    })
  }));
};

TabEmptyIcon.defaultProps = {
  width: "24",
  height: "24",
  viewBox: "0 0 24 24",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};



const StyledIcon = styled_components__WEBPACK_IMPORTED_MODULE_5___default()(TabEmptyIcon).withConfig({
  displayName: "SidebarOffices__StyledIcon",
  componentId: "sc-18uo41p-0"
})(["min-height:24px;min-width:24px;margin-right:12px;"]);
const StyledCircleTick = styled_components__WEBPACK_IMPORTED_MODULE_5___default()(CircleTickIcon).withConfig({
  displayName: "SidebarOffices__StyledCircleTick",
  componentId: "sc-18uo41p-1"
})(["min-height:24px;min-width:24px;margin-right:12px;"]);
const SidebarOffices = styled_components__WEBPACK_IMPORTED_MODULE_5___default().div.withConfig({
  displayName: "SidebarOffices",
  componentId: "sc-18uo41p-2"
})(["min-width:265px;max-width:12rem;margin-right:20px;border-right:1px solid ", ";position:relative;"], p => p.theme.colors.secondaryBlue);
const Office = styled_components__WEBPACK_IMPORTED_MODULE_5___default().div.withConfig({
  displayName: "SidebarOffices__Office",
  componentId: "sc-18uo41p-3"
})(["display:flex;flex-direction:row;align-items:flex-start;padding:14px 20px;margin-right:-1px;cursor:pointer;border-right:", ";border-bottom:1px solid ", ";"], p => p.isActive ? `2px solid ${p.theme.colors.blue}` : `1px solid ${p.theme.colors.secondaryBlue}`, p => p.theme.colors.secondaryBlue);
const TextContainer = styled_components__WEBPACK_IMPORTED_MODULE_5___default().div.withConfig({
  displayName: "SidebarOffices__TextContainer",
  componentId: "sc-18uo41p-4"
})(["display:flex;flex-direction:column;& > span:not(:last-child){margin-bottom:0.5rem;}"]);
const ButtonContainer = styled_components__WEBPACK_IMPORTED_MODULE_5___default().div.withConfig({
  displayName: "SidebarOffices__ButtonContainer",
  componentId: "sc-18uo41p-5"
})(["display:flex;width:100%;margin-top:22px;justify-content:center;"]);
const ClearButtonContainer = styled_components__WEBPACK_IMPORTED_MODULE_5___default().div.withConfig({
  displayName: "SidebarOffices__ClearButtonContainer",
  componentId: "sc-18uo41p-6"
})(["position:absolute;bottom:0;left:50%;transform:translate(-50%,0%);"]);

const OfficesSidebar = ({
  handleAddOffice,
  isActiveOffice,
  setActiveOfficeForm,
  handleResetForm,
  countries,
  measurement
}) => {
  var _measurement$office_m, _measurement$office_m2;

  const {
    0: showResetConfirmationModal,
    1: setShowResetConfirmationModal
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(SidebarOffices, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_data_collection_ResetFormModal__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
      showConfirmationModal: showResetConfirmationModal,
      setShowConfirmationModal: setShowResetConfirmationModal,
      onConfirm: handleResetForm
    }), measurement === null || measurement === void 0 ? void 0 : measurement.office_measurements.map((office, index) => {
      var _office$details, _countries$find;

      return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(Office, {
        isActive: isActiveOffice(index),
        onClick: () => setActiveOfficeForm(index),
        children: [!!office.measurement_result ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(StyledCircleTick, {}) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(StyledIcon, {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(TextContainer, {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
            align: "left",
            color: isActiveOffice(index) ? "blue" : "black",
            size: "alert",
            children: ((_office$details = office.details) === null || _office$details === void 0 ? void 0 : _office$details.name) || `Office ${index + 1}`
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
            align: "left",
            color: isActiveOffice(index) ? "blue" : "placeholderGrey",
            size: "meta",
            children: (_countries$find = countries.find(countryObj => {
              var _office$details2;

              return countryObj.value === ((_office$details2 = office.details) === null || _office$details2 === void 0 ? void 0 : _office$details2.country);
            })) === null || _countries$find === void 0 ? void 0 : _countries$find.name
          })]
        })]
      }, index);
    }), !(measurement !== null && measurement !== void 0 && (_measurement$office_m = measurement.office_measurements[0]) !== null && _measurement$office_m !== void 0 && (_measurement$office_m2 = _measurement$office_m.details) !== null && _measurement$office_m2 !== void 0 && _measurement$office_m2.fully_remote) && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(ButtonContainer, {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
        type: "button",
        secondary: true,
        loading: false,
        onClick: async () => {
          await handleAddOffice();
          setActiveOfficeForm(measurement === null || measurement === void 0 ? void 0 : measurement.office_measurements.length);
        },
        children: "Add office"
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(ClearButtonContainer, {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
        type: "button",
        warning: true,
        secondary: true,
        loading: false,
        onClick: () => setShowResetConfirmationModal(!showResetConfirmationModal),
        children: "Clear and restart"
      })
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (OfficesSidebar);

/***/ })

};
;