"use strict";
exports.id = 7438;
exports.ids = [7438];
exports.modules = {

/***/ 47906:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _button_Button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(59067);
/* harmony import */ var _common_ButtonsContainer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(30495);
/* harmony import */ var _MeasurementSection__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(28067);
/* harmony import */ var _utils_applicationMap__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(40516);
/* harmony import */ var _contexts_auth__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(58368);
/* harmony import */ var _contexts_measurements__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(85238);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(11098);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }













const HasCompanyVehicles = ({
  hasVehicles,
  setHasVehicles,
  sectionDisabled
}) => {
  const {
    user
  } = (0,_contexts_auth__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)();
  const {
    selectedMeasurement,
    setSelectedMeasurement
  } = (0,_contexts_measurements__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)();
  const id = "has_company_vehicles";
  const {
    0: close,
    1: setClose
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
  const {
    0: loading,
    1: setLoading
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
  const {
    0: loadingFalse,
    1: setLoadingFalse
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);

  const updateMeasurementHasVehicles = async value => {
    try {
      value ? setLoading(true) : setLoadingFalse(true);
      const {
        data: measurement
      } = await axios__WEBPACK_IMPORTED_MODULE_0___default().patch(`/api/organisations/${user.organisation_id}/measurements/${selectedMeasurement.id}`, _objectSpread({
        has_company_vehicles: value
      }, (0,_utils_applicationMap__WEBPACK_IMPORTED_MODULE_9__/* .shouldUpdateLastCompletedStep */ ._Z)({
        step: id,
        measurement: selectedMeasurement
      }) ? {
        last_completed_step: id
      } : {}));
      setSelectedMeasurement(measurement);
      setHasVehicles(!!measurement.has_company_vehicles);
      setClose(!close);
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_7__/* .logError */ .H)(error);
    }

    value ? setLoading(false) : setLoadingFalse(false);
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_MeasurementSection__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
    id: id,
    title: "Do you have any company owned vehicles?",
    value: hasVehicles ? "Yes" : "No",
    sectionDisabled: sectionDisabled,
    defaultOpen: selectedMeasurement.has_company_vehicles === null && !sectionDisabled,
    close: close,
    setClose: setClose,
    required: true,
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(_common_ButtonsContainer__WEBPACK_IMPORTED_MODULE_3__/* .OfficeButtonsContainer */ .g, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
        onClick: async () => await updateMeasurementHasVehicles(true),
        loading: loading,
        disabled: loadingFalse,
        children: "Yes"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
        onClick: async () => await updateMeasurementHasVehicles(false),
        loading: loadingFalse,
        disabled: loading,
        children: "No"
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HasCompanyVehicles);

/***/ }),

/***/ 45960:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61908);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(45641);
/* harmony import */ var _button_Button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(59067);
/* harmony import */ var _common_Divider__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6459);
/* harmony import */ var _form_Input__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(18183);
/* harmony import */ var _form_InputDropdown__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(51894);
/* harmony import */ var _common_ButtonsContainer__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(30495);
/* harmony import */ var _common_Form__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(79397);
/* harmony import */ var _common_FormGroup__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(13586);
/* harmony import */ var _MeasurementArraySection__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(98782);
/* harmony import */ var _MeasurementSection__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(28067);
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(19390);
/* harmony import */ var _contexts_auth__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(58368);
/* harmony import */ var _contexts_measurements__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(85238);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(11098);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(75609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__, react_hook_form__WEBPACK_IMPORTED_MODULE_3__, _form_Input__WEBPACK_IMPORTED_MODULE_6__, _form_InputDropdown__WEBPACK_IMPORTED_MODULE_7__]);
([_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__, react_hook_form__WEBPACK_IMPORTED_MODULE_3__, _form_Input__WEBPACK_IMPORTED_MODULE_6__, _form_InputDropdown__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





















const schema = yup__WEBPACK_IMPORTED_MODULE_17__.object().shape({
  vehicle_usage: yup__WEBPACK_IMPORTED_MODULE_17__.array().of(yup__WEBPACK_IMPORTED_MODULE_17__.object().shape({
    distance: yup__WEBPACK_IMPORTED_MODULE_17__.number().required("Distance is required").typeError("Distance must be a valid number"),
    vehicle: yup__WEBPACK_IMPORTED_MODULE_17__.object().shape({
      registration_number: yup__WEBPACK_IMPORTED_MODULE_17__.string()
    })
  }))
});

const VehicleUsage = ({
  hasVehicles,
  sectionDisabled
}) => {
  const {
    user
  } = (0,_contexts_auth__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z)();
  const {
    selectedMeasurement,
    setSelectedMeasurement,
    updateLastCompletedStep
  } = (0,_contexts_measurements__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z)();
  const {
    0: deleteLoading,
    1: setDeleteLoading
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)();
  const id = "vehicle_usage";
  const methods = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_3__.useForm)({
    shouldUnregister: false,
    resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__.yupResolver)(schema),
    defaultValues: {
      vehicle_usage: selectedMeasurement.vehicle_usage.map(vehicleUsage => {
        var _vehicleUsage$vehicle;

        return {
          id: vehicleUsage.id,
          distance: vehicleUsage.distance,
          period: _utils_constants__WEBPACK_IMPORTED_MODULE_13__/* .PERIODS.find */ .z5.find(mode => mode.value === vehicleUsage.period),
          metric: _utils_constants__WEBPACK_IMPORTED_MODULE_13__/* .DISTANCE_METRICS.find */ .Kk.find(metric => metric.value === (vehicleUsage === null || vehicleUsage === void 0 ? void 0 : vehicleUsage.metric)),
          vehicle: {
            registration_number: (_vehicleUsage$vehicle = vehicleUsage.vehicle) === null || _vehicleUsage$vehicle === void 0 ? void 0 : _vehicleUsage$vehicle.registration_number
          }
        };
      })
    }
  });
  const {
    fields,
    append,
    move,
    remove
  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_3__.useFieldArray)({
    control: methods.control,
    name: "vehicle_usage"
  });

  const deleteVehicleUsage = async (id, index) => {
    setDeleteLoading(true);

    try {
      await axios__WEBPACK_IMPORTED_MODULE_1___default()["delete"](`/api/organisations/${user.organisation_id}/measurements/${selectedMeasurement.id}/vehicle-usage/${id}`);
      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`/api/organisations/${user.organisation_id}/measurements/${selectedMeasurement.id}`);
      setSelectedMeasurement(data);
      remove(index);
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_16__/* .logError */ .H)(error);
    }

    setDeleteLoading(false);
  };

  const upsertVehicleUsage = async ({
    vehicle_usage
  }, cb) => {
    try {
      const newVehicles = [];
      const existingVehicles = [];
      const newVehicleUsage = [];
      const existingVehicleUsage = [];
      const vehicles = vehicle_usage.map(vehicleUsage => vehicleUsage.vehicle);
      const mVehicles = selectedMeasurement.vehicle_usage.map(vehicleUsage => vehicleUsage.vehicle).filter(vehicle => vehicle !== undefined);
      vehicles.forEach(vehicle => {
        if (mVehicles.find(mvehicle => vehicle.id === mvehicle.id)) {
          return existingVehicles.push(vehicle);
        }

        newVehicles.push(vehicle);
      });
      vehicle_usage.filter(({
        distance
      }) => !!distance).forEach(vehicleUsage => {
        if (selectedMeasurement.vehicle_usage.find(mvehicleUsage => vehicleUsage.id === mvehicleUsage.id)) {
          return existingVehicleUsage.push(vehicleUsage);
        }

        newVehicleUsage.push(vehicleUsage);
      });
      const results = await Promise.all([...newVehicles.map(({
        registration_number
      }) => axios__WEBPACK_IMPORTED_MODULE_1___default().post(`/api/organisations/${user.organisation_id}/vehicles`, {
        registration_number
      })), ...existingVehicles.map(({
        id,
        registration_number
      }) => axios__WEBPACK_IMPORTED_MODULE_1___default().patch(`/api/organisations/${user.organisation_id}/vehicles/${id}`, {
        registration_number
      }))]);
      const createdVehicles = results.map(res => res.data);
      await axios__WEBPACK_IMPORTED_MODULE_1___default().post(`/api/organisations/${user.organisation_id}/measurements/${selectedMeasurement.id}/vehicle-usage/batch`, {
        create: newVehicleUsage.map(({
          period,
          metric,
          distance,
          vehicle
        }) => {
          var _find;

          return {
            period: period.value,
            distance: parseInt(distance),
            metric: metric.value,
            vehicle_id: (_find = [...createdVehicles, ...existingVehicles].find(currentVehicle => currentVehicle.registration_number === vehicle.registration_number)) === null || _find === void 0 ? void 0 : _find.id
          };
        }),
        update: existingVehicleUsage.map(({
          period,
          metric,
          distance,
          id,
          vehicle
        }) => {
          var _find2;

          return {
            id,
            period: period.value,
            metric: metric.value,
            distance: parseInt(distance),
            vehicle_id: (_find2 = [...createdVehicles, ...existingVehicles].find(currentVehicle => currentVehicle.registration_number === vehicle.registration_number)) === null || _find2 === void 0 ? void 0 : _find2.id
          };
        })
      });
      const data = await updateLastCompletedStep(id);
      methods.reset({
        vehicle_usage: data.vehicle_usage.map(vehicleUsage => {
          var _vehicleUsage$vehicle2;

          return {
            id: vehicleUsage.id,
            distance: vehicleUsage.distance,
            period: _utils_constants__WEBPACK_IMPORTED_MODULE_13__/* .PERIODS.find */ .z5.find(mode => mode.value === vehicleUsage.period),
            metric: _utils_constants__WEBPACK_IMPORTED_MODULE_13__/* .DISTANCE_METRICS.find */ .Kk.find(metric => metric.value === (vehicleUsage === null || vehicleUsage === void 0 ? void 0 : vehicleUsage.metric)),
            vehicle: {
              registration_number: (_vehicleUsage$vehicle2 = vehicleUsage.vehicle) === null || _vehicleUsage$vehicle2 === void 0 ? void 0 : _vehicleUsage$vehicle2.registration_number
            }
          };
        })
      });
      cb();
    } catch (error) {
      throw error;
    }
  };

  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(() => {
    if (!selectedMeasurement.vehicle_usage.length) {
      append({
        distance: "",
        period: null,
        metric: {
          label: "Kilometres",
          value: "km"
        },
        vehicle: {
          registration_number: ""
        }
      });
    }
  }, []);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_MeasurementSection__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
    id: id,
    title: "Company Vehicles",
    onNextClick: methods.handleSubmit(upsertVehicleUsage),
    sectionDisabled: sectionDisabled,
    value: `${selectedMeasurement.vehicle_usage.length} ${selectedMeasurement.vehicle_usage.length === 1 ? "vehicle" : "vehicles"}`,
    nextDisabled: !fields.length,
    required: selectedMeasurement.has_company_vehicles,
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_common_Form__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
      onSubmit: methods.handleSubmit(upsertVehicleUsage),
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)(react_hook_form__WEBPACK_IMPORTED_MODULE_3__.FormProvider, _objectSpread(_objectSpread({}, methods), {}, {
        children: [fields && fields.map((vehicle_usage, index) => {
          var _DISTANCE_METRICS$fin, _vehicle_usage$vehicl;

          return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx("div", {
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)(_MeasurementArraySection__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
              title: `Car ${vehicle_usage.vehicle && vehicle_usage.vehicle.registration_number ? vehicle_usage.vehicle.registration_number : index + 1}`,
              value: `${vehicle_usage.distance} ${(_DISTANCE_METRICS$fin = _utils_constants__WEBPACK_IMPORTED_MODULE_13__/* .DISTANCE_METRICS.find */ .Kk.find(metric => {
                var _vehicle_usage$metric;

                return metric.value === (vehicle_usage === null || vehicle_usage === void 0 ? void 0 : (_vehicle_usage$metric = vehicle_usage.metric) === null || _vehicle_usage$metric === void 0 ? void 0 : _vehicle_usage$metric.value);
              })) === null || _DISTANCE_METRICS$fin === void 0 ? void 0 : _DISTANCE_METRICS$fin.label}`,
              defaultOpen: !vehicle_usage.distance,
              closeLoading: deleteLoading,
              onClose: async () => Number.isInteger(vehicle_usage.id) ? await deleteVehicleUsage(vehicle_usage.id, index) : remove(index),
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx("input", {
                name: `id`,
                disabled: true,
                hidden: true,
                defaultValue: vehicle_usage.id
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_form_Input__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                id: `vehicle_usage.${index}.vehicle.registration_number`,
                name: `vehicle_usage.${index}.vehicle.registration_number`,
                testId: `vehicle_usage.${index}.vehicle.registration_number`,
                width: "50%",
                placeholder: "Registration Number (Optional)...",
                defaultValue: (_vehicle_usage$vehicl = vehicle_usage.vehicle) === null || _vehicle_usage$vehicl === void 0 ? void 0 : _vehicle_usage$vehicl.registration_number
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_form_InputDropdown__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                id: `vehicle_usage.${index}.period`,
                width: "50%",
                placeholder: "Please select timeframe...",
                optionArray: _utils_constants__WEBPACK_IMPORTED_MODULE_13__/* .PERIODS */ .z5,
                defaultValue: vehicle_usage.period,
                hasDefaultValue: false
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)(_common_FormGroup__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                align: "flex-start",
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_form_InputDropdown__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                  id: `vehicle_usage.${index}.metric`,
                  width: "18.5%",
                  placeholder: "Select metric...",
                  optionArray: _utils_constants__WEBPACK_IMPORTED_MODULE_13__/* .DISTANCE_METRICS */ .Kk,
                  defaultValue: vehicle_usage.metric
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_form_Input__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                  id: `vehicle_usage.${index}.distance`,
                  name: `vehicle_usage.${index}.distance`,
                  testId: `vehicle_usage.${index}.distance`,
                  width: "30%",
                  placeholder: "Distance travelled",
                  type: "number",
                  isRequired: true,
                  defaultValue: vehicle_usage.distance
                })]
              })]
            })
          }, vehicle_usage.id);
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_common_Divider__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
          margin: "0.5rem 0 2rem",
          width: "70%"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_common_ButtonsContainer__WEBPACK_IMPORTED_MODULE_8__/* .OfficeButtonsContainer */ .g, {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP, {
            type: "button",
            onClick: () => append({
              distance: "",
              period: null,
              metric: {
                label: "Kilometres",
                value: "km"
              },
              vehicle: {
                registration_number: ""
              }
            }),
            children: "Add more"
          })
        })]
      }))
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (VehicleUsage);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;