"use strict";
exports.id = 8782;
exports.ids = [8782];
exports.modules = {

/***/ 98782:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _button_Button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59067);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(87491);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);







const Container = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
  displayName: "MeasurementArraySection__Container",
  componentId: "sc-11y5150-0"
})(["display:flex;flex-direction:", ";justify-content:space-between;width:100%;padding:1.5rem 0;"], p => p.open ? "column" : "row");
const DescriptionTextContainer = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
  displayName: "MeasurementArraySection__DescriptionTextContainer",
  componentId: "sc-11y5150-1"
})(["", ""], p => p.open && "margin-bottom: 3rem;");
const EditContainer = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
  displayName: "MeasurementArraySection__EditContainer",
  componentId: "sc-11y5150-2"
})(["background:", ";border-radius:10px;padding:0.625rem;display:flex;align-items:center;max-width:85%;"], p => p.theme.colors.white);
const ValueContainer = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
  displayName: "MeasurementArraySection__ValueContainer",
  componentId: "sc-11y5150-3"
})(["margin-right:1.25rem;"]);
const ButtonContainer = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
  displayName: "MeasurementArraySection__ButtonContainer",
  componentId: "sc-11y5150-4"
})(["margin-left:1rem;display:inline-block;"]);

const MeasurementArraySection = ({
  title,
  value,
  children,
  defaultOpen,
  onClose,
  closeLoading
}) => {
  const {
    0: open,
    1: setOpen
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(!!defaultOpen);
  const fieldRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    fieldRef.current && fieldRef.current.scrollIntoView({
      behavior: "smooth",
      block: "center"
    });
  }, [open]);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(Container, {
    open: open,
    ref: fieldRef,
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(DescriptionTextContainer, {
      open: open,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
        size: "cardTitle",
        children: title
      }), open && onClose && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(ButtonContainer, {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
          small: true,
          warning: true,
          onClick: onClose,
          loading: closeLoading,
          children: "Remove"
        })
      })]
    }), !open ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(EditContainer, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(ValueContainer, {
        children: typeof value === "string" ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
          size: "subtitle",
          color: "blue",
          children: value
        }) : value
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
        small: true,
        onClick: () => setOpen(!open),
        children: "Edit"
      }), onClose && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(ButtonContainer, {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP, {
          small: true,
          warning: true,
          onClick: onClose,
          loading: closeLoading,
          type: "button",
          children: "Remove"
        })
      })]
    }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.Fragment, {
      children: children
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MeasurementArraySection);

/***/ })

};
;