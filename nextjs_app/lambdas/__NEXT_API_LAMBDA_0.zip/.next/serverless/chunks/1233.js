"use strict";
exports.id = 1233;
exports.ids = [1233];
exports.modules = {

/***/ 54251:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export labelStyles */
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const labelStyles = (0,styled_components__WEBPACK_IMPORTED_MODULE_0__.css)(["color:", ";font-weight:", ";font-size:", ";"], p => p.color ? p.color : p.theme.colors.label, p => p.fontWeight || p.theme.body.weight, p => p.theme.tiny.size);
const Label = styled_components__WEBPACK_IMPORTED_MODULE_0___default().label.withConfig({
  displayName: "Label",
  componentId: "l08cxq-0"
})(["", " margin:", ";", ""], labelStyles, p => p.margin || " 0 0.125rem 0.1rem", p => p.block && "display:block;");
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Label);

/***/ }),

/***/ 19390:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "z5": () => (/* binding */ PERIODS),
/* harmony export */   "j3": () => (/* binding */ WASTE_PERIODS),
/* harmony export */   "Kk": () => (/* binding */ DISTANCE_METRICS),
/* harmony export */   "X9": () => (/* binding */ SPACE_METRICS),
/* harmony export */   "Qj": () => (/* binding */ GAS_ELECTRICTY_METRICS),
/* harmony export */   "Se": () => (/* binding */ WATER_METRICS),
/* harmony export */   "Nx": () => (/* binding */ EXCLUDED_CHART_KEYS)
/* harmony export */ });
/* unused harmony exports PERIODS_INTEGER, PERIODS_INTEGER_QUARTERS, WASTE_METRICS */
const PERIODS_INTEGER = [{
  label: "Quarter",
  value: 2,
  id: "quarter"
}, {
  label: "Bi-Annual",
  value: 5,
  id: "bi-annual"
}, {
  label: "Annual",
  value: 11,
  id: "annual"
}];
const PERIODS_INTEGER_QUARTERS = [{
  label: "Quarter",
  value: 1,
  id: "quarter"
}, {
  label: "Bi-Annual",
  value: 2,
  id: "bi-annual"
}, {
  label: "Annual",
  value: 4,
  id: "annual"
}];
const PERIODS = [{
  label: "Quarterly",
  value: "quarter",
  id: "quarter"
}, {
  label: "Bi-Annually",
  value: "bi-annual",
  id: "bi-annual"
}, {
  label: "Annually",
  value: "annual",
  id: "annual"
}];
const WASTE_PERIODS = [{
  label: "Weekly",
  value: "week",
  id: "week"
}, {
  label: "Monthly",
  value: "month",
  id: "month"
}, ...PERIODS];
const DISTANCE_METRICS = [{
  label: "km",
  value: "km"
}, {
  label: "mi",
  value: "miles"
}];
const SPACE_METRICS = [{
  label: "m²",
  value: "m2"
}, {
  label: "ft²",
  value: "sqft"
}];
const GAS_ELECTRICTY_METRICS = [{
  label: "kWh",
  value: "kwh"
}, {
  label: "GBP",
  value: "gbp"
}];
const WATER_METRICS = [{
  label: "m3",
  value: "m3"
}, {
  label: "GBP",
  value: "gbp"
}];
const WASTE_METRICS = [{
  label: "kg",
  value: "kg"
}, {
  label: "Bin Bags",
  value: "bin_bags"
}];
const EXCLUDED_CHART_KEYS = ["scope_1", "scope_2", "scope_3", "homeworking_gas", "homeworking_electricity", "waste_recycling", "waste_landfill", "id", "created_at", "updated_at", "measurement_id", "water_treated", "water_supply", "total", "office_measurements_id", "utilities", "employee_commutes"];

/***/ })

};
;