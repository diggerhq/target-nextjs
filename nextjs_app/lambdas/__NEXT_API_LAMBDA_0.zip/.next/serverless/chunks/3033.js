"use strict";
exports.id = 3033;
exports.ids = [3033];
exports.modules = {

/***/ 63033:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "fc": () => (/* binding */ calculateNumberOfMiles),
/* harmony export */   "Qd": () => (/* binding */ calculateNumberOfMilesBusinessTravel),
/* harmony export */   "sU": () => (/* binding */ countViewModeTravels),
/* harmony export */   "LB": () => (/* binding */ countViewModeVehicleUsage),
/* harmony export */   "rS": () => (/* binding */ EMPLOYEE_COMMUTES_MODES_OF_TRANSPORT),
/* harmony export */   "Ho": () => (/* binding */ BUSINESS_TRAVEL_MODES_OF_TRANSPORT),
/* harmony export */   "Kh": () => (/* binding */ VEHICLE_USAGE_MODES_OF_TRANSPORT),
/* harmony export */   "L8": () => (/* binding */ WASTE_UNITS),
/* harmony export */   "XM": () => (/* binding */ utilitiesOrderArray),
/* harmony export */   "dh": () => (/* binding */ wasteOrderArray),
/* harmony export */   "_u": () => (/* binding */ checkMeasurementHasResults)
/* harmony export */ });
const ONE_MILE_IN_KM = 1.60934;

const sortAlphabetically = (a, b) => a.label.toLowerCase().localeCompare(b.label.toLowerCase());

const calculateNumberOfMiles = travelArray => {
  return travelArray.reduce((sum, next) => {
    if (next.unit === "km") return sum + next.value * (1 / ONE_MILE_IN_KM);
    return sum + next.value;
  }, 0);
};
const calculateNumberOfMilesBusinessTravel = travelArray => {
  return travelArray.reduce((sum, next) => {
    if (next.unit === "km") return sum + next.distance * (1 / ONE_MILE_IN_KM);
    return sum + next.distance;
  }, 0);
};
const countViewModeTravels = travelArray => {
  let travelDataObject = {};
  travelArray.forEach(travel => {
    var _find;

    let modeLabel = (_find = [...BUSINESS_TRAVEL_MODES_OF_TRANSPORT, ...EMPLOYEE_COMMUTES_MODES_OF_TRANSPORT].find(element => travel.mode === element.value)) === null || _find === void 0 ? void 0 : _find.label;
    if (!travelDataObject[modeLabel]) return travelDataObject[modeLabel] = 1;else return travelDataObject[modeLabel] += 1;
  });
  return Object.entries(travelDataObject).map(([key, value]) => ({
    title: key,
    value: value
  }));
};
const countViewModeVehicleUsage = travelArray => {
  let travelDataObject = {};
  travelArray.forEach(travel => {
    var _VEHICLE_USAGE_MODES_;

    let modeLabel = (_VEHICLE_USAGE_MODES_ = VEHICLE_USAGE_MODES_OF_TRANSPORT.find(element => travel.mode === element.value)) === null || _VEHICLE_USAGE_MODES_ === void 0 ? void 0 : _VEHICLE_USAGE_MODES_.label;
    if (!travelDataObject[modeLabel]) return travelDataObject[modeLabel] = 1;else return travelDataObject[modeLabel] += 1;
  });
  return Object.entries(travelDataObject).map(([key, value]) => ({
    title: key,
    value: value
  }));
};
const TRANSPORT_MODES = {
  flight: [{
    value: "flight_domestic",
    label: "Flight: Domestic UK"
  }, {
    value: "flight_short_haul",
    label: "Flight: Short Haul"
  }, {
    value: "flight_long_haul",
    label: "Flight: Long Haul"
  }, {
    value: "flight_international",
    label: "Flight: International (Non UK)"
  }],
  bus: [{
    value: "bus",
    label: "Bus"
  }, {
    value: "local_london_bus",
    label: "Bus: London"
  }],
  car: [{
    value: "average_car_petrol",
    label: "Car: Petrol"
  }, {
    value: "average_car_diesel",
    label: "Car: Diesel"
  }, {
    value: "average_car_hybrid",
    label: "Car: Hybrid"
  }, {
    value: "average_car_electric",
    label: "Car: Electric"
  }],
  taxi: [{
    value: "taxi_regular",
    label: "Taxi"
  }],
  train: [{
    value: "train_national",
    label: "Train: National"
  }, {
    value: "train_international",
    label: "Train: International"
  }],
  commute_train: [{
    value: "train_national",
    label: "Train"
  }],
  london_underground: [{
    value: "light_rail_or_tram",
    label: "Tram"
  }, {
    value: "london_underground",
    label: "London Underground"
  }],
  carbon_neutral: [{
    value: "bicycle",
    label: "Bicycle"
  }, {
    value: "walk",
    label: "Walk"
  }]
};
const EMPLOYEE_COMMUTES_MODES_OF_TRANSPORT = ["car", "commute_train", "bus", "london_underground", "taxi", "carbon_neutral"].map(key => TRANSPORT_MODES[key]).flat().sort(sortAlphabetically);
const BUSINESS_TRAVEL_MODES_OF_TRANSPORT = ["car", "flight", "london_underground", "train"].map(key => TRANSPORT_MODES[key]).flat().sort(sortAlphabetically);
const VEHICLE_USAGE_MODES_OF_TRANSPORT = ["car"].map(key => TRANSPORT_MODES[key]).flat().sort(sortAlphabetically);
const WASTE_UNITS = [{
  label: "kg",
  value: "kg"
}, {
  label: "Bin Bags",
  value: "bin_bags"
}];
const utilitiesOrderArray = ["gas", "electricity", "water"];
const wasteOrderArray = ["landfill", "recycling"];
const checkMeasurementHasResults = measurement => {
  var _measurement$office_m, _measurement$office_m2;

  return !!(measurement !== null && measurement !== void 0 && (_measurement$office_m = measurement.office_measurements) !== null && _measurement$office_m !== void 0 && (_measurement$office_m2 = _measurement$office_m.filter(office => !!office.measurement_result)) !== null && _measurement$office_m2 !== void 0 && _measurement$office_m2.length);
};

/***/ })

};
;