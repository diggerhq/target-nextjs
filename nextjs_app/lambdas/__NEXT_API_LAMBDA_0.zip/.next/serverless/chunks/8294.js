"use strict";
exports.id = 8294;
exports.ids = [8294];
exports.modules = {

/***/ 48294:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ settings_Menu)
});

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(71853);
// EXTERNAL MODULE: ./src/theme.js
var theme = __webpack_require__(91073);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(57518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(41664);
// EXTERNAL MODULE: ./src/components/common/Text.jsx
var Text = __webpack_require__(87491);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
;// CONCATENATED MODULE: ./src/components/settings/MenuItem.jsx






const TextConatiner = external_styled_components_default().div.withConfig({
  displayName: "MenuItem__TextConatiner",
  componentId: "sc-1hq6ekt-0"
})(["display:flex;flex-direction:column;justify-content:center;height:100%;width:100%;margin:auto 0;"]);
const IconContainer = external_styled_components_default().div.withConfig({
  displayName: "MenuItem__IconContainer",
  componentId: "sc-1hq6ekt-1"
})(["display:flex;border-radius:10px;margin-right:0.5rem;& > svg{height:1rem;width:1rem;fill:", ";}"], p => p.active ? p.theme.colors.blue : p.theme.colors.black);
const Title = external_styled_components_default().div.withConfig({
  displayName: "MenuItem__Title",
  componentId: "sc-1hq6ekt-2"
})([""]);
const Description = external_styled_components_default().div.withConfig({
  displayName: "MenuItem__Description",
  componentId: "sc-1hq6ekt-3"
})([""]);
const Container = external_styled_components_default().div.withConfig({
  displayName: "MenuItem__Container",
  componentId: "sc-1hq6ekt-4"
})(["display:flex;height:4.75rem;width:100%;align-items:center;cursor:pointer;&:not(:last-child) > ", "{border-bottom:1px solid ", ";}", " &:hover{", "}"], TextConatiner, p => p.theme.colors.secondaryBlue, theme/* media.tablet */.BC.tablet`
    height: 4rem;
    width: 11rem;
    align-items: center;
  `, p => !p.active && `
    ${Title} > span {
      font-weight: 400;
    }
    ${Description} > span {
      font-weight: 400;
    }
    
    `);

const MenuItem = ({
  icon,
  title,
  description,
  link,
  active
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
    href: `${link}`,
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(Container, {
      active: active,
      children: [/*#__PURE__*/jsx_runtime_.jsx(IconContainer, {
        active: active,
        children: icon
      }), /*#__PURE__*/jsx_runtime_.jsx(TextConatiner, {
        children: /*#__PURE__*/jsx_runtime_.jsx(Title, {
          children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
            size: "meta",
            color: active ? "blue" : undefined,
            children: title
          })
        })
      })]
    })
  });
};

/* harmony default export */ const settings_MenuItem = (MenuItem);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
;// CONCATENATED MODULE: ./src/components/settings/Menu.jsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }







const Menu_Container = external_styled_components_default().div.withConfig({
  displayName: "Menu__Container",
  componentId: "sc-5hzwh0-0"
})(["", " width:90%;height:100%;z-index:1;background:", ";overflow-y:scroll;&::-webkit-scrollbar{display:none;}::-webkit-scrollbar-thumb{background:", ";border-radius:10px;}", ";"], p => p.absolute && "position: absolute;", p => theme/* default.colors.backgroundGrey */.ZP.colors.backgroundGrey, p => p.theme.colors.secondaryBlue, theme/* media.tablet */.BC.tablet`
    height: auto;
    z-index: initial;
    width: unset;
    position: initial;
    border-right: 1px solid ${p => p.theme.colors.secondaryBlue};
  `);

const Menu = ({
  pages,
  route
}) => {
  const router = (0,router_.useRouter)();
  const pathname = router.pathname.split("/");
  const currentPath = pathname[pathname.length - 1];

  const createLink = path => `${route}/${path}`;

  const defaultPages = ["admin", "personal"];
  return /*#__PURE__*/jsx_runtime_.jsx(Menu_Container, {
    absolute: !defaultPages.includes(currentPath),
    children: pages.map((page, index) => /*#__PURE__*/(0,external_react_.createElement)(settings_MenuItem, _objectSpread(_objectSpread({}, _objectSpread(_objectSpread({}, page), {}, {
      link: createLink(page.path)
    })), {}, {
      active: currentPath === page.path,
      key: `${page.link}-${index}`
    })))
  });
};

/* harmony default export */ const settings_Menu = (Menu);

/***/ })

};
;