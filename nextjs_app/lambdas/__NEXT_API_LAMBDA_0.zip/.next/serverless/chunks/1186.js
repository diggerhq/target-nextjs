"use strict";
exports.id = 1186;
exports.ids = [1186];
exports.modules = {

/***/ 12255:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const BigLabelTextContainer = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "BigLabelTextContainer",
  componentId: "sc-1g51wl0-0"
})(["margin:2.25rem 0;"]);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BigLabelTextContainer);

/***/ }),

/***/ 51186:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61908);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(45641);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(87491);
/* harmony import */ var _form_Input__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(18183);
/* harmony import */ var _form_Slider__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(83864);
/* harmony import */ var _common_DescriptionTextContainer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1069);
/* harmony import */ var _common_Form__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(79397);
/* harmony import */ var _MeasurementSection__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(28067);
/* harmony import */ var _utils_applicationMap__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(40516);
/* harmony import */ var _contexts_auth__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(58368);
/* harmony import */ var _contexts_measurements__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(85238);
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(16170);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(75609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _common_BigLabelTextContainer__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(12255);
/* harmony import */ var _common_FormGroup__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(13586);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__, react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _form_Input__WEBPACK_IMPORTED_MODULE_4__, _form_Slider__WEBPACK_IMPORTED_MODULE_5__]);
([_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__, react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _form_Input__WEBPACK_IMPORTED_MODULE_4__, _form_Slider__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



















const schema = yup__WEBPACK_IMPORTED_MODULE_11__.object().shape({
  number_of_staff: yup__WEBPACK_IMPORTED_MODULE_11__.number().required("Please enter the number of staff at your office").min(1).max(Number.MAX_SAFE_INTEGER).typeError("Please enter the number of staff at your office"),
  staff_working_from_home_percentage: yup__WEBPACK_IMPORTED_MODULE_11__.number().required("Please enter the number of staff at your office").min(0).max(Number.MAX_SAFE_INTEGER).typeError("Please enter the number of staff at your office")
});

const Staff = ({
  sectionDisabled
}) => {
  const {
    user,
    organisation,
    setOrganisation
  } = (0,_contexts_auth__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)();
  const {
    selectedMeasurement,
    setSelectedMeasurement
  } = (0,_contexts_measurements__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)();
  const id = "staff";
  const methods = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_2__.useForm)({
    resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__.yupResolver)(schema),
    defaultValues: {
      number_of_staff: selectedMeasurement.number_of_staff || organisation.max_users_count,
      staff_working_from_home_percentage: selectedMeasurement.staff_working_from_home_percentage || 0
    }
  });

  const updateMeasurementStaff = async ({
    number_of_staff,
    staff_working_from_home_percentage
  }, cb) => {
    try {
      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_1___default().patch(`/api/organisations/${user.organisation_id}/measurements/${selectedMeasurement.id}`, _objectSpread({
        number_of_staff: parseInt(number_of_staff),
        staff_working_from_home_percentage
      }, (0,_utils_applicationMap__WEBPACK_IMPORTED_MODULE_15__/* .shouldUpdateLastCompletedStep */ ._Z)({
        step: id,
        measurement: selectedMeasurement
      }) ? {
        last_completed_step: id
      } : {}));
      setSelectedMeasurement(data);
      cb();
    } catch (error) {
      throw error;
    }
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_MeasurementSection__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
    id: id,
    title: "Staff",
    onNextClick: methods.handleSubmit(updateMeasurementStaff),
    disabled: !organisation.net_zero_target,
    sectionDisabled: sectionDisabled,
    value: `${selectedMeasurement.number_of_staff || 0} staff` + " " + `${selectedMeasurement.staff_working_from_home_percentage || 0}% WFH`,
    defaultOpen: organisation.net_zero_target && (!selectedMeasurement.number_of_staff || (0,_utils_constants__WEBPACK_IMPORTED_MODULE_16__/* .isFalsy */ .X0)(selectedMeasurement.staff_working_from_home_percentage)),
    required: true,
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(_common_Form__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
      onSubmit: methods.handleSubmit(updateMeasurementStaff),
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_common_DescriptionTextContainer__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.FormProvider, _objectSpread(_objectSpread({}, methods), {}, {
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(_common_FormGroup__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP, {
            size: "cardTitle",
            children: "Total staff:"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_form_Input__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
            id: "number_of_staff",
            name: "number_of_staff",
            testId: "number_of_staff",
            width: "30%",
            type: "number",
            isRequired: true
          })]
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_common_BigLabelTextContainer__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP, {
            size: "cardTitle",
            children: "Average % of staff working from home across the period:"
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_form_Slider__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
          id: "staff_working_from_home_percentage",
          min: 0,
          max: 100,
          defaultValue: 0,
          marks: [{
            value: 0,
            label: "0%"
          }, {
            value: 25,
            label: "25%"
          }, {
            value: 50,
            label: "50%"
          }, {
            value: 75,
            label: "75%"
          }, {
            value: 100,
            label: "100%"
          }],
          valueLabelDisplay: "auto",
          step: 1
        })]
      }))]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Staff);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;