"use strict";
exports.id = 9343;
exports.ids = [9343];
exports.modules = {

/***/ 19343:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "e": () => (/* binding */ formatChartLabels),
/* harmony export */   "d": () => (/* binding */ createTotalMeasurementResults)
/* harmony export */ });
/* harmony import */ var _utils_text__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(88703);

const formatChartLabels = label => {
  const formattedLabels = {
    gas: "Company facilities",
    expenses: "Purchased goods",
    vehicle_usage: "Vehicles",
    homeworking: "Homeworking",
    projected_employee_commutes: "Employee commutes"
  };
  return (0,_utils_text__WEBPACK_IMPORTED_MODULE_0__/* .truncate */ .$)(Object.keys(formattedLabels).includes(label) ? formattedLabels[label] : label.replaceAll("_", " ").replace(/^\w/, c => c.toUpperCase()), 15);
};
const createTotalMeasurementResults = measurement => {
  var _measurement$office_m, _measurement$office_m2;

  const allResults = measurement === null || measurement === void 0 ? void 0 : (_measurement$office_m = measurement.office_measurements) === null || _measurement$office_m === void 0 ? void 0 : (_measurement$office_m2 = _measurement$office_m.filter(office => !!office.measurement_result)) === null || _measurement$office_m2 === void 0 ? void 0 : _measurement$office_m2.map(o => o.measurement_result);
  return allResults === null || allResults === void 0 ? void 0 : allResults.reduce((prev, curr) => {
    const keys = Object.keys(curr);

    for (const key of keys) {
      if (!prev[key]) {
        prev[key] = curr[key];
      } else {
        prev[key] += curr[key];
      }
    }

    return prev;
  }, {});
};

/***/ })

};
;