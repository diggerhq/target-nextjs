"use strict";
exports.id = 661;
exports.ids = [661];
exports.modules = {

/***/ 40833:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ form_PasswordCriteria)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
// EXTERNAL MODULE: ./src/components/common/Text.jsx
var Text = __webpack_require__(87491);
;// CONCATENATED MODULE: ./src/lib/password.js
const rules = [{
  message: "Min 8 characters",
  pattern: /.{8,}/
}, {
  message: "Lowercase",
  pattern: /[a-z]/
}, {
  message: "Number",
  pattern: /[0-9]/
}, {
  message: "Uppercase",
  pattern: /[A-Z]/
}, {
  message: "Special character",
  pattern: /[$&+,:;=?@#|'<>.^*()%!-]/
}];
const defaultValidationState = rules.map(({
  message
}) => ({
  message,
  valid: false
}));
const validatePassword = password => {
  if (!password) return defaultValidationState;
  const currentValidationState = rules.map(({
    message,
    pattern
  }) => ({
    message,
    valid: pattern.test(password) ? true : false
  }));
  return currentValidationState;
};
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(57518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
;// CONCATENATED MODULE: ./src/components/form/PasswordCriteria.jsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




var CriteriaTickIcon = function CriteriaTickIcon(props) {
  return /*#__PURE__*/jsx_runtime_.jsx("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: /*#__PURE__*/jsx_runtime_.jsx("path", {
      d: "M14.995.963c.024.233-.088.429-.238.61l-2.12 2.575-5.717 6.936c-.427.52-.853 1.04-1.278 1.563-.38.465-1.165.473-1.546.01A6506.57 6506.57 0 0 1 .247 7.98c-.238-.291-.331-.61-.164-.96.178-.375.492-.582.915-.61.315-.021.575.116.768.35 1.002 1.212 2.001 2.425 2.999 3.64.097.116.098.116.196 0 2.667-3.237 5.335-6.474 8.004-9.71.09-.111.18-.224.273-.333a.94.94 0 0 1 .99-.324c.368.083.806.479.767.93z"
    })
  }));
};

CriteriaTickIcon.defaultProps = {
  width: "15",
  height: "13",
  viewBox: "0 0 15 13",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};





const PasswordCriteriaContainer = external_styled_components_default().div.withConfig({
  displayName: "PasswordCriteria__PasswordCriteriaContainer",
  componentId: "sc-1bq970u-0"
})(["display:flex;flex-wrap:wrap;"]);
const Criteria = external_styled_components_default().div.withConfig({
  displayName: "PasswordCriteria__Criteria",
  componentId: "sc-1bq970u-1"
})(["border-radius:10px;height:2rem;display:flex;align-items:center;padding:0.125rem 0.625rem;background-color:", ";margin:0.375rem 0;&:not(:last-child){margin-right:0.625rem;}& > svg{margin-right:0.3125rem;fill:", ";}"], p => p.valid ? p.theme.colors.green : p.theme.colors.secondaryGrey, p => p.valid ? p.theme.colors.black : p.theme.colors.placeholderGrey);
const Progress = external_styled_components_default().progress.withConfig({
  displayName: "PasswordCriteria__Progress",
  componentId: "sc-1bq970u-2"
})(["-webkit-appearance:none;appearance:none;height:0.3125rem;margin:0.5rem 0 0.25rem;width:100%;::-webkit-progress-bar{border-radius:10px;background:", ";}::-webkit-progress-value{border-radius:10px;background:", ";}"], p => p.theme.colors.secondaryGrey, p => p.value < 4 ? p.theme.colors.red : p.value < 5 ? p.theme.colors.progressYellow : p.theme.colors.green);
const StrengthContainer = external_styled_components_default().div.withConfig({
  displayName: "PasswordCriteria__StrengthContainer",
  componentId: "sc-1bq970u-3"
})(["display:flex;justify-content:flex-end;"]);

const PasswordCriteria = ({
  password
}) => {
  const criteria = validatePassword(password);
  const fullfilledCriteria = criteria.filter(a => a.valid).length;
  const strength = fullfilledCriteria < 4 ? "Weak" : fullfilledCriteria < 5 ? "Medium" : "Strong";
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(Progress, {
      value: fullfilledCriteria,
      max: criteria.length
    }), /*#__PURE__*/jsx_runtime_.jsx(StrengthContainer, {
      children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
        size: "tiny",
        children: strength
      })
    }), /*#__PURE__*/jsx_runtime_.jsx(PasswordCriteriaContainer, {
      children: criteria.map(({
        message,
        valid
      }, i) => /*#__PURE__*/(0,jsx_runtime_.jsxs)(Criteria, {
        valid: valid,
        children: [/*#__PURE__*/jsx_runtime_.jsx(CriteriaTickIcon, {}), /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
          size: "tiny",
          children: message
        })]
      }, `pc-${i}`))
    })]
  });
};

/* harmony default export */ const form_PasswordCriteria = (PasswordCriteria);

/***/ }),

/***/ 20661:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export inputStyles */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _hookform_error_message__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(83218);
/* harmony import */ var _hookform_error_message__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_hookform_error_message__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(45641);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(87491);
/* harmony import */ var _Error__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(26428);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _PasswordCriteria__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(40833);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_2__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
const _excluded = ["label", "name", "disabled", "labelColor", "inputColor", "isRequired", "showCriteria", "width", "type"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }








var CrossEyeIcon = function CrossEyeIcon(props) {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("path", {
      d: "M12.531 17.732a12.555 12.555 0 0 1-4.005-.606c-.352-.108-.358-.132-.098-.393.7-.713 1.407-1.423 2.101-2.142a.437.437 0 0 1 .497-.134c2.382.672 4.706-.268 5.927-2.42.715-1.268.842-2.629.451-4.033a.475.475 0 0 1 .128-.534 299.951 299.951 0 0 0 3.008-3.058c.192-.198.315-.218.536-.032A15.976 15.976 0 0 1 24.91 9.19c.09.17.135.32.033.509-2.134 3.963-5.226 6.695-9.631 7.73-.91.226-1.844.327-2.78.302zM7.407 9.48c-.026.524.044 1.049.206 1.548a.369.369 0 0 1-.097.405A415.106 415.106 0 0 0 4.401 14.6c-.15.152-.257.163-.425.024-1.64-1.36-2.912-3.018-3.913-4.902a.49.49 0 0 1 .017-.51C1.976 5.71 4.657 3.129 8.454 1.87c2.656-.88 5.325-.847 7.992-.045.382.122.384.136.1.427-.702.714-1.407 1.423-2.104 2.142a.398.398 0 0 1-.448.121c-3.18-.885-6.129 1.09-6.585 4.396-.013.189-.014.379-.002.568zM4.19 18.999a.26.26 0 0 1-.177-.11c-.252-.256-.501-.517-.76-.768-.133-.13-.119-.242.013-.35.052-.047.097-.1.147-.15L20.507.246c.323-.327.323-.327.639-.007.196.2.387.405.595.596.138.131.162.242.007.37-.098.085-.183.185-.275.278l-17.03 17.31A.654.654 0 0 1 4.19 19z",
      fill: "#BBB"
    })
  }));
};

CrossEyeIcon.defaultProps = {
  width: "25",
  height: "19",
  viewBox: "0 0 25 19",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var EyeIcon = function EyeIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("path", {
      d: "M12.496 16.961c-4.422-.093-7.979-2.007-10.751-5.572A16.052 16.052 0 0 1 .078 8.753a.485.485 0 0 1-.02-.496C2.16 4.253 5.188 1.408 9.523.379c4.426-1.05 8.39.09 11.843 3.146 1.476 1.306 2.629 2.892 3.545 4.668.09.174.133.328.032.522-2.134 4.066-5.227 6.868-9.633 7.93-.921.227-1.866.333-2.813.316zm5.11-8.465a5.505 5.505 0 0 0-.378-2.041 5.33 5.33 0 0 0-1.102-1.733 5.081 5.081 0 0 0-1.656-1.158 4.909 4.909 0 0 0-1.956-.406 4.91 4.91 0 0 0-1.957.394A5.08 5.08 0 0 0 8.897 4.7a5.326 5.326 0 0 0-1.112 1.724 5.504 5.504 0 0 0-.392 2.037 5.496 5.496 0 0 0 .376 2.05 5.32 5.32 0 0 0 1.106 1.738 5.073 5.073 0 0 0 1.664 1.16 4.9 4.9 0 0 0 1.964.398c.67.005 1.336-.129 1.956-.394a5.061 5.061 0 0 0 1.66-1.15 5.305 5.305 0 0 0 1.105-1.728c.256-.647.386-1.34.382-2.039z",
      fill: "#BBB"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("path", {
      d: "M12.505 12.353a3.571 3.571 0 0 1-1.419-.288 3.696 3.696 0 0 1-1.205-.833 3.874 3.874 0 0 1-.807-1.25 4.004 4.004 0 0 1-.287-1.478 4.008 4.008 0 0 1 .279-1.488c.186-.472.46-.9.806-1.261a3.7 3.7 0 0 1 1.21-.842 3.575 3.575 0 0 1 1.428-.29c.487 0 .969.1 1.419.295.45.194.858.48 1.201.84.344.36.616.786.801 1.256a4 4 0 0 1 .278 1.48 3.989 3.989 0 0 1-.28 1.48 3.864 3.864 0 0 1-.802 1.253 3.685 3.685 0 0 1-1.203.836 3.56 3.56 0 0 1-1.419.29z",
      fill: "#BBB"
    })]
  }));
};

EyeIcon.defaultProps = {
  width: "25",
  height: "19",
  viewBox: "0 0 25 19",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};





const inputStyles = (0,styled_components__WEBPACK_IMPORTED_MODULE_7__.css)(["border:none;resize:none;background-color:inherit;padding:0.5rem 0.5rem;width:100%;text-align:", ";font-family:", ";font-weight:", ";font-size:", ";color:", ";border-bottom:0.0625rem solid ", ";", " ", " ", " &::-webkit-outer-spin-button,&::-webkit-inner-spin-button{-webkit-appearance:none;margin:0;}&[type=\"number\"]{-moz-appearance:textfield;}::placeholder{color:", ";font-weight:", ";font-size:", ";}&:focus{outline:none;border-bottom:2px solid #2e68f1;}", ""], p => p.align || "left", p => p.theme.input.font, p => p.theme.input.fontWeight, p => p.theme.input.size, p => p.color ? p.color : p.theme.colors.black, p => p.theme.colors.black, p => !p.disabled && p.isError ? `border-bottom: 2px solid ${p.theme.colors.red};` : "border-bottom: 2px solid #BED1FF;", p => p.height && `height: ${p.height};`, p => p.padding && `padding: ${p.padding};`, p => p.theme.colors.placeholderGrey, p => p.theme.input.fontWeight, p => p.theme.tiny.size, _theme__WEBPACK_IMPORTED_MODULE_6__/* .media.tabletLarge */ .BC.tabletLarge`
    text-align: left;
  `);
const StyledInput = styled_components__WEBPACK_IMPORTED_MODULE_7___default().input.withConfig({
  displayName: "PasswordInput__StyledInput",
  componentId: "sc-1bcnegc-0"
})(["", ""], inputStyles);
const InputContainer = styled_components__WEBPACK_IMPORTED_MODULE_7___default().div.withConfig({
  displayName: "PasswordInput__InputContainer",
  componentId: "sc-1bcnegc-1"
})(["display:flex;flex-direction:column;position:relative;width:", ";font-size:", ";"], p => p.width, p => p.theme.input.size);
const Label = styled_components__WEBPACK_IMPORTED_MODULE_7___default().label.withConfig({
  displayName: "PasswordInput__Label",
  componentId: "sc-1bcnegc-2"
})(["color:", ";font-weight:", ";margin-bottom:0.125rem;"], p => p.color ? p.color : p.theme.colors.label, p => p.fontWeight || p.theme.body.weight);
const eyeIconCSS = (0,styled_components__WEBPACK_IMPORTED_MODULE_7__.css)(["position:absolute;bottom:", ";right:", ";"], p => p.showCriteria ? "5.25rem" : "0.5rem", p => p.isRequired ? "1.5rem" : "1rem");
const StyledEyeIcon = styled_components__WEBPACK_IMPORTED_MODULE_7___default()(EyeIcon).withConfig({
  displayName: "PasswordInput__StyledEyeIcon",
  componentId: "sc-1bcnegc-3"
})(["", ""], eyeIconCSS);
const StyledCrossEyeIcon = styled_components__WEBPACK_IMPORTED_MODULE_7___default()(CrossEyeIcon).withConfig({
  displayName: "PasswordInput__StyledCrossEyeIcon",
  componentId: "sc-1bcnegc-4"
})(["", " bottom:", ";"], eyeIconCSS, p => p.label ? p.showCriteria ? "5.325rem" : "0.55rem" : p.showCriteria ? "5.45rem" : "0.45rem");

const PasswordInput = _ref => {
  let {
    label,
    name,
    disabled,
    labelColor,
    inputColor,
    isRequired,
    showCriteria,
    width,
    type
  } = _ref,
      rest = _objectWithoutProperties(_ref, _excluded);

  const {
    register,
    control,
    formState
  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_2__.useFormContext)();
  const {
    errors
  } = formState;
  const {
    touchedFields
  } = formState;
  const {
    0: showPassword,
    1: setShowPassword
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(!(type === "password"));
  const isValid = touchedFields[name] && !errors[name];
  const isError = errors[name];
  const value = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_2__.useWatch)({
    control,
    name
  });
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(InputContainer, {
    label: label,
    value: value,
    isRequired: isRequired,
    isValid: isValid,
    isError: isError,
    width: width,
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(Label, {
      color: labelColor,
      htmlFor: name,
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP, {
        color: labelColor,
        size: "small",
        children: label
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(StyledInput, _objectSpread(_objectSpread({
      id: name,
      type: showPassword && type === "password" ? "text" : type,
      color: inputColor,
      isError: isError
    }, register(name)), {}, {
      "data-cy": `${name}`,
      disabled: disabled,
      width: width
    }, rest)), type === "password" && (!showPassword ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(StyledEyeIcon, {
      label: label,
      isRequired: isRequired,
      showCriteria: showCriteria,
      onClick: () => setShowPassword(!showPassword)
    }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(StyledCrossEyeIcon, {
      label: label,
      isRequired: isRequired,
      showCriteria: showCriteria,
      onClick: () => setShowPassword(!showPassword)
    })), type === "password" && showCriteria && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_PasswordCriteria__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
      password: value
    }), errors && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_hookform_error_message__WEBPACK_IMPORTED_MODULE_1__.ErrorMessage, {
      errors: errors,
      name: name,
      as: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_Error__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PasswordInput);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;