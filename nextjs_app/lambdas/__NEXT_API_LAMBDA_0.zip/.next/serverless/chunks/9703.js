"use strict";
exports.id = 9703;
exports.ids = [9703];
exports.modules = {

/***/ 97598:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "ZL": () => (/* binding */ GlobalStyle),
  "v2": () => (/* binding */ NAVBAR_OFFSET),
  "ZP": () => (/* binding */ common_Page)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./src/components/common/Text.jsx
var Text = __webpack_require__(87491);
// EXTERNAL MODULE: external "react-responsive"
var external_react_responsive_ = __webpack_require__(16666);
// EXTERNAL MODULE: ./src/contexts/auth.js
var auth = __webpack_require__(58368);
// EXTERNAL MODULE: ./src/theme.js
var theme = __webpack_require__(91073);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(57518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: ./src/styles.jsx
var styles = __webpack_require__(72994);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
;// CONCATENATED MODULE: ./src/components/nav/BurgerMenu.jsx





const Wrapper = external_styled_components_default().div.withConfig({
  displayName: "BurgerMenu__Wrapper",
  componentId: "sc-1xpn155-0"
})(["position:relative;cursor:pointer;display:flex;align-items:center;justify-content:center;border-radius:10px;height:3rem;width:3rem;border:0.5px solid ", ";padding-top:0.2rem;& span{background:", ";display:block;position:relative;width:1.5rem;height:0.2rem;margin-bottom:0.3rem;transition:all ease-in-out 0.3s;", "}span:nth-child(2){width:75%;}span:nth-child(3){width:50%;}"], p => p.theme.colors.secondaryBlue, p => p.theme.colors.blue, styles/* borderRadius */.E);

const Burgermenu = props => {
  return /*#__PURE__*/jsx_runtime_.jsx(Wrapper, {
    onClick: props.handleNavbar,
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
        children: "\xA0"
      }), /*#__PURE__*/jsx_runtime_.jsx("span", {
        children: "\xA0"
      }), /*#__PURE__*/jsx_runtime_.jsx("span", {
        children: "\xA0"
      })]
    })
  });
};

/* harmony default export */ const BurgerMenu = (Burgermenu);
// EXTERNAL MODULE: ./src/components/nav/LogoLink.jsx
var LogoLink = __webpack_require__(95273);
// EXTERNAL MODULE: ./src/contexts/flags.js
var contexts_flags = __webpack_require__(62942);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(41664);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(71853);
;// CONCATENATED MODULE: ./src/components/nav/ActiveLink.jsx
const _excluded = ["children"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }






const ActiveLink = _ref => {
  let {
    children
  } = _ref,
      props = _objectWithoutProperties(_ref, _excluded);

  const router = (0,router_.useRouter)();
  const child = external_react_default().Children.only(children);
  const path = router.pathname.split("/")[1];
  const propsHrefPath = props.href.split("/")[1];
  return /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
    href: props.href,
    children: /*#__PURE__*/external_react_default().cloneElement(child, _objectSpread({
      active: path === propsHrefPath
    }, props))
  });
};

/* harmony default export */ const nav_ActiveLink = (ActiveLink);
;// CONCATENATED MODULE: ./src/components/nav/NavIcon.jsx








const Icon = external_styled_components_default().img.withConfig({
  displayName: "NavIcon__Icon",
  componentId: "sc-4y7gyi-0"
})([""]);
const NavIconInnerContainer = external_styled_components_default().div.withConfig({
  displayName: "NavIcon__NavIconInnerContainer",
  componentId: "sc-4y7gyi-1"
})(["display:flex;align-items:center;justify-content:flex-start;text-decoration:none;height:3rem;width:1.5rem;transition:box-shadow 0.3s,background-color 0.3s,color 0.3s;margin-right:1rem;& > svg{fill:", ";height:1rem;width:1rem;}", ""], p => p.selected ? p.theme.colors.blue : p.theme.colors.black, theme/* media.tabletLarge */.BC.tabletLarge`
    margin-right: initial;
  `);
const NavIconContainer = external_styled_components_default().div.withConfig({
  displayName: "NavIcon__NavIconContainer",
  componentId: "sc-4y7gyi-2"
})(["display:flex;align-items:center;justify-content:flex-start;white-space:nowrap;color:", ";cursor:pointer;width:100%;", ";:hover{", "}"], p => p.selected ? p.theme.colors.white : p.theme.colors.blue, p => p.selected && (0,external_styled_components_.css)(["border-right:0.25rem solid ", ";"], p.theme.colors.blue), p => !p.selected && (0,external_styled_components_.css)(["border-right:0.125rem solid ", ";"], p.theme.colors.mediumGrey));

const NavIcon = ({
  href,
  text,
  icon
}) => {
  const router = (0,router_.useRouter)();
  const path = router.pathname.split("/")[1] === "settings" ? router.pathname.split("/")[2] : router.pathname.split("/")[1];
  const propsHrefPath = href.split("/")[1] === "settings" ? href.split("/")[2] : href.split("/")[1];

  if (path === propsHrefPath) {}

  const isTabletLarge = (0,external_react_responsive_.useMediaQuery)({
    query: `(min-width: ${theme/* sizes.tabletLarge */.J7.tabletLarge}px)`
  });
  const selected = path === propsHrefPath;
  return /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
    href: href,
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(NavIconContainer, {
      selected: selected,
      children: [/*#__PURE__*/jsx_runtime_.jsx(NavIconInnerContainer, {
        selected: selected,
        children: icon
      }), /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
        size: isTabletLarge ? "tiny" : "small",
        color: selected ? "blue" : "black",
        fontWeight: path === propsHrefPath ? "500" : "300",
        children: text
      })]
    })
  });
};

/* harmony default export */ const nav_NavIcon = (NavIcon);
;// CONCATENATED MODULE: ./src/components/nav/NavLinks.jsx
function NavLinks_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function NavLinks_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { NavLinks_ownKeys(Object(source), true).forEach(function (key) { NavLinks_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { NavLinks_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function NavLinks_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





var AdminSettingsIcon = function AdminSettingsIcon(props) {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("svg", NavLinks_objectSpread(NavLinks_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/jsx_runtime_.jsx("path", {
      d: "M24.978 12.572c-.013.328.022.734-.018 1.139-.081.812-.622 1.396-1.43 1.535-.46.08-.923.157-1.385.229-.145.023-.228.082-.277.23a6.956 6.956 0 0 1-.476 1.14c-.076.139-.07.245.026.373.28.376.547.761.82 1.142.503.7.447 1.575-.154 2.192a81.343 81.343 0 0 1-1.537 1.538c-.62.6-1.492.657-2.193.154-.39-.281-.784-.558-1.172-.842a.239.239 0 0 0-.288-.024 7.937 7.937 0 0 1-1.193.495c-.15.05-.207.128-.23.272-.069.445-.144.887-.222 1.33-.164.928-.742 1.465-1.688 1.5-.767.028-1.537.042-2.304-.014a1.652 1.652 0 0 1-1.5-1.373c-.081-.48-.16-.961-.235-1.442a.3.3 0 0 0-.233-.274 7.312 7.312 0 0 1-1.14-.475.223.223 0 0 0-.271.021c-.409.3-.821.594-1.237.88-.71.492-1.555.42-2.173-.187-.51-.5-1.015-1.003-1.515-1.512-.61-.618-.671-1.5-.162-2.206.273-.38.543-.764.822-1.14.08-.108.1-.194.031-.319a7.112 7.112 0 0 1-.502-1.185.26.26 0 0 0-.233-.203c-.45-.068-.9-.15-1.35-.226-.955-.158-1.5-.74-1.537-1.715a21.514 21.514 0 0 1 .014-2.285 1.64 1.64 0 0 1 1.322-1.486c.496-.095.995-.179 1.495-.256.14-.022.204-.088.244-.214.132-.41.294-.81.487-1.197a.265.265 0 0 0-.028-.309c-.287-.394-.57-.79-.85-1.19-.516-.743-.437-1.589.205-2.23l1.46-1.457c.634-.629 1.487-.705 2.218-.192.389.273.774.551 1.155.834.108.08.2.096.322.03.381-.2.78-.368 1.19-.5a.258.258 0 0 0 .2-.234c.063-.433.15-.862.216-1.293C9.827.644 10.364.101 11.34.04c.767-.05 1.537-.048 2.303.007.835.065 1.407.614 1.55 1.434.08.461.16.922.231 1.385.02.126.072.2.197.24.44.141.869.318 1.281.527a.247.247 0 0 0 .29-.027c.4-.29.803-.574 1.206-.86a1.647 1.647 0 0 1 2.13.153 79.24 79.24 0 0 1 1.591 1.59c.568.583.621 1.463.144 2.134-.286.4-.57.805-.862 1.203a.242.242 0 0 0-.022.289c.196.37.357.758.48 1.158.05.172.146.236.312.261.432.065.862.142 1.293.219.975.173 1.493.781 1.51 1.771.007.32.003.645.003 1.049zm-7.9 6.894a.887.887 0 0 1 .544.178c.529.378 1.06.75 1.587 1.131.1.072.177.1.276 0 .416-.423.835-.842 1.257-1.26.11-.109.11-.192.018-.318-.38-.52-.75-1.05-1.118-1.573-.23-.325-.237-.656-.036-1a7.886 7.886 0 0 0 .832-2c.105-.407.363-.64.78-.707.622-.1 1.243-.21 1.865-.308.15-.024.211-.077.209-.239a57.87 57.87 0 0 1 0-1.743c0-.14-.044-.2-.184-.22-.623-.1-1.243-.216-1.866-.313-.425-.066-.688-.293-.797-.708a7.545 7.545 0 0 0-.813-1.968c-.235-.393-.206-.75.064-1.112.369-.497.716-1.009 1.082-1.507.096-.129.082-.203-.03-.312a54.582 54.582 0 0 1-1.232-1.232c-.104-.106-.175-.116-.296-.027-.523.386-1.05.763-1.581 1.14-.31.221-.637.243-.968.05a8.374 8.374 0 0 0-2.11-.869c-.4-.104-.624-.365-.689-.773-.1-.616-.206-1.231-.304-1.85-.024-.153-.079-.221-.25-.217a40.65 40.65 0 0 1-1.687 0c-.18-.004-.25.05-.28.228-.093.611-.208 1.218-.303 1.829-.067.429-.292.704-.716.815-.69.18-1.35.458-1.963.825-.392.236-.75.2-1.112-.067-.5-.372-1.018-.725-1.523-1.093-.104-.077-.164-.065-.25.023-.42.43-.845.854-1.273 1.274-.104.1-.098.175-.017.286.374.515.737 1.04 1.112 1.555.253.347.276.692.056 1.064a7.607 7.607 0 0 0-.808 1.99c-.1.391-.342.627-.744.695-.633.108-1.267.221-1.9.32-.15.024-.2.085-.196.231a95 95 0 0 1 0 1.743c0 .15.05.207.2.23.653.105 1.305.22 1.957.333.355.061.595.27.69.61.204.742.503 1.454.889 2.119.195.336.165.666-.064.983-.374.516-.738 1.039-1.114 1.554-.086.119-.087.197.021.3.42.41.837.825 1.245 1.246.108.112.179.103.295.018.5-.365 1.011-.712 1.507-1.082.375-.279.74-.306 1.15-.071a7.615 7.615 0 0 0 1.904.774c.4.104.631.356.7.765.1.61.208 1.218.3 1.83.028.186.088.263.293.257a28.907 28.907 0 0 1 1.65 0c.197.005.256-.07.284-.246.09-.587.21-1.169.29-1.756.065-.486.325-.753.792-.873a7.36 7.36 0 0 0 1.945-.819.837.837 0 0 1 .428-.133h.002z"
    }), /*#__PURE__*/jsx_runtime_.jsx("path", {
      d: "M12.497 7.025c3.006 0 5.477 2.474 5.477 5.48 0 3.006-2.48 5.477-5.485 5.473-3.005-.004-5.487-2.488-5.465-5.491a5.487 5.487 0 0 1 5.473-5.462zm.005 1.7a3.789 3.789 0 0 0-3.782 3.779c0 2.068 1.705 3.772 3.773 3.773 2.067.002 3.776-1.697 3.779-3.764a3.78 3.78 0 0 0-3.77-3.787v-.001z"
    })]
  }));
};

AdminSettingsIcon.defaultProps = {
  width: "25",
  height: "25",
  viewBox: "0 0 25 25",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var DashboardIcon = function DashboardIcon(props) {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("svg", NavLinks_objectSpread(NavLinks_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/jsx_runtime_.jsx("g", {
      clipPath: "url(#clip0_4536_28663)",
      children: /*#__PURE__*/jsx_runtime_.jsx("path", {
        d: "M10.938 16.406a.782.782 0 0 1 .78.719v7.156a.782.782 0 0 1-.78.719H.78A.781.781 0 0 1 0 24.281v-7.156a.781.781 0 0 1 .781-.719h10.156zm13.28-6.25a.781.781 0 0 1 .782.781V24.22a.781.781 0 0 1-.781.781H14.062a.781.781 0 0 1-.78-.781V10.937a.781.781 0 0 1 .78-.78H24.22zm-14.062 7.68H1.562v5.734h8.594v-5.734zm13.281-6.117h-8.593v11.719h8.594v-11.72zM10.938 0a.781.781 0 0 1 .782.781v13.281a.781.781 0 0 1-.781.782H.78A.781.781 0 0 1 0 14.063V.78A.781.781 0 0 1 .781 0h10.156zm-.78 1.563H1.561V13.28h8.594V1.562zM24.218 0A.781.781 0 0 1 25 .719v7.156a.781.781 0 0 1-.781.719H14.062a.781.781 0 0 1-.78-.719V.719a.782.782 0 0 1 .78-.719H24.22zm-.782 1.43h-8.593v5.734h8.594V1.43z"
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("defs", {
      children: /*#__PURE__*/jsx_runtime_.jsx("clipPath", {
        id: "clip0_4536_28663",
        children: /*#__PURE__*/jsx_runtime_.jsx("path", {
          fill: "#fff",
          d: "M0 0h25v25H0z"
        })
      })
    })]
  }));
};

DashboardIcon.defaultProps = {
  width: "25",
  height: "25",
  viewBox: "0 0 25 25",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var DataCollectionIcon = function DataCollectionIcon(props) {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("svg", NavLinks_objectSpread(NavLinks_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/jsx_runtime_.jsx("g", {
      clipPath: "url(#clip0_4333_73696)",
      children: /*#__PURE__*/jsx_runtime_.jsx("path", {
        d: "M3.356 0A.568.568 0 0 0 2.84.57v23.863a.568.568 0 0 0 .568.568H21.59a.568.568 0 0 0 .569-.568V5.647a.568.568 0 0 0-.169-.4L16.894.16a.568.568 0 0 0-.4-.16H3.357zm.621 1.137H15.91v4.545a.568.568 0 0 0 .568.568h4.545v17.614H3.977V1.137zm13.068.781l3.205 3.196h-3.205V1.918zM6.197 8.24a.568.568 0 0 0-.515.568v2.841a.568.568 0 0 0 .568.568h3.125a.568.568 0 0 0 .568-.568v-2.84a.568.568 0 0 0-.568-.569H6.197zm5.397 0a.568.568 0 0 0-.515.568v2.841a.568.568 0 0 0 .569.568h7.102a.569.569 0 0 0 .568-.568v-2.84a.568.568 0 0 0-.568-.569H11.594zM6.818 9.375h1.989v1.705H6.818V9.375zm5.398 0h5.966v1.705h-5.966V9.375zm-6.02 3.694a.568.568 0 0 0-.514.568v2.84a.568.568 0 0 0 .568.569h3.125a.568.568 0 0 0 .568-.569v-2.84a.568.568 0 0 0-.568-.569H6.197zm5.398 0a.568.568 0 0 0-.515.568v2.84a.568.568 0 0 0 .569.569h7.102a.569.569 0 0 0 .568-.569v-2.84a.568.568 0 0 0-.568-.569H11.594zm-4.776 1.136h1.989v1.704H6.818v-1.704zm5.398 0h5.966v1.704h-5.966v-1.704zm-6.02 3.693a.568.568 0 0 0-.514.568v2.84a.568.568 0 0 0 .568.57h3.125a.568.568 0 0 0 .568-.57v-2.84a.568.568 0 0 0-.568-.568H6.197zm5.398 0a.568.568 0 0 0-.515.568v2.84a.568.568 0 0 0 .569.57h7.102a.568.568 0 0 0 .568-.57v-2.84a.569.569 0 0 0-.568-.568h-7.102a.59.59 0 0 0-.054 0zm-4.776 1.136h1.989v1.705H6.818v-1.705zm5.398 0h5.966v1.705h-5.966v-1.705z"
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("defs", {
      children: /*#__PURE__*/jsx_runtime_.jsx("clipPath", {
        id: "clip0_4333_73696",
        children: /*#__PURE__*/jsx_runtime_.jsx("path", {
          d: "M0 0h25v25H0z"
        })
      })
    })]
  }));
};

DataCollectionIcon.defaultProps = {
  width: "25",
  height: "25",
  viewBox: "0 0 25 25",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};

var HistoryIcon = function HistoryIcon(props) {
  return /*#__PURE__*/jsx_runtime_.jsx("svg", NavLinks_objectSpread(NavLinks_objectSpread({}, props), {}, {
    children: /*#__PURE__*/jsx_runtime_.jsx("path", {
      d: "M6.709 28.88C7.296 14.676 18.996 3.342 33.343 3.342 48.065 3.343 60 15.278 60 30S48.065 56.657 33.343 56.657a26.574 26.574 0 0 1-18.85-7.807l2.095-2.095a23.608 23.608 0 0 0 16.755 6.94c13.086 0 23.695-10.608 23.695-23.695S46.43 6.305 33.343 6.305c-12.7 0-23.067 9.992-23.668 22.544l5.134-3.08 1.524 2.539-8.166 4.9L0 28.308l1.524-2.54 5.185 3.111zm35.683 8.85l-1.85 2.312-7.961-6.368V15.19h2.962v17.06l6.849 5.478z",
      fill: "#000"
    })
  }));
};

HistoryIcon.defaultProps = {
  width: "60",
  height: "60",
  viewBox: "0 0 60 60",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};








const LinkContainer = external_styled_components_default().div.withConfig({
  displayName: "NavLinks__LinkContainer",
  componentId: "otqrsp-0"
})(["display:flex;color:#000000;text-decoration:none;align-items:center;width:100%;", ""], theme/* media.tabletLarge */.BC.tabletLarge`
    display: block;
    text-align: left;
    padding: 0;
   `);
const PageLink = external_styled_components_default()(nav_ActiveLink).withConfig({
  displayName: "NavLinks__PageLink",
  componentId: "otqrsp-1"
})(["text-decoration:none;color:", ";font-weight:300;margin:auto;"], p => p.theme.colors.body);
const NavLink = external_styled_components_default().a.withConfig({
  displayName: "NavLinks__NavLink",
  componentId: "otqrsp-2"
})(["text-decoration:none;font-family:", ";font-size:1rem;font-weight:bold;cursor:pointer;color:", ";:hover{text-decoration:underline;}", ""], p => p.theme.body.font, ({
  active
}) => active ? "black" : "#cecece", theme/* media.tabletLarge */.BC.tabletLarge`
    font-size: 1.125rem;
   `);

const NavLinks = ({
  onClick
}) => {
  const {
    user,
    organisation,
    isAdmin
  } = (0,auth/* default */.Z)();
  const {
    flags
  } = (0,contexts_flags/* default */.Z)();
  const isTabletLarge = (0,external_react_responsive_.useMediaQuery)({
    query: `(min-width: ${theme/* sizes.tabletLarge */.J7.tabletLarge}px)`
  });
  const topLinks = [{
    href: "/",
    text: "Dashboard",
    icon: /*#__PURE__*/jsx_runtime_.jsx(DashboardIcon, {})
  }, ...(flags !== null && flags !== void 0 && flags.data_collection ? [{
    href: "/data-input",
    text: "Data Input",
    icon: /*#__PURE__*/jsx_runtime_.jsx(DataCollectionIcon, {})
  }] : []), {
    href: "/history",
    text: "History",
    icon: /*#__PURE__*/jsx_runtime_.jsx(HistoryIcon, {})
  }, {
    href: isTabletLarge ? "/settings/admin/profile" : "/settings/admin",
    text: "Settings",
    icon: /*#__PURE__*/jsx_runtime_.jsx(AdminSettingsIcon, {})
  }];
  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: topLinks.map(link => /*#__PURE__*/jsx_runtime_.jsx(LinkContainer, {
      children: link.admin ? isAdmin({
        user,
        organisation
      }) && /*#__PURE__*/jsx_runtime_.jsx(nav_NavIcon, NavLinks_objectSpread({}, NavLinks_objectSpread(NavLinks_objectSpread({}, link), {}, {
        href: `${link.href}`
      }))) : /*#__PURE__*/jsx_runtime_.jsx(nav_NavIcon, NavLinks_objectSpread({}, NavLinks_objectSpread(NavLinks_objectSpread({}, link), {}, {
        href: `${link.href}`
      })))
    }, link.href))
  });
};

/* harmony default export */ const nav_NavLinks = (NavLinks);
;// CONCATENATED MODULE: ./src/components/nav/CollapseMenu.jsx








const Container = external_styled_components_default().div.withConfig({
  displayName: "CollapseMenu__Container",
  componentId: "sc-1ixb8wu-0"
})(["", ""], theme/* media.tabletLarge */.BC.tabletLarge`
    display:none
  `);
const CollapseOverlay = external_styled_components_default().div.withConfig({
  displayName: "CollapseMenu__CollapseOverlay",
  componentId: "sc-1ixb8wu-1"
})(["position:absolute;top:0;left:0;bottom:0;right:0;height:100vh;width:100vw;background:", ";opacity:0.25;"], p => p.theme.colors.blue);
const CollapseWrapper = external_styled_components_default().div.withConfig({
  displayName: "CollapseMenu__CollapseWrapper",
  componentId: "sc-1ixb8wu-2"
})(["padding-left:1.5rem;position:fixed;left:", ";bottom:0;right:25%;background-color:#fff;display:flex;flex-direction:column;align-items:flex-start;overflow-y:scroll;display:flex;height:100%;width:", ";transition:left 0.5s;", ""], p => p.open ? 0 : "-75%", p => p.open ? "75%" : 0, theme/* media.tabletLarge */.BC.tabletLarge`
    display:none
  `);
const BurgerMenuContainer = external_styled_components_default().div.withConfig({
  displayName: "CollapseMenu__BurgerMenuContainer",
  componentId: "sc-1ixb8wu-3"
})(["padding:0.5rem 0;display:block;margin-bottom:0.5rem;", ""], theme/* media.tabletLarge */.BC.tabletLarge`
    display: none;
  `);
const LogoLinkContainer = external_styled_components_default().div.withConfig({
  displayName: "CollapseMenu__LogoLinkContainer",
  componentId: "sc-1ixb8wu-4"
})(["padding:0.5rem 0;width:100%;margin-bottom:0.5rem;& > svg{width:6rem;}"]);

const CollapseMenu = props => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(Container, {
    children: [props.navbarState === true && /*#__PURE__*/jsx_runtime_.jsx(CollapseOverlay, {
      onClick: props.handleNavbar
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(CollapseWrapper, {
      open: props.navbarState,
      children: [/*#__PURE__*/jsx_runtime_.jsx(BurgerMenuContainer, {
        children: /*#__PURE__*/jsx_runtime_.jsx(BurgerMenu, {
          handleNavbar: props.handleNavbar
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(LogoLinkContainer, {
        children: /*#__PURE__*/jsx_runtime_.jsx(LogoLink/* default */.Z, {
          onClick: props.handleNavbar,
          href: "/"
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(nav_NavLinks, {
        onClick: props.handleNavbar
      })]
    })]
  });
};

/* harmony default export */ const nav_CollapseMenu = (CollapseMenu);
;// CONCATENATED MODULE: ./src/components/nav/Navbar.jsx











const NavigationBarOuterContainer = external_styled_components_default().div.withConfig({
  displayName: "Navbar__NavigationBarOuterContainer",
  componentId: "sc-19mmfdw-0"
})(["display:flex;align-items:center;justify-content:center;position:sticky;top:0;border-bottom:2px solid ", ";background-color:", ";z-index:10;height:4.875rem;", " ", ""], p => p.theme.colors.seperator, p => p.theme.colors.backgroundGrey, theme/* media.tabletLarge */.BC.tabletLarge`
  height: ${theme/* default.NavigationBarHeight */.ZP.NavigationBarHeight};
  background: ${p => p.theme.colors.white};
  min-height: 100vh;
  width: 20%;
  max-width: 145px;
  `, theme/* media.desktop */.BC.desktop`
`);
const NavigationBarInnerContainer = external_styled_components_default().div.withConfig({
  displayName: "Navbar__NavigationBarInnerContainer",
  componentId: "sc-19mmfdw-1"
})(["display:flex;flex-direction:row;justify-content:space-between;align-items:center;width:100%;max-width:1280px;padding:0 1rem;", ""], theme/* media.tabletLarge */.BC.tabletLarge`
    height: 100%;
    flex-direction: column;
    justify-content: flex-start;
    padding: 0;
  `);
const SubContainer = external_styled_components_default().div.withConfig({
  displayName: "Navbar__SubContainer",
  componentId: "sc-19mmfdw-2"
})(["display:none;justify-content:space-evenly;align-items:center;width:100%;", ""], theme/* media.tabletLarge */.BC.tabletLarge`
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 0 0 0 1rem;
  `);
const LogoContainer = external_styled_components_default().div.withConfig({
  displayName: "Navbar__LogoContainer",
  componentId: "sc-19mmfdw-3"
})(["text-decoration:none;color:#000000;width:100%;flex-direction:column;display:none;", ""], theme/* media.tabletLarge */.BC.tabletLarge`
    display: flex;
    margin-top: 1.5rem;
    margin-bottom: 3rem;
    text-align: center;
    align-items: center;
  `);
const BurgerWrapper = external_styled_components_default().div.withConfig({
  displayName: "Navbar__BurgerWrapper",
  componentId: "sc-19mmfdw-4"
})(["margin:auto 0;display:block;", ""], theme/* media.tabletLarge */.BC.tabletLarge`
    display: none;
  `);
const UserActionsContainer = external_styled_components_default().div.withConfig({
  displayName: "Navbar__UserActionsContainer",
  componentId: "sc-19mmfdw-5"
})(["display:flex;justify-content:flex-end;", ""], theme/* media.tabletLarge */.BC.tabletLarge`
    display: none;
  `);
const Anchor = external_styled_components_default().a.withConfig({
  displayName: "Navbar__Anchor",
  componentId: "sc-19mmfdw-6"
})(["text-decoration:none;"]);

const NavigationBar = () => {
  const {
    0: navbarOpen,
    1: setNavbarOpen
  } = (0,external_react_.useState)();

  const handleNavbar = () => setNavbarOpen(!navbarOpen);

  const {
    isAuthenticated
  } = (0,auth/* default */.Z)();
  const isTabletLarge = (0,external_react_responsive_.useMediaQuery)({
    query: `(min-width: ${theme/* sizes.tabletLarge */.J7.tabletLarge}px)`
  });

  if (!isAuthenticated) {
    return null;
  }

  return /*#__PURE__*/jsx_runtime_.jsx(NavigationBarOuterContainer, {
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(NavigationBarInnerContainer, {
      children: [/*#__PURE__*/jsx_runtime_.jsx(LogoContainer, {
        children: /*#__PURE__*/jsx_runtime_.jsx(LogoLink/* default */.Z, {
          onClick: () => setNavbarOpen(false),
          href: "/"
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(SubContainer, {
        children: /*#__PURE__*/jsx_runtime_.jsx(nav_NavLinks, {})
      }), /*#__PURE__*/jsx_runtime_.jsx(BurgerWrapper, {
        children: /*#__PURE__*/jsx_runtime_.jsx(BurgerMenu, {
          navbarState: navbarOpen,
          handleNavbar: handleNavbar
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(nav_CollapseMenu, {
        navbarState: navbarOpen,
        handleNavbar: handleNavbar
      })]
    })
  });
};

/* harmony default export */ const Navbar = (NavigationBar);
// EXTERNAL MODULE: ./src/contexts/config.js
var config = __webpack_require__(33742);
// EXTERNAL MODULE: external "styled-normalize"
var external_styled_normalize_ = __webpack_require__(24535);
;// CONCATENATED MODULE: ./src/components/common/Page.jsx











const NAVBAR_OFFSET = "2.5rem";

const createBackGroundColor = ({
  backgroundColor,
  theme
}) => theme.colors[backgroundColor] || theme.colors.white;

const Page_Container = external_styled_components_default().div.withConfig({
  displayName: "Page__Container",
  componentId: "o7vhar-0"
})(["margin-right:auto;margin-left:auto;background-color:", ";max-height:100vh;min-height:100vh;overflow-y:scroll;overflow-x:hidden;", ";", ";&::-webkit-scrollbar{scrollbar-width:none;-ms-overflow-style:none;display:none;}"], createBackGroundColor, theme/* media.tabletLarge */.BC.tabletLarge`
    display: flex;
    flex-direction: row;
    box-shadow: 0 3px 6px 0 rgba(0, 0, 0, 0.16);
  `, theme/* media.desktopLarge */.BC.desktopLarge`
    display: flex;
    flex-direction: row;
    max-width: 1440px;
  `);
const GlobalStyle = external_styled_components_.createGlobalStyle`
${external_styled_normalize_.normalize}
@font-face {
  font-family: 'kabel_black';
  src: url('/fonts/kabel_black.ttf');
}

@font-face {
  font-family: 'kabel_heavy';
  src: url('/fonts/kabel_heavy.ttf');
}

:root {
  --tooltip-text-color: white;
  --tooltip-background-color: black;
  --tooltip-margin: 5px;
  --tooltip-arrow-size: 3px;
}

  * {
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    -webkit-tap-highlight-color: rgba(0,0,0,0);
    box-sizing: border-box;
    font-family: ${theme/* default.body.font */.ZP.body.font};
    font-size: ${theme/* default.body.size */.ZP.body.size};
    font-weight: normal;
    font-style: normal;
    font-stretch: normal;
    line-height: normal;
    letter-spacing: normal;

  }

  html {
    font-size: 100%;
  }

  html,
  body {
    min-height: 100%;
    height: 100%;
    margin: 0;
    padding:0;
    line-height: 1.25;
    color: ${p => p.theme.colors.body};
    overflow: hidden;
  }

  table {
    border-collapse: collapse;
  }

  table, th, td {
    border: 1px solid ${theme/* default.colors.grey */.ZP.colors.grey};
    padding: 0.25rem;
  }
  
  td:nth-child(1) {
    width: 25%;
  }
  
  ol {
   list-style-type: lower-alpha;
  }
  
  [id=__next] {
      height: 100%;
      background-color: ${theme/* default.colors.lightGrey */.ZP.colors.lightGrey};
  }

  div[role=dialog],div[role=presentation] {
    z-index: 10;
  }

  input {
  border-radius: 0;
}

input[type="search"] {
  -webkit-appearance: none;
}

input:-webkit-autofill::first-line {font-size: inherit}

input:-webkit-autofill,
input:-webkit-autofill:hover, 
input:-webkit-autofill:focus, 
input:-webkit-autofill:active{
    -webkit-box-shadow: 0 0 0 30px inherit inset !important;
}

input:-webkit-autofill,
input:-webkit-autofill:hover,
input:-webkit-autofill:focus,
input:-webkit-autofill:active {
  -webkit-animation: autofill 0s forwards;
  animation: autofill 0s forwards;
   background: transparent;
    color: inherit;
    font-size: inherit;
}

@keyframes autofill {
  100% {
    background: transparent;
    color: inherit;
    font-size: inherit;
  }
}

@-webkit-keyframes autofill {
  100% {
    background: transparent;
    color: inherit;
    font-size: inherit;
  }
}

[type="submit"] {
  -webkit-appearance: none;
}

.image-gallery-slide .image-gallery-image {
	object-fit: cover !important;
	height: 250px;
}

.image-gallery-thumbnail .image-gallery-thumbnail-image {
	object-fit: cover;
	height: 75px;
	width: 95%;
	cursor: pointer;
}

.image-gallery-thumbnail.active, .image-gallery-thumbnail:hover, .image-gallery-thumbnail:focus {
	border: none;
}

.image-gallery-thumbnail {
	border: none;
}

.image-gallery-thumbnails-container {
	padding-left: 0; 
	display: flex; 
}

.image-gallery-thumbnail .image-gallery-thumbnail-inner {
	display: flex;
}

div.react-multi-email.empty {
  background-color: inherit;
  width: 100%;
  text-align: ${p => p.align || "left"};
}

div.react-multi-email {
	border-radius: 0;
	margin-bottom: 1rem;
}

.react-multi-email > input {
	padding: 0 !important;
	font-family: ${p => p.theme.input.font};
  font-weight: ${p => p.theme.input.fontWeight};
  font-size: ${p => p.theme.input.size};
}

.react-multi-email [data-tag] {
	background-color: #D8E4FE;
	color: #333333
	margin: 0 1rem;
	height: 1.25rem;
}
`;
const NavigationBarOffset = external_styled_components_default().div.withConfig({
  displayName: "Page__NavigationBarOffset",
  componentId: "o7vhar-1"
})(["", ";"], theme/* media.tabletLarge */.BC.tabletLarge`
    padding-top: ${NAVBAR_OFFSET};
  `);
const PageContent = external_styled_components_default().div.withConfig({
  displayName: "Page__PageContent",
  componentId: "o7vhar-2"
})(["margin:0 auto;height:100%;width:100%;", " ", " ", ";"], theme/* media.tablet */.BC.tablet`
    padding: 1.25rem;
    `, theme/* media.tabletLarge */.BC.tabletLarge`
    padding: 0.625rem 0.625rem 0.625rem 0;
  `, theme/* media.desktopLarge */.BC.desktopLarge`
      max-width: 1295px;
  `);
const NoticeBanner = external_styled_components_default().div.withConfig({
  displayName: "Page__NoticeBanner",
  componentId: "o7vhar-3"
})(["background:", ";width:100%;padding:1rem;display:flex;align-items:center;justify-content:center;"], createBackGroundColor);

const Page = ({
  children,
  backgroundColor
}) => {
  const {
    pageContainer
  } = (0,config/* default */.Z)();
  const {
    organisation
  } = (0,auth/* default */.Z)();
  return /*#__PURE__*/jsx_runtime_.jsx(external_styled_components_.ThemeProvider, {
    theme: theme/* default */.ZP,
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
      children: [organisation && !organisation.onboarded && /*#__PURE__*/jsx_runtime_.jsx(NoticeBanner, {
        backgroundColor: "red",
        children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
          color: "white",
          children: "Organisation is not yet live. Please activate through onboarding email."
        })
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(Page_Container, {
        ref: pageContainer,
        backgroundColor: backgroundColor,
        children: [/*#__PURE__*/jsx_runtime_.jsx(Navbar, {}), /*#__PURE__*/jsx_runtime_.jsx(NavigationBarOffset, {}), /*#__PURE__*/jsx_runtime_.jsx(PageContent, {
          children: children
        })]
      })]
    })
  });
};

/* harmony default export */ const common_Page = (Page);

/***/ }),

/***/ 87491:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "sO": () => (/* binding */ createSize),
/* harmony export */   "h6": () => (/* binding */ createMobileSize),
/* harmony export */   "sz": () => (/* binding */ textCSS),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports createColor, createFont, createFontWeight */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





const createColor = ({
  color,
  size,
  theme
}) => theme.colors[color] || size && theme[size].color || theme.colors.body;
const createSize = ({
  size,
  theme
}) => size && theme[size].size || theme.body.size;
const createMobileSize = ({
  size,
  theme
}) => size && theme.mobile[size].size || theme.body.size;
const createFont = ({
  size,
  theme
}) => size && theme[size].font || theme.body.font;
const createFontWeight = ({
  fontWeight,
  size,
  theme
}) => fontWeight || size && theme[size].fontWeight || theme.body.fontWeight;
const textCSS = (0,styled_components__WEBPACK_IMPORTED_MODULE_2__.css)(["font-family:", ";font-weight:", ";font-size:", ";font-style:", ";font-stretch:normal;line-height:normal;letter-spacing:normal;text-align:", ";text-transform:", ";border-bottom:", ";color:", ";cursor:", ";vertical-align:", ";", " ", ""], p => p.font || createFont, createFontWeight, createMobileSize, p => p.italic ? "italic" : "normal", p => p.align || "center", p => p.capitalize && "capitalize", p => p.underline && `0.125rem solid ${createColor(p)}`, createColor, p => p.pointer && "pointer", p => p.vAlign, p => p.level && `
        margin-block-start: 0;
        margin-block-end: 0;
        margin-inline-start: 0;
        margin-inline-end: 0;
        margin: 0; `, _theme__WEBPACK_IMPORTED_MODULE_1__/* .media.tabletLarge */ .BC.tabletLarge`
      font-size: ${createSize};
    `);
const TextComp = styled_components__WEBPACK_IMPORTED_MODULE_2___default().span.withConfig({
  displayName: "Text__TextComp",
  componentId: "sc-1g97nhx-0"
})(["font-family:", ";font-weight:", ";font-size:", ";font-style:", ";font-stretch:normal;line-height:", ";letter-spacing:normal;text-align:", ";display:", ";text-transform:", ";border-bottom:", ";color:", ";cursor:", ";vertical-align:", ";", " ", " ", " ", ""], p => p.font || createFont, createFontWeight, createMobileSize, p => p.italic ? "italic" : "normal", p => p.lineHeight || "normal", p => p.align || "center", p => p.display || "initial", p => p.capitalize && "capitalize", p => p.underline && `0.125rem solid ${createColor(p)}`, createColor, p => p.pointer && "pointer", p => p.vAlign, p => p.inherit && "color: inherit;", p => p.margin && (0,styled_components__WEBPACK_IMPORTED_MODULE_2__.css)(["margin:", ";"], p.margin), p => p.level && `
        margin-block-start: 0;
        margin-block-end: 0;
        margin-inline-start: 0;
        margin-inline-end: 0;
        margin: 0; `, _theme__WEBPACK_IMPORTED_MODULE_1__/* .media.tabletLarge */ .BC.tabletLarge`
      font-size: ${createSize};
    `);

const Text = props => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(TextComp, _objectSpread({}, props));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Text);

/***/ }),

/***/ 40516:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AZ": () => (/* binding */ initAppMap),
/* harmony export */   "es": () => (/* binding */ checkPageIsComplete),
/* harmony export */   "JM": () => (/* binding */ checkStepIsNextStep),
/* harmony export */   "FZ": () => (/* binding */ getCurrentPage),
/* harmony export */   "$X": () => (/* binding */ checkPreviousPageIsComplete),
/* harmony export */   "rs": () => (/* binding */ getCurrentProgress),
/* harmony export */   "VC": () => (/* binding */ getNumberOfPages),
/* harmony export */   "_Z": () => (/* binding */ shouldUpdateLastCompletedStep),
/* harmony export */   "Nb": () => (/* binding */ stepIsCompleted)
/* harmony export */ });
/* unused harmony exports getAppMapKeys, getAllSteps */
const initAppMap = ({
  measurement
}) => ({
  details: ["net_zero_target", "staff"],
  offices: ["has_office", ...(measurement.has_office ? ["office_details", "has_utility_bills", ...(measurement.has_utility_bills ? ["gas", "electricity", "water"] : []), "waste", "commutes"] : [])],
  vehicles: ["has_company_vehicles", ...(measurement.has_company_vehicles ? ["vehicle_usage"] : [])],
  "business-travel": ["has_business_travel", ...(measurement.has_business_travel ? ["business_travel"] : [])],
  expenses: ["expenses"],
  review: ["review"]
});
const checkPageIsComplete = ({
  page,
  measurement
}) => {
  const appMap = initAppMap({
    measurement
  });
  const appMapKeys = getAppMapKeys(appMap);
  const currentPage = getCurrentPage({
    appMap,
    measurement
  });

  if (appMapKeys.indexOf(page) === appMapKeys.indexOf(currentPage)) {
    return appMap[currentPage].indexOf(measurement.last_completed_step) === appMap[currentPage].length - 1;
  }

  return appMapKeys.indexOf(page) < appMapKeys.indexOf(currentPage);
};
const getAppMapKeys = appMap => Object.keys(appMap);
const checkStepIsNextStep = ({
  step,
  measurement
}) => {
  const appMap = initAppMap({
    measurement
  });
  const allSteps = getAllSteps(appMap);
  return allSteps.indexOf(step) === allSteps.indexOf(measurement.last_completed_step) + 1;
};

const getLastCompletedPage = ({
  measurement
}) => {
  const appMap = initAppMap({
    measurement
  });
  const appMapKeys = getAppMapKeys(appMap);
  const currentPage = appMapKeys.find(key => appMap[key].includes(measurement.last_completed_step));

  if (!currentPage) {
    return appMapKeys[0];
  }

  if (currentPage && appMap[currentPage].indexOf(measurement.last_completed_step) === appMap[currentPage].length - 1) {
    return currentPage;
  }

  return appMapKeys[appMapKeys.indexOf(currentPage) - 1];
};

const getCurrentPage = ({
  measurement
}) => {
  const appMap = initAppMap({
    measurement
  });
  const appMapKeys = getAppMapKeys(appMap);
  return appMapKeys.find(key => appMap[key].includes(measurement.last_completed_step)) || appMapKeys[0];
};
const checkPreviousPageIsComplete = ({
  page,
  measurement
}) => {
  const appMap = initAppMap({
    measurement
  });
  const appMapKeys = getAppMapKeys(appMap);
  const previousPageIndex = appMapKeys.indexOf(page) - 1;

  if (previousPageIndex < 1) {
    return true;
  }

  return checkPageIsComplete({
    page: appMapKeys[previousPageIndex],
    measurement
  });
};
const getCurrentProgress = ({
  measurement
}) => {
  const appMap = initAppMap({
    measurement
  });
  const appMapKeys = getAppMapKeys(appMap);
  const lastCompletePage = getLastCompletedPage({
    appMap,
    measurement
  });
  return Math.max(appMapKeys.indexOf(lastCompletePage), 0);
};
const getNumberOfPages = appMap => getAppMapKeys(appMap).length - 1;
const getAllSteps = appMap => {
  const appMapKeys = getAppMapKeys(appMap);
  return appMapKeys.map(key => appMap[key]).flat();
};
const shouldUpdateLastCompletedStep = ({
  step,
  measurement
}) => {
  if (!measurement.last_completed_step) {
    return true;
  }

  const appMap = initAppMap({
    measurement
  });
  const allSteps = getAllSteps(appMap);
  return allSteps.indexOf(step) > allSteps.indexOf(measurement.last_completed_step);
};
const stepIsCompleted = ({
  step,
  measurement
}) => {
  if (!(measurement !== null && measurement !== void 0 && measurement.last_completed_step)) {
    return false;
  }

  const appMap = initAppMap({
    measurement
  });
  const allSteps = getAllSteps(appMap);
  return allSteps.indexOf(step) <= allSteps.indexOf(measurement.last_completed_step);
};

/***/ }),

/***/ 95273:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(41664);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




var Inhabit = function Inhabit(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("g", {
      clipPath: "url(#clip0_4478_114974)",
      fill: "#000",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
        d: "M52.654 25.875c-.502-.089-1.01-.15-1.505-.27a4.648 4.648 0 0 1-1.9-.873 3.743 3.743 0 0 1-1.326-2.47c-.188-1.266.075-2.405.931-3.369a6.394 6.394 0 0 1 2.133-1.483c1.233-.58 2.543-.902 3.855-1.213 1.419-.34 2.85-.63 4.266-.985a7.014 7.014 0 0 0 1.538-.58c.903-.469 1.118-1.033.913-2.057-.313-1.545-1.26-2.433-2.724-2.765-1.466-.353-3-.28-4.428.21-1.459.508-2.471 1.545-3.224 2.884-.059.106-.117.214-.18.32-.187.344-.285.377-.633.184-.458-.251-.908-.516-1.361-.773l-.617-.357c-.358-.205-.4-.352-.189-.703 1.353-2.239 3.226-3.77 5.733-4.452a11.573 11.573 0 0 1 3.388-.442 10.26 10.26 0 0 1 3.847.792c1.946.847 3.025 2.395 3.358 4.506.065.447.097.899.096 1.352.019 2.142.024 4.285.036 6.43 0 .668 0 1.338.01 2.006a.884.884 0 0 0 .178.564.844.844 0 0 0 .49.317 2.17 2.17 0 0 0 1.138-.016c.376-.127.534 0 .536.41v1.873c0 .386-.128.55-.484.65-1.129.312-2.258.364-3.367-.07a2.277 2.277 0 0 1-.821-.539 2.35 2.35 0 0 1-.528-.84 5.532 5.532 0 0 1-.377-2.1c.014-1.04 0-2.082-.028-3.133-.12.269-.237.537-.36.806-.752 1.647-1.693 3.146-3.07 4.318a7.523 7.523 0 0 1-4.33 1.84.689.689 0 0 0-.109.028h-.885zm8.948-11.376c-.335.245-.683.47-1.043.676-.368.192-.757.34-1.159.442-1.287.33-2.605.62-3.905.924-.941.216-1.883.448-2.73.929-.916.511-1.505 1.243-1.612 2.346-.132 1.352.446 2.358 1.65 2.795a6.488 6.488 0 0 0 4.425.029c1.861-.637 3.043-1.995 3.802-3.8.585-1.395.687-2.858.565-4.34h.007zM0 1.814a.55.55 0 0 1 .222-.224c.093-.05.2-.072.305-.062h2.07c.052 0 .105.003.156.01.36.048.401.086.44.453.011.124.015.247.012.371v22.23c.004.177-.003.354-.02.53a.324.324 0 0 1-.096.219.308.308 0 0 1-.217.09c-.216.011-.433 0-.65 0-.519 0-1.036.02-1.554.029-.25 0-.504.021-.67-.23L0 1.814zM72.618 19.497c.012 1.667.025 3.423.036 5.18.005.085.005.17 0 .253-.024.358-.178.52-.529.526-.284 0-.564-.023-.856-.025h-1.485a.28.28 0 0 1-.23-.075.295.295 0 0 1-.094-.229 3.577 3.577 0 0 1-.017-.347V.792.56c0-.421.098-.516.51-.518h2.122c.402 0 .564.15.58.564.012.33 0 .663 0 .995v10.986a.352.352 0 0 0 .061.218c.064-.164.14-.326.189-.494a8.065 8.065 0 0 1 1.805-3.218 6.741 6.741 0 0 1 3.961-2.184c2.36-.377 4.517.17 6.4 1.707 1.191.966 1.95 2.271 2.446 3.733.489 1.462.677 3.012.554 4.553a11.165 11.165 0 0 1-.785 3.639c-1.18 2.78-3.2 4.53-6.142 5.046-1.859.327-3.645.052-5.28-.965-1.266-.788-2.084-1.96-2.636-3.344-.235-.612-.425-1.245-.61-1.78zm6.198-9.757c-.521.062-1.048.09-1.562.193-2.07.404-3.504 1.61-4.278 3.627-.504 1.314-.564 2.666-.352 4.045.352 2.368 1.645 3.936 3.83 4.735a7.282 7.282 0 0 0 3.576.288c1.809-.259 3.2-1.159 4.08-2.822.882-1.662 1.028-3.463.68-5.297a5.753 5.753 0 0 0-.841-2.169 5.593 5.593 0 0 0-1.623-1.636c-1.063-.71-2.27-.914-3.51-.964zM31.266 13.338c.17-.535.329-1.072.513-1.6a8.413 8.413 0 0 1 1.866-3.163 5.922 5.922 0 0 1 3.798-1.827c1.45-.139 2.866.014 4.172.705 1.849.978 2.946 2.565 3.266 4.66.116.933.163 1.872.141 2.81.017 3.325.01 6.647.011 9.97 0 .447-.135.58-.564.569h-1.894c-.516 0-.68-.145-.68-.678v-9.945a7.481 7.481 0 0 0-.29-2.19c-.507-1.688-1.629-2.677-3.312-2.994a7.176 7.176 0 0 0-2.911 0c-1.267.282-2.214 1.033-2.936 2.113a7.113 7.113 0 0 0-1.226 4.056v9.182c-.03.3-.116.398-.412.407-.404.014-.81 0-1.214 0-.346 0-.69.03-1.037.027-.42 0-.555-.144-.555-.579V.641c0-.485.115-.599.587-.599h2.07c.435 0 .565.126.565.58v12.71l.042.006zM10.368 13.28c.245-.685.465-1.383.736-2.059.642-1.593 1.645-2.88 3.14-3.721a6.231 6.231 0 0 1 2.89-.798 8.136 8.136 0 0 1 3.147.49c1.946.73 3.138 2.183 3.644 4.211.197.775.303 1.571.318 2.372.047 3.538.041 7.076.055 10.623 0 .177.009.355 0 .53-.02.348-.166.51-.503.532-.201.011-.405-.023-.606-.021-.502 0-.998.01-1.489.029-.564.019-.72-.134-.72-.706V14.72a6.844 6.844 0 0 0-.377-2.36 4.005 4.005 0 0 0-1.122-1.723 3.858 3.858 0 0 0-1.812-.915 6.96 6.96 0 0 0-3.085-.056c-1.525.324-2.616 1.222-3.34 2.617a8.343 8.343 0 0 0-.942 3.886v8.558c0 .64-.188.772-.815.734-.514-.037-1.035-.01-1.553 0-.097 0-.188.015-.293.011-.41-.017-.565-.193-.565-.602V7.729c.003-.108.013-.215.03-.322a.3.3 0 0 1 .09-.196.286.286 0 0 1 .194-.082c.307-.02.616-.033.923-.037h1.4c.46 0 .627.15.625.614 0 .91-.023 1.82-.028 2.727v2.865l.058-.018zM103.283 15.337v4.603c-.003.518.116 1.029.344 1.49.39.799 1.032 1.177 1.882 1.237a4.415 4.415 0 0 0 1.969-.307l.105-.037c.307-.096.428 0 .424.323 0 .53-.017 1.064-.021 1.595 0 .193 0 .4.013.6a.468.468 0 0 1-.065.335.446.446 0 0 1-.272.197c-1.389.402-2.787.533-4.208.174-1.613-.408-2.554-1.476-2.947-3.1a12.055 12.055 0 0 1-.307-2.704c-.011-.81.032-1.619.03-2.428 0-1.379-.026-2.758-.034-4.137v-2.544c0-.473-.047-.523-.521-.525h-2.596c-.476 0-.6-.18-.574-.676.03-.58.029-1.159 0-1.738-.018-.443.108-.624.537-.624h2.663c.406 0 .493-.08.493-.497V2.48a1.09 1.09 0 0 1 .134-.595c.101-.181.25-.328.431-.423.694-.415 1.368-.867 2.059-1.292a.418.418 0 0 1 .346-.046c.071.034.119.202.119.31v6.06c0 .486.09.579.564.579h3.589c.463 0 .586.172.565.641-.026.58-.026 1.17 0 1.756.024.463-.094.635-.538.635h-3.62c-.47 0-.564.1-.564.58V15.336zM94.248 16.253v8.498c0 .58-.156.728-.732.718-.638-.01-1.276 0-1.914 0-.55 0-.717-.152-.717-.722V7.791c0-.626.077-.703.69-.703h2.031c.509 0 .635.132.635.66l.007 8.505zM90.562 2.057a2.059 2.059 0 0 1 .141-.797c.1-.253.248-.482.436-.675.188-.192.413-.343.66-.444.247-.1.51-.148.777-.141.265-.003.528.049.774.151.246.103.47.255.658.446a2.107 2.107 0 0 1 .594 1.465c0 .562-.216 1.1-.602 1.499-.386.398-.91.623-1.456.626a1.965 1.965 0 0 1-.777-.17 2.008 2.008 0 0 1-.65-.467 2.068 2.068 0 0 1-.425-.69 2.109 2.109 0 0 1-.13-.803z"
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("defs", {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("clipPath", {
        id: "clip0_4478_114974",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
          fill: "#fff",
          d: "M0 0h108v25.875H0z"
        })
      })
    })]
  }));
};

Inhabit.defaultProps = {
  width: "108",
  height: "26",
  viewBox: "0 0 108 26",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};




const StyledLogo = styled_components__WEBPACK_IMPORTED_MODULE_4___default()(Inhabit).withConfig({
  displayName: "LogoLink__StyledLogo",
  componentId: "zp7uha-0"
})(["width:", ";cursor:pointer;", ""], p => p.width || "105px", _theme__WEBPACK_IMPORTED_MODULE_3__/* .media.tablet */ .BC.tablet`
    margin: 0.5rem 0;

    width: 112px;
    width: ${p => p.width || "90px"};
  `);

const LogoLink = (props, ref) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(next_link__WEBPACK_IMPORTED_MODULE_0__["default"], {
  href: props.href,
  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("a", {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(StyledLogo, {
      width: props.width
    })
  })
});

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LogoLink);

/***/ }),

/***/ 58368:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "H": () => (/* binding */ AuthProvider),
/* harmony export */   "Z": () => (/* binding */ useAuth)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utils_ga__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(41453);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(11098);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6153);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(universal_cookie__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _utils_cookies__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1420);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__);
//api here is an axios instance








const cookies = new (universal_cookie__WEBPACK_IMPORTED_MODULE_4___default())();
const AuthContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.createContext)({});
const AuthProvider = ({
  children
}) => {
  const {
    0: user,
    1: setUser
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(null);
  const {
    0: organisation,
    1: setOrganisation
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(null);
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
  const {
    0: isAuthenticated,
    1: setIsAuthenticated
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
  const {
    0: loading,
    1: setLoading
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(true);
  const {
    0: showAdmin,
    1: setShowAdmin
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);

  const isAdmin = ({
    user,
    organisation
  } = {
    user,
    organisation
  }) => user.is_admin || user.id === organisation.owner_id;

  const getUser = async (userId, defaultToAdmin) => {
    setLoading(true);

    try {
      const {
        data: {
          user,
          organisation
        }
      } = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`/api/users/${userId}`);

      if (user) {
        setUser(user);
      }

      if (organisation) {
        setOrganisation(organisation);
      }

      if (user && isAdmin({
        user,
        organisation
      }) && defaultToAdmin) {
        setShowAdmin(isAdmin({
          user,
          organisation
        }));
      }
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_3__/* .logError */ .H)(error);
    } finally {
      setLoading(false);
    }
  };

  const setAdmin = admin => {
    if (user && organisation && isAdmin({
      user,
      organisation
    })) {
      if (admin) {
        (0,_utils_cookies__WEBPACK_IMPORTED_MODULE_5__/* .setCookies */ .lE)("inhabit_admin", 1);
      } else {
        (0,_utils_cookies__WEBPACK_IMPORTED_MODULE_5__/* .removeCookie */ .nJ)("inhabit_admin");
      }

      setShowAdmin(admin);
    }
  };

  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(() => {
    async function loadUserFromCookies() {
      try {
        const exemptRoutes = ["onboarded"];
        const token = (0,_utils_cookies__WEBPACK_IMPORTED_MODULE_5__/* .getCookie */ .ej)("inhabit_token");
        const userId = (0,_utils_cookies__WEBPACK_IMPORTED_MODULE_5__/* .getCookie */ .ej)("inhabit_user_id");
        const showAdminDashboard = parseInt((0,_utils_cookies__WEBPACK_IMPORTED_MODULE_5__/* .getCookie */ .ej)("inhabit_admin")) === 1;
        const pathname = router.pathname.split("/");
        const currentPath = pathname[pathname.length - 1];

        if (token && !exemptRoutes.includes(currentPath)) {
          await getUser(userId, showAdminDashboard);
        }
      } catch (error) {
        (0,_utils_logger__WEBPACK_IMPORTED_MODULE_3__/* .logError */ .H)(error);
      } finally {
        setLoading(false);
      }
    }

    loadUserFromCookies();
  }, []);

  const login = async ({
    email,
    password
  }) => {
    setLoading(true);
    const {
      data: {
        token,
        user,
        organisation
      }
    } = await axios__WEBPACK_IMPORTED_MODULE_0___default().post("/api/login", {
      email,
      password
    });

    if (token) {
      (0,_utils_cookies__WEBPACK_IMPORTED_MODULE_5__/* .setCookies */ .lE)("inhabit_token", token);
      (0,_utils_cookies__WEBPACK_IMPORTED_MODULE_5__/* .setCookies */ .lE)("inhabit_user_id", user.id);
      localStorage.setItem("inht-login-event", "logout" + Math.random());
      (0,_utils_ga__WEBPACK_IMPORTED_MODULE_7__/* .event */ .B)({
        action: "login"
      });
      setUser(user);
      setOrganisation(organisation);
      setShowAdmin(isAdmin({
        user,
        organisation
      }));
    }

    setLoading(false);
  };

  const logout = () => {
    (0,_utils_cookies__WEBPACK_IMPORTED_MODULE_5__/* .removeCookie */ .nJ)("inhabit_admin");
    (0,_utils_cookies__WEBPACK_IMPORTED_MODULE_5__/* .removeCookie */ .nJ)("inhabit_token");
    (0,_utils_cookies__WEBPACK_IMPORTED_MODULE_5__/* .removeCookie */ .nJ)("inhabit_user_id");
    localStorage.removeItem("inht-login-event");
    setUser(null);
    setOrganisation(null);
    window.location.pathname = "/login";
  };

  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(() => {
    setIsAuthenticated(!!user && !!organisation);
  }, [user, organisation]);
  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(() => {
    const handleInvalidToken = e => {
      if (e.key === "inht-login-event" && e.oldValue && !e.newValue) {
        logout();
      }
    };

    window.addEventListener("storage", handleInvalidToken);
    return function cleanup() {
      window.removeEventListener("storage", handleInvalidToken);
    };
  }, [logout]);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(AuthContext.Provider, {
    value: {
      isAuthenticated,
      user,
      organisation,
      login,
      loading,
      logout,
      setUser,
      setOrganisation,
      getUser,
      setAdmin,
      showAdmin,
      isAdmin
    },
    children: children
  });
};
function useAuth() {
  const context = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(AuthContext);
  return context;
}

/***/ }),

/***/ 36398:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "J": () => (/* binding */ BlogProvider),
/* harmony export */   "Z": () => (/* binding */ useBlogs)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utils_custom_hooks_useLoading__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(68037);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(11098);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);






const BlogContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.createContext)({});
const BlogProvider = ({
  children
}) => {
  const {
    0: features,
    1: setFeatures
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]);
  const {
    0: selectedFeature,
    1: setSelectedFeature
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)();
  const {
    loading,
    setLoading,
    progress,
    setProgress
  } = (0,_utils_custom_hooks_useLoading__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)();
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();

  const getFeatures = async () => {
    try {
      setLoading(true);
      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_0___default().get("/api/features", {
        onDownloadProgress: () => {
          setProgress(Math.floor(progress + (100 - progress / 2)));
        }
      });
      setFeatures(data.sort((a, b) => new Date(b.created_at) - new Date(a.created_at)));
      setLoading(false);
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_4__/* .logError */ .H)(error);
      setLoading(false);
    }
  };

  const getSelectedFeature = async () => {
    const {
      slug
    } = router.query;

    try {
      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`/api/features/${slug}`);
      setSelectedFeature(data);
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_4__/* .logError */ .H)(error);
    }
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(BlogContext.Provider, {
    value: {
      features,
      getFeatures,
      selectedFeature,
      getSelectedFeature,
      setSelectedFeature,
      loading: loading && !features.length,
      progress,
      setProgress
    },
    children: children
  });
};
function useBlogs() {
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
  const context = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(BlogContext);
  const {
    features,
    setSelectedFeature
  } = context;
  const {
    slug
  } = router.query;
  features.length && setSelectedFeature(features.find(feature => feature.slug === slug));
  return context;
}

/***/ }),

/***/ 44989:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ CartProvider),
/* harmony export */   "C": () => (/* binding */ useCart)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _auth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(58368);
/* harmony import */ var _utils_custom_hooks_useLoading__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(68037);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(11098);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);






const CartContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)({});
const CartProvider = ({
  children
}) => {
  const {
    organisation
  } = (0,_auth__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)();
  const {
    0: paymentMethod,
    1: setPaymentMethod
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
  const {
    loading,
    setLoading
  } = (0,_utils_custom_hooks_useLoading__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)();

  const getPaymentMethod = async paymentMethodId => {
    try {
      setLoading(true);
      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`/api/organisations/${organisation.id}/payment-methods/${paymentMethodId}`);
      setPaymentMethod(data);
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_4__/* .logError */ .H)(error);
    } finally {
      setLoading(false);
    }
  };

  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {}, []);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(CartContext.Provider, {
    value: {
      loading,
      getPaymentMethod,
      setPaymentMethod,
      paymentMethod
    },
    children: children
  });
};
function useCart() {
  return (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(CartContext);
}

/***/ }),

/***/ 33742:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "i": () => (/* binding */ ConfigProvider),
/* harmony export */   "Z": () => (/* binding */ useConfig)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_custom_hooks_useLoading__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(68037);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(11098);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);





const ConfigContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)({});
const ConfigProvider = ({
  children
}) => {
  const {
    0: countries,
    1: setCountries
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
  const {
    0: prices,
    1: setPrices
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
  const pageContainer = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
  const {
    loading,
    setLoading
  } = (0,_utils_custom_hooks_useLoading__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)();

  const getCountryCodes = async () => {
    try {
      setLoading(true);
      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`/api/places/country-codes`);
      setCountries(data);
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_3__/* .logError */ .H)(error);
      setLoading(false);
    } finally {
      setLoading(false);
    }
  };

  const getPrices = async () => {
    try {
      setLoading(true);
      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`/api/prices`);
      setPrices(data);
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_3__/* .logError */ .H)(error);
      setLoading(false);
    } finally {
      setLoading(false);
    }
  };

  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
    getCountryCodes();
    getPrices();
  }, []);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(ConfigContext.Provider, {
    value: {
      loadingConfig: loading,
      getCountryCodes,
      countries,
      prices,
      getPrices,
      pageContainer
    },
    children: children
  });
};
function useConfig() {
  return (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(ConfigContext);
}

/***/ }),

/***/ 62942:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "O": () => (/* binding */ FeatureFlagsProvider),
/* harmony export */   "Z": () => (/* binding */ useFeatureFlags)
/* harmony export */ });
/* harmony import */ var _happykit_flags_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(94970);
/* harmony import */ var _happykit_flags_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_happykit_flags_client__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




const FeatureFlagsContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)({});
const FeatureFlagsProvider = ({
  flags,
  children
}) => {
  const featureFlags = (0,_happykit_flags_client__WEBPACK_IMPORTED_MODULE_0__.useFlags)({
    initialState: flags
  });
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(FeatureFlagsContext.Provider, {
    value: _objectSpread({}, featureFlags),
    children: children
  });
};
function useFeatureFlags() {
  return (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(FeatureFlagsContext);
}

/***/ }),

/***/ 85238:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "y": () => (/* binding */ MeasurementProvider),
  "Z": () => (/* binding */ useMeasurements)
});

// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(52167);
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(71853);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
// EXTERNAL MODULE: ./src/components/measurement/utils/applicationMap.js
var applicationMap = __webpack_require__(40516);
// EXTERNAL MODULE: ./src/contexts/auth.js
var auth = __webpack_require__(58368);
;// CONCATENATED MODULE: ./src/utils/arrays.jsx
const sortMeasurementsByDate = (a, b) => new Date(a.period_end) < new Date(b.period_end) ? 1 : -1;
const sortMeasurementsByCreateDate = (a, b) => new Date(a.created_at) < new Date(b.created_at) ? 1 : -1;
// EXTERNAL MODULE: ./src/utils/custom-hooks/useLoading.js
var useLoading = __webpack_require__(68037);
// EXTERNAL MODULE: ./src/utils/logger.js + 1 modules
var logger = __webpack_require__(11098);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
;// CONCATENATED MODULE: ./src/contexts/measurements.js
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }










const MeasurementContext = /*#__PURE__*/(0,external_react_.createContext)({});
const MeasurementProvider = ({
  children
}) => {
  const {
    loading,
    setLoading,
    progress,
    setProgress
  } = (0,useLoading/* default */.Z)();
  const {
    0: measurements,
    1: setMeasurements
  } = (0,external_react_.useState)([]);
  const {
    0: selectedMeasurement,
    1: setSelectedMeasurement
  } = (0,external_react_.useState)(null);
  const {
    0: annualMeasurementsWithResults,
    1: setAnnualMeasurementsWithResults
  } = (0,external_react_.useState)([]);
  const {
    0: mostRecentMeasurementWithResult,
    1: setMostRecentMeasurementWithResult
  } = (0,external_react_.useState)(null);
  const {
    0: dataCollectionMeasurement,
    1: setDataCollectionMeasurement
  } = (0,external_react_.useState)(null);
  const router = (0,router_.useRouter)();
  const {
    organisation
  } = (0,auth/* default */.Z)();

  const getDataCollectionMeasurement = async () => {
    try {
      !dataCollectionMeasurement && setLoading(true);
      const {
        data
      } = await external_axios_default().get(`/api/organisations/${organisation.id}/data-collection`);
      setDataCollectionMeasurement(data);
      setLoading(false);
    } catch (error) {
      (0,logger/* logError */.H)(error);
      setLoading(false);
    }
  };

  const getMeasurements = async () => {
    try {
      var _sortedMeasurements$f;

      setLoading(true);
      const {
        data
      } = await external_axios_default().get(`/api/organisations/${organisation.id}/measurements`, {
        onDownloadProgress: progressEvent => {
          setProgress(Math.floor(progressEvent.loaded * 100 / progressEvent.total));
        }
      });
      const sortedMeasurements = data === null || data === void 0 ? void 0 : data.sort(sortMeasurementsByDate);
      setMeasurements(sortedMeasurements);
      setAnnualMeasurementsWithResults(data === null || data === void 0 ? void 0 : data.filter(measurement => {
        var _measurement$office_m;

        return measurement.time_period === 12 && !!(measurement !== null && measurement !== void 0 && (_measurement$office_m = measurement.office_measurements) !== null && _measurement$office_m !== void 0 && _measurement$office_m.filter(office => !!office.measurement_result).length);
      }).sort((a, b) => new Date(a.year) < new Date(b.year) ? 1 : -1));
      setMostRecentMeasurementWithResult((_sortedMeasurements$f = sortedMeasurements.filter(measurement => {
        var _measurement$office_m2;

        return measurement === null || measurement === void 0 ? void 0 : (_measurement$office_m2 = measurement.office_measurements) === null || _measurement$office_m2 === void 0 ? void 0 : _measurement$office_m2.find(office => !!office.measurement_result);
      })) === null || _sortedMeasurements$f === void 0 ? void 0 : _sortedMeasurements$f[0]);
      setLoading(false);
    } catch (error) {
      (0,logger/* logError */.H)(error);
      setLoading(false);
    }
  };

  const getSelectedMeasurement = async () => {
    const {
      id
    } = router.query;

    try {
      setLoading(true);
      const {
        data
      } = await external_axios_default().get(`/api/organisations/${organisation.id}/measurements/${id}`, {
        onDownloadProgress: progressEvent => {
          setProgress(Math.floor(progressEvent.loaded * 100 / progressEvent.total));
        }
      });
      setSelectedMeasurement(data);
    } catch (error) {
      (0,logger/* logError */.H)(error);
    } finally {
      setLoading(false);
    }
  };

  const updateLastCompletedStep = async step => {
    if ((0,applicationMap/* shouldUpdateLastCompletedStep */._Z)({
      step,
      measurement: selectedMeasurement
    })) {
      const {
        data: measurement
      } = await external_axios_default().patch(`/api/organisations/${organisation.id}/measurements/${selectedMeasurement.id}`, {
        last_completed_step: step
      });
      setSelectedMeasurement(_objectSpread(_objectSpread({}, selectedMeasurement), measurement));
      return measurement;
    } else {
      const {
        data: measurement
      } = await external_axios_default().get(`/api/organisations/${organisation.id}/measurements/${selectedMeasurement.id}`);
      setSelectedMeasurement(_objectSpread(_objectSpread({}, selectedMeasurement), measurement));
      return measurement;
    }
  };

  (0,external_react_.useEffect)(() => {
    organisation && getDataCollectionMeasurement();
  }, [organisation]);
  return /*#__PURE__*/jsx_runtime_.jsx(MeasurementContext.Provider, {
    value: {
      measurements,
      getMeasurements,
      selectedMeasurement,
      getSelectedMeasurement,
      setSelectedMeasurement,
      dataCollectionMeasurement,
      setDataCollectionMeasurement,
      loading,
      mostRecentMeasurementWithResult,
      setLoading,
      progress,
      setProgress,
      updateLastCompletedStep,
      getDataCollectionMeasurement,
      annualMeasurementsWithResults
    },
    children: children
  });
};
function useMeasurements({
  defaultSelectedMeasurement
} = {
  defaultSelectedMeasurement: false
}) {
  const router = (0,router_.useRouter)();
  const context = (0,external_react_.useContext)(MeasurementContext);
  const {
    measurements,
    setSelectedMeasurement
  } = context;
  const {
    id
  } = router.query;

  if (defaultSelectedMeasurement) {
    !!measurements.length && setSelectedMeasurement(measurements.find(measurement => measurement.id === parseInt(id)));
  }

  return context;
}

/***/ }),

/***/ 24175:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "L": () => (/* binding */ PolicyProvider),
/* harmony export */   "Z": () => (/* binding */ usePolicies)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_custom_hooks_useLoading__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(68037);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(11098);
/* harmony import */ var _auth__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(58368);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }







const PolicyContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)({});
const CONTAINER_ID = "policy";
const PolicyProvider = ({
  children
}) => {
  const {
    organisation
  } = (0,_auth__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)();
  const {
    0: policies,
    1: setPolicies
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
  const {
    0: categories,
    1: setCategories
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
  const {
    0: categoryIcons,
    1: setCategoryIcons
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
  const {
    0: confirmationPolicies,
    1: setConfirmationPolicies
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
  const {
    0: showConfirmationModal,
    1: setShowConfirmationModal
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
  const {
    0: editing,
    1: setEditing
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
  const {
    loading,
    setLoading,
    progress,
    setProgress
  } = (0,_utils_custom_hooks_useLoading__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)({
    defaultLoading: true
  });

  const getImage = async imageUrl => {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(imageUrl);
    return data;
  };

  const getPolicies = async () => {
    try {
      setLoading(true);
      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`/api/organisations/${organisation.id}/policies`);
      const {
        data: categories
      } = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`/api/policy-categories`, {
        onDownloadProgress: progressEvent => {
          setProgress(Math.floor(progressEvent.loaded * 100 / progressEvent.total));
        }
      });
      const categoryIcons = await Promise.all(categories.filter(category => !!category.icon).map(async category => ({
        id: category.id,
        svg: await getImage(category.icon)
      })));
      setCategoryIcons(categoryIcons);
      setCategories(categories);
      setPolicies(data);
      setLoading(false);
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_3__/* .logError */ .H)(error, CONTAINER_ID);
      setLoading(false);
    }
  };

  const handlePolicies = async ({
    editedPolicies,
    deletedPolicies
  }) => {
    try {
      setLoading(true);
      setShowConfirmationModal(false);
      let updatedPolicies;

      try {
        const {
          data
        } = await axios__WEBPACK_IMPORTED_MODULE_0___default().patch(`/api/organisations/${organisation.id}/policies`, editedPolicies.map(policy => _objectSpread(_objectSpread({}, policy), policy.policy_category_id && {
          policy_category_id: policy.policy_category_id.value
        })), {
          onUploadProgress: progressEvent => {
            setProgress(Math.floor(progressEvent.loaded * (!deletedPolicies.length ? 100 : 90) / progressEvent.total));
          }
        });
        updatedPolicies = data;
      } catch (error) {
        (0,_utils_logger__WEBPACK_IMPORTED_MODULE_3__/* .logError */ .H)(error, CONTAINER_ID);
      }

      if (deletedPolicies.length) {
        try {
          const {
            data
          } = await axios__WEBPACK_IMPORTED_MODULE_0___default()["delete"](`/api/organisations/${organisation.id}/policies`, {
            data: deletedPolicies
          });
          setProgress(100);
          updatedPolicies = data;
        } catch (error) {
          (0,_utils_logger__WEBPACK_IMPORTED_MODULE_3__/* .logError */ .H)(error, CONTAINER_ID);
        }
      }

      setConfirmationPolicies({});
      setPolicies(updatedPolicies);
      setEditing(false);
      setLoading(false);
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_3__/* .logError */ .H)(error, CONTAINER_ID);
      setLoading(false);
    }
  };

  const submitPolicies = async ({
    policies
  }) => {
    const deletedPolicies = policies.filter(policy => policy.delete);
    const editedPolicies = policies.filter(policy => !policy.delete && policy.description.length > 3).map(policy => {
      delete policy.delete;
      return policy;
    });

    if (deletedPolicies.length) {
      setConfirmationPolicies({
        editedPolicies,
        deletedPolicies
      });
      setShowConfirmationModal(true);
    } else {
      await handlePolicies({
        editedPolicies,
        deletedPolicies
      });
    }
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(PolicyContext.Provider, {
    value: {
      policies,
      categories,
      categoryIcons,
      confirmationPolicies,
      getPolicies,
      setPolicies,
      handlePolicies,
      submitPolicies,
      loading: loading && !policies.length,
      progress,
      setProgress,
      showConfirmationModal,
      setShowConfirmationModal,
      editing,
      setEditing
    },
    children: children
  });
};
function usePolicies() {
  const context = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(PolicyContext);
  return context;
}

/***/ }),

/***/ 98605:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "j": () => (/* binding */ ProjectProvider),
/* harmony export */   "Z": () => (/* binding */ useProjects)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var lodash_uniqby__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(51650);
/* harmony import */ var lodash_uniqby__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash_uniqby__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _utils_custom_hooks_useLoading__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(68037);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(11098);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__);







const ProjectContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_3__.createContext)({});
const ProjectProvider = ({
  children
}) => {
  const {
    loading,
    setLoading,
    progress,
    setProgress
  } = (0,_utils_custom_hooks_useLoading__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)();
  const {
    0: projects,
    1: setProjects
  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)([]);
  const {
    0: nextPage,
    1: setNextPage
  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(1);
  const {
    0: hasNextPage,
    1: setHasNextPage
  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
  const {
    0: selectedProject,
    1: setSelectedProject
  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(null);
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();

  const getProjects = async ({
    page,
    minimum_available_mass
  } = {}) => {
    try {
      var _data$meta, _data$meta2, _data$meta3, _data$data, _data$data2;

      setLoading(true);
      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`/api/projects`, {
        params: {
          page,
          minimum_available_mass
        },
        onDownloadProgress: progressEvent => {
          setProgress(Math.floor(progressEvent.loaded * 100 / progressEvent.total));
        }
      });
      setHasNextPage(!!(data !== null && data !== void 0 && (_data$meta = data.meta) !== null && _data$meta !== void 0 && _data$meta.next_page));
      setProjects(lodash_uniqby__WEBPACK_IMPORTED_MODULE_1___default()([...((data === null || data === void 0 ? void 0 : (_data$meta2 = data.meta) === null || _data$meta2 === void 0 ? void 0 : _data$meta2.next_page) > 2 || (data === null || data === void 0 ? void 0 : (_data$meta3 = data.meta) === null || _data$meta3 === void 0 ? void 0 : _data$meta3.next_page) === null ? [...projects, ...((_data$data = data.data) === null || _data$data === void 0 ? void 0 : _data$data.filter(project => project.remaining_mass_g))] : (_data$data2 = data.data) === null || _data$data2 === void 0 ? void 0 : _data$data2.filter(project => project.remaining_mass_g))], "id"));
      setLoading(false);
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_5__/* .logError */ .H)(error);
      setLoading(false);
    }
  };

  const getSelectedProject = async project_id => {
    const id = project_id || router.query.id;

    try {
      setLoading(true);
      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`/api/projects/${id}`, {
        onDownloadProgress: progressEvent => {
          setProgress(Math.floor(progressEvent.loaded * 100 / progressEvent.total));
        }
      });
      setSelectedProject(data.data);
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_5__/* .logError */ .H)(error);
    } finally {
      setLoading(false);
    }
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(ProjectContext.Provider, {
    value: {
      projects,
      getProjects,
      selectedProject,
      getSelectedProject,
      setSelectedProject,
      loading: loading,
      setLoading,
      progress,
      setProgress,
      nextPage,
      setNextPage,
      hasNextPage
    },
    children: children
  });
};
function useProjects() {
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
  const context = (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(ProjectContext);
  return context;
}

/***/ }),

/***/ 55100:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "w": () => (/* binding */ ReductionPartnersProvider),
/* harmony export */   "Z": () => (/* binding */ useReductionPartners)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utils_custom_hooks_useLoading__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(68037);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(11098);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);






const ReductionPartnersContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.createContext)({});
const ReductionPartnersProvider = ({
  children
}) => {
  const {
    0: categories,
    1: setCategories
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]);
  const {
    0: reductionPartners,
    1: setReductionPartners
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]);
  const {
    0: categoryName,
    1: setCategoryName
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)();
  const {
    0: selectedReductionPartner,
    1: setSelectedReductionPartner
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(null);
  const {
    0: filtered,
    1: setFiltered
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)();
  const {
    loading,
    setLoading,
    progress,
    setProgress
  } = (0,_utils_custom_hooks_useLoading__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)();
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();

  const getReductionPartners = async () => {
    try {
      setLoading(true);
      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_0___default().get("/api/reduce", {
        onDownloadProgress: progressEvent => {
          setProgress(Math.floor(progress + (100 - progress / 2)));
        }
      });
      const categories = [...new Set(data.map(e => e.reduction_category).map(o => JSON.stringify(o)))].map(s => JSON.parse(s)).sort((a, b) => a.label > b.label ? 1 : -1);
      setCategories(categories);
      setReductionPartners(data);
      setLoading(false);
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_4__/* .logError */ .H)(error);
      setLoading(false);
    }
  };

  const getFilteredReductionPartners = () => {
    const res = categories.map(({
      label
    }) => label).reduce((accu, currentValue) => (accu[currentValue] = reductionPartners.filter(reductionPartner => reductionPartner.reduction_category.label === currentValue), accu), {});
    return res;
  };

  const getSelectedReductionPartner = async () => {
    const {
      slug
    } = router.query;

    try {
      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`/api/reduce/${slug}`);
      setSelectedReductionPartner(data);
      setCategoryName(data.reduction_category.label);
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_4__/* .logError */ .H)(error);
    }
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(ReductionPartnersContext.Provider, {
    value: {
      categories,
      reductionPartners,
      getReductionPartners,
      getFilteredReductionPartners,
      getSelectedReductionPartner,
      setSelectedReductionPartner,
      loading: loading && !reductionPartners.length,
      progress,
      setProgress,
      filtered,
      selectedReductionPartner,
      setSelectedReductionPartner,
      categoryName,
      setCategoryName
    },
    children: children
  });
};
function useReductionPartners() {
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
  const context = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(ReductionPartnersContext);
  const {
    reductionPartners,
    setSelectedReductionPartner
  } = context;
  const {
    slug
  } = router.query;
  reductionPartners.length && setSelectedReductionPartner(reductionPartners.find(offer => offer.slug === slug));
  return context;
}

/***/ }),

/***/ 13724:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "@happykit/flags/config"
var config_ = __webpack_require__(46411);
// EXTERNAL MODULE: external "@happykit/flags/server"
var server_ = __webpack_require__(48095);
// EXTERNAL MODULE: external "@stripe/react-stripe-js"
var react_stripe_js_ = __webpack_require__(64515);
// EXTERNAL MODULE: external "@stripe/stripe-js"
var stripe_js_ = __webpack_require__(20943);
// EXTERNAL MODULE: ./node_modules/next/app.js
var app = __webpack_require__(7544);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(71853);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
// EXTERNAL MODULE: external "react-hotjar"
var external_react_hotjar_ = __webpack_require__(25716);
// EXTERNAL MODULE: external "react-toastify"
var external_react_toastify_ = __webpack_require__(1187);
// EXTERNAL MODULE: ./node_modules/react-toastify/dist/ReactToastify.css
var ReactToastify = __webpack_require__(88819);
// EXTERNAL MODULE: ./src/components/common/Page.jsx + 6 modules
var Page = __webpack_require__(97598);
// EXTERNAL MODULE: ./src/theme.js
var theme = __webpack_require__(91073);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(57518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: ./src/utils/constants.js
var constants = __webpack_require__(16170);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
;// CONCATENATED MODULE: ./src/components/common/PageToastContainer.jsx





const StyledToastContainer = external_styled_components_default()(external_react_toastify_.ToastContainer).attrs({
  autoClose: false,
  enableMultiContainer: true
}).withConfig({
  displayName: "PageToastContainer__StyledToastContainer",
  componentId: "sc-1v2c2w0-0"
})(["&.Toastify__toast-container{width:100%;color:", ";top:0;padding:0;position:relative;", "}.Toastify__toast{border-radius:0;min-height:3rem;display:flex;align-items:center;margin-bottom:initial;}.Toastify__toast--error{background-color:", ";}.Toastify__toast--info{background-color:", ";}.Toastify__toast--warning{background-color:#f5c223;}.Toastify__toast--success{background-color:", ";}.Toastify__toast-body{font-weight:500;display:flex;align-items:center;justify-content:center;}.Toastify__progress-bar{}.Toastify__close-button > svg{height:30px;width:30px;}"], p => p.theme.colors.white, theme/* media.tablet */.BC.tablet`
        max-width: ${p => p.maxWidth || "100%"};
    `, p => p.theme.colors.red, p => p.theme.colors.blue, p => p.theme.colors.green);

const PageToastContainer = ({
  maxWidth,
  position
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx(StyledToastContainer, {
    enableMultiContainer: true,
    containerId: constants/* IMPORTANT_NOTIFICATIONS_CONTAINER_ID */.A4,
    transition: external_react_toastify_.Zoom,
    limit: 1,
    maxWidth: maxWidth,
    position: position
  });
};

/* harmony default export */ const common_PageToastContainer = (PageToastContainer);
// EXTERNAL MODULE: external "@material-ui/core/styles"
var styles_ = __webpack_require__(48308);
// EXTERNAL MODULE: ./src/contexts/auth.js
var auth = __webpack_require__(58368);
// EXTERNAL MODULE: ./src/contexts/blog.js
var blog = __webpack_require__(36398);
// EXTERNAL MODULE: ./src/contexts/cart.js
var cart = __webpack_require__(44989);
// EXTERNAL MODULE: ./src/contexts/config.js
var config = __webpack_require__(33742);
// EXTERNAL MODULE: ./src/contexts/flags.js
var contexts_flags = __webpack_require__(62942);
// EXTERNAL MODULE: ./src/contexts/measurements.js + 1 modules
var measurements = __webpack_require__(85238);
// EXTERNAL MODULE: ./src/contexts/policy.js
var policy = __webpack_require__(24175);
// EXTERNAL MODULE: ./src/contexts/project.js
var project = __webpack_require__(98605);
// EXTERNAL MODULE: ./src/contexts/reductionPartners.js
var reductionPartners = __webpack_require__(55100);
;// CONCATENATED MODULE: ./src/components/common/Providers.jsx














const Providers = ({
  flags,
  children
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx(styles_.ThemeProvider, {
    theme: theme/* muiTheme */.Dg,
    children: /*#__PURE__*/jsx_runtime_.jsx(external_styled_components_.ThemeProvider, {
      theme: theme/* default */.ZP,
      children: /*#__PURE__*/jsx_runtime_.jsx(config/* ConfigProvider */.i, {
        children: /*#__PURE__*/jsx_runtime_.jsx(contexts_flags/* FeatureFlagsProvider */.O, {
          flags,
          children: /*#__PURE__*/jsx_runtime_.jsx(auth/* AuthProvider */.H, {
            children: /*#__PURE__*/jsx_runtime_.jsx(blog/* BlogProvider */.J, {
              children: /*#__PURE__*/jsx_runtime_.jsx(project/* ProjectProvider */.j, {
                children: /*#__PURE__*/jsx_runtime_.jsx(cart/* CartProvider */.Z, {
                  children: /*#__PURE__*/jsx_runtime_.jsx(policy/* PolicyProvider */.L, {
                    children: /*#__PURE__*/jsx_runtime_.jsx(measurements/* MeasurementProvider */.y, {
                      children: /*#__PURE__*/jsx_runtime_.jsx(reductionPartners/* ReductionPartnersProvider */.w, {
                        children: children
                      })
                    })
                  })
                })
              })
            })
          })
        })
      })
    })
  });
};
// EXTERNAL MODULE: ./src/components/common/Text.jsx
var Text = __webpack_require__(87491);
;// CONCATENATED MODULE: ./src/components/common/StyledToastContainer.jsx






const v1Styles = (0,external_styled_components_.css)([".Toastify__toast-container{}.Toastify__toast{}.Toastify__toast--error{background-color:#ff5252;}.Toastify__toast--info{background-color:#1a66fa;}.Toastify__toast--warning{background-color:#f5c223;}.Toastify__toast--success{background-color:#46d88c;}.Toastify__toast-body{}.Toastify__progress-bar{}"]);
const v2Styles = (0,external_styled_components_.css)(["&.Toastify__toast-container{color:", ";}.Toastify__toast{border-radius:4px;min-height:3rem;display:flex;align-items:center;padding:0.75rem 1.5rem;}.Toastify__toast--error{background-color:", ";&:before{display:block;content:\" \";background:url(/images/cross.svg);background-size:1.25rem 1.25rem;height:1.25rem;width:1.25rem;margin-right:1rem;min-width:1.25rem;}}.Toastify__toast--info{background-color:#1a66fa;color:", ";}.Toastify__toast--warning{background-color:#f5c223;}.Toastify__toast--success{background-color:", ";}.Toastify__toast-body{font-weight:500;}.Toastify__progress-bar{}"], theme/* default.colors.body */.ZP.colors.body, theme/* default.colors.secondaryRed */.ZP.colors.secondaryRed, theme/* default.colors.white */.ZP.colors.white, theme/* default.colors.tertiaryGreen */.ZP.colors.tertiaryGreen);
const StyledToastContainer_StyledToastContainer = external_styled_components_default()(external_react_toastify_.ToastContainer).attrs({
  closeButton: /*#__PURE__*/jsx_runtime_.jsx(external_styled_components_.ThemeProvider, {
    theme: theme/* default */.ZP,
    children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
      color: "placeholderGrey",
      children: "Close"
    })
  })
}).withConfig({
  displayName: "StyledToastContainer",
  componentId: "sc-9iyuv5-0"
})(["", ""], v2Styles);
/* harmony default export */ const common_StyledToastContainer = (StyledToastContainer_StyledToastContainer);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(40968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
;// CONCATENATED MODULE: ./src/components/nav/PageHead.jsx





const PageHead = ({
  title,
  description,
  path,
  imageLink,
  structuredData
}) => {
  const headData = {
    title: title || "Inhabit",
    description: description || "We're here to reduce the barriers to everyday planet-friendly action. Making conscious living accessible, and effortless, for everyone."
  };
  const checkedPath = path === "/" ? "" : path;
  const pageStructuredData = structuredData ? structuredData : `
{
  "@context": "http://schema.org",
  "@type": "Organization",
  "url": "https://inhabit.eco",
  "name": "Inhabit",
  "logo": "https://inhabit.eco/favicon.ico"
}
`;
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)((head_default()), {
    children: [/*#__PURE__*/jsx_runtime_.jsx("title", {
      children: headData.title
    }, "title"), /*#__PURE__*/jsx_runtime_.jsx("meta", {
      name: "theme-color",
      content: "#ffffff"
    }, "theme-color"), path && /*#__PURE__*/jsx_runtime_.jsx("link", {
      rel: "canonical",
      href: `https://inhabit.eco${checkedPath}`
    }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
      name: "description",
      content: headData.description
    }, "description"), /*#__PURE__*/jsx_runtime_.jsx("meta", {
      name: "google-site-verification",
      content: "Ei_ahsKSG9oTOp9XPsd0VS-jz2UgNlRysSC11SYhgcA"
    }, "google-site-verification"), /*#__PURE__*/jsx_runtime_.jsx("meta", {
      name: "test",
      content: "inhabit"
    }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
      property: "og:locale",
      content: "en_GB"
    }, "og:locale"), /*#__PURE__*/jsx_runtime_.jsx("meta", {
      property: "og:type",
      content: "website"
    }, "og:type"), /*#__PURE__*/jsx_runtime_.jsx("meta", {
      property: "og:title",
      content: headData.title
    }, "og:title"), /*#__PURE__*/jsx_runtime_.jsx("meta", {
      name: "viewport",
      content: "width=device-width, initial-scale=1.0"
    }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
      property: "og:description",
      content: headData.description
    }, "og:description"), path && /*#__PURE__*/jsx_runtime_.jsx("meta", {
      property: "og:url",
      content: `https://inhabit.eco${checkedPath}`
    }, "og:url"), /*#__PURE__*/jsx_runtime_.jsx("meta", {
      property: "og:site_name",
      content: "inhabit."
    }, "og:site_name"), /*#__PURE__*/jsx_runtime_.jsx("meta", {
      property: "og:image",
      content: imageLink
    }, "og:image"), /*#__PURE__*/jsx_runtime_.jsx("meta", {
      name: "twitter:card",
      content: "summary"
    }, "twitter:card"), /*#__PURE__*/jsx_runtime_.jsx("meta", {
      name: "twitter:title",
      content: headData.title
    }, "twitter:title"), /*#__PURE__*/jsx_runtime_.jsx("meta", {
      name: "twitter:description",
      content: headData.description
    }, "twitter:description"), /*#__PURE__*/jsx_runtime_.jsx("link", {
      rel: "apple-touch-icon",
      sizes: "180x180",
      href: "/apple-touch-icon.png"
    }), /*#__PURE__*/jsx_runtime_.jsx("link", {
      rel: "icon",
      type: "image/png",
      sizes: "32x32",
      href: "/favicon-32x32.png"
    }), /*#__PURE__*/jsx_runtime_.jsx("link", {
      rel: "icon",
      type: "image/png",
      sizes: "16x16",
      href: "/favicon-16x16.png"
    }), /*#__PURE__*/jsx_runtime_.jsx("link", {
      rel: "manifest",
      href: "/site.webmanifest"
    }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
      name: "msapplication-TileColor",
      content: "#4e4e4e"
    }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
      name: "theme-color",
      content: "#ffffff"
    }), /*#__PURE__*/jsx_runtime_.jsx("script", {
      type: "application/ld+json",
      dangerouslySetInnerHTML: {
        __html: pageStructuredData
      }
    }, "schema")]
  });
};

/* harmony default export */ const nav_PageHead = (PageHead);
// EXTERNAL MODULE: ./src/utils/ga.js
var ga = __webpack_require__(41453);
;// CONCATENATED MODULE: ./src/pages/_app.js
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






















const stripePromise = (0,stripe_js_.loadStripe)("pk_live_bQDaTEuYc10x3BZt9YcGj2cE00Gzwm4gDD");
(0,config_.configure)({
  envKey: "flags_pub_289425705564897805"
});

MyApp.getInitialProps = async appContext => {
  const appProps = await app["default"].getInitialProps(appContext);
  const {
    initialFlagState
  } = await (0,server_.getFlags)({
    context: appContext
  });
  return _objectSpread({
    props: {
      initialFlagState
    }
  }, appProps);
};

function MyApp({
  Component,
  pageProps,
  props
}) {
  const router = (0,router_.useRouter)();
  (0,external_react_.useEffect)(() => {
    const handleRouteChange = url => {
      (0,ga/* pageview */.L)(url);
    }; //When the component is mounted, subscribe to router changes
    //and log those page views


    router.events.on("routeChangeComplete", handleRouteChange); // If the component is unmounted, unsubscribe
    // from the event with the `off` method

    return () => {
      router.events.off("routeChangeComplete", handleRouteChange);
    };
  }, [router.events]);
  (0,external_react_.useEffect)(() => {
    external_react_hotjar_.hotjar.initialize("1504852", "6");
  }, []);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(Providers, {
    flags: props.initialFlagState,
    children: [/*#__PURE__*/jsx_runtime_.jsx(Page/* GlobalStyle */.ZL, {}), /*#__PURE__*/jsx_runtime_.jsx(nav_PageHead, {}), /*#__PURE__*/jsx_runtime_.jsx(common_StyledToastContainer, {
      enableMultiContainer: true,
      position: external_react_toastify_.toast.POSITION.BOTTOM_RIGHT
    }), /*#__PURE__*/jsx_runtime_.jsx(common_PageToastContainer, {
      position: external_react_toastify_.toast.POSITION.TOP_CENTER
    }), /*#__PURE__*/jsx_runtime_.jsx(react_stripe_js_.Elements, {
      stripe: stripePromise,
      options: {
        fonts: [{
          family: "Beatrice",
          src: "url(https://staging-dashboard.inhabit.eco/fonts/Beatrice-Regular.woff)",
          weight: "normal"
        }]
      },
      children: /*#__PURE__*/jsx_runtime_.jsx(Component, _objectSpread({}, pageProps))
    })]
  });
}

/* harmony default export */ const _app = (MyApp);

/***/ }),

/***/ 9968:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_document__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56859);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }







class MyDocument extends next_document__WEBPACK_IMPORTED_MODULE_0__["default"] {
  static async getInitialProps(ctx) {
    const sheet = new styled_components__WEBPACK_IMPORTED_MODULE_1__.ServerStyleSheet();
    const originalRenderPage = ctx.renderPage;

    try {
      ctx.renderPage = () => originalRenderPage({
        enhanceApp: App => props => sheet.collectStyles( /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(App, _objectSpread({}, props)))
      });

      const initialProps = await next_document__WEBPACK_IMPORTED_MODULE_0__["default"].getInitialProps(ctx);
      return _objectSpread(_objectSpread({}, initialProps), {}, {
        styles: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
          children: [initialProps.styles, sheet.getStyleElement()]
        })
      });
    } finally {
      sheet.seal();
    }
  }

  render() {
    return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(next_document__WEBPACK_IMPORTED_MODULE_0__.Html, {
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(next_document__WEBPACK_IMPORTED_MODULE_0__.Head, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("link", {
          rel: "apple-touch-icon",
          sizes: "152x152",
          href: "/apple-touch-icon.png"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("link", {
          rel: "icon",
          type: "image/png",
          sizes: "32x32",
          href: "/favicon-32x32.png"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("link", {
          rel: "icon",
          type: "image/png",
          sizes: "16x16",
          href: "/favicon-16x16.png"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("link", {
          rel: "manifest",
          href: "/site.webmanifest"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("link", {
          rel: "mask-icon",
          href: "/safari-pinned-tab.svg",
          color: "#5bbad5"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("meta", {
          name: "msapplication-TileColor",
          content: "#da532c"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("meta", {
          name: "theme-color",
          content: "#ffffff"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("link", {
          rel: "stylesheet",
          href: "/fonts/fonts.css"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("link", {
          rel: "preconnect",
          href: "https://fonts.gstatic.com/",
          crossOrigin: true
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("link", {
          href: "https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap",
          rel: "stylesheet"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("script", {
          async: true,
          src: `https://www.googletagmanager.com/gtag/js?id=${"G-1CBB78XFQ4"}`
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("script", {
          dangerouslySetInnerHTML: {
            __html: `
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', '${"G-1CBB78XFQ4"}', {
              page_path: window.location.pathname,
            });
          `
          }
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("body", {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(next_document__WEBPACK_IMPORTED_MODULE_0__.Main, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(next_document__WEBPACK_IMPORTED_MODULE_0__.NextScript, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("noscript", {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("iframe", {
            src: `https://www.googletagmanager.com/ns.html?id=${process.env.GTM_ID}`,
            height: "0",
            width: "0",
            title: "gtm",
            style: {
              display: "none",
              visibility: "hidden"
            }
          })
        })]
      })]
    });
  }

}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyDocument);

/***/ }),

/***/ 72994:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "E": () => (/* binding */ borderRadius)
/* harmony export */ });
/* unused harmony export ghostStyles */
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const borderRadius = (0,styled_components__WEBPACK_IMPORTED_MODULE_0__.css)(["border-radius:10px;"]);
const ghostStyles = (0,styled_components__WEBPACK_IMPORTED_MODULE_0__.css)(["null"]);

/***/ }),

/***/ 91073:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "J7": () => (/* binding */ sizes),
/* harmony export */   "BC": () => (/* binding */ media),
/* harmony export */   "Dg": () => (/* binding */ muiTheme),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(48308);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);


const sizes = {
  mobileSmall: "320",
  mobileModern: "375",
  mobileLandscape: "410",
  mobileLarge: "620",
  tablet: "768",
  tabletLarge: "960",
  desktop: "1200",
  desktopLarge: "1360",
  wideScreen: "1400"
};
const media = Object.keys(sizes).reduce((accumulator, label) => {
  const emSize = sizes[label] / 16;

  accumulator[label] = (literals, ...args) => (0,styled_components__WEBPACK_IMPORTED_MODULE_1__.css)(["@media (min-width:", "em){", ";}"], emSize, (0,styled_components__WEBPACK_IMPORTED_MODULE_1__.css)(literals, ...args));

  return accumulator;
}, {});
const colors = {
  body: "#4E4E4E",
  seperator: "#F4F5F5",
  white: "#FFFFFF",
  label: "#4E4E4E",
  lightestGrey: "#f7f7f7",
  lightGrey: "#F5F5F4",
  timeGrey: "#acacac",
  grey: "#797979",
  mediumGrey: "#5a5a5a",
  tabGrey: "#f4f4f4",
  backgroundGrey: "#F5F6FA",
  linkBlue: "#3C65EC",
  black: "#4E4E4E",
  admin: "#1A66FA",
  nonAdmin: "#F5C223",
  transparent: "transparent",
  error: "#FE5151",
  yellow: "#f4c223",
  secondaryYellow: "#F1C95B",
  lightYellow: "rgba(245, 194, 35, 0.27)",
  inactive: "#cecece",
  red: "#EC5F59",
  placeholderGrey: "#BBBBBB",
  secondaryGrey: "#E6E7EA",
  backgroundYellow: "#FFEBB1",
  progressYellow: "#FBD365",
  blue: "#2E68F1",
  secondaryBlue: "#BED1FF",
  tertiaryBlue: "#CBD9FB",
  secondaryRed: "#FCD5D4",
  tertiaryRed: "#F8B7B5",
  warning: "#FE5151",
  tertiaryGreen: "#B6F1CE",
  green: "#71E69E",
  peach: "#FFDEC4",
  graphBlue: "#7495B1",
  graphYellow: "#EEBC32",
  graphGreen: "#76B591",
  paleOlive: "#BEBFBB",
  paleBlue: "#DAE5FF",
  paleYellow: "#FFF3D0",
  paleOrange: "#FFEAD9",
  paleRed: "#FBE8E7",
  paleGreen: "#C6DED0",
  palePurple: "#F0E3FF",
  darkRed: "#D4622A",
  darkGreen: "#76B591",
  darkBlue: "#7495B1",
  darkYellow: "#EEBC32"
};
const muiTheme = (0,_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__.createTheme)({
  palette: {
    primary: {
      main: colors.blue
    }
  },
  typography: {
    fontFamily: "Beatrice, sans-serif"
  }
});
const theme = {
  colors,
  zIndex: {
    header: 1,
    hamburger: 2,
    logo: 3,
    mobileMenuLink: 4,
    modal: 5
  },
  mobile: {
    h1: {
      color: colors.body,
      size: "1.875rem",
      fontWeight: "400",
      font: "Beatrice, sans-serif;"
    },
    h2: {
      size: "1.35rem",
      fontWeight: "400",
      font: "Beatrice, sans-serif;"
    },
    h3: {
      color: colors.body,
      size: "1.375rem",
      fontWeight: "400",
      font: "Beatrice, sans-serif;"
    },
    h4: {
      color: colors.body,
      size: "1.25rem",
      fontWeight: "400",
      font: "Beatrice, sans-serif;"
    },
    button: {
      size: "0.75rem",
      fontWeight: "400",
      font: "Beatrice, sans-serif;",
      hover: {
        fontWeight: "400"
      }
    },
    body: {
      color: colors.body,
      size: "1.125rem",
      fontWeight: "400",
      font: "Beatrice, sans-serif;"
    },
    subtitle: {
      color: colors.body,
      size: "1rem",
      fontWeight: "400",
      font: "Beatrice, sans-serif;"
    },
    subtitleBold: {
      size: "0.875rem",
      fontWeight: "400",
      font: "Beatrice, sans-serif;"
    },
    bigBody: {
      color: colors.body,
      size: "1.375rem",
      fontWeight: "400",
      font: "Beatrice, sans-serif;"
    },
    boldBody: {
      color: colors.body,
      size: "1.125rem",
      fontWeight: "400",
      font: "Beatrice, sans-serif;"
    },
    bigNumber: {
      size: "2rem",
      fontWeight: "400",
      font: "Beatrice, sans-serif;"
    },
    modalTitle: {
      color: "#1A66FA",
      size: "1.25rem",
      fontWeight: "400",
      font: "Beatrice, sans-serif;"
    },
    small: {
      color: colors.body,
      size: "0.875rem",
      fontWeight: "400",
      font: "Beatrice, sans-serif;"
    },
    smallBold: {
      color: colors.body,
      size: "0.875rem",
      fontWeight: "400",
      font: "Beatrice, sans-serif;"
    },
    tiny: {
      color: colors.body,
      size: "0.75rem",
      fontWeight: "400",
      font: "Beatrice, sans-serif;"
    },
    tinyTitle: {
      color: colors.placeholderGrey,
      size: "0.75rem",
      fontWeight: "400",
      font: "Beatrice, sans-serif;"
    },
    tinyBold: {
      color: colors.body,
      size: "0.75rem",
      fontWeight: "400",
      font: "Beatrice, sans-serif;"
    },
    minisculeBold: {
      color: colors.body,
      size: "0.685rem",
      fontWeight: "400",
      font: "Beatrice, sans-serif;"
    },
    cardHeader: {
      color: colors.body,
      size: "0.9rem",
      fontWeight: "400",
      font: "Beatrice, sans-serif;"
    },
    contentTitle: {
      size: "1.5rem",
      fontWeight: "400",
      font: "Beatrice, sans-serif;"
    },
    cardTitle: {
      size: "1rem",
      fontWeight: "400",
      font: "Beatrice, sans-serif;"
    },
    cardTitleBold: {
      size: "1rem",
      fontWeight: "400",
      font: "Beatrice, sans-serif;"
    },
    breadcrumb: {
      size: "0.685rem",
      fontWeight: "400",
      font: "Beatrice, sans-serif;"
    },
    subheader: {
      size: "1.25rem",
      fontWeight: "400",
      font: "Beatrice, sans-serif;"
    },
    logo: {
      size: "1rem",
      fontWeight: "400",
      font: "Beatrice, sans-serif;"
    },
    subheaderBold: {
      size: "1.25rem",
      fontWeight: "400",
      font: "Beatrice, sans-serif;"
    },
    avatar: {
      size: "3.5rem",
      fontWeight: "400",
      font: "Beatrice, sans-serif;"
    },
    blogTitle: {
      size: "1.875rem",
      fontWeight: "400",
      font: "Beatrice, sans-serif;"
    },
    offerPrice: {
      size: "0.875rem",
      fontWeight: "400",
      font: "Beatrice, sans-serif;"
    },
    miniscule: {
      size: "0.685rem",
      fontWeight: "400",
      font: "Beatrice, sans-serif;"
    },
    comingSoon: {
      size: "1.625rem",
      fontWeight: "400",
      font: "Beatrice, sans-serif;"
    },
    alert: {
      size: "0.875rem",
      fontWeight: "400",
      font: "Beatrice, sans-serif;"
    },
    meta: {
      size: "0.75rem",
      fontWeight: "400",
      font: "Beatrice, sans-serif;"
    },
    sectionTitle: {
      size: "1.25rem",
      fontWeight: "400",
      font: "Beatrice, sans-serif;"
    },
    error: {
      color: colors.error,
      size: "0.6rem",
      fontWeight: "400",
      font: "Beatrice, sans-serif;"
    },
    subtitle1: {
      size: "1.125rem",
      fontWeight: "400",
      font: "Beatrice, sans-serif;"
    }
  },
  h1: {
    color: colors.body,
    size: "3.4375rem",
    fontWeight: "400",
    font: "Beatrice, sans-serif;"
  },
  h2: {
    color: colors.body,
    size: "2.375rem",
    fontWeight: "400",
    font: "Beatrice, sans-serif;"
  },
  h3: {
    color: colors.body,
    size: "1.625rem",
    fontWeight: "400",
    font: "Beatrice, sans-serif;"
  },
  h4: {
    color: colors.body,
    size: "1.25rem",
    fontWeight: "400",
    font: "Beatrice, sans-serif;"
  },
  button: {
    size: "0.75rem",
    fontWeight: "400",
    font: "Beatrice, sans-serif;",
    hover: {
      fontWeight: "400"
    }
  },
  input: {
    size: "0.875rem",
    fontWeight: "400",
    font: "Beatrice, sans-serif;"
  },
  body: {
    color: colors.body,
    size: "0.875rem",
    fontWeight: "400",
    font: "Beatrice, sans-serif;"
  },
  boldBody: {
    color: colors.body,
    size: "1.125rem",
    fontWeight: "400",
    font: "Beatrice, sans-serif;"
  },
  modalTitle: {
    color: "#1A66FA",
    size: "1.25rem",
    fontWeight: "400",
    font: "Beatrice, sans-serif;"
  },
  bigNumber: {
    color: colors.body,
    size: "3rem",
    fontWeight: "400",
    font: "Beatrice, sans-serif;"
  },
  subtitle: {
    color: colors.body,
    size: "1rem",
    fontWeight: "400",
    font: "Beatrice, sans-serif;"
  },
  subtitleBold: {
    size: "1rem",
    fontWeight: "400",
    font: "Beatrice, sans-serif;"
  },
  bigBody: {
    color: colors.body,
    size: "1.375rem",
    fontWeight: "400",
    font: "Beatrice, sans-serif;"
  },
  small: {
    color: colors.body,
    size: "0.875rem",
    fontWeight: "400",
    font: "Beatrice, sans-serif;"
  },
  smallBold: {
    color: colors.body,
    size: "0.875rem",
    fontWeight: "400",
    font: "Beatrice, sans-serif;"
  },
  tiny: {
    color: colors.body,
    size: "0.75rem",
    fontWeight: "400",
    font: "Beatrice, sans-serif;"
  },
  tinyTitle: {
    color: colors.placeholderGrey,
    size: "0.75rem",
    fontWeight: "400",
    font: "Beatrice, sans-serif;"
  },
  tinyBold: {
    color: colors.body,
    size: "0.75rem",
    fontWeight: "400",
    font: "Beatrice, sans-serif;"
  },
  minisculeBold: {
    color: colors.body,
    size: "0.685rem",
    fontWeight: "400",
    font: "Beatrice, sans-serif;"
  },
  cardHeader: {
    color: colors.body,
    size: "0.9rem",
    fontWeight: "400",
    font: "Beatrice, sans-serif;"
  },
  contentTitle: {
    size: "1.5rem",
    fontWeight: "400",
    font: "Beatrice, sans-serif;"
  },
  miniscule: {
    size: "0.685rem",
    fontWeight: "400",
    font: "Beatrice, sans-serif;"
  },
  textarea: {
    size: "0.875rem",
    fontWeight: "400",
    font: "Beatrice, sans-serif;"
  },
  cardTitle: {
    size: "1.25rem",
    fontWeight: "400",
    font: "Beatrice, sans-serif;"
  },
  cardTitleBold: {
    size: "1.25rem",
    fontWeight: "400",
    font: "Beatrice, sans-serif;"
  },
  breadcrumb: {
    size: "0.685rem",
    fontWeight: "400",
    font: "Beatrice, sans-serif;"
  },
  subheader: {
    size: "1.5rem",
    fontWeight: "400",
    font: "Beatrice, sans-serif;"
  },
  subheaderBold: {
    size: "1.5rem",
    fontWeight: "400",
    font: "Beatrice, sans-serif;"
  },
  logo: {
    size: "1.5rem",
    fontWeight: "400",
    font: "Beatrice, sans-serif;"
  },
  avatar: {
    size: "3.5rem",
    fontWeight: "400",
    font: "Beatrice, sans-serif;"
  },
  blogTitle: {
    size: "2.25rem",
    fontWeight: "400",
    font: "Beatrice, sans-serif;"
  },
  offerPrice: {
    size: "1.25rem",
    fontWeight: "400",
    font: "Beatrice, sans-serif;"
  },
  comingSoon: {
    size: "1.625rem",
    fontWeight: "400",
    font: "Beatrice, sans-serif;"
  },
  alert: {
    size: "0.875rem",
    fontWeight: "400",
    font: "Beatrice, sans-serif;"
  },
  meta: {
    size: "0.75rem",
    fontWeight: "400",
    font: "Beatrice, sans-serif;"
  },
  sectionTitle: {
    size: "1.25rem",
    fontWeight: "400",
    font: "Beatrice, sans-serif;"
  },
  error: {
    color: colors.error,
    size: "0.6rem",
    fontWeight: "400",
    font: "Beatrice, sans-serif;"
  },
  subtitle1: {
    size: "1.125rem",
    fontWeight: "400",
    font: "Beatrice, sans-serif;"
  }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (theme);

/***/ }),

/***/ 16170:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C3": () => (/* binding */ POSTCODE_REGEX),
/* harmony export */   "X0": () => (/* binding */ isFalsy),
/* harmony export */   "fQ": () => (/* binding */ isTruthy),
/* harmony export */   "A4": () => (/* binding */ IMPORTANT_NOTIFICATIONS_CONTAINER_ID)
/* harmony export */ });
const POSTCODE_REGEX = /^(([gG][iI][rR] {0,}0[aA]{2})|(BFPO ?\d{1,4})|(([aA][sS][cC][nN]|[sS][tT][hH][lL]|[tT][dD][cC][uU]|[bB][bB][nN][dD]|[bB][iI][qQ][qQ]|[fF][iI][qQ][qQ]|[pP][cC][rR][nN]|[sS][iI][qQ][qQ]|[iT][kK][cC][aA]) {0,}1[zZ]{2})|((([a-pr-uwyzA-PR-UWYZ][a-hk-yxA-HK-XY]?[0-9][0-9]?)|(([a-pr-uwyzA-PR-UWYZ][0-9][a-hjkstuwA-HJKSTUW])|([a-pr-uwyzA-PR-UWYZ][a-hk-yA-HK-Y][0-9][abehmnprv-yABEHMNPRV-Y]))) {0,}[0-9][abd-hjlnp-uw-zABD-HJLNP-UW-Z]{2}))$/i;
const FALSY_VALUES = [undefined, null, ""];
const isFalsy = value => FALSY_VALUES.includes(value);
const isTruthy = value => !isFalsy(value);
const IMPORTANT_NOTIFICATIONS_CONTAINER_ID = "important_notification";

/***/ }),

/***/ 1420:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "lE": () => (/* binding */ setCookies),
/* harmony export */   "ej": () => (/* binding */ getCookie),
/* harmony export */   "nJ": () => (/* binding */ removeCookie)
/* harmony export */ });
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6153);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(universal_cookie__WEBPACK_IMPORTED_MODULE_0__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const cookies = new (universal_cookie__WEBPACK_IMPORTED_MODULE_0___default())();
const setCookies = (name, value, options) => cookies.set(name, value, _objectSpread({
  sameSite: "strict",
  path: "/"
}, options));
const getCookie = (name, options) => cookies.get(name, options);
const removeCookie = name => cookies.remove(name, {
  path: "/"
});

/***/ }),

/***/ 68037:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);


const useLoading = ({
  defaultLoading
} = {
  defaultLoading: false
}) => {
  const {
    0: loading,
    1: setLoading
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(defaultLoading);
  const {
    0: progress,
    1: setProgress
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
  return {
    loading,
    setLoading,
    progress,
    setProgress
  };
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useLoading);

/***/ }),

/***/ 41453:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "L": () => (/* binding */ pageview),
/* harmony export */   "B": () => (/* binding */ event)
/* harmony export */ });
// log the pageview with their URL
const pageview = url => {
  window.gtag("config", "G-1CBB78XFQ4", {
    page_path: url
  });
}; // log specific events happening.

const event = ({
  action,
  params
}) => {
  window.gtag("event", action, params);
};

/***/ }),

/***/ 11098:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "H": () => (/* binding */ logError)
});

// EXTERNAL MODULE: external "react-toastify"
var external_react_toastify_ = __webpack_require__(1187);
;// CONCATENATED MODULE: ./src/utils/error.js
const getErrorString = err => {
  if (err.request && err.response) {
    console.error(err);
    return `Error ${err.request.method} ${err.request.path} ${err.response.status} ${err.errors}`;
  }

  return err.toString();
};

const transformErrorMessage = message => {
  switch (message) {
    case "jwt expired":
      return "Token has expired. Please re-authenticate to get a new one";
      break;

    case "jwt malformed":
      return "Token is unusable. Please re-authenticate to get a new one";
      break;

    default:
      return message;
      break;
  }
};

const formatErrorString = err => {
  if (err.request && err.response) {
    return transformErrorMessage(err.response.data.errors) || "Sorry, something went wrong. Please try again.";
  }

  return transformErrorMessage(err.toString());
};
// EXTERNAL MODULE: ./src/utils/text.js
var utils_text = __webpack_require__(88703);
;// CONCATENATED MODULE: ./src/utils/logger.js



const logError = (error, containerId) => {
  console.error(error);

  if (error.request && error.response) {
    switch (typeof error.response.data.errors) {
      case "string":
        external_react_toastify_.toast.error(formatErrorString(error), {
          containerId,
          enableMultiContainer: !!containerId
        });
        break;

      case "object":
        if (error.response.status === 400) {
          const errorMessages = Object.keys(error.response.data.errors).map(errorKey => ({
            key: errorKey,
            value: error.response.data.errors[errorKey][0].message
          }));
          errorMessages.forEach(error => external_react_toastify_.toast.error(`${(0,utils_text/* capitalize */.k)(error.key)}: ${error.value}`, {
            containerId
          }));
        } else {
          external_react_toastify_.toast.error(formatErrorString(error), {
            containerId,
            enableMultiContainer: !!containerId
          });
        }

        break;

      default:
        external_react_toastify_.toast.error("Sorry, something went wrong. Please try again.", {
          containerId,
          enableMultiContainer: !!containerId
        });
        break;
    }
  } else {
    external_react_toastify_.toast.error(error.message, {
      containerId,
      enableMultiContainer: !!containerId
    });
  }
};

/***/ }),

/***/ 88703:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "k": () => (/* binding */ capitalize),
/* harmony export */   "$": () => (/* binding */ truncate)
/* harmony export */ });
function capitalize(str) {
  if (typeof str !== "string") {
    return;
  }

  return str.replace(/\w\S*/g, function (txt) {
    return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
  });
}
function truncate(str, n) {
  return str.length > n ? str.substr(0, n - 1).trim() + "..." : str;
}

/***/ }),

/***/ 97020:
/***/ ((module) => {

module.exports = JSON.parse('{"polyfillFiles":["static/chunks/polyfills-5cd94c89d3acac5f.js"],"devFiles":[],"ampDevFiles":[],"lowPriorityFiles":["static/lDoX7RBEQ31kzKIJJbkVC/_buildManifest.js","static/lDoX7RBEQ31kzKIJJbkVC/_ssgManifest.js","static/lDoX7RBEQ31kzKIJJbkVC/_middlewareManifest.js"],"pages":{"/":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/3826-f656ba177fd42305.js","static/chunks/6203-ce6579a42bb27e59.js","static/chunks/2912-86c577cc801305ad.js","static/chunks/5519-c109267b52d9ba2e.js","static/chunks/1511-26a4c3b24c5482c5.js","static/chunks/9290-3bc45a6467aa17bf.js","static/chunks/2523-327f421adadfe4f9.js","static/chunks/490-63f16e02e4d1d888.js","static/chunks/577-7655b7fccb464601.js","static/chunks/1041-e850db0cfdbcc36c.js","static/chunks/pages/index-36a622087db00fc1.js"],"/_app":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/css/24c4927316b24e0b.css","static/chunks/pages/_app-efa6fff72cde0942.js"],"/_error":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/pages/_error-e2ea5f0865bb3517.js"],"/blog":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/3826-f656ba177fd42305.js","static/chunks/6203-ce6579a42bb27e59.js","static/chunks/6556-9b6a2cd77303ced7.js","static/chunks/2523-327f421adadfe4f9.js","static/chunks/490-63f16e02e4d1d888.js","static/chunks/pages/blog-f0a853fe45aefac9.js"],"/blog/[slug]":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/3826-f656ba177fd42305.js","static/chunks/6203-ce6579a42bb27e59.js","static/chunks/6556-9b6a2cd77303ced7.js","static/chunks/2523-327f421adadfe4f9.js","static/chunks/490-63f16e02e4d1d888.js","static/chunks/pages/blog/[slug]-75ef4136ef26710b.js"],"/data-input":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/3826-f656ba177fd42305.js","static/chunks/6203-ce6579a42bb27e59.js","static/chunks/5519-c109267b52d9ba2e.js","static/chunks/8841-16e4103401b1bc1f.js","static/chunks/9720-cad33d74c45d57ef.js","static/chunks/6452-d72287bca908e844.js","static/chunks/8867-5a50a7a102823b80.js","static/chunks/2523-327f421adadfe4f9.js","static/chunks/490-63f16e02e4d1d888.js","static/chunks/4074-f9acaf383231b47c.js","static/chunks/577-7655b7fccb464601.js","static/chunks/1908-061c3c682dbf054b.js","static/chunks/pages/data-input-91727598b64a8423.js"],"/forgot-password":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/3826-f656ba177fd42305.js","static/chunks/2523-327f421adadfe4f9.js","static/chunks/pages/forgot-password-fa64b0cde8a862fe.js"],"/history":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/3826-f656ba177fd42305.js","static/chunks/6203-ce6579a42bb27e59.js","static/chunks/2912-86c577cc801305ad.js","static/chunks/2523-327f421adadfe4f9.js","static/chunks/490-63f16e02e4d1d888.js","static/chunks/pages/history-36b0ccdfd64f1075.js"],"/history/[id]":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/3826-f656ba177fd42305.js","static/chunks/6203-ce6579a42bb27e59.js","static/chunks/2912-86c577cc801305ad.js","static/chunks/5519-c109267b52d9ba2e.js","static/chunks/8841-16e4103401b1bc1f.js","static/chunks/9720-cad33d74c45d57ef.js","static/chunks/6452-d72287bca908e844.js","static/chunks/8867-5a50a7a102823b80.js","static/chunks/2523-327f421adadfe4f9.js","static/chunks/490-63f16e02e4d1d888.js","static/chunks/4074-f9acaf383231b47c.js","static/chunks/577-7655b7fccb464601.js","static/chunks/1908-061c3c682dbf054b.js","static/chunks/4941-8793798670e25fc3.js","static/chunks/pages/history/[id]-1af1d33af7cf8c88.js"],"/history/[id]/compensate":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/3826-f656ba177fd42305.js","static/chunks/6203-ce6579a42bb27e59.js","static/chunks/2523-327f421adadfe4f9.js","static/chunks/490-63f16e02e4d1d888.js","static/chunks/pages/history/[id]/compensate-aade22089c2fdd63.js"],"/history/[id]/compensate/[project_id]":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/3826-f656ba177fd42305.js","static/chunks/6203-ce6579a42bb27e59.js","static/chunks/2523-327f421adadfe4f9.js","static/chunks/490-63f16e02e4d1d888.js","static/chunks/pages/history/[id]/compensate/[project_id]-8d5ee77b1ad25527.js"],"/history/[id]/compensate/[project_id]/checkout":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/3826-f656ba177fd42305.js","static/chunks/6203-ce6579a42bb27e59.js","static/chunks/2523-327f421adadfe4f9.js","static/chunks/490-63f16e02e4d1d888.js","static/chunks/pages/history/[id]/compensate/[project_id]/checkout-6da49316841105c6.js"],"/history/[id]/compensate/[project_id]/payment":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/3826-f656ba177fd42305.js","static/chunks/6203-ce6579a42bb27e59.js","static/chunks/2523-327f421adadfe4f9.js","static/chunks/490-63f16e02e4d1d888.js","static/chunks/pages/history/[id]/compensate/[project_id]/payment-dbda7cbcbb50bb64.js"],"/history/annual/[id]":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/3826-f656ba177fd42305.js","static/chunks/6203-ce6579a42bb27e59.js","static/chunks/2912-86c577cc801305ad.js","static/chunks/5519-c109267b52d9ba2e.js","static/chunks/1511-26a4c3b24c5482c5.js","static/chunks/9290-3bc45a6467aa17bf.js","static/chunks/2523-327f421adadfe4f9.js","static/chunks/490-63f16e02e4d1d888.js","static/chunks/577-7655b7fccb464601.js","static/chunks/1041-e850db0cfdbcc36c.js","static/chunks/pages/history/annual/[id]-e2d7d18306434b65.js"],"/history/annual/[id]/edit":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/3826-f656ba177fd42305.js","static/chunks/6203-ce6579a42bb27e59.js","static/chunks/2912-86c577cc801305ad.js","static/chunks/5519-c109267b52d9ba2e.js","static/chunks/8841-16e4103401b1bc1f.js","static/chunks/9720-cad33d74c45d57ef.js","static/chunks/6452-d72287bca908e844.js","static/chunks/8867-5a50a7a102823b80.js","static/chunks/2523-327f421adadfe4f9.js","static/chunks/490-63f16e02e4d1d888.js","static/chunks/4074-f9acaf383231b47c.js","static/chunks/577-7655b7fccb464601.js","static/chunks/1908-061c3c682dbf054b.js","static/chunks/4941-8793798670e25fc3.js","static/chunks/pages/history/annual/[id]/edit-ece41d2909124e2b.js"],"/history/annual/new":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/3826-f656ba177fd42305.js","static/chunks/6203-ce6579a42bb27e59.js","static/chunks/2912-86c577cc801305ad.js","static/chunks/5519-c109267b52d9ba2e.js","static/chunks/2523-327f421adadfe4f9.js","static/chunks/490-63f16e02e4d1d888.js","static/chunks/pages/history/annual/new-e1ba4d7a09b8a90b.js"],"/login":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/3826-f656ba177fd42305.js","static/chunks/2523-327f421adadfe4f9.js","static/chunks/pages/login-bde4d1e0d338cec1.js"],"/measurements":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/3826-f656ba177fd42305.js","static/chunks/6203-ce6579a42bb27e59.js","static/chunks/2912-86c577cc801305ad.js","static/chunks/8841-16e4103401b1bc1f.js","static/chunks/4629-90711547e1496373.js","static/chunks/1511-26a4c3b24c5482c5.js","static/chunks/9290-3bc45a6467aa17bf.js","static/chunks/1213-f34d1b92551d24f6.js","static/chunks/2523-327f421adadfe4f9.js","static/chunks/490-63f16e02e4d1d888.js","static/chunks/4365-2498f642eec1a108.js","static/chunks/pages/measurements-714b49ab7aa249bb.js"],"/measurements/[id]":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/3826-f656ba177fd42305.js","static/chunks/6203-ce6579a42bb27e59.js","static/chunks/2912-86c577cc801305ad.js","static/chunks/5519-c109267b52d9ba2e.js","static/chunks/8841-16e4103401b1bc1f.js","static/chunks/9720-cad33d74c45d57ef.js","static/chunks/6452-d72287bca908e844.js","static/chunks/8867-5a50a7a102823b80.js","static/chunks/2523-327f421adadfe4f9.js","static/chunks/490-63f16e02e4d1d888.js","static/chunks/4074-f9acaf383231b47c.js","static/chunks/473-dd2b9d7e86fd1d55.js","static/chunks/1303-66b734c2a865fdd8.js","static/chunks/7438-693cbb8a0ff1a4ad.js","static/chunks/2920-ec2530eba91a8d9d.js","static/chunks/pages/measurements/[id]-4bc72571db39503c.js"],"/measurements/[id]/business-travel":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/3826-f656ba177fd42305.js","static/chunks/6203-ce6579a42bb27e59.js","static/chunks/2912-86c577cc801305ad.js","static/chunks/5519-c109267b52d9ba2e.js","static/chunks/8841-16e4103401b1bc1f.js","static/chunks/4629-90711547e1496373.js","static/chunks/9720-cad33d74c45d57ef.js","static/chunks/8867-5a50a7a102823b80.js","static/chunks/2523-327f421adadfe4f9.js","static/chunks/490-63f16e02e4d1d888.js","static/chunks/4365-2498f642eec1a108.js","static/chunks/9595-eefd8616d29ad485.js","static/chunks/4074-f9acaf383231b47c.js","static/chunks/1303-66b734c2a865fdd8.js","static/chunks/pages/measurements/[id]/business-travel-9eb7728e54ee9cdb.js"],"/measurements/[id]/details":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/3826-f656ba177fd42305.js","static/chunks/6203-ce6579a42bb27e59.js","static/chunks/2912-86c577cc801305ad.js","static/chunks/8841-16e4103401b1bc1f.js","static/chunks/4629-90711547e1496373.js","static/chunks/6452-d72287bca908e844.js","static/chunks/2523-327f421adadfe4f9.js","static/chunks/490-63f16e02e4d1d888.js","static/chunks/4365-2498f642eec1a108.js","static/chunks/9595-eefd8616d29ad485.js","static/chunks/pages/measurements/[id]/details-03c2c0de4b760fc8.js"],"/measurements/[id]/expenses":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/3826-f656ba177fd42305.js","static/chunks/6203-ce6579a42bb27e59.js","static/chunks/2912-86c577cc801305ad.js","static/chunks/5519-c109267b52d9ba2e.js","static/chunks/8841-16e4103401b1bc1f.js","static/chunks/4629-90711547e1496373.js","static/chunks/2523-327f421adadfe4f9.js","static/chunks/490-63f16e02e4d1d888.js","static/chunks/4365-2498f642eec1a108.js","static/chunks/9595-eefd8616d29ad485.js","static/chunks/pages/measurements/[id]/expenses-8cef39d1b2e62498.js"],"/measurements/[id]/offices":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/3826-f656ba177fd42305.js","static/chunks/6203-ce6579a42bb27e59.js","static/chunks/2912-86c577cc801305ad.js","static/chunks/5519-c109267b52d9ba2e.js","static/chunks/8841-16e4103401b1bc1f.js","static/chunks/4629-90711547e1496373.js","static/chunks/2523-327f421adadfe4f9.js","static/chunks/490-63f16e02e4d1d888.js","static/chunks/4365-2498f642eec1a108.js","static/chunks/9595-eefd8616d29ad485.js","static/chunks/473-dd2b9d7e86fd1d55.js","static/chunks/pages/measurements/[id]/offices-7281cddcddab9228.js"],"/measurements/[id]/result":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/3826-f656ba177fd42305.js","static/chunks/6203-ce6579a42bb27e59.js","static/chunks/2912-86c577cc801305ad.js","static/chunks/5519-c109267b52d9ba2e.js","static/chunks/1511-26a4c3b24c5482c5.js","static/chunks/9290-3bc45a6467aa17bf.js","static/chunks/2523-327f421adadfe4f9.js","static/chunks/490-63f16e02e4d1d888.js","static/chunks/577-7655b7fccb464601.js","static/chunks/pages/measurements/[id]/result-1300237db1cb0730.js"],"/measurements/[id]/review":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/3826-f656ba177fd42305.js","static/chunks/6203-ce6579a42bb27e59.js","static/chunks/2912-86c577cc801305ad.js","static/chunks/5519-c109267b52d9ba2e.js","static/chunks/8841-16e4103401b1bc1f.js","static/chunks/4629-90711547e1496373.js","static/chunks/9720-cad33d74c45d57ef.js","static/chunks/6452-d72287bca908e844.js","static/chunks/8867-5a50a7a102823b80.js","static/chunks/2523-327f421adadfe4f9.js","static/chunks/490-63f16e02e4d1d888.js","static/chunks/4365-2498f642eec1a108.js","static/chunks/9595-eefd8616d29ad485.js","static/chunks/4074-f9acaf383231b47c.js","static/chunks/473-dd2b9d7e86fd1d55.js","static/chunks/1303-66b734c2a865fdd8.js","static/chunks/7438-693cbb8a0ff1a4ad.js","static/chunks/2920-ec2530eba91a8d9d.js","static/chunks/pages/measurements/[id]/review-0b6d705f02e22c0e.js"],"/measurements/[id]/vehicles":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/3826-f656ba177fd42305.js","static/chunks/6203-ce6579a42bb27e59.js","static/chunks/2912-86c577cc801305ad.js","static/chunks/5519-c109267b52d9ba2e.js","static/chunks/8841-16e4103401b1bc1f.js","static/chunks/4629-90711547e1496373.js","static/chunks/2523-327f421adadfe4f9.js","static/chunks/490-63f16e02e4d1d888.js","static/chunks/4365-2498f642eec1a108.js","static/chunks/9595-eefd8616d29ad485.js","static/chunks/7438-693cbb8a0ff1a4ad.js","static/chunks/pages/measurements/[id]/vehicles-dc974b0fe385ee15.js"],"/offers":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/3826-f656ba177fd42305.js","static/chunks/6203-ce6579a42bb27e59.js","static/chunks/7847-c73d42200f52177a.js","static/chunks/2523-327f421adadfe4f9.js","static/chunks/490-63f16e02e4d1d888.js","static/chunks/9506-5c4618fb8332d6ad.js","static/chunks/pages/offers-0e992ca64bed4b7b.js"],"/offers/[slug]":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/3826-f656ba177fd42305.js","static/chunks/6203-ce6579a42bb27e59.js","static/chunks/1511-26a4c3b24c5482c5.js","static/chunks/881-8b9088401ec2c565.js","static/chunks/2523-327f421adadfe4f9.js","static/chunks/490-63f16e02e4d1d888.js","static/chunks/9506-5c4618fb8332d6ad.js","static/chunks/pages/offers/[slug]-451e687fc05d9925.js"],"/offset":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/3826-f656ba177fd42305.js","static/chunks/6203-ce6579a42bb27e59.js","static/chunks/6529-59ba61da95fb5745.js","static/chunks/2523-327f421adadfe4f9.js","static/chunks/490-63f16e02e4d1d888.js","static/chunks/8273-f3a01e7f638b1ce3.js","static/chunks/pages/offset-616487be8d780b2e.js"],"/offset/projects/[slug]":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/3826-f656ba177fd42305.js","static/chunks/6203-ce6579a42bb27e59.js","static/chunks/2523-327f421adadfe4f9.js","static/chunks/490-63f16e02e4d1d888.js","static/chunks/8273-f3a01e7f638b1ce3.js","static/chunks/pages/offset/projects/[slug]-f0ba17a406a55f68.js"],"/offset/projects/[slug]/payment":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/3826-f656ba177fd42305.js","static/chunks/6203-ce6579a42bb27e59.js","static/chunks/2523-327f421adadfe4f9.js","static/chunks/490-63f16e02e4d1d888.js","static/chunks/8273-f3a01e7f638b1ce3.js","static/chunks/pages/offset/projects/[slug]/payment-e241e29fbe1e8c05.js"],"/onboard/change-password":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/3826-f656ba177fd42305.js","static/chunks/6203-ce6579a42bb27e59.js","static/chunks/2523-327f421adadfe4f9.js","static/chunks/490-63f16e02e4d1d888.js","static/chunks/pages/onboard/change-password-93cf4574dc1c65c9.js"],"/onboard/subscribe":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/3826-f656ba177fd42305.js","static/chunks/6203-ce6579a42bb27e59.js","static/chunks/2523-327f421adadfe4f9.js","static/chunks/490-63f16e02e4d1d888.js","static/chunks/pages/onboard/subscribe-804cbdcfc09039b8.js"],"/onboarded":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/pages/onboarded-91f9ed3c4f9edb03.js"],"/policy":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/bee240a3-88d21657c73a4e52.js","static/chunks/a908dc70-d158bd763ad583d1.js","static/chunks/c9184924-e944c58b23cd7c86.js","static/chunks/74fdba35-c9a29b2e41efc8a0.js","static/chunks/3826-f656ba177fd42305.js","static/chunks/6203-ce6579a42bb27e59.js","static/chunks/2912-86c577cc801305ad.js","static/chunks/5519-c109267b52d9ba2e.js","static/chunks/9720-cad33d74c45d57ef.js","static/chunks/7847-c73d42200f52177a.js","static/chunks/73-baae66852089b12f.js","static/chunks/2523-327f421adadfe4f9.js","static/chunks/490-63f16e02e4d1d888.js","static/chunks/pages/policy-6a8d6506d37b542a.js"],"/reset-password":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/3826-f656ba177fd42305.js","static/chunks/pages/reset-password-230d88d03490e83d.js"],"/settings/admin":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/3826-f656ba177fd42305.js","static/chunks/6203-ce6579a42bb27e59.js","static/chunks/2523-327f421adadfe4f9.js","static/chunks/490-63f16e02e4d1d888.js","static/chunks/3086-b5051316dc49e2dd.js","static/chunks/pages/settings/admin-df836aef0ee7cb4b.js"],"/settings/admin/billing":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/3826-f656ba177fd42305.js","static/chunks/6203-ce6579a42bb27e59.js","static/chunks/2912-86c577cc801305ad.js","static/chunks/2523-327f421adadfe4f9.js","static/chunks/490-63f16e02e4d1d888.js","static/chunks/3086-b5051316dc49e2dd.js","static/chunks/pages/settings/admin/billing-c5b88a3a00e31bab.js"],"/settings/admin/manage-team":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/3826-f656ba177fd42305.js","static/chunks/6203-ce6579a42bb27e59.js","static/chunks/2523-327f421adadfe4f9.js","static/chunks/490-63f16e02e4d1d888.js","static/chunks/3086-b5051316dc49e2dd.js","static/chunks/pages/settings/admin/manage-team-fdde99fbe57336dc.js"],"/settings/admin/offset-history":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/3826-f656ba177fd42305.js","static/chunks/6203-ce6579a42bb27e59.js","static/chunks/2912-86c577cc801305ad.js","static/chunks/2523-327f421adadfe4f9.js","static/chunks/490-63f16e02e4d1d888.js","static/chunks/3086-b5051316dc49e2dd.js","static/chunks/pages/settings/admin/offset-history-99315a3019aaf00e.js"],"/settings/admin/organisation-details":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/3826-f656ba177fd42305.js","static/chunks/6203-ce6579a42bb27e59.js","static/chunks/2523-327f421adadfe4f9.js","static/chunks/490-63f16e02e4d1d888.js","static/chunks/3086-b5051316dc49e2dd.js","static/chunks/pages/settings/admin/organisation-details-bf06fccb8133fdb0.js"],"/settings/admin/password":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/3826-f656ba177fd42305.js","static/chunks/6203-ce6579a42bb27e59.js","static/chunks/2523-327f421adadfe4f9.js","static/chunks/490-63f16e02e4d1d888.js","static/chunks/3086-b5051316dc49e2dd.js","static/chunks/pages/settings/admin/password-928f0250234ba0a5.js"],"/settings/admin/profile":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/3826-f656ba177fd42305.js","static/chunks/6203-ce6579a42bb27e59.js","static/chunks/2523-327f421adadfe4f9.js","static/chunks/490-63f16e02e4d1d888.js","static/chunks/3086-b5051316dc49e2dd.js","static/chunks/pages/settings/admin/profile-bb09e89364111d06.js"],"/settings/personal":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/3826-f656ba177fd42305.js","static/chunks/6203-ce6579a42bb27e59.js","static/chunks/2523-327f421adadfe4f9.js","static/chunks/490-63f16e02e4d1d888.js","static/chunks/pages/settings/personal-5830ea4940aa65e5.js"],"/verify":["static/chunks/webpack-2b983d5c653a52c4.js","static/chunks/framework-761d01c2f56123b2.js","static/chunks/main-2ca41895a91bd640.js","static/chunks/pages/verify-965c64d52f882c4c.js"]},"ampFirstPages":[]}');

/***/ }),

/***/ 73978:
/***/ ((module) => {

module.exports = JSON.parse('{"../../node_modules/next/dist/client/index.js -> ../pages/_error":{"id":99651,"files":["static/chunks/9651.f4dfb1c3d92b56b7.js"]}}');

/***/ }),

/***/ 59450:
/***/ ((module) => {

module.exports = {"Dg":[]};

/***/ })

};
;