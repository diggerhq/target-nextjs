"use strict";
exports.id = 1041;
exports.ids = [1041];
exports.modules = {

/***/ 51041:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ history_HistoryResults)
});

// EXTERNAL MODULE: external "date-fns"
var external_date_fns_ = __webpack_require__(74146);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
// EXTERNAL MODULE: ./src/components/button/Button.jsx
var Button = __webpack_require__(59067);
// EXTERNAL MODULE: ./src/components/common/InputDropdown.jsx
var InputDropdown = __webpack_require__(31217);
// EXTERNAL MODULE: ./src/components/common/Text.jsx
var Text = __webpack_require__(87491);
// EXTERNAL MODULE: ./src/theme.js
var theme = __webpack_require__(91073);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(57518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
;// CONCATENATED MODULE: ./src/components/dashboard/Row.jsx



const limited = ({
  limit
}) => limit ? (0,external_styled_components_.css)(["", ""], theme/* media.desktopLarge */.BC.desktopLarge`
    flex-direction: row;
  `) : (0,external_styled_components_.css)(["", ""], theme/* media.desktop */.BC.desktop`
    flex-direction: row;
  `);

const Row = external_styled_components_default().div.withConfig({
  displayName: "Row",
  componentId: "pvtlr7-0"
})(["display:flex;justify-content:space-between;flex-direction:column;", ""], limited);
/* harmony default export */ const dashboard_Row = (Row);
// EXTERNAL MODULE: external "react-responsive"
var external_react_responsive_ = __webpack_require__(16666);
// EXTERNAL MODULE: external "recharts"
var external_recharts_ = __webpack_require__(36157);
// EXTERNAL MODULE: ./src/utils/text.js
var utils_text = __webpack_require__(88703);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
;// CONCATENATED MODULE: ./src/components/measurement/EmissionsPerEmployeeBarChart.jsx








const Container = external_styled_components_default().div.withConfig({
  displayName: "EmissionsPerEmployeeBarChart__Container",
  componentId: "sc-1lakez9-0"
})(["display:flex;flex-direction:column;align-items:center;border-radius:6px;background:", ";padding:1.125rem;width:100%;margin-right:0.75rem;", " .custom-tooltip{border-radius:50%;backgroundcolor:white;}text{fill:", ";font-size:", ";}.recharts-cartesian-axis-tick-value{tspan{font-size:", ";}}"], p => p.theme.colors.white, theme/* media.tabletLarge */.BC.tabletLarge`
    margin: initial;
  `, p => p.theme.colors.black, p => p.theme.miniscule.size, p => p.theme.miniscule.size);
const InnerContainer = external_styled_components_default().div.withConfig({
  displayName: "EmissionsPerEmployeeBarChart__InnerContainer",
  componentId: "sc-1lakez9-1"
})(["display:flex;align-items:center;text-align:center;margin:1.625rem 0 0;height:19.5rem;width:100%;", ""], theme/* media.desktop */.BC.desktop`
    padding: 0 1rem;
  `);
const Legend = external_styled_components_default().div.withConfig({
  displayName: "EmissionsPerEmployeeBarChart__Legend",
  componentId: "sc-1lakez9-2"
})(["display:flex;"]);
const LegendItem = external_styled_components_default().div.withConfig({
  displayName: "EmissionsPerEmployeeBarChart__LegendItem",
  componentId: "sc-1lakez9-3"
})(["display:flex;align-items:center;&:not(:last-of-type){margin-right:1.5rem;}"]);
const LegendColor = external_styled_components_default().div.withConfig({
  displayName: "EmissionsPerEmployeeBarChart__LegendColor",
  componentId: "sc-1lakez9-4"
})(["background-color:", ";height:0.75rem;width:0.75rem;margin-right:0.52rem;"], p => p.color);
const StyledTooltip = external_styled_components_default().div.withConfig({
  displayName: "EmissionsPerEmployeeBarChart__StyledTooltip",
  componentId: "sc-1lakez9-5"
})(["background-color:", ";border-radius:100%;height:3rem;width:3rem;display:flex;justify-content:center;align-items:center;box-shadow:0px 5px 5px rgba(46,104,241,0.5);"], p => p.theme.colors.backgroundGrey);
const TitleContainer = external_styled_components_default().div.withConfig({
  displayName: "EmissionsPerEmployeeBarChart__TitleContainer",
  componentId: "sc-1lakez9-6"
})(["align-self:flex-start;display:flex;justify-content:space-between;width:100%;flex-direction:column;align-items:flex-start;", ""], theme/* media.tabletLarge */.BC.tabletLarge`
    flex-direction: row;
    align-items: initial;
  `);
const SubtitleContainer = external_styled_components_default().div.withConfig({
  displayName: "EmissionsPerEmployeeBarChart__SubtitleContainer",
  componentId: "sc-1lakez9-7"
})(["width:100%;"]);

const CustomTooltip = props => {
  const {
    active,
    payload
  } = props;

  if (active && payload && payload.length) {
    return /*#__PURE__*/jsx_runtime_.jsx(StyledTooltip, {
      children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
        children: Number(payload[0].payload.value) > 0.1 ? `${Number(payload[0].payload.value).toLocaleString()}` : `<0.1`
      })
    });
  }

  return null;
};

const CustomYAxisTick = props => {
  const {
    x,
    y,
    payload,
    angle
  } = props;
  return /*#__PURE__*/jsx_runtime_.jsx("g", {
    transform: `translate(${x},${y}) rotate(${angle})`,
    children: /*#__PURE__*/jsx_runtime_.jsx("text", {
      fill: theme/* default.colors.black */.ZP.colors.black,
      textAnchor: "end",
      dominantBaseline: "middle",
      children: (0,utils_text/* truncate */.$)(payload.value, 15)
    })
  });
};

const EmissionsPerEmployeeBarChart = ({
  measurement,
  width = 700,
  placeholder,
  isMonthly
}) => {
  var _measurement$office_m;

  const isTabletLarge = (0,external_react_responsive_.useMediaQuery)({
    query: `(min-width: ${theme/* sizes.tabletLarge */.J7.tabletLarge}px)`
  });
  const margin = isTabletLarge ? {
    top: 0,
    right: 30,
    bottom: 20,
    left: -30
  } : {
    left: -20
  };

  const formatValue = value => !value ? 0 : value / 1000;

  const data = measurement === null || measurement === void 0 ? void 0 : (_measurement$office_m = measurement.office_measurements) === null || _measurement$office_m === void 0 ? void 0 : _measurement$office_m.filter(office => !!office.measurement_result).sort((a, b) => {
    var _a$details, _b$details;

    return (a === null || a === void 0 ? void 0 : (_a$details = a.details) === null || _a$details === void 0 ? void 0 : _a$details.name) > (b === null || b === void 0 ? void 0 : (_b$details = b.details) === null || _b$details === void 0 ? void 0 : _b$details.name) ? 1 : -1;
  }).map(office => {
    var _office$details, _office$measurement_r, _office$details2;

    return {
      name: office === null || office === void 0 ? void 0 : (_office$details = office.details) === null || _office$details === void 0 ? void 0 : _office$details.name,
      value: parseFloat(formatValue(office === null || office === void 0 ? void 0 : (_office$measurement_r = office.measurement_result) === null || _office$measurement_r === void 0 ? void 0 : _office$measurement_r.total) / (office === null || office === void 0 ? void 0 : (_office$details2 = office.details) === null || _office$details2 === void 0 ? void 0 : _office$details2.number_of_staff)).toFixed(1)
    };
  });
  const colorScopes = {
    scope_1: theme/* default.colors.graphBlue */.ZP.colors.graphBlue,
    scope_2: theme/* default.colors.graphYellow */.ZP.colors.graphYellow,
    scope_3: theme/* default.colors.graphGreen */.ZP.colors.graphGreen
  };
  const longestLabelLength = data.map(c => c.name).reduce((acc, cur) => cur.length > acc ? cur.length : acc, 0);
  const yAxisWidth = Math.min(Math.max(75, longestLabelLength * 17.5), 150);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(Container, {
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(TitleContainer, {
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(Text/* default */.ZP, {
        size: "smallBold",
        children: ["Per employee ", placeholder && "(Placeholder)"]
      }), /*#__PURE__*/jsx_runtime_.jsx(Legend, {
        children: Object.keys(colorScopes).map(key => /*#__PURE__*/(0,jsx_runtime_.jsxs)(LegendItem, {
          children: [/*#__PURE__*/jsx_runtime_.jsx(LegendColor, {
            color: placeholder ? theme/* default.colors.secondaryGrey */.ZP.colors.secondaryGrey : colorScopes[key]
          }), /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
            size: "smallBold",
            children: key.replace("_", " ").replace(/^\w/, c => c.toUpperCase())
          })]
        }, key))
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx(SubtitleContainer, {
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(Text/* default */.ZP, {
        align: "left",
        size: "miniscule",
        children: ["(", isMonthly ? "kgCO2e" : "tCO2e", ")"]
      })
    }), /*#__PURE__*/jsx_runtime_.jsx(InnerContainer, {
      children: /*#__PURE__*/jsx_runtime_.jsx(external_recharts_.ResponsiveContainer, {
        width: "100%",
        height: "100%",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_recharts_.BarChart, {
          layout: "vertical",
          data: data,
          margin: margin,
          children: [/*#__PURE__*/jsx_runtime_.jsx(external_recharts_.YAxis, {
            type: "category",
            dataKey: "name",
            angle: 0,
            textAnchor: "end",
            axisLine: false,
            tickLine: false,
            tick: /*#__PURE__*/jsx_runtime_.jsx(CustomYAxisTick, {}),
            width: yAxisWidth,
            offset: 0,
            interval: 0
          }), /*#__PURE__*/jsx_runtime_.jsx(external_recharts_.XAxis, {
            type: "number",
            axisLine: false,
            tickLine: false,
            tickFormatter: tick => Number(tick).toLocaleString()
          }), /*#__PURE__*/jsx_runtime_.jsx(external_recharts_.Tooltip, {
            content: /*#__PURE__*/jsx_runtime_.jsx(CustomTooltip, {
              width: width
            }),
            cursor: {
              fill: theme/* default.colors.transparent */.ZP.colors.transparent
            }
          }), /*#__PURE__*/jsx_runtime_.jsx(external_recharts_.CartesianGrid, {
            horizontal: false
          }), /*#__PURE__*/jsx_runtime_.jsx(external_recharts_.Bar, {
            dataKey: "value",
            fill: theme/* default.colors.darkRed */.ZP.colors.darkRed
          })]
        })
      })
    })]
  });
};

/* harmony default export */ const measurement_EmissionsPerEmployeeBarChart = (EmissionsPerEmployeeBarChart);
;// CONCATENATED MODULE: ./src/components/measurement/CategoryBarChart.jsx







const CategoryBarChart_StyledTooltip = external_styled_components_default().div.withConfig({
  displayName: "CategoryBarChart__StyledTooltip",
  componentId: "sc-1et8n2j-0"
})(["background-color:", ";border-radius:100%;height:3rem;width:3rem;display:flex;justify-content:center;align-items:center;box-shadow:0px 5px 5px rgba(46,104,241,0.5);"], p => p.theme.colors.backgroundGrey);

const CategoryBarChart_CustomYAxisTick = props => {
  const {
    x,
    y,
    payload,
    angle
  } = props;
  return /*#__PURE__*/jsx_runtime_.jsx("g", {
    transform: `translate(${x},${y}) rotate(${angle})`,
    children: /*#__PURE__*/jsx_runtime_.jsx("text", {
      fill: theme/* default.colors.black */.ZP.colors.black,
      textAnchor: "end",
      dominantBaseline: "middle",
      children: payload.value
    })
  });
};

const CategoryBarChart_CustomTooltip = ({
  active,
  payload,
  label
}) => {
  if (active && payload && payload.length) {
    return /*#__PURE__*/jsx_runtime_.jsx(CategoryBarChart_StyledTooltip, {
      children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
        children: Number(payload[0].value) > 0.1 ? `${Number(payload[0].value).toLocaleString()}` : `<0.1`
      })
    });
  }

  return null;
};

const scopes = {
  scope_1: ["gas", "vehicle_usage"],
  scope_2: ["electricity"]
};
const colorScopes = {
  scope_1: theme/* default.colors.graphBlue */.ZP.colors.graphBlue,
  scope_2: theme/* default.colors.graphYellow */.ZP.colors.graphYellow,
  scope_3: theme/* default.colors.graphGreen */.ZP.colors.graphGreen
};

const colorFill = (name, placeholder) => placeholder ? theme/* default.colors.secondaryGrey */.ZP.colors.secondaryGrey : scopes.scope_1.includes(name) ? colorScopes["scope_1"] : scopes.scope_2.includes(name) ? colorScopes["scope_2"] : colorScopes["scope_3"];

const CategoryBarChart = ({
  data,
  width,
  placeholder
}) => {
  const isTabletLarge = (0,external_react_responsive_.useMediaQuery)({
    query: `(min-width: ${theme/* sizes.tabletLarge */.J7.tabletLarge}px)`
  });
  const margin = isTabletLarge ? {
    top: 0,
    right: 20,
    bottom: 0,
    left: 25
  } : {
    left: 0
  };
  return /*#__PURE__*/jsx_runtime_.jsx(external_recharts_.ResponsiveContainer, {
    width: "100%",
    height: "100%",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_recharts_.BarChart, {
      layout: "vertical",
      data: data,
      margin: margin,
      children: [/*#__PURE__*/jsx_runtime_.jsx(external_recharts_.YAxis, {
        type: "category",
        dataKey: "name",
        angle: 0,
        textAnchor: "end",
        axisLine: false,
        tickLine: false,
        tick: /*#__PURE__*/jsx_runtime_.jsx(CategoryBarChart_CustomYAxisTick, {}),
        width: 95,
        interval: 0
      }), /*#__PURE__*/jsx_runtime_.jsx(external_recharts_.XAxis, {
        type: "number",
        axisLine: false,
        tickLine: false,
        tickFormatter: tick => Number(tick).toLocaleString()
      }), /*#__PURE__*/jsx_runtime_.jsx(external_recharts_.Tooltip, {
        content: /*#__PURE__*/jsx_runtime_.jsx(CategoryBarChart_CustomTooltip, {
          width: width
        }),
        cursor: {
          fill: theme/* default.colors.transparent */.ZP.colors.transparent
        }
      }), /*#__PURE__*/jsx_runtime_.jsx(external_recharts_.CartesianGrid, {
        horizontal: false
      }), /*#__PURE__*/jsx_runtime_.jsx(external_recharts_.Bar, {
        dataKey: "value",
        maxBarSize: 20,
        children: data.map((entry, index) => /*#__PURE__*/jsx_runtime_.jsx(external_recharts_.Cell, {
          fill: colorFill(entry.key, placeholder)
        }, `cell-${index}`))
      })]
    })
  });
};

/* harmony default export */ const measurement_CategoryBarChart = (CategoryBarChart);
// EXTERNAL MODULE: ./src/components/measurement/utils/charts.js
var charts = __webpack_require__(19343);
// EXTERNAL MODULE: ./src/components/measurement/utils/constants.js
var constants = __webpack_require__(19390);
;// CONCATENATED MODULE: ./src/components/measurement/LiveDashboardBreakdownBarChart.jsx








const LiveDashboardBreakdownBarChart_Container = external_styled_components_default().div.withConfig({
  displayName: "LiveDashboardBreakdownBarChart__Container",
  componentId: "sc-1wgulix-0"
})(["display:flex;flex-direction:column;align-items:center;border-radius:6px;background:", ";padding:1.125rem;margin-bottom:0.75rem;", " .custom-tooltip{border-radius:50%;backgroundcolor:white;}text{fill:", ";font-size:", ";}.recharts-cartesian-axis-tick-value{tspan{font-size:", ";}}"], p => p.theme.colors.white, theme/* media.tablet */.BC.tablet`
      width: 100%;
      margin: initial;
      margin-right: 0.75rem;

  `, p => p.theme.colors.black, p => p.theme.miniscule.size, p => p.theme.small.size);
const LiveDashboardBreakdownBarChart_InnerContainer = external_styled_components_default().div.withConfig({
  displayName: "LiveDashboardBreakdownBarChart__InnerContainer",
  componentId: "sc-1wgulix-1"
})(["display:flex;align-items:center;text-align:center;margin:auto 0;height:16.25rem;width:100%;", ""], theme/* media.desktop */.BC.desktop`
    padding: 0 1rem;
  `);
const LiveDashboardBreakdownBarChart_TitleContainer = external_styled_components_default().div.withConfig({
  displayName: "LiveDashboardBreakdownBarChart__TitleContainer",
  componentId: "sc-1wgulix-2"
})(["align-self:flex-start;display:flex;justify-content:space-between;width:100%;"]);

const LiveDashboardBreakdownBarChart = ({
  measurement,
  width = 700,
  placeholder,
  isMonthly,
  officeId
}) => {
  var _measurement$office_m;

  const scopes = {
    scope_1: ["gas", "vehicle_usage"],
    scope_2: ["electricity"]
  };
  const totalMeasurementResults = (0,charts/* createTotalMeasurementResults */.d)(measurement);
  const measurementResults = officeId ? measurement === null || measurement === void 0 ? void 0 : (_measurement$office_m = measurement.office_measurements.find(office => office.office_id === officeId)) === null || _measurement$office_m === void 0 ? void 0 : _measurement$office_m.measurement_result : totalMeasurementResults;

  const formatValue = value => !value ? 0 : value / 1000;

  const data = Object.keys(measurementResults).filter(key => !constants/* EXCLUDED_CHART_KEYS.includes */.Nx.includes(key)).filter(key => measurementResults[key] > 0).sort((a, b) => measurementResults[a] > measurementResults[b] ? -1 : 1).sort((a, b) => scopes.scope_2.includes(a) && !scopes.scope_2.includes(b) ? -1 : 1).sort((a, b) => scopes.scope_1.includes(a) && !scopes.scope_1.includes(b) ? -1 : 1).map(key => ({
    name: (0,charts/* formatChartLabels */.e)(key),
    value: parseFloat(formatValue(measurementResults[key]).toFixed(1)),
    key
  }));
  const categoryData = [...data];
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(LiveDashboardBreakdownBarChart_Container, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(LiveDashboardBreakdownBarChart_TitleContainer, {
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(Text/* default */.ZP, {
        size: "smallBold",
        children: ["Category breakdown ", placeholder && "(Placeholder)"]
      })
    }), /*#__PURE__*/jsx_runtime_.jsx(LiveDashboardBreakdownBarChart_InnerContainer, {
      children: /*#__PURE__*/jsx_runtime_.jsx(measurement_CategoryBarChart, {
        data: categoryData,
        width: width,
        placeholder: placeholder
      })
    })]
  });
};

/* harmony default export */ const measurement_LiveDashboardBreakdownBarChart = (LiveDashboardBreakdownBarChart);
;// CONCATENATED MODULE: ./src/components/measurement/ScopePieChart.jsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }








const LabelNumber = external_styled_components_default().text.withConfig({
  displayName: "ScopePieChart__LabelNumber",
  componentId: "sc-182g8dm-0"
})(["tspan{font-size:", " !important;font-weight:", ";}#label-metric{font-size:", " !important;font-weight:", ";}"], p => p.theme.contentTitle.size, p => p.theme.contentTitle.fontWeight, p => p.theme.body.size, p => p.theme.body.fontWeight);

const renderActiveShape = props => {
  const RADIAN = Math.PI / 180;
  const {
    cx,
    cy,
    midAngle,
    innerRadius,
    outerRadius,
    startAngle,
    endAngle,
    fill,
    value,
    chartWidth,
    index
  } = props;
  const sin = Math.sin(-RADIAN * midAngle);
  const cos = Math.cos(-RADIAN * midAngle);
  const sx = cx + outerRadius * cos;
  const sy = cy + outerRadius * sin;
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("g", {
    children: [/*#__PURE__*/jsx_runtime_.jsx(external_recharts_.Sector, {
      cx: cx,
      cy: cy,
      innerRadius: innerRadius,
      outerRadius: outerRadius,
      startAngle: startAngle,
      endAngle: endAngle,
      fill: fill
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("g", {
      style: {
        display: "none"
      },
      children: [/*#__PURE__*/jsx_runtime_.jsx("filter", {
        id: "shadow",
        children: /*#__PURE__*/jsx_runtime_.jsx("feDropShadow", {
          dx: "2",
          dy: "2",
          stdDeviation: "2",
          floodColor: theme/* default.colors.blue */.ZP.colors.blue,
          floodOpacity: "0.5"
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("circle", {
        cx: sx,
        cy: sy,
        r: 5 + chartWidth / 15,
        fill: "white",
        filter: "url(#shadow)",
        id: "circle-" + index
      }), /*#__PURE__*/jsx_runtime_.jsx("text", {
        x: sx,
        y: sy,
        fill: theme/* default.colors.black */.ZP.colors.black,
        textAnchor: "middle",
        dominantBaseline: "middle",
        style: {
          fontWeight: 700
        },
        id: "text-" + index,
        children: `${Number(value.toFixed(1)).toLocaleString()}`
      })]
    })]
  });
};

const ScopePieChart = ({
  data,
  chartHeight = 350,
  chartWidth = 350,
  placeholder
}) => {
  const {
    0: activeIndex,
    1: setActiveIndex
  } = (0,external_react_.useState)(null);
  const total = data.reduce((prev, curr) => prev + curr.value, 0);
  const colors = {
    scope_1: theme/* default.colors.graphBlue */.ZP.colors.graphBlue,
    scope_2: theme/* default.colors.graphYellow */.ZP.colors.graphYellow,
    scope_3: theme/* default.colors.graphGreen */.ZP.colors.graphGreen
  };

  const onPieEnter = (_, index) => setActiveIndex(index);

  const onPieLeave = _ => setActiveIndex(null);

  const useCircle = `<use xlink:href="#circle-${activeIndex}" /><use xlink:href="#text-${activeIndex}" />`;
  return /*#__PURE__*/jsx_runtime_.jsx(external_recharts_.ResponsiveContainer, {
    width: "100%",
    height: "100%",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_recharts_.PieChart, {
      width: chartWidth,
      chartHeight: chartHeight + 25,
      onMouseLeave: onPieLeave,
      margin: {
        top: 25,
        right: 20,
        bottom: 25,
        left: 20
      },
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(external_recharts_.Pie, {
        activeIndex: activeIndex,
        activeShape: props => renderActiveShape(_objectSpread(_objectSpread({}, props), {}, {
          chartWidth,
          index: activeIndex
        })),
        data: data,
        dataKey: "value",
        cx: "50%",
        cy: "50%",
        innerRadius: chartWidth / 4.25,
        outerRadius: chartWidth / 3,
        fill: "#8884d8",
        labelLine: false,
        onMouseEnter: onPieEnter,
        children: [/*#__PURE__*/jsx_runtime_.jsx(external_recharts_.Label, {
          content: props => {
            const {
              viewBox: {
                cx,
                cy
              }
            } = props;
            const positioningProps = {
              x: cx,
              y: cy + 5,
              textAnchor: "middle",
              verticalAnchor: "middle"
            };
            const presentationProps = {};
            return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(LabelNumber, _objectSpread(_objectSpread(_objectSpread({}, positioningProps), presentationProps), {}, {
                children: [/*#__PURE__*/jsx_runtime_.jsx("tspan", {
                  children: Number(total.toFixed(1)).toLocaleString()
                }), /*#__PURE__*/jsx_runtime_.jsx("tspan", {
                  x: cx,
                  dy: 20,
                  id: "label-metric",
                  children: "tCO2e"
                })]
              }))
            });
          }
        }), data.map((entry, index) => /*#__PURE__*/jsx_runtime_.jsx(external_recharts_.Cell, {
          fill: placeholder ? theme/* default.colors.secondaryGrey */.ZP.colors.secondaryGrey : colors[entry.name]
        }, `cell-${index}`))]
      }), /*#__PURE__*/jsx_runtime_.jsx("svg", {
        dangerouslySetInnerHTML: {
          __html: useCircle
        }
      })]
    })
  });
};

/* harmony default export */ const measurement_ScopePieChart = (ScopePieChart);
;// CONCATENATED MODULE: ./src/components/measurement/LiveDashboardScopePieChart.jsx







const LiveDashboardScopePieChart_Container = external_styled_components_default().div.withConfig({
  displayName: "LiveDashboardScopePieChart__Container",
  componentId: "sc-6dnnmo-0"
})(["display:flex;flex-direction:column;align-items:center;border-radius:6px;background:", ";padding:1.125rem;", " ", " .custom-tooltip{border-radius:50%;backgroundcolor:white;}text{fill:", ";font-size:", ";}.recharts-cartesian-axis-tick-value{tspan{font-size:", ";}}"], p => p.theme.colors.white, theme/* media.tablet */.BC.tablet`
      width: 100%;
      max-width: 20rem;
      margin: initial;
  `, theme/* media.desktop */.BC.desktop`
    margin: initial;
  `, p => p.theme.colors.black, p => p.theme.miniscule.size, p => p.theme.small.size);
const LiveDashboardScopePieChart_InnerContainer = external_styled_components_default().div.withConfig({
  displayName: "LiveDashboardScopePieChart__InnerContainer",
  componentId: "sc-6dnnmo-1"
})(["display:flex;align-items:center;text-align:center;margin:auto 0;height:16.25rem;width:100%;", ""], theme/* media.desktop */.BC.desktop`
    padding: 0 1rem;
  `);
const LiveDashboardScopePieChart_Legend = external_styled_components_default().div.withConfig({
  displayName: "LiveDashboardScopePieChart__Legend",
  componentId: "sc-6dnnmo-2"
})(["display:flex;width:100%;justify-content:space-around;"]);
const LiveDashboardScopePieChart_LegendItem = external_styled_components_default().div.withConfig({
  displayName: "LiveDashboardScopePieChart__LegendItem",
  componentId: "sc-6dnnmo-3"
})(["display:flex;align-items:center;flex-direction:column;&:not(:last-of-type){margin-right:1.5rem;}"]);
const LiveDashboardScopePieChart_LegendColor = external_styled_components_default().div.withConfig({
  displayName: "LiveDashboardScopePieChart__LegendColor",
  componentId: "sc-6dnnmo-4"
})(["background-color:", ";height:0.75rem;width:0.75rem;margin-right:0.52rem;"], p => p.color);
const LegendInnerContainer = external_styled_components_default().div.withConfig({
  displayName: "LiveDashboardScopePieChart__LegendInnerContainer",
  componentId: "sc-6dnnmo-5"
})(["display:flex;align-items:center;"]);
const LegendValue = external_styled_components_default().div.withConfig({
  displayName: "LiveDashboardScopePieChart__LegendValue",
  componentId: "sc-6dnnmo-6"
})([""]);
const LiveDashboardScopePieChart_TitleContainer = external_styled_components_default().div.withConfig({
  displayName: "LiveDashboardScopePieChart__TitleContainer",
  componentId: "sc-6dnnmo-7"
})(["align-self:flex-start;display:flex;justify-content:space-between;width:100%;"]);
const LiveDashboardScopePieChart_SubtitleContainer = external_styled_components_default().div.withConfig({
  displayName: "LiveDashboardScopePieChart__SubtitleContainer",
  componentId: "sc-6dnnmo-8"
})(["width:100%;"]);
const ButtonsContainer = external_styled_components_default().div.withConfig({
  displayName: "LiveDashboardScopePieChart__ButtonsContainer",
  componentId: "sc-6dnnmo-9"
})(["display:flex;width:100%;margin:1rem;& >:not(:first-child){margin-left:0.5rem;}"]);
const StyledText = external_styled_components_default()(Text/* default */.ZP).withConfig({
  displayName: "LiveDashboardScopePieChart__StyledText",
  componentId: "sc-6dnnmo-10"
})(["cursor:", ";transition:color 0.1s;:hover{", "}"], p => !p.active ? "pointer" : "default", p => !p.active && `color: ${p.theme.colors.black};`);

const LiveDashboardScopePieChart = ({
  measurement,
  width = 310,
  placeholder,
  isMonthly,
  officeId
}) => {
  var _measurement$office_m;

  const totalMeasurementResults = (0,charts/* createTotalMeasurementResults */.d)(measurement);
  const measurementResults = officeId ? measurement === null || measurement === void 0 ? void 0 : (_measurement$office_m = measurement.office_measurements.find(office => office.office_id === officeId)) === null || _measurement$office_m === void 0 ? void 0 : _measurement$office_m.measurement_result : totalMeasurementResults;

  const formatValue = value => !value ? 0 : value / 1000;

  const CHART_KEYS = ["scope_1", "scope_2", "scope_3"];
  const pieData = Object.keys(measurementResults).filter(key => CHART_KEYS.includes(key)).sort((a, b) => measurementResults[a] > measurementResults[b] ? 1 : -1).map(key => ({
    name: key,
    value: formatValue(measurementResults[key])
  }));
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(LiveDashboardScopePieChart_Container, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(LiveDashboardScopePieChart_TitleContainer, {
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(Text/* default */.ZP, {
        size: "smallBold",
        children: ["Scope breakdown ", placeholder && "(Placeholder)"]
      })
    }), /*#__PURE__*/jsx_runtime_.jsx(LiveDashboardScopePieChart_InnerContainer, {
      children: /*#__PURE__*/jsx_runtime_.jsx(measurement_ScopePieChart, {
        data: pieData,
        chartWidth: width,
        chartHeight: width,
        placeholder: placeholder
      })
    })]
  });
};

/* harmony default export */ const measurement_LiveDashboardScopePieChart = (LiveDashboardScopePieChart);
;// CONCATENATED MODULE: ./src/components/measurement/OfficeEmissionsBarChart.jsx








const OfficeEmissionsBarChart_Container = external_styled_components_default().div.withConfig({
  displayName: "OfficeEmissionsBarChart__Container",
  componentId: "sc-1x05787-0"
})(["display:flex;flex-direction:column;align-items:center;border-radius:6px;background:", ";padding:1.125rem;width:100%;margin-right:0.75rem;", " ", " .custom-tooltip{border-radius:50%;backgroundcolor:white;}text{fill:", ";font-size:", ";}.recharts-cartesian-axis-tick-value{tspan{font-size:", ";}}"], p => p.theme.colors.white, theme/* media.tabletLarge */.BC.tabletLarge`
    margin: initial;
  `, theme/* media.desktop */.BC.desktop`
  `, p => p.theme.colors.black, p => p.theme.miniscule.size, p => p.theme.miniscule.size);
const OfficeEmissionsBarChart_InnerContainer = external_styled_components_default().div.withConfig({
  displayName: "OfficeEmissionsBarChart__InnerContainer",
  componentId: "sc-1x05787-1"
})(["display:flex;align-items:center;text-align:center;margin:1.625rem 0 0;height:19.5rem;width:100%;", ""], theme/* media.desktop */.BC.desktop`
    padding: 0 1rem;
  `);
const OfficeEmissionsBarChart_Legend = external_styled_components_default().div.withConfig({
  displayName: "OfficeEmissionsBarChart__Legend",
  componentId: "sc-1x05787-2"
})(["display:flex;"]);
const OfficeEmissionsBarChart_LegendItem = external_styled_components_default().div.withConfig({
  displayName: "OfficeEmissionsBarChart__LegendItem",
  componentId: "sc-1x05787-3"
})(["display:flex;align-items:center;&:not(:last-of-type){margin-right:1.5rem;}"]);
const OfficeEmissionsBarChart_LegendColor = external_styled_components_default().div.withConfig({
  displayName: "OfficeEmissionsBarChart__LegendColor",
  componentId: "sc-1x05787-4"
})(["background-color:", ";height:0.75rem;width:0.75rem;margin-right:0.52rem;"], p => p.color);
const OfficeEmissionsBarChart_StyledTooltip = external_styled_components_default().div.withConfig({
  displayName: "OfficeEmissionsBarChart__StyledTooltip",
  componentId: "sc-1x05787-5"
})(["background-color:", ";border-radius:100%;height:3rem;width:3rem;display:flex;justify-content:center;align-items:center;box-shadow:0px 5px 5px rgba(46,104,241,0.5);"], p => p.theme.colors.backgroundGrey);
const OfficeEmissionsBarChart_TitleContainer = external_styled_components_default().div.withConfig({
  displayName: "OfficeEmissionsBarChart__TitleContainer",
  componentId: "sc-1x05787-6"
})(["align-self:flex-start;display:flex;justify-content:space-between;width:100%;flex-direction:column;align-items:flex-start;", ""], theme/* media.tabletLarge */.BC.tabletLarge`
    flex-direction: row;
    align-items: initial;
  `);
const OfficeEmissionsBarChart_SubtitleContainer = external_styled_components_default().div.withConfig({
  displayName: "OfficeEmissionsBarChart__SubtitleContainer",
  componentId: "sc-1x05787-7"
})(["width:100%;"]);

const OfficeEmissionsBarChart_CustomTooltip = props => {
  const {
    active,
    payload
  } = props;

  if (active && payload && payload.length) {
    return /*#__PURE__*/jsx_runtime_.jsx(OfficeEmissionsBarChart_StyledTooltip, {
      children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
        children: Number(payload[0].payload.value) > 0.1 ? `${Number(payload[0].payload.value).toLocaleString()}` : `<0.1`
      })
    });
  }

  return null;
};

const OfficeEmissionsBarChart_CustomYAxisTick = props => {
  const {
    x,
    y,
    payload,
    angle
  } = props;
  return /*#__PURE__*/jsx_runtime_.jsx("g", {
    transform: `translate(${x},${y}) rotate(${angle})`,
    children: /*#__PURE__*/jsx_runtime_.jsx("text", {
      fill: theme/* default.colors.black */.ZP.colors.black,
      textAnchor: "end",
      dominantBaseline: "middle",
      children: (0,utils_text/* truncate */.$)(payload.value, 15)
    })
  });
};

const OfficeEmissionsBarChart = ({
  measurement,
  width = 700,
  placeholder,
  isMonthly,
  officeId
}) => {
  var _measurement$office_m;

  const isTabletLarge = (0,external_react_responsive_.useMediaQuery)({
    query: `(min-width: ${theme/* sizes.tabletLarge */.J7.tabletLarge}px)`
  });
  const margin = isTabletLarge ? {
    top: 0,
    right: 30,
    bottom: 20,
    left: -30
  } : {
    left: -20
  };

  const formatValue = value => !value ? 0 : value / 1000;

  const data = measurement === null || measurement === void 0 ? void 0 : (_measurement$office_m = measurement.office_measurements) === null || _measurement$office_m === void 0 ? void 0 : _measurement$office_m.filter(office => !!office.measurement_result).sort((a, b) => {
    var _a$details, _b$details;

    return (a === null || a === void 0 ? void 0 : (_a$details = a.details) === null || _a$details === void 0 ? void 0 : _a$details.name) > (b === null || b === void 0 ? void 0 : (_b$details = b.details) === null || _b$details === void 0 ? void 0 : _b$details.name) ? 1 : -1;
  }).map(office => {
    var _office$details, _office$measurement_r, _office$measurement_r2, _office$measurement_r3, _office$measurement_r4;

    return {
      name: office === null || office === void 0 ? void 0 : (_office$details = office.details) === null || _office$details === void 0 ? void 0 : _office$details.name,
      value: parseFloat(formatValue(office === null || office === void 0 ? void 0 : (_office$measurement_r = office.measurement_result) === null || _office$measurement_r === void 0 ? void 0 : _office$measurement_r.total)).toFixed(1),
      scope_1: parseFloat(formatValue(office === null || office === void 0 ? void 0 : (_office$measurement_r2 = office.measurement_result) === null || _office$measurement_r2 === void 0 ? void 0 : _office$measurement_r2.scope_1)).toFixed(1) || 0,
      scope_2: parseFloat(formatValue(office === null || office === void 0 ? void 0 : (_office$measurement_r3 = office.measurement_result) === null || _office$measurement_r3 === void 0 ? void 0 : _office$measurement_r3.scope_2)).toFixed(1) || 0,
      scope_3: parseFloat(formatValue(office === null || office === void 0 ? void 0 : (_office$measurement_r4 = office.measurement_result) === null || _office$measurement_r4 === void 0 ? void 0 : _office$measurement_r4.scope_3)).toFixed(1) || 0
    };
  });
  const colorScopes = {
    scope_1: theme/* default.colors.graphBlue */.ZP.colors.graphBlue,
    scope_2: theme/* default.colors.graphYellow */.ZP.colors.graphYellow,
    scope_3: theme/* default.colors.graphGreen */.ZP.colors.graphGreen
  };
  const longestLabelLength = data.map(c => c.name).reduce((acc, cur) => cur.length > acc ? cur.length : acc, 0);
  const yAxisWidth = Math.min(Math.max(75, longestLabelLength * 17.5), 150);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(OfficeEmissionsBarChart_Container, {
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(OfficeEmissionsBarChart_TitleContainer, {
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(Text/* default */.ZP, {
        size: "smallBold",
        children: ["Office breakdown ", placeholder && "(Placeholder)"]
      }), /*#__PURE__*/jsx_runtime_.jsx(OfficeEmissionsBarChart_Legend, {
        children: Object.keys(colorScopes).map(key => /*#__PURE__*/(0,jsx_runtime_.jsxs)(OfficeEmissionsBarChart_LegendItem, {
          children: [/*#__PURE__*/jsx_runtime_.jsx(OfficeEmissionsBarChart_LegendColor, {
            color: placeholder ? theme/* default.colors.secondaryGrey */.ZP.colors.secondaryGrey : colorScopes[key]
          }), /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
            size: "smallBold",
            children: key.replace("_", " ").replace(/^\w/, c => c.toUpperCase())
          })]
        }, key))
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx(OfficeEmissionsBarChart_SubtitleContainer, {
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(Text/* default */.ZP, {
        align: "left",
        size: "miniscule",
        children: ["(", isMonthly ? "kgCO2e" : "tCO2e", ")"]
      })
    }), /*#__PURE__*/jsx_runtime_.jsx(OfficeEmissionsBarChart_InnerContainer, {
      children: /*#__PURE__*/jsx_runtime_.jsx(external_recharts_.ResponsiveContainer, {
        width: "100%",
        height: "100%",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_recharts_.BarChart, {
          layout: "vertical",
          data: data,
          margin: margin,
          children: [/*#__PURE__*/jsx_runtime_.jsx(external_recharts_.YAxis, {
            type: "category",
            dataKey: "name",
            angle: 0,
            textAnchor: "end",
            axisLine: false,
            tickLine: false,
            tick: /*#__PURE__*/jsx_runtime_.jsx(OfficeEmissionsBarChart_CustomYAxisTick, {}),
            width: yAxisWidth,
            offset: 0,
            interval: 0
          }), /*#__PURE__*/jsx_runtime_.jsx(external_recharts_.XAxis, {
            type: "number",
            axisLine: false,
            tickLine: false,
            tickFormatter: tick => Number(tick).toLocaleString()
          }), /*#__PURE__*/jsx_runtime_.jsx(external_recharts_.Tooltip, {
            content: /*#__PURE__*/jsx_runtime_.jsx(OfficeEmissionsBarChart_CustomTooltip, {
              width: width
            }),
            cursor: {
              fill: theme/* default.colors.transparent */.ZP.colors.transparent
            }
          }), /*#__PURE__*/jsx_runtime_.jsx(external_recharts_.CartesianGrid, {
            horizontal: false
          }), /*#__PURE__*/jsx_runtime_.jsx(external_recharts_.Bar, {
            dataKey: "scope_1",
            stackId: "scope",
            fill: colorScopes["scope_1"]
          }), /*#__PURE__*/jsx_runtime_.jsx(external_recharts_.Bar, {
            dataKey: "scope_2",
            stackId: "scope",
            fill: colorScopes["scope_2"]
          }), /*#__PURE__*/jsx_runtime_.jsx(external_recharts_.Bar, {
            dataKey: "scope_3",
            stackId: "scope",
            fill: colorScopes["scope_3"]
          })]
        })
      })
    })]
  });
};

/* harmony default export */ const measurement_OfficeEmissionsBarChart = (OfficeEmissionsBarChart);
;// CONCATENATED MODULE: ./src/utils/placeholders/measurementWithResult.json
const measurementWithResult_namespaceObject = JSON.parse('{"id":1,"state":"pending","has_office":null,"has_utility_bills":null,"has_company_vehicles":null,"has_business_travel":null,"user_id":null,"organisation_id":1,"submitted_at":null,"created_at":"2022-02-02T16:18:03.495Z","updated_at":"2022-02-02T16:28:57.051Z","spreadsheet_id":null,"last_completed_step":null,"time_period":12,"year":2022,"month":0,"expenses":null,"user":null,"vehicle_usage":[],"result":{"id":410,"gas":15846.05,"electricity":736.3333,"water_supply":355.266,"water_treated":731.187,"business_travel":80506.94,"waste_landfill":1738.778,"waste_recycling":62.33091,"employee_commutes":670.65155,"expenses":null,"homeworking_gas":1390.3391,"homeworking_electricity":65.16315,"measurement_id":1,"created_at":"2022-02-02T16:18:15.597Z","updated_at":"2022-02-02T16:18:15.597Z","vehicle_usage":null,"office_measurements_id":5422,"scope_1":15846.05,"scope_2":736.3333,"scope_3":85520.65570999999,"homeworking":1455.50225,"waste":1801.10891,"water":1086.453,"utilities":19469.945209999998,"total":102103.03901},"office_measurements":[{"id":5421,"measurement_id":1,"office_id":1,"created_at":"2022-02-02T16:18:03.506Z","updated_at":"2022-02-02T16:18:03.506Z","business_travel":[{"id":10106,"from":"London, ON, Canada","to":"Rovinj, Croatia","mode":"london_underground","distance":5255.5195,"passengers":11,"round_trip":true,"created_at":"2022-02-02T16:18:03.559Z","updated_at":"2022-02-02T16:18:03.559Z","departure_place_id":null,"destination_place_id":null,"departure_lat":null,"departure_lng":null,"destination_lat":null,"destination_lng":null,"office_measurements_id":5421,"unit":"km","departure":"London, ON, Canada","destination":"Rovinj, Croatia"},{"id":10107,"from":"London, UK","to":"Rostock, Germany","mode":"london_underground","distance":639.1917,"passengers":11,"round_trip":true,"created_at":"2022-02-02T16:18:03.559Z","updated_at":"2022-02-02T16:18:03.559Z","departure_place_id":null,"destination_place_id":null,"departure_lat":null,"departure_lng":null,"destination_lat":null,"destination_lng":null,"office_measurements_id":5421,"unit":"miles","departure":"London, UK","destination":"Rostock, Germany"},{"id":10108,"from":"London, ON, Canada","to":"Roma, Metropolitan City of Rome, Italy","mode":"london_underground","distance":4161.309,"passengers":5,"round_trip":true,"created_at":"2022-02-02T16:18:03.559Z","updated_at":"2022-02-02T16:18:03.559Z","departure_place_id":null,"destination_place_id":null,"departure_lat":null,"departure_lng":null,"destination_lat":null,"destination_lng":null,"office_measurements_id":5421,"unit":"km","departure":"London, ON, Canada","destination":"Roma, Metropolitan City of Rome, Italy"},{"id":10109,"from":"London, ON, Canada","to":"Rostock, Germany","mode":"london_underground","distance":1993.6259,"passengers":16,"round_trip":true,"created_at":"2022-02-02T16:18:03.559Z","updated_at":"2022-02-02T16:18:03.559Z","departure_place_id":null,"destination_place_id":null,"departure_lat":null,"departure_lng":null,"destination_lat":null,"destination_lng":null,"office_measurements_id":5421,"unit":"miles","departure":"London, ON, Canada","destination":"Rostock, Germany"}],"employee_commutes":[{"id":12260,"value":33,"mode":"average_car_petrol","unit":"miles","office_id":null,"created_at":"2022-02-02T16:18:03.583Z","updated_at":"2022-02-02T16:18:03.583Z","office_measurements_id":5421,"name":"Kristina Grady"},{"id":12261,"value":88.6,"mode":"walk","unit":"miles","office_id":null,"created_at":"2022-02-02T16:18:03.583Z","updated_at":"2022-02-02T16:18:03.583Z","office_measurements_id":5421,"name":"Oma Klein"},{"id":12262,"value":7.2,"mode":"average_car_petrol","unit":"km","office_id":null,"created_at":"2022-02-02T16:18:03.583Z","updated_at":"2022-02-02T16:18:03.583Z","office_measurements_id":5421,"name":"Dawn Jones"},{"id":12263,"value":44.8,"mode":"walk","unit":"miles","office_id":null,"created_at":"2022-02-02T16:18:03.583Z","updated_at":"2022-02-02T16:18:03.583Z","office_measurements_id":5421,"name":"Vita Davis"},{"id":12264,"value":82.3,"mode":"average_car_petrol","unit":"miles","office_id":null,"created_at":"2022-02-02T16:18:03.583Z","updated_at":"2022-02-02T16:18:03.583Z","office_measurements_id":5421,"name":"Jabari Effertz"},{"id":12265,"value":26.5,"mode":"walk","unit":"miles","office_id":null,"created_at":"2022-02-02T16:18:03.583Z","updated_at":"2022-02-02T16:18:03.583Z","office_measurements_id":5421,"name":"Melyssa Senger"}],"utilities":[{"id":11989,"value":782,"type":"gas","unit":"gbp","period":null,"created_at":"2022-02-02T16:18:03.518Z","updated_at":"2022-02-02T16:18:03.518Z","known":"yes","office_measurements_id":5421},{"id":11990,"value":2180,"type":"electricity","unit":"gbp","period":null,"created_at":"2022-02-02T16:18:03.518Z","updated_at":"2022-02-02T16:18:03.518Z","known":"yes","office_measurements_id":5421},{"id":11991,"value":292,"type":"water","unit":"gbp","period":null,"created_at":"2022-02-02T16:18:03.518Z","updated_at":"2022-02-02T16:18:03.518Z","known":"yes","office_measurements_id":5421}],"waste":[{"id":7897,"value":3524,"unit":"kg","type":"recycling","period":null,"created_at":"2022-02-02T16:18:03.536Z","updated_at":"2022-02-02T16:18:03.536Z","known":"yes","office_measurements_id":5421},{"id":7898,"value":1120,"unit":"kg","type":"landfill","period":null,"created_at":"2022-02-02T16:18:03.536Z","updated_at":"2022-02-02T16:18:03.536Z","known":"yes","office_measurements_id":5421}],"details":{"id":1,"name":"London - West End","postcode":null,"size":300,"organisation_id":1,"created_at":"2022-02-02T16:18:03.489Z","updated_at":"2022-02-02T16:18:03.489Z","fully_remote":null,"country":"GB","unit":"m2","number_of_staff":333,"staff_working_from_home_percentage":76},"measurement_result":{"id":409,"gas":4793.66,"electricity":4235.3765,"water_supply":135.6048,"water_treated":279.0936,"business_travel":7769.71,"waste_landfill":513.1571,"waste_recycling":75.12111,"employee_commutes":322.53625,"expenses":null,"homeworking_gas":5938.684,"homeworking_electricity":1380.6719,"measurement_id":1,"created_at":"2022-02-02T16:18:15.487Z","updated_at":"2022-02-02T16:18:15.487Z","vehicle_usage":null,"office_measurements_id":5421,"scope_1":4793.66,"scope_2":4235.3765,"scope_3":16414.57876,"homeworking":7319.3559000000005,"waste":588.2782100000001,"water":414.6984,"utilities":10032.01311,"total":25443.61526},"offices_ids":[],"business_travel_ids":[10106,10107,10108,10109],"employee_commutes_ids":[12260,12261,12262,12263,12264,12265],"utilities_ids":[11989,11990,11991],"vehicle_usage_ids":[],"waste_ids":[7897,7898]},{"id":5422,"measurement_id":1,"office_id":2,"created_at":"2022-02-02T16:18:03.506Z","updated_at":"2022-02-02T16:18:03.506Z","business_travel":[{"id":10110,"from":"London, OH, USA","to":"Rostock, Germany","mode":"london_underground","distance":8565.851,"passengers":0,"round_trip":false,"created_at":"2022-02-02T16:18:03.559Z","updated_at":"2022-02-02T16:18:03.559Z","departure_place_id":null,"destination_place_id":null,"departure_lat":null,"departure_lng":null,"destination_lat":null,"destination_lng":null,"office_measurements_id":5422,"unit":"km","departure":"London, OH, USA","destination":"Rostock, Germany"},{"id":10111,"from":"London, UK","to":"Roma, Metropolitan City of Rome, Italy","mode":"flight_domestic","distance":2856.1992,"passengers":11,"round_trip":true,"created_at":"2022-02-02T16:18:03.559Z","updated_at":"2022-02-02T16:18:03.559Z","departure_place_id":null,"destination_place_id":null,"departure_lat":null,"departure_lng":null,"destination_lat":null,"destination_lng":null,"office_measurements_id":5422,"unit":"miles","departure":"London, UK","destination":"Roma, Metropolitan City of Rome, Italy"},{"id":10112,"from":"London, OH, USA","to":"Rostock, Germany","mode":"london_underground","distance":4889.8726,"passengers":15,"round_trip":true,"created_at":"2022-02-02T16:18:03.559Z","updated_at":"2022-02-02T16:18:03.559Z","departure_place_id":null,"destination_place_id":null,"departure_lat":null,"departure_lng":null,"destination_lat":null,"destination_lng":null,"office_measurements_id":5422,"unit":"miles","departure":"London, OH, USA","destination":"Rostock, Germany"},{"id":10113,"from":"London, OH, USA","to":"Rostock, Germany","mode":"flight_domestic","distance":9043.846,"passengers":12,"round_trip":false,"created_at":"2022-02-02T16:18:03.559Z","updated_at":"2022-02-02T16:18:03.559Z","departure_place_id":null,"destination_place_id":null,"departure_lat":null,"departure_lng":null,"destination_lat":null,"destination_lng":null,"office_measurements_id":5422,"unit":"km","departure":"London, OH, USA","destination":"Rostock, Germany"},{"id":10114,"from":"London, KY, USA","to":"Rovinj, Croatia","mode":"flight_domestic","distance":3821.284,"passengers":14,"round_trip":false,"created_at":"2022-02-02T16:18:03.559Z","updated_at":"2022-02-02T16:18:03.559Z","departure_place_id":null,"destination_place_id":null,"departure_lat":null,"departure_lng":null,"destination_lat":null,"destination_lng":null,"office_measurements_id":5422,"unit":"miles","departure":"London, KY, USA","destination":"Rovinj, Croatia"},{"id":10115,"from":"London, OH, USA","to":"Rostock, Germany","mode":"flight_domestic","distance":3609.2227,"passengers":2,"round_trip":false,"created_at":"2022-02-02T16:18:03.559Z","updated_at":"2022-02-02T16:18:03.559Z","departure_place_id":null,"destination_place_id":null,"departure_lat":null,"departure_lng":null,"destination_lat":null,"destination_lng":null,"office_measurements_id":5422,"unit":"km","departure":"London, OH, USA","destination":"Rostock, Germany"},{"id":10116,"from":"London, OH, USA","to":"Rotterdam, Netherlands","mode":"london_underground","distance":3425.2463,"passengers":0,"round_trip":true,"created_at":"2022-02-02T16:18:03.559Z","updated_at":"2022-02-02T16:18:03.559Z","departure_place_id":null,"destination_place_id":null,"departure_lat":null,"departure_lng":null,"destination_lat":null,"destination_lng":null,"office_measurements_id":5422,"unit":"miles","departure":"London, OH, USA","destination":"Rotterdam, Netherlands"}],"employee_commutes":[{"id":12266,"value":22.5,"mode":"average_car_petrol","unit":"miles","office_id":null,"created_at":"2022-02-02T16:18:03.583Z","updated_at":"2022-02-02T16:18:03.583Z","office_measurements_id":5422,"name":"Destinee Lehner"},{"id":12267,"value":7.3,"mode":"walk","unit":"km","office_id":null,"created_at":"2022-02-02T16:18:03.583Z","updated_at":"2022-02-02T16:18:03.583Z","office_measurements_id":5422,"name":"Garett Lockman"},{"id":12268,"value":53.1,"mode":"average_car_petrol","unit":"km","office_id":null,"created_at":"2022-02-02T16:18:03.583Z","updated_at":"2022-02-02T16:18:03.583Z","office_measurements_id":5422,"name":"Maybell Abernathy"},{"id":12269,"value":76.1,"mode":"walk","unit":"miles","office_id":null,"created_at":"2022-02-02T16:18:03.583Z","updated_at":"2022-02-02T16:18:03.583Z","office_measurements_id":5422,"name":"Kacie Smitham"},{"id":12270,"value":38.9,"mode":"walk","unit":"km","office_id":null,"created_at":"2022-02-02T16:18:03.583Z","updated_at":"2022-02-02T16:18:03.583Z","office_measurements_id":5422,"name":"Cierra Terry"},{"id":12271,"value":26.4,"mode":"walk","unit":"miles","office_id":null,"created_at":"2022-02-02T16:18:03.583Z","updated_at":"2022-02-02T16:18:03.583Z","office_measurements_id":5422,"name":"Dwight Wolff"},{"id":12272,"value":24.2,"mode":"average_car_petrol","unit":"miles","office_id":null,"created_at":"2022-02-02T16:18:03.583Z","updated_at":"2022-02-02T16:18:03.583Z","office_measurements_id":5422,"name":"Imani Treutel"}],"utilities":[{"id":11992,"value":2585,"type":"gas","unit":"gbp","period":null,"created_at":"2022-02-02T16:18:03.518Z","updated_at":"2022-02-02T16:18:03.518Z","known":"yes","office_measurements_id":5422},{"id":11993,"value":1880,"type":"electricity","unit":"gbp","period":null,"created_at":"2022-02-02T16:18:03.518Z","updated_at":"2022-02-02T16:18:03.518Z","known":"yes","office_measurements_id":5422},{"id":11994,"value":765,"type":"water","unit":"gbp","period":null,"created_at":"2022-02-02T16:18:03.518Z","updated_at":"2022-02-02T16:18:03.518Z","known":"yes","office_measurements_id":5422}],"waste":[{"id":7899,"value":2924,"unit":"kg","type":"recycling","period":null,"created_at":"2022-02-02T16:18:03.536Z","updated_at":"2022-02-02T16:18:03.536Z","known":"yes","office_measurements_id":5422},{"id":7900,"value":3795,"unit":"kg","type":"landfill","period":null,"created_at":"2022-02-02T16:18:03.536Z","updated_at":"2022-02-02T16:18:03.536Z","known":"yes","office_measurements_id":5422}],"details":{"id":2,"name":"Paris - Champs-Élysées","postcode":null,"size":250,"organisation_id":1,"created_at":"2022-02-02T16:18:03.489Z","updated_at":"2022-02-02T16:18:03.489Z","fully_remote":null,"country":"FR","unit":"m2","number_of_staff":237,"staff_working_from_home_percentage":25},"measurement_result":{"id":410,"gas":15846.05,"electricity":736.3333,"water_supply":355.266,"water_treated":731.187,"business_travel":80506.94,"waste_landfill":1738.778,"waste_recycling":62.33091,"employee_commutes":670.65155,"expenses":null,"homeworking_gas":1390.3391,"homeworking_electricity":65.16315,"measurement_id":1,"created_at":"2022-02-02T16:18:15.597Z","updated_at":"2022-02-02T16:18:15.597Z","vehicle_usage":null,"office_measurements_id":5422,"scope_1":15846.05,"scope_2":736.3333,"scope_3":85520.65570999999,"homeworking":1455.50225,"waste":1801.10891,"water":1086.453,"utilities":19469.945209999998,"total":102103.03901},"offices_ids":[],"business_travel_ids":[10110,10111,10112,10113,10114,10115,10116],"employee_commutes_ids":[12266,12267,12268,12269,12270,12271,12272],"utilities_ids":[11992,11993,11994],"vehicle_usage_ids":[],"waste_ids":[7899,7900]},{"id":5423,"measurement_id":1,"office_id":3,"created_at":"2022-02-02T16:18:03.506Z","updated_at":"2022-02-02T16:18:03.506Z","business_travel":[{"id":10117,"from":"London, OH, USA","to":"Rostock, Germany","mode":"london_underground","distance":9322.575,"passengers":0,"round_trip":true,"created_at":"2022-02-02T16:18:03.559Z","updated_at":"2022-02-02T16:18:03.559Z","departure_place_id":null,"destination_place_id":null,"departure_lat":null,"departure_lng":null,"destination_lat":null,"destination_lng":null,"office_measurements_id":5423,"unit":"km","departure":"London, OH, USA","destination":"Rostock, Germany"},{"id":10118,"from":"London, ON, Canada","to":"Rotterdam, Netherlands","mode":"london_underground","distance":9634,"passengers":9,"round_trip":true,"created_at":"2022-02-02T16:18:03.559Z","updated_at":"2022-02-02T16:18:03.559Z","departure_place_id":null,"destination_place_id":null,"departure_lat":null,"departure_lng":null,"destination_lat":null,"destination_lng":null,"office_measurements_id":5423,"unit":"miles","departure":"London, ON, Canada","destination":"Rotterdam, Netherlands"},{"id":10119,"from":"London, KY, USA","to":"Rovinj, Croatia","mode":"flight_domestic","distance":854.8356,"passengers":3,"round_trip":false,"created_at":"2022-02-02T16:18:03.559Z","updated_at":"2022-02-02T16:18:03.559Z","departure_place_id":null,"destination_place_id":null,"departure_lat":null,"departure_lng":null,"destination_lat":null,"destination_lng":null,"office_measurements_id":5423,"unit":"miles","departure":"London, KY, USA","destination":"Rovinj, Croatia"},{"id":10120,"from":"London, UK","to":"Rovinj, Croatia","mode":"flight_domestic","distance":7277.1704,"passengers":0,"round_trip":true,"created_at":"2022-02-02T16:18:03.559Z","updated_at":"2022-02-02T16:18:03.559Z","departure_place_id":null,"destination_place_id":null,"departure_lat":null,"departure_lng":null,"destination_lat":null,"destination_lng":null,"office_measurements_id":5423,"unit":"miles","departure":"London, UK","destination":"Rovinj, Croatia"},{"id":10121,"from":"London, UK","to":"Rotterdam, Netherlands","mode":"london_underground","distance":8362.042,"passengers":11,"round_trip":false,"created_at":"2022-02-02T16:18:03.559Z","updated_at":"2022-02-02T16:18:03.559Z","departure_place_id":null,"destination_place_id":null,"departure_lat":null,"departure_lng":null,"destination_lat":null,"destination_lng":null,"office_measurements_id":5423,"unit":"km","departure":"London, UK","destination":"Rotterdam, Netherlands"}],"employee_commutes":[{"id":12273,"value":40.8,"mode":"walk","unit":"miles","office_id":null,"created_at":"2022-02-02T16:18:03.583Z","updated_at":"2022-02-02T16:18:03.583Z","office_measurements_id":5423,"name":"Sydnie Willms"},{"id":12274,"value":44.8,"mode":"walk","unit":"km","office_id":null,"created_at":"2022-02-02T16:18:03.583Z","updated_at":"2022-02-02T16:18:03.583Z","office_measurements_id":5423,"name":"Lavada Heidenreich"},{"id":12275,"value":52.3,"mode":"walk","unit":"km","office_id":null,"created_at":"2022-02-02T16:18:03.583Z","updated_at":"2022-02-02T16:18:03.583Z","office_measurements_id":5423,"name":"Jaime Bailey"},{"id":12276,"value":65.1,"mode":"walk","unit":"miles","office_id":null,"created_at":"2022-02-02T16:18:03.583Z","updated_at":"2022-02-02T16:18:03.583Z","office_measurements_id":5423,"name":"Zola Zboncak"},{"id":12277,"value":67.5,"mode":"average_car_petrol","unit":"miles","office_id":null,"created_at":"2022-02-02T16:18:03.583Z","updated_at":"2022-02-02T16:18:03.583Z","office_measurements_id":5423,"name":"Angelita Nader"}],"utilities":[{"id":11995,"value":2366,"type":"gas","unit":"gbp","period":null,"created_at":"2022-02-02T16:18:03.518Z","updated_at":"2022-02-02T16:18:03.518Z","known":"yes","office_measurements_id":5423},{"id":11996,"value":3839,"type":"electricity","unit":"gbp","period":null,"created_at":"2022-02-02T16:18:03.518Z","updated_at":"2022-02-02T16:18:03.518Z","known":"yes","office_measurements_id":5423},{"id":11997,"value":666,"type":"water","unit":"gbp","period":null,"created_at":"2022-02-02T16:18:03.518Z","updated_at":"2022-02-02T16:18:03.518Z","known":"yes","office_measurements_id":5423}],"waste":[{"id":7901,"value":3407,"unit":"kg","type":"recycling","period":null,"created_at":"2022-02-02T16:18:03.536Z","updated_at":"2022-02-02T16:18:03.536Z","known":"yes","office_measurements_id":5423},{"id":7902,"value":4104,"unit":"kg","type":"landfill","period":null,"created_at":"2022-02-02T16:18:03.536Z","updated_at":"2022-02-02T16:18:03.536Z","known":"yes","office_measurements_id":5423}],"details":{"id":3,"name":"New York - Manhatten","postcode":null,"size":187,"organisation_id":1,"created_at":"2022-02-02T16:18:03.489Z","updated_at":"2022-02-02T16:18:03.489Z","fully_remote":null,"country":"US","unit":"m2","number_of_staff":136,"staff_working_from_home_percentage":12},"measurement_result":{"id":411,"gas":14503.58,"electricity":15224.834,"water_supply":309.2904,"water_treated":636.5628,"business_travel":11212.452,"waste_landfill":1880.3542,"waste_recycling":72.62702,"employee_commutes":666.48694,"expenses":null,"homeworking_gas":382.95926,"homeworking_electricity":181.7405,"measurement_id":1,"created_at":"2022-02-02T16:18:15.735Z","updated_at":"2022-02-02T16:18:15.735Z","vehicle_usage":null,"office_measurements_id":5423,"scope_1":14503.58,"scope_2":15224.834,"scope_3":15342.473119999999,"homeworking":564.69976,"waste":1952.98122,"water":945.8532,"utilities":32627.248420000004,"total":45070.88712},"offices_ids":[],"business_travel_ids":[10117,10118,10119,10120,10121],"employee_commutes_ids":[12273,12274,12275,12276,12277],"utilities_ids":[11995,11996,11997],"vehicle_usage_ids":[],"waste_ids":[7901,7902]},{"id":5424,"measurement_id":1,"office_id":4,"created_at":"2022-02-02T16:18:03.506Z","updated_at":"2022-02-02T16:18:03.506Z","business_travel":[{"id":10122,"from":"London, ON, Canada","to":"Rovinj, Croatia","mode":"flight_domestic","distance":8845.782,"passengers":3,"round_trip":true,"created_at":"2022-02-02T16:18:03.559Z","updated_at":"2022-02-02T16:18:03.559Z","departure_place_id":null,"destination_place_id":null,"departure_lat":null,"departure_lng":null,"destination_lat":null,"destination_lng":null,"office_measurements_id":5424,"unit":"miles","departure":"London, ON, Canada","destination":"Rovinj, Croatia"},{"id":10123,"from":"London, UK","to":"Rotterdam, Netherlands","mode":"flight_domestic","distance":4595.0225,"passengers":2,"round_trip":true,"created_at":"2022-02-02T16:18:03.559Z","updated_at":"2022-02-02T16:18:03.559Z","departure_place_id":null,"destination_place_id":null,"departure_lat":null,"departure_lng":null,"destination_lat":null,"destination_lng":null,"office_measurements_id":5424,"unit":"miles","departure":"London, UK","destination":"Rotterdam, Netherlands"},{"id":10124,"from":"London, OH, USA","to":"Rovinj, Croatia","mode":"london_underground","distance":3211.2563,"passengers":13,"round_trip":true,"created_at":"2022-02-02T16:18:03.559Z","updated_at":"2022-02-02T16:18:03.559Z","departure_place_id":null,"destination_place_id":null,"departure_lat":null,"departure_lng":null,"destination_lat":null,"destination_lng":null,"office_measurements_id":5424,"unit":"miles","departure":"London, OH, USA","destination":"Rovinj, Croatia"},{"id":10125,"from":"London, KY, USA","to":"Rostock, Germany","mode":"flight_domestic","distance":129.18753,"passengers":14,"round_trip":false,"created_at":"2022-02-02T16:18:03.559Z","updated_at":"2022-02-02T16:18:03.559Z","departure_place_id":null,"destination_place_id":null,"departure_lat":null,"departure_lng":null,"destination_lat":null,"destination_lng":null,"office_measurements_id":5424,"unit":"km","departure":"London, KY, USA","destination":"Rostock, Germany"},{"id":10126,"from":"London, OH, USA","to":"Rostock, Germany","mode":"london_underground","distance":9837.397,"passengers":10,"round_trip":true,"created_at":"2022-02-02T16:18:03.559Z","updated_at":"2022-02-02T16:18:03.559Z","departure_place_id":null,"destination_place_id":null,"departure_lat":null,"departure_lng":null,"destination_lat":null,"destination_lng":null,"office_measurements_id":5424,"unit":"km","departure":"London, OH, USA","destination":"Rostock, Germany"},{"id":10127,"from":"London, OH, USA","to":"Roma, Metropolitan City of Rome, Italy","mode":"london_underground","distance":1184.9569,"passengers":10,"round_trip":true,"created_at":"2022-02-02T16:18:03.559Z","updated_at":"2022-02-02T16:18:03.559Z","departure_place_id":null,"destination_place_id":null,"departure_lat":null,"departure_lng":null,"destination_lat":null,"destination_lng":null,"office_measurements_id":5424,"unit":"miles","departure":"London, OH, USA","destination":"Roma, Metropolitan City of Rome, Italy"},{"id":10128,"from":"London, UK","to":"Roma, Metropolitan City of Rome, Italy","mode":"london_underground","distance":2442.31,"passengers":19,"round_trip":true,"created_at":"2022-02-02T16:18:03.559Z","updated_at":"2022-02-02T16:18:03.559Z","departure_place_id":null,"destination_place_id":null,"departure_lat":null,"departure_lng":null,"destination_lat":null,"destination_lng":null,"office_measurements_id":5424,"unit":"km","departure":"London, UK","destination":"Roma, Metropolitan City of Rome, Italy"}],"employee_commutes":[{"id":12278,"value":61.1,"mode":"walk","unit":"miles","office_id":null,"created_at":"2022-02-02T16:18:03.583Z","updated_at":"2022-02-02T16:18:03.583Z","office_measurements_id":5424,"name":"Marilyne King"},{"id":12279,"value":48.5,"mode":"average_car_petrol","unit":"miles","office_id":null,"created_at":"2022-02-02T16:18:03.583Z","updated_at":"2022-02-02T16:18:03.583Z","office_measurements_id":5424,"name":"Alvah Zulauf"},{"id":12280,"value":67,"mode":"walk","unit":"km","office_id":null,"created_at":"2022-02-02T16:18:03.583Z","updated_at":"2022-02-02T16:18:03.583Z","office_measurements_id":5424,"name":"Ashly Rowe"}],"utilities":[{"id":11998,"value":495,"type":"gas","unit":"gbp","period":null,"created_at":"2022-02-02T16:18:03.518Z","updated_at":"2022-02-02T16:18:03.518Z","known":"yes","office_measurements_id":5424},{"id":11999,"value":76,"type":"electricity","unit":"gbp","period":null,"created_at":"2022-02-02T16:18:03.518Z","updated_at":"2022-02-02T16:18:03.518Z","known":"yes","office_measurements_id":5424},{"id":12000,"value":9,"type":"water","unit":"gbp","period":null,"created_at":"2022-02-02T16:18:03.518Z","updated_at":"2022-02-02T16:18:03.518Z","known":"yes","office_measurements_id":5424}],"waste":[{"id":7903,"value":2874,"unit":"kg","type":"recycling","period":null,"created_at":"2022-02-02T16:18:03.536Z","updated_at":"2022-02-02T16:18:03.536Z","known":"yes","office_measurements_id":5424},{"id":7904,"value":2137,"unit":"kg","type":"landfill","period":null,"created_at":"2022-02-02T16:18:03.536Z","updated_at":"2022-02-02T16:18:03.536Z","known":"yes","office_measurements_id":5424}],"details":{"id":4,"name":"Signapore - The City","postcode":null,"size":400,"organisation_id":1,"created_at":"2022-02-02T16:18:03.489Z","updated_at":"2022-02-02T16:18:03.489Z","fully_remote":null,"country":"SG","unit":"m2","number_of_staff":122,"staff_working_from_home_percentage":81},"measurement_result":{"id":412,"gas":3034.35,"electricity":147.65533,"water_supply":4.1796,"water_treated":8.6022,"business_travel":41241.89,"waste_landfill":979.12213,"waste_recycling":61.265057,"employee_commutes":103.39523,"expenses":null,"homeworking_gas":2318.8745,"homeworking_electricity":539.11017,"measurement_id":1,"created_at":"2022-02-02T16:18:15.848Z","updated_at":"2022-02-02T16:18:15.848Z","vehicle_usage":null,"office_measurements_id":5424,"scope_1":3034.35,"scope_2":147.65533,"scope_3":45256.438887,"homeworking":2857.98467,"waste":1040.387187,"water":12.7818,"utilities":4235.174317,"total":48438.444217},"offices_ids":[],"business_travel_ids":[10122,10123,10124,10125,10126,10127,10128],"employee_commutes_ids":[12278,12279,12280],"utilities_ids":[11998,11999,12000],"vehicle_usage_ids":[],"waste_ids":[7903,7904]}],"office_measurements_ids":[5421,5422,5423,5424]}');
;// CONCATENATED MODULE: ./src/components/history/HistoryResults.jsx


















const createColor = ({
  color,
  theme
}) => theme.colors[color] || theme.colors.white;

const DashboardRow = external_styled_components_default()(dashboard_Row).withConfig({
  displayName: "HistoryResults__DashboardRow",
  componentId: "sc-1arybhf-0"
})(["width:100%;overflow:hidden;"]);
const HeadingContainer = external_styled_components_default().div.withConfig({
  displayName: "HistoryResults__HeadingContainer",
  componentId: "sc-1arybhf-1"
})(["display:flex;width:100%;justify-content:space-between;margin:1rem 0;"]);
const DashboardSection = external_styled_components_default().div.withConfig({
  displayName: "HistoryResults__DashboardSection",
  componentId: "sc-1arybhf-2"
})(["display:flex;flex-direction:column;align-items:flex-start;width:100%;", ""], theme/* media.tablet */.BC.tablet`
    width: ${p => p.width || "100%"};
    margin: ${p => p.margin || "initial"};
  `);
const LabelContainer = external_styled_components_default().div.withConfig({
  displayName: "HistoryResults__LabelContainer",
  componentId: "sc-1arybhf-3"
})(["margin-bottom:5px;"]);
const ScopeColor = external_styled_components_default().div.withConfig({
  displayName: "HistoryResults__ScopeColor",
  componentId: "sc-1arybhf-4"
})(["background-color:", ";height:1rem;width:1rem;margin-right:0.52rem;"], p => p.color);
const ScopeInnerContainer = external_styled_components_default().div.withConfig({
  displayName: "HistoryResults__ScopeInnerContainer",
  componentId: "sc-1arybhf-5"
})(["display:flex;align-items:center;"]);
const ScopeContainer = external_styled_components_default().div.withConfig({
  displayName: "HistoryResults__ScopeContainer",
  componentId: "sc-1arybhf-6"
})(["display:flex;align-items:center;height:6.25rem;background:", ";border-radius:6px;padding:2.75rem 2rem;width:100%;justify-content:space-between;margin-bottom:0.75rem;", ""], createColor, theme/* media.tablet */.BC.tablet`
    margin: 0;
  
    &:not(:last-child) {
      margin-bottom: 0.75rem;
    }
  `);
const Scopes = external_styled_components_default().div.withConfig({
  displayName: "HistoryResults__Scopes",
  componentId: "sc-1arybhf-7"
})(["width:100%;margin-right:0.75rem;", ""], theme/* media.tablet */.BC.tablet`
      max-width: 17.5rem;
  `);
const HistoryResults_Container = external_styled_components_default().div.withConfig({
  displayName: "HistoryResults__Container",
  componentId: "sc-1arybhf-8"
})(["width:100%;display:flex;flex-direction:column;& > ", ":not(:last-of-type){margin-bottom:1.25rem;}"], dashboard_Row);
const StatContainer = external_styled_components_default().div.withConfig({
  displayName: "HistoryResults__StatContainer",
  componentId: "sc-1arybhf-9"
})(["border-radius:6px;padding:", ";display:flex;flex-direction:row;align-items:center;justify-content:space-between;width:100%;background:", ";margin-bottom:0.75rem;height:4.75rem;", ";"], p => p.padding || "1rem 2rem", createColor, theme/* media.tablet */.BC.tablet`
    margin-bottom: 0;

    &:not(:last-child) {
      margin-right: 0.75rem;
    }
  `);
const HistoryResults_TitleContainer = external_styled_components_default().div.withConfig({
  displayName: "HistoryResults__TitleContainer",
  componentId: "sc-1arybhf-10"
})([""]);
const TextContainer = external_styled_components_default().div.withConfig({
  displayName: "HistoryResults__TextContainer",
  componentId: "sc-1arybhf-11"
})(["display:flex;justify-content:flex-end;flex-direction:column;"]);
const ButtonContainer = external_styled_components_default().div.withConfig({
  displayName: "HistoryResults__ButtonContainer",
  componentId: "sc-1arybhf-12"
})(["margin:0.5rem;display:flex;flex-direction:column;"]);
const IconContainer = external_styled_components_default().div.withConfig({
  displayName: "HistoryResults__IconContainer",
  componentId: "sc-1arybhf-13"
})(["display:flex;align-items:center;& > svg{margin-right:0.5rem;}"]);

const HistoryResults = ({
  measurement,
  edit = true
}) => {
  var _measurement$office_m7, _measurement$office_m8, _measurement$office_m9;

  const {
    0: result,
    1: setResult
  } = (0,external_react_.useState)(null);
  const {
    0: totalFootprint,
    1: setTotalFootprint
  } = (0,external_react_.useState)(0);
  const {
    0: totalStaff,
    1: setTotalStaff
  } = (0,external_react_.useState)(0);
  const {
    0: selectedOfficeId,
    1: setSelectedOfficeId
  } = (0,external_react_.useState)();
  const {
    0: year,
    1: setYear
  } = (0,external_react_.useState)(null);
  const PLACEHOLDER_FLOAT = "-.-";

  const formatValue = value => !value ? 0 : value / 1000;

  (0,external_react_.useEffect)(() => {
    if (measurement) {
      var _measurement$office_m, _measurement$office_m2, _measurement$office_m3, _measurement$office_m4, _measurement$office_m5, _measurement$office_m6;

      const measurementResult = !selectedOfficeId ? (0,charts/* createTotalMeasurementResults */.d)(measurement) : measurement === null || measurement === void 0 ? void 0 : (_measurement$office_m = measurement.office_measurements) === null || _measurement$office_m === void 0 ? void 0 : (_measurement$office_m2 = _measurement$office_m.find(({
        office_id
      }) => selectedOfficeId === office_id)) === null || _measurement$office_m2 === void 0 ? void 0 : _measurement$office_m2.measurement_result;
      const {
        scope_1,
        scope_2,
        scope_3
      } = measurementResult;
      const total = scope_1 + scope_2 + scope_3;
      const number_of_staff = !selectedOfficeId ? measurement === null || measurement === void 0 ? void 0 : (_measurement$office_m3 = measurement.office_measurements) === null || _measurement$office_m3 === void 0 ? void 0 : _measurement$office_m3.reduce((prev, curr) => prev + curr.details.number_of_staff, 0) : measurement === null || measurement === void 0 ? void 0 : (_measurement$office_m4 = measurement.office_measurements) === null || _measurement$office_m4 === void 0 ? void 0 : (_measurement$office_m5 = _measurement$office_m4.find(({
        office_id
      }) => selectedOfficeId === office_id)) === null || _measurement$office_m5 === void 0 ? void 0 : (_measurement$office_m6 = _measurement$office_m5.details) === null || _measurement$office_m6 === void 0 ? void 0 : _measurement$office_m6.number_of_staff;
      const yearString = [...new Set([(0,external_date_fns_.format)(new Date(measurement.year, measurement.month), "LLLL"), (0,external_date_fns_.format)((0,external_date_fns_.subDays)((0,external_date_fns_.addMonths)(new Date(measurement.year, measurement.month), measurement.time_period), 1), "LLLL")])].join(" - ");
      setTotalFootprint(formatValue(total));
      setTotalStaff(number_of_staff);
      setYear(yearString);
      setResult(measurementResult);
    }
  }, [measurement, selectedOfficeId]);
  const metric = "t";
  const dataCollectionHasResults = !!(measurement !== null && measurement !== void 0 && (_measurement$office_m7 = measurement.office_measurements) !== null && _measurement$office_m7 !== void 0 && (_measurement$office_m8 = _measurement$office_m7.filter(office => !!office.measurement_result)) !== null && _measurement$office_m8 !== void 0 && _measurement$office_m8.length);
  const colorScopes = {
    scope_1: theme/* default.colors.graphBlue */.ZP.colors.graphBlue,
    scope_2: theme/* default.colors.graphYellow */.ZP.colors.graphYellow,
    scope_3: theme/* default.colors.graphGreen */.ZP.colors.graphGreen
  };
  const optionArray = measurement && [{
    label: "Company Overview",
    value: null
  }, ...measurement.office_measurements.map(office => ({
    label: office.details.name,
    value: office.office_id
  }))];
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(HistoryResults_Container, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(HeadingContainer, {
      children: (measurement === null || measurement === void 0 ? void 0 : (_measurement$office_m9 = measurement.office_measurements) === null || _measurement$office_m9 === void 0 ? void 0 : _measurement$office_m9.filter(office => !!office.measurement_result).length) && /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [/*#__PURE__*/jsx_runtime_.jsx(InputDropdown/* default */.Z, {
          optionArray: optionArray,
          defaultValue: optionArray === null || optionArray === void 0 ? void 0 : optionArray[0],
          onChange: ({
            value
          }) => setSelectedOfficeId(value),
          width: "20rem",
          controlMargin: "0"
        }), edit && /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.ZP, {
          href: `/history/annual/${measurement.id}/edit`,
          children: "Edit"
        })]
      })
    }), /*#__PURE__*/jsx_runtime_.jsx(DashboardRow, {
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(DashboardSection, {
        width: "100%",
        children: [/*#__PURE__*/jsx_runtime_.jsx(LabelContainer, {
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(Text/* default */.ZP, {
            children: [!edit && measurement && `${[...new Set([(0,external_date_fns_.format)(new Date(measurement.year, measurement.month), "yyyy"), (0,external_date_fns_.format)((0,external_date_fns_.subDays)((0,external_date_fns_.addMonths)(new Date(measurement.year, measurement.month), measurement.time_period), 1), "yyyy")])].join(" - ")} 
            `, " ", selectedOfficeId ? "Office figures" : "Company figures"]
          })
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(DashboardRow, {
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(StatContainer, {
            children: [/*#__PURE__*/jsx_runtime_.jsx(HistoryResults_TitleContainer, {
              children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
                size: "smallBold",
                children: "Annual footprint"
              })
            }), totalFootprint ? /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              children: [/*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
                size: "subtitle1",
                children: Number(parseFloat(totalFootprint).toFixed(1)).toLocaleString()
              }), " ", /*#__PURE__*/(0,jsx_runtime_.jsxs)(Text/* default */.ZP, {
                size: "small",
                align: "right",
                children: [metric, "CO2e"]
              })]
            }) : /*#__PURE__*/jsx_runtime_.jsx(TextContainer, {
              children: /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.ZP, {
                href: "/data-input",
                disabled: measurement,
                children: !!measurement ? "Pending" : "Get started"
              })
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(StatContainer, {
            children: [/*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
              size: "smallBold",
              children: "per employee"
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              children: [/*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
                size: "subtitle1",
                children: totalStaff ? Number((totalFootprint / parseInt(totalStaff)).toFixed(1)).toLocaleString() : PLACEHOLDER_FLOAT
              }), " ", /*#__PURE__*/(0,jsx_runtime_.jsxs)(Text/* default */.ZP, {
                size: "small",
                children: [metric, "CO2e"]
              })]
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(StatContainer, {
            children: [/*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
              size: "smallBold",
              children: "No. of employees"
            }), /*#__PURE__*/jsx_runtime_.jsx("div", {
              children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
                size: "subtitle1",
                children: totalStaff ? Number(parseInt(totalStaff).toFixed(1)).toLocaleString() : PLACEHOLDER_FLOAT
              })
            })]
          })]
        })]
      })
    }), /*#__PURE__*/jsx_runtime_.jsx(DashboardRow, {
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(DashboardSection, {
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(LabelContainer, {
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(Text/* default */.ZP, {
            children: [year, "'s emissions"]
          }), " ", /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
            size: "meta",
            color: "blue",
            children: "(tCO2e)"
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(DashboardRow, {
          children: [/*#__PURE__*/jsx_runtime_.jsx(Scopes, {
            children: Object.keys(colorScopes).map(key => /*#__PURE__*/(0,jsx_runtime_.jsxs)(ScopeContainer, {
              children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(ScopeInnerContainer, {
                children: [/*#__PURE__*/jsx_runtime_.jsx(ScopeColor, {
                  color: colorScopes[key]
                }), /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
                  children: key.replace("_", " ").replace(/^\w/, c => c.toUpperCase())
                })]
              }), result && /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                children: [/*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
                  size: "subtitle1",
                  children: Number(formatValue(result[key]).toFixed(1)).toLocaleString()
                }), " ", /*#__PURE__*/(0,jsx_runtime_.jsxs)(Text/* default */.ZP, {
                  color: "blue",
                  size: "meta",
                  children: [Math.round((result === null || result === void 0 ? void 0 : result[key]) / (result === null || result === void 0 ? void 0 : result.total) * 100), "%"]
                })]
              })]
            }))
          }), /*#__PURE__*/jsx_runtime_.jsx(measurement_LiveDashboardBreakdownBarChart, {
            measurement: dataCollectionHasResults ? measurement : measurementWithResult_namespaceObject,
            officeId: selectedOfficeId,
            isMonthly: (measurement === null || measurement === void 0 ? void 0 : measurement.time_period) === 1,
            placeholder: !dataCollectionHasResults
          }), /*#__PURE__*/jsx_runtime_.jsx(measurement_LiveDashboardScopePieChart, {
            measurement: dataCollectionHasResults ? measurement : measurementWithResult_namespaceObject,
            officeId: selectedOfficeId,
            isMonthly: (measurement === null || measurement === void 0 ? void 0 : measurement.time_period) === 1,
            placeholder: !dataCollectionHasResults
          })]
        })]
      })
    }), !selectedOfficeId && /*#__PURE__*/jsx_runtime_.jsx(DashboardRow, {
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(DashboardSection, {
        width: "100%",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(LabelContainer, {
          children: [/*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
            children: "Offices"
          }), " ", /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
            size: "meta",
            color: "blue",
            children: "(tCO2e)"
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(DashboardRow, {
          children: [/*#__PURE__*/jsx_runtime_.jsx(DashboardSection, {
            width: "49.5%",
            children: /*#__PURE__*/jsx_runtime_.jsx(measurement_OfficeEmissionsBarChart, {
              measurement: dataCollectionHasResults ? measurement : measurementWithResult_namespaceObject,
              officeId: selectedOfficeId
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(DashboardSection, {
            width: "49.5%",
            children: /*#__PURE__*/jsx_runtime_.jsx(DashboardRow, {
              children: /*#__PURE__*/jsx_runtime_.jsx(measurement_EmissionsPerEmployeeBarChart, {
                measurement: measurement
              })
            })
          })]
        })]
      })
    })]
  });
};

/* harmony default export */ const history_HistoryResults = (HistoryResults);

/***/ })

};
;