"use strict";
exports.id = 1537;
exports.ids = [1537];
exports.modules = {

/***/ 54251:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export labelStyles */
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const labelStyles = (0,styled_components__WEBPACK_IMPORTED_MODULE_0__.css)(["color:", ";font-weight:", ";font-size:", ";"], p => p.color ? p.color : p.theme.colors.label, p => p.fontWeight || p.theme.body.weight, p => p.theme.tiny.size);
const Label = styled_components__WEBPACK_IMPORTED_MODULE_0___default().label.withConfig({
  displayName: "Label",
  componentId: "l08cxq-0"
})(["", " margin:", ";", ""], labelStyles, p => p.margin || " 0 0.125rem 0.1rem", p => p.block && "display:block;");
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Label);

/***/ }),

/***/ 32083:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(87491);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);





const TextConatiner = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "UserItem__TextConatiner",
  componentId: "sc-1itveff-0"
})(["display:flex;flex-direction:column;justify-content:center;height:100%;margin:auto 0;", ""], _theme__WEBPACK_IMPORTED_MODULE_1__/* .media.tablet */ .BC.tablet`
    margin: auto 0;
    width: 100%;
  `);
const Container = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "UserItem__Container",
  componentId: "sc-1itveff-1"
})(["display:flex;width:100%;align-items:center;flex-wrap:", ";", ""], p => p.wrap || "nowrap", _theme__WEBPACK_IMPORTED_MODULE_1__/* .media.tablet */ .BC.tablet`
  flex-wrap:unset;
    width: 100%;
  `);
const AvatarContainer = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "UserItem__AvatarContainer",
  componentId: "sc-1itveff-2"
})(["min-width:", ";width:", ";height:", ";display:flex;align-items:center;justify-content:center;border-radius:50%;margin-right:1.5rem;background-color:", ";", ""], p => p.size || "2rem", p => p.size || "2rem", p => p.size || "2rem", p => p.theme.colors.progressYellow, _theme__WEBPACK_IMPORTED_MODULE_1__/* .media.tablet */ .BC.tablet`
  min-width: 3rem;
  width: 3rem;
  height: 3rem;
  `);
const ActionContainer = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "UserItem__ActionContainer",
  componentId: "sc-1itveff-3"
})(["margin:", ";width:", ";", ";"], p => p.actionMargin || "initial", p => p.actionWidth || "initial", _theme__WEBPACK_IMPORTED_MODULE_1__/* .media.tablet */ .BC.tablet`
  justify-self: flex-end;
  `);
const Image = styled_components__WEBPACK_IMPORTED_MODULE_2___default().img.withConfig({
  displayName: "UserItem__Image",
  componentId: "sc-1itveff-4"
})(["width:100%;height:100%;border-radius:50%;object-fit:cover;"]);

const UserItem = ({
  user,
  action,
  size,
  wrap,
  actionMargin,
  actionWidth
}) => {
  var _user$first_name;

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(Container, {
    wrap: wrap,
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(AvatarContainer, {
      size: size,
      children: user.profile_picture ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(Image, {
        src: user.profile_picture
      }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .ZP, {
        size: "logo",
        color: "white",
        children: user === null || user === void 0 ? void 0 : (_user$first_name = user.first_name) === null || _user$first_name === void 0 ? void 0 : _user$first_name.charAt(0)
      })
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(TextConatiner, {
      children: [((user === null || user === void 0 ? void 0 : user.first_name) || (user === null || user === void 0 ? void 0 : user.last_name)) && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(_common_Text__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .ZP, {
          size: "subtitleBold",
          children: [user === null || user === void 0 ? void 0 : user.first_name, " ", user === null || user === void 0 ? void 0 : user.last_name, " "]
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .ZP, {
          size: "small",
          children: user.email
        })
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(ActionContainer, {
      actionMargin: actionMargin,
      actionWidth: actionWidth,
      children: action
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (UserItem);

/***/ })

};
;