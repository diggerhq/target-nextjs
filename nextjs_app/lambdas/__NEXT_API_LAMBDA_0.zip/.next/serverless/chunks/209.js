"use strict";
exports.id = 209;
exports.ids = [209];
exports.modules = {

/***/ 72052:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);


const CardContainer = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "CardsContainer__CardContainer",
  componentId: "tmea7o-0"
})(["width:100%;margin-top:2rem;display:flex;flex-wrap:wrap;flex-direction:row;justify-content:space-between;& > div{width:100%;}", " ", ""], _theme__WEBPACK_IMPORTED_MODULE_0__/* .media.mobileModern */ .BC.mobileModern`

    & > div {
      width: 45%;
    }
  `, _theme__WEBPACK_IMPORTED_MODULE_0__/* .media.tablet */ .BC.tablet`
    justify-content: initial;

    &> div {
      width: initial;
      margin-right: 3rem;
      max-width:18.375rem;
    }
	`);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CardContainer);

/***/ }),

/***/ 72555:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ offers_OfferItem)
});

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(41664);
// EXTERNAL MODULE: external "react-responsive"
var external_react_responsive_ = __webpack_require__(16666);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./src/styles.jsx
var styles = __webpack_require__(72994);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(57518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
;// CONCATENATED MODULE: ./src/components/common/LazyImage.jsx




const Image = external_styled_components_default().img.withConfig({
  displayName: "LazyImage__Image",
  componentId: "sc-28si-0"
})(["", " width:100%;height:100%;min-height:inherit;max-height:inherit;min-width:inherit;max-width:inherit;padding:0;object-fit:cover;"], styles/* borderRadius */.E);
const LazyImage = /*#__PURE__*/external_react_default().memo(({
  src,
  placeholder
}) => {
  const {
    0: loading,
    1: setLoading
  } = (0,external_react_.useState)(true);
  const {
    0: currentSrc,
    1: updateSrc
  } = (0,external_react_.useState)("/images/loading.png");
  (0,external_react_.useEffect)(() => {
    // start loading original image
    let imageToLoad = document.createElement("img");
    imageToLoad.src = src;

    imageToLoad.onload = () => {
      // When image is loaded replace the src and set loading to false
      setLoading(false);
      updateSrc(src);
    };
  }, [src]);
  return /*#__PURE__*/jsx_runtime_.jsx(Image, {
    src: currentSrc,
    style: {
      opacity: loading ? 0.2 : 1,
      transition: "opacity .15s linear"
    }
  });
});
/* harmony default export */ const common_LazyImage = (LazyImage);
// EXTERNAL MODULE: ./src/components/common/Text.jsx
var Text = __webpack_require__(87491);
// EXTERNAL MODULE: ./src/theme.js
var theme = __webpack_require__(91073);
;// CONCATENATED MODULE: ./src/components/offers/Card.jsx



const Card = external_styled_components_default().div.withConfig({
  displayName: "Card",
  componentId: "sc-1lqvggr-0"
})(["display:flex;margin-bottom:1rem;align-items:", ";position:relative;flex-direction:column;", " ", " box-shadow:5px 5px 30px ", ";", " transition:box-shadow 0.3s;width:100%;&:hover{box-shadow:10px 10px 30px ", "80;}", " ", ""], p => p.alignItems ? p.alignItems : "center", p => p.padding && `padding: ${p.padding};`, p => p.border && `border: 1px solid ${p.theme.colors.black};`, p => p.theme.colors.tertiaryBlue, styles/* borderRadius */.E, p => p.theme.colors.blue, theme/* media.mobileModern */.BC.mobileModern`
    width: fit-content;
  `, theme/* media.tabletLarge */.BC.tabletLarge`
      margin-bottom: 1.5rem;
      display: flex;
  `);
/* harmony default export */ const offers_Card = (Card);
// EXTERNAL MODULE: ./src/utils/text.js
var utils_text = __webpack_require__(88703);
;// CONCATENATED MODULE: ./src/components/offers/OfferItem.jsx











const textHeight = (0,external_styled_components_.css)(["min-height:2rem;max-height:2rem;", ""], theme/* media.tablet */.BC.tablet`
    min-height: initial;
    max-height: initial;
  `);
const commonContainer = (0,external_styled_components_.css)(["", ""], theme/* media.tablet */.BC.tablet`
    max-width: 18.75rem;
    min-width: 18.75rem;
  `);
const InnerContainer = external_styled_components_default().div.withConfig({
  displayName: "OfferItem__InnerContainer",
  componentId: "sc-1qg1gsk-0"
})(["", " width:100%;display:flex;flex-direction:column;padding:0.875rem 0.5rem;cursor:pointer;align-self:stretch;", " background-color:white;margin-top:-2rem;z-index:1;", " ", ""], commonContainer, styles/* borderRadius */.E, theme/* media.mobileModern */.BC.mobileModern`
    max-width: 100%;
    max-height: 9.375rem;
    min-height: 9.375rem;
  `, theme/* media.tablet */.BC.tablet`
    padding: 1rem 1.5rem;
	`);
const ImageContainer = external_styled_components_default().div.withConfig({
  displayName: "OfferItem__ImageContainer",
  componentId: "sc-1qg1gsk-1"
})(["", " width:100%;min-height:14rem;padding:0;max-height:14rem;", " cursor:pointer;", " ", ";"], commonContainer, styles/* borderRadius */.E, theme/* media.mobileModern */.BC.mobileModern`
    max-width: 100%;
    max-height: 9.375rem;
    min-height: 9.375rem;
  `, theme/* media.tablet */.BC.tablet`
    width: 18.75rem;
    height: 18.75rem;
    max-height: unset;
  `);
const Title = external_styled_components_default().div.withConfig({
  displayName: "OfferItem__Title",
  componentId: "sc-1qg1gsk-2"
})(["", " text-transform:capitalize;& > *{display:inline-block;line-height:1;}", ""], textHeight, theme/* media.tablet */.BC.tablet`
	  margin: 0.5rem 0 1rem;
    

    & > * {
      display: initial;
      line-height: initial;
    }
	`);
const Small = external_styled_components_default().div.withConfig({
  displayName: "OfferItem__Small",
  componentId: "sc-1qg1gsk-3"
})(["", " overflow:hidden;display:flex;margin-bottom:0.5rem;& > *{display:inline-block;line-height:1.5;}", ""], textHeight, theme/* media.tablet */.BC.tablet`
    height: 3rem;
    display: block;
    margin-bottom: initial;

    & > * {
    display: initial;
    line-height: initial;
  }
	`);
const BottomContainer = external_styled_components_default().div.withConfig({
  displayName: "OfferItem__BottomContainer",
  componentId: "sc-1qg1gsk-4"
})(["display:block;", ""], theme/* media.tablet */.BC.tablet`
    margin-top: auto;
  `);
const TimeStamps = external_styled_components_default().div.withConfig({
  displayName: "OfferItem__TimeStamps",
  componentId: "sc-1qg1gsk-5"
})(["display:flex;flex-direction:column;align-items:flex-start;", ""], theme/* media.tablet */.BC.tablet`
    flex-direction: row;
    align-items: center;
  `);
const OfferTitle = external_styled_components_default().div.withConfig({
  displayName: "OfferItem__OfferTitle",
  componentId: "sc-1qg1gsk-6"
})(["padding:0.15rem 0.5rem;display:flex;align-items:center;background-color:", ";text-align:center;font-weight:", ";text-transform:uppercase;border-radius:10px;", ""], p => p.theme.colors.yellow, p => p.theme.mobile.small.fontWeight, theme/* media.tablet */.BC.tablet`
		margin-left: 0.75rem;
`);

const OfferItem = ({
  reductionPartner
}) => {
  const isTablet = (0,external_react_responsive_.useMediaQuery)({
    query: `(min-width: ${theme/* sizes.tablet */.J7.tablet}px)`
  });
  return /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
    href: "/offers/[slug]",
    as: `/offers/${reductionPartner.slug}`,
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(offers_Card, {
      alignItems: "flex-start",
      children: [/*#__PURE__*/jsx_runtime_.jsx(ImageContainer, {
        children: /*#__PURE__*/jsx_runtime_.jsx(common_LazyImage, {
          src: !!reductionPartner.images.length && reductionPartner.images[0].url
        })
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(InnerContainer, {
        children: [/*#__PURE__*/jsx_runtime_.jsx(Title, {
          children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
            align: "left",
            size: isTablet ? "h4" : "smallBold",
            children: isTablet ? reductionPartner.name : (0,utils_text/* truncate */.$)(reductionPartner.name, 30)
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(Small, {
          children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
            align: "left",
            size: isTablet ? "tiny" : "miniscule",
            children: isTablet ? reductionPartner.summary : (0,utils_text/* truncate */.$)(reductionPartner.summary, 45)
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(BottomContainer, {
          children: reductionPartner.price === 0 ? /*#__PURE__*/jsx_runtime_.jsx(TimeStamps, {
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(Text/* default */.ZP, {
              size: "offerPrice",
              children: ["FREE ", reductionPartner.price_suffix]
            })
          }) : /*#__PURE__*/(0,jsx_runtime_.jsxs)(TimeStamps, {
            children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(Text/* default */.ZP, {
              size: "offerPrice",
              children: ["from \xA3", reductionPartner.price.toFixed(2), " ", reductionPartner.price_suffix, " "]
            }), /*#__PURE__*/jsx_runtime_.jsx(OfferTitle, {
              children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.ZP, {
                size: isTablet ? "tiny" : "miniscule",
                color: "white",
                children: "Offer"
              })
            })]
          })
        })]
      })]
    })
  });
};

/* harmony default export */ const offers_OfferItem = (OfferItem);

/***/ })

};
;