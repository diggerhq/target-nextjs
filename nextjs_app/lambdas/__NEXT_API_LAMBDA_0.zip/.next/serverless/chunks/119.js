"use strict";
exports.id = 119;
exports.ids = [119];
exports.modules = {

/***/ 7020:
/***/ ((module) => {

module.exports = JSON.parse('{"polyfillFiles":["static/chunks/polyfills-5cd94c89d3acac5f.js"],"devFiles":[],"ampDevFiles":[],"lowPriorityFiles":["static/prO4zswvGy6pHIAtUtviK/_buildManifest.js","static/prO4zswvGy6pHIAtUtviK/_ssgManifest.js","static/prO4zswvGy6pHIAtUtviK/_middlewareManifest.js"],"pages":{"/":["static/chunks/webpack-514908bffb652963.js","static/chunks/framework-6e4ba497ae0c8a3f.js","static/chunks/main-e47bb435dabe4202.js","static/chunks/821-94d0dc1c2bd140d9.js","static/chunks/pages/index-14a030ed56c4e71c.js"],"/_app":["static/chunks/webpack-514908bffb652963.js","static/chunks/framework-6e4ba497ae0c8a3f.js","static/chunks/main-e47bb435dabe4202.js","static/chunks/pages/_app-ba0d1cdf43a37972.js"],"/_error":["static/chunks/webpack-514908bffb652963.js","static/chunks/framework-6e4ba497ae0c8a3f.js","static/chunks/main-e47bb435dabe4202.js","static/chunks/pages/_error-6679c1efb053c50e.js"],"/person/[id]":["static/chunks/webpack-514908bffb652963.js","static/chunks/framework-6e4ba497ae0c8a3f.js","static/chunks/main-e47bb435dabe4202.js","static/chunks/821-94d0dc1c2bd140d9.js","static/chunks/pages/person/[id]-d7d03064d4248577.js"]},"ampFirstPages":[]}');

/***/ }),

/***/ 3978:
/***/ ((module) => {

module.exports = {};

/***/ }),

/***/ 9450:
/***/ ((module) => {

module.exports = {"Dg":[]};

/***/ })

};
;