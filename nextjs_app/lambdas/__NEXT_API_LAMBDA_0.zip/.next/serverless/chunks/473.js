"use strict";
exports.id = 473;
exports.ids = [473];
exports.modules = {

/***/ 1069:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const DescriptonTextContainer = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "DescriptionTextContainer__DescriptonTextContainer",
  componentId: "sc-1y2caq0-0"
})(["margin-bottom:1.5rem;"]);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DescriptonTextContainer);

/***/ }),

/***/ 49611:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61908);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(45641);
/* harmony import */ var _button_Button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(59067);
/* harmony import */ var _common_Divider__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6459);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(87491);
/* harmony import */ var _form_Input__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(18183);
/* harmony import */ var _form_InputDropdown__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(51894);
/* harmony import */ var _common_ButtonsContainer__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(30495);
/* harmony import */ var _common_DescriptionTextContainer__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1069);
/* harmony import */ var _common_Form__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(79397);
/* harmony import */ var _common_FormGroup__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(13586);
/* harmony import */ var _MeasurementArraySection__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(98782);
/* harmony import */ var _MeasurementSection__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(28067);
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(19390);
/* harmony import */ var _contexts_auth__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(58368);
/* harmony import */ var _contexts_measurements__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(85238);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(11098);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(75609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__, react_hook_form__WEBPACK_IMPORTED_MODULE_3__, _form_Input__WEBPACK_IMPORTED_MODULE_7__, _form_InputDropdown__WEBPACK_IMPORTED_MODULE_8__]);
([_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__, react_hook_form__WEBPACK_IMPORTED_MODULE_3__, _form_Input__WEBPACK_IMPORTED_MODULE_7__, _form_InputDropdown__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }























const schema = yup__WEBPACK_IMPORTED_MODULE_19__.object().shape({
  commutes: yup__WEBPACK_IMPORTED_MODULE_19__.array().of(yup__WEBPACK_IMPORTED_MODULE_19__.object().shape({
    distance: yup__WEBPACK_IMPORTED_MODULE_19__.number().required("Distance is required").typeError("Enter valid distance or remove Employee to proceed"),
    type: yup__WEBPACK_IMPORTED_MODULE_19__.object().shape({
      label: yup__WEBPACK_IMPORTED_MODULE_19__.string(),
      value: yup__WEBPACK_IMPORTED_MODULE_19__.string()
    }).required("Please select a mode of transport").typeError("Please select a mode of transport")
  }))
});
const modesOfTransport = [{
  label: "Small Car",
  value: "small_car"
}, {
  label: "Medium Car",
  value: "medium_car"
}, {
  label: "Large Car",
  value: "large_car"
}, {
  label: "Hybrid Car",
  value: "hybrid_car"
}, {
  label: "Bus",
  value: "bus"
}, {
  label: "London Underground",
  value: "subway"
}, {
  label: "Tram or Light Rail",
  value: "tram"
}, {
  label: "Train",
  value: "train"
}, {
  label: "Cycle",
  value: "cycle"
}, {
  label: "Walk",
  value: "walk"
}];

const Commutes = ({
  sectionDisabled,
  review
}) => {
  const {
    user
  } = (0,_contexts_auth__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z)();
  const {
    selectedMeasurement,
    setSelectedMeasurement,
    updateLastCompletedStep
  } = (0,_contexts_measurements__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z)();
  const {
    0: deleteLoading,
    1: setDeleteLoading
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)();
  const id = "commutes";
  const methodsFieldArray = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_3__.useForm)({
    shouldUnregister: false,
    resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__.yupResolver)(schema),
    defaultValues: {
      commutes: selectedMeasurement.commutes.map(commute => ({
        id: commute.id,
        distance: commute.distance,
        type: modesOfTransport.find(mode => mode.value === commute.type),
        metric: _utils_constants__WEBPACK_IMPORTED_MODULE_15__/* .DISTANCE_METRICS.find */ .Kk.find(metric => metric.value === (commute === null || commute === void 0 ? void 0 : commute.metric))
      }))
    }
  });
  const {
    fields,
    append,
    remove
  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_3__.useFieldArray)({
    control: methodsFieldArray.control,
    name: "commutes"
  });

  const deleteCommute = async (id, index) => {
    setDeleteLoading(true);

    try {
      await axios__WEBPACK_IMPORTED_MODULE_1___default()["delete"](`/api/organisations/${user.organisation_id}/measurements/${selectedMeasurement.id}/commutes/${id}`);
      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`/api/organisations/${user.organisation_id}/measurements/${selectedMeasurement.id}`);
      setSelectedMeasurement(data);
      remove(index);
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_18__/* .logError */ .H)(error);
    }

    setDeleteLoading(false);
  };

  const upsertCommutes = async ({
    commutes
  }, cb) => {
    try {
      const newCommutes = [];
      const existingCommutes = [];
      commutes.filter(({
        distance
      }) => !!distance).forEach(commute => {
        if (selectedMeasurement.commutes.find(mcommute => commute.id === mcommute.id)) {
          return existingCommutes.push(commute);
        }

        newCommutes.push(commute);
      });
      await axios__WEBPACK_IMPORTED_MODULE_1___default().post(`/api/organisations/${user.organisation_id}/measurements/${selectedMeasurement.id}/commutes/batch`, {
        create: newCommutes.map(({
          type,
          metric,
          distance
        }) => ({
          type: type.value,
          distance: parseFloat(distance),
          metric: metric.value,
          office_id: selectedMeasurement.offices[0].id
        })),
        update: existingCommutes.map(({
          type,
          metric,
          distance,
          id
        }) => ({
          id,
          type: type.value,
          distance: parseFloat(distance),
          metric: metric.value
        }))
      });
      const data = await updateLastCompletedStep(id);
      methodsFieldArray.reset({
        commutes: data.commutes.map(commute => ({
          id: commute.id,
          distance: commute.distance,
          type: modesOfTransport.find(mode => mode.value === commute.type),
          metric: _utils_constants__WEBPACK_IMPORTED_MODULE_15__/* .DISTANCE_METRICS.find */ .Kk.find(metric => metric.value === (commute === null || commute === void 0 ? void 0 : commute.metric))
        }))
      });
      cb();
    } catch (error) {
      throw error;
    }
  };

  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(() => {
    if (!selectedMeasurement.commutes.length) {
      append({
        distance: null,
        type: "",
        metric: _utils_constants__WEBPACK_IMPORTED_MODULE_15__/* .DISTANCE_METRICS[0] */ .Kk[0]
      });
    }
  }, []);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxs)(_MeasurementSection__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
    id: id,
    title: "Employee Commute",
    onNextClick: methodsFieldArray.handleSubmit(upsertCommutes),
    sectionDisabled: sectionDisabled,
    value: `${selectedMeasurement.commutes.length} ${selectedMeasurement.commutes.length === 1 ? "employee" : "employees"}`,
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_common_DescriptionTextContainer__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .ZP, {
        children: "If it is not possible to add all employee commuter journeys, please add a sample and we will average and project out to the entire workforce."
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_common_Form__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
      onSubmit: methodsFieldArray.handleSubmit(upsertCommutes),
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxs)(react_hook_form__WEBPACK_IMPORTED_MODULE_3__.FormProvider, _objectSpread(_objectSpread({}, methodsFieldArray), {}, {
        children: [fields && fields.map((commute, index) => {
          var _DISTANCE_METRICS$fin, _commute$type;

          return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx("div", {
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxs)(_MeasurementArraySection__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
              title: `Employee ${index + 1}`,
              value: `${commute.distance} ${(_DISTANCE_METRICS$fin = _utils_constants__WEBPACK_IMPORTED_MODULE_15__/* .DISTANCE_METRICS.find */ .Kk.find(metric => {
                var _commute$metric;

                return metric.value === (commute === null || commute === void 0 ? void 0 : (_commute$metric = commute.metric) === null || _commute$metric === void 0 ? void 0 : _commute$metric.value);
              })) === null || _DISTANCE_METRICS$fin === void 0 ? void 0 : _DISTANCE_METRICS$fin.label}, ${(_commute$type = commute.type) === null || _commute$type === void 0 ? void 0 : _commute$type.label}`,
              defaultOpen: !commute.distance,
              onClose: async () => Number.isInteger(commute.id) ? await deleteCommute(commute.id, index) : remove(index),
              closeLoading: deleteLoading,
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx("input", {
                name: `id`,
                disabled: true,
                hidden: true,
                defaultValue: commute.id
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_form_InputDropdown__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                id: `commutes.${index}.type`,
                width: "50%",
                placeholder: "Please select transport mode...",
                optionArray: modesOfTransport,
                defaultValue: commute.type,
                hasDefaultValue: false
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxs)(_common_FormGroup__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                align: "flex-start",
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_form_InputDropdown__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                  id: `commutes.${index}.metric`,
                  width: "18.5%",
                  placeholder: "Select metric...",
                  optionArray: _utils_constants__WEBPACK_IMPORTED_MODULE_15__/* .DISTANCE_METRICS */ .Kk,
                  defaultValue: commute.metric
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_form_Input__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                  id: `commutes.${index}.distance`,
                  name: `commutes.${index}.distance`,
                  testId: `commutes.${index}.distance`,
                  width: "30%",
                  placeholder: "Enter Value",
                  type: "number",
                  step: 0.01,
                  isRequired: true,
                  defaultValue: commute.distance
                })]
              })]
            })
          }, commute.id);
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_common_Divider__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
          margin: "0.5rem 0 2rem",
          width: "70%"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_common_ButtonsContainer__WEBPACK_IMPORTED_MODULE_9__/* .OfficeButtonsContainer */ .g, {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_20__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP, {
            type: "button",
            onClick: () => append({
              distance: null,
              type: "",
              metric: _utils_constants__WEBPACK_IMPORTED_MODULE_15__/* .DISTANCE_METRICS[0] */ .Kk[0]
            }),
            children: "Add more"
          })
        })]
      }))
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Commutes);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 98667:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61908);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(45641);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(87491);
/* harmony import */ var _form_Input__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(18183);
/* harmony import */ var _form_InputDropdown__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(51894);
/* harmony import */ var _common_DescriptionTextContainer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1069);
/* harmony import */ var _common_Form__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(79397);
/* harmony import */ var _common_FormGroup__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(13586);
/* harmony import */ var _MeasurementSection__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(28067);
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(19390);
/* harmony import */ var _contexts_auth__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(58368);
/* harmony import */ var _contexts_measurements__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(85238);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(75609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__, react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _form_Input__WEBPACK_IMPORTED_MODULE_4__, _form_InputDropdown__WEBPACK_IMPORTED_MODULE_5__]);
([_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__, react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _form_Input__WEBPACK_IMPORTED_MODULE_4__, _form_InputDropdown__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

















const schema = yup__WEBPACK_IMPORTED_MODULE_13__.object().shape({
  usage: yup__WEBPACK_IMPORTED_MODULE_13__.number().required().typeError("Please enter a valid number"),
  period: yup__WEBPACK_IMPORTED_MODULE_13__.object().shape({
    label: yup__WEBPACK_IMPORTED_MODULE_13__.string(),
    value: yup__WEBPACK_IMPORTED_MODULE_13__.string()
  }).required("Please select a time frame").typeError("Please select a time frame")
});
const METRICS_ARRAY = [{
  label: "kWh",
  value: "kwh"
}, {
  label: "GBP",
  value: "gbp"
}];

const ElectricityUtility = ({
  sectionDisabled
}) => {
  var _METRICS_ARRAY$find;

  const {
    user
  } = (0,_contexts_auth__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z)();
  const {
    selectedMeasurement,
    updateLastCompletedStep
  } = (0,_contexts_measurements__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z)();
  const id = "electricity";
  const currentElectricityUtility = selectedMeasurement.utilities.find(utility => utility.type === "electricity");
  const currentGasUtility = selectedMeasurement.utilities.find(utility => utility.type === "gas");
  const methods = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_2__.useForm)({
    resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__.yupResolver)(schema),
    defaultValues: {
      usage: currentElectricityUtility === null || currentElectricityUtility === void 0 ? void 0 : currentElectricityUtility.usage,
      metric: METRICS_ARRAY.find(metric => (currentElectricityUtility === null || currentElectricityUtility === void 0 ? void 0 : currentElectricityUtility.metric) === metric.value),
      period: _utils_constants__WEBPACK_IMPORTED_MODULE_10__/* .PERIODS.find */ .z5.find(period => period.value === (currentElectricityUtility === null || currentElectricityUtility === void 0 ? void 0 : currentElectricityUtility.period))
    }
  });

  const updateMeasurementElectricity = async ({
    period,
    metric,
    usage
  }, cb) => {
    try {
      const electricityUtility = selectedMeasurement.utilities.find(utility => utility.type === "electricity");

      if (!electricityUtility) {
        await axios__WEBPACK_IMPORTED_MODULE_1___default().post(`/api/organisations/${user.organisation_id}/measurements/${selectedMeasurement.id}/utilities`, {
          type: "electricity",
          period: period.value,
          metric: metric.value,
          office_id: selectedMeasurement.offices[0].id,
          usage: parseInt(usage)
        });
      } else {
        await axios__WEBPACK_IMPORTED_MODULE_1___default().patch(`/api/organisations/${user.organisation_id}/measurements/${selectedMeasurement.id}/utilities/${electricityUtility.id}`, {
          period: period.value,
          metric: metric.value,
          usage: parseInt(usage)
        });
      }

      await updateLastCompletedStep(id);
      cb();
    } catch (error) {
      throw error;
    }
  };

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(_MeasurementSection__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
    id: id,
    title: "Electricity",
    onNextClick: methods.handleSubmit(updateMeasurementElectricity),
    sectionDisabled: sectionDisabled,
    value: selectedMeasurement.utilities && selectedMeasurement.utilities.find(utility => utility.type === "electricity") && `${selectedMeasurement.utilities && currentElectricityUtility.usage} ${(_METRICS_ARRAY$find = METRICS_ARRAY.find(metric => (currentElectricityUtility === null || currentElectricityUtility === void 0 ? void 0 : currentElectricityUtility.metric) === metric.value)) === null || _METRICS_ARRAY$find === void 0 ? void 0 : _METRICS_ARRAY$find.label} ${_utils_constants__WEBPACK_IMPORTED_MODULE_10__/* .PERIODS.find */ .z5.find(period => period.value === selectedMeasurement.utilities.find(utility => utility.type === "electricity").period).label}`,
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_common_DescriptionTextContainer__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP, {
        children: "What was your electricity usage for the period?"
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_common_Form__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
      onSubmit: methods.handleSubmit(updateMeasurementElectricity),
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.FormProvider, _objectSpread(_objectSpread({}, methods), {}, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_form_InputDropdown__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
          id: "period",
          width: "50%",
          placeholder: "Please select timeframe...",
          optionArray: _utils_constants__WEBPACK_IMPORTED_MODULE_10__/* .PERIODS */ .z5,
          hasDefaultValue: false
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(_common_FormGroup__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
          align: "flex-start",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_form_InputDropdown__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
            id: "metric",
            width: "18.5%",
            placeholder: "Select metric...",
            optionArray: METRICS_ARRAY
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_form_Input__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
            id: "usage",
            name: "usage",
            testId: "usage",
            width: "30%",
            placeholder: "Enter Value",
            type: "number",
            isRequired: true
          })]
        })]
      }))
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ElectricityUtility);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 86465:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61908);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(45641);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(87491);
/* harmony import */ var _form_Input__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(18183);
/* harmony import */ var _form_InputDropdown__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(51894);
/* harmony import */ var _common_DescriptionTextContainer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1069);
/* harmony import */ var _common_Form__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(79397);
/* harmony import */ var _common_FormGroup__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(13586);
/* harmony import */ var _MeasurementSection__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(28067);
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(19390);
/* harmony import */ var _contexts_auth__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(58368);
/* harmony import */ var _contexts_measurements__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(85238);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(75609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__, react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _form_Input__WEBPACK_IMPORTED_MODULE_4__, _form_InputDropdown__WEBPACK_IMPORTED_MODULE_5__]);
([_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__, react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _form_Input__WEBPACK_IMPORTED_MODULE_4__, _form_InputDropdown__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

















const schema = yup__WEBPACK_IMPORTED_MODULE_13__.object().shape({
  usage: yup__WEBPACK_IMPORTED_MODULE_13__.number().required().typeError("Please enter a valid number"),
  period: yup__WEBPACK_IMPORTED_MODULE_13__.object().shape({
    label: yup__WEBPACK_IMPORTED_MODULE_13__.string(),
    value: yup__WEBPACK_IMPORTED_MODULE_13__.string()
  }).required("Please select a time frame").typeError("Please select a time frame")
});
const METRICS_ARRAY = [{
  label: "kWh",
  value: "kwh"
}, {
  label: "GBP",
  value: "gbp"
}];

const GasUtility = ({
  hasUtilityBills,
  sectionDisabled
}) => {
  var _selectedMeasurement$, _METRICS_ARRAY$find;

  const {
    user
  } = (0,_contexts_auth__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z)();
  const {
    selectedMeasurement,
    updateLastCompletedStep
  } = (0,_contexts_measurements__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z)();
  const id = "gas";
  const currentGasUtility = selectedMeasurement.utilities.find(utility => utility.type === "gas");
  const methods = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_2__.useForm)({
    resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__.yupResolver)(schema),
    defaultValues: {
      usage: (_selectedMeasurement$ = selectedMeasurement.utilities.find(utility => utility.type === "gas")) === null || _selectedMeasurement$ === void 0 ? void 0 : _selectedMeasurement$.usage,
      metric: METRICS_ARRAY.find(metric => (currentGasUtility === null || currentGasUtility === void 0 ? void 0 : currentGasUtility.metric) === metric.value),
      period: _utils_constants__WEBPACK_IMPORTED_MODULE_10__/* .PERIODS.find */ .z5.find(period => period.value === (currentGasUtility === null || currentGasUtility === void 0 ? void 0 : currentGasUtility.period))
    }
  });

  const updateMeasurementGas = async ({
    period,
    metric,
    usage
  }, cb) => {
    try {
      const gasUtility = selectedMeasurement.utilities.find(utility => utility.type === "gas");

      if (!gasUtility) {
        await axios__WEBPACK_IMPORTED_MODULE_1___default().post(`/api/organisations/${user.organisation_id}/measurements/${selectedMeasurement.id}/utilities`, {
          type: "gas",
          period: period.value,
          metric: metric.value,
          office_id: selectedMeasurement.offices[0].id,
          usage: parseInt(usage)
        });
      } else {
        await axios__WEBPACK_IMPORTED_MODULE_1___default().patch(`/api/organisations/${user.organisation_id}/measurements/${selectedMeasurement.id}/utilities/${gasUtility.id}`, {
          period: period.value,
          metric: metric.value,
          usage: parseInt(usage)
        });
      }

      await updateLastCompletedStep(id);
      cb();
    } catch (error) {
      throw error;
    }
  };

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(_MeasurementSection__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
    id: id,
    title: "Gas",
    onNextClick: methods.handleSubmit(updateMeasurementGas),
    sectionDisabled: sectionDisabled,
    value: selectedMeasurement.utilities && currentGasUtility && `${selectedMeasurement.utilities && (currentGasUtility === null || currentGasUtility === void 0 ? void 0 : currentGasUtility.usage)} ${(_METRICS_ARRAY$find = METRICS_ARRAY.find(metric => (currentGasUtility === null || currentGasUtility === void 0 ? void 0 : currentGasUtility.metric) === metric.value)) === null || _METRICS_ARRAY$find === void 0 ? void 0 : _METRICS_ARRAY$find.label} ${_utils_constants__WEBPACK_IMPORTED_MODULE_10__/* .PERIODS.find */ .z5.find(period => period.value === (currentGasUtility === null || currentGasUtility === void 0 ? void 0 : currentGasUtility.period)).label}`,
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_common_DescriptionTextContainer__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP, {
        children: "What was your gas usage for the period?"
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_common_Form__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
      onSubmit: methods.handleSubmit(updateMeasurementGas),
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.FormProvider, _objectSpread(_objectSpread({}, methods), {}, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_form_InputDropdown__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
          id: "period",
          width: "50%",
          placeholder: "Please select timeframe...",
          optionArray: _utils_constants__WEBPACK_IMPORTED_MODULE_10__/* .PERIODS */ .z5,
          hasDefaultValue: false
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(_common_FormGroup__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
          align: "flex-start",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_form_InputDropdown__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
            id: "metric",
            width: "18.5%",
            placeholder: "Select metric...",
            optionArray: METRICS_ARRAY
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_form_Input__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
            id: "usage",
            name: "usage",
            testId: "usage",
            width: "30%",
            placeholder: "Enter Value",
            type: "number",
            isRequired: true
          })]
        })]
      }))
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (GasUtility);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 71681:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ offices_HasOffice)
});

// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(52167);
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
// EXTERNAL MODULE: ./src/components/button/Button.jsx
var Button = __webpack_require__(59067);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(57518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
;// CONCATENATED MODULE: ./src/components/common/Anchor.jsx

const Anchor = external_styled_components_default().a.attrs({
  target: "_blank"
}).withConfig({
  displayName: "Anchor",
  componentId: "ezwq2-0"
})(["text-decoration:none;cursor:pointer;color:", ";"], p => p.theme.colors.blue);
/* harmony default export */ const common_Anchor = (Anchor);
// EXTERNAL MODULE: ./src/components/common/Text.jsx
var Text = __webpack_require__(87491);
// EXTERNAL MODULE: ./src/components/measurement/common/ButtonsContainer.jsx
var ButtonsContainer = __webpack_require__(30495);
// EXTERNAL MODULE: ./src/components/measurement/common/DescriptionTextContainer.jsx
var DescriptionTextContainer = __webpack_require__(1069);
// EXTERNAL MODULE: ./src/components/measurement/MeasurementSection.jsx
var MeasurementSection = __webpack_require__(28067);
// EXTERNAL MODULE: ./src/components/measurement/utils/applicationMap.js
var applicationMap = __webpack_require__(40516);
// EXTERNAL MODULE: ./src/contexts/auth.js
var auth = __webpack_require__(58368);
// EXTERNAL MODULE: ./src/contexts/measurements.js + 1 modules
var measurements = __webpack_require__(85238);
// EXTERNAL MODULE: ./src/utils/logger.js + 1 modules
var logger = __webpack_require__(11098);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
;// CONCATENATED MODULE: ./src/components/measurement/sections/offices/HasOffice.jsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
















const HasOffice = ({
  setHasOffice,
  hasOffice,
  sectionDisabled
}) => {
  const {
    user
  } = (0,auth/* default */.Z)();
  const {
    selectedMeasurement,
    setSelectedMeasurement
  } = (0,measurements/* default */.Z)();
  const {
    0: close,
    1: setClose
  } = (0,external_react_.useState)(false);
  const {
    0: loading,
    1: setLoading
  } = (0,external_react_.useState)(false);
  const {
    0: loadingFalse,
    1: setLoadingFalse
  } = (0,external_react_.useState)(false);
  const id = "has_office";

  const updateMeasurementHasOffice = async value => {
    try {
      value ? setLoading(true) : setLoadingFalse(true);
      const {
        data: measurement
      } = await external_axios_default().patch(`/api/organisations/${user.organisation_id}/measurements/${selectedMeasurement.id}`, _objectSpread({
        has_office: value
      }, (0,applicationMap/* shouldUpdateLastCompletedStep */._Z)({
        step: id,
        measurement: selectedMeasurement
      }) ? {
        last_completed_step: id
      } : {}));
      setSelectedMeasurement(measurement);
      setHasOffice(!!measurement.has_office);
      setClose(!close);
    } catch (error) {
      (0,logger/* logError */.H)(error);
    }

    value ? setLoading(false) : setLoadingFalse(false);
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(MeasurementSection/* default */.Z, {
    id: id,
    title: "Do you have an office?",
    value: hasOffice ? "Yes" : "No",
    sectionDisabled: sectionDisabled,
    defaultOpen: selectedMeasurement.has_office === null && !sectionDisabled,
    close: close,
    setClose: setClose,
    required: true,
    children: [/*#__PURE__*/jsx_runtime_.jsx(DescriptionTextContainer/* default */.Z, {
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(Text/* default */.ZP, {
        children: ["If you have multiple offices, please", " ", /*#__PURE__*/jsx_runtime_.jsx(common_Anchor, {
          href: "mailto:team@inhabit.eco",
          children: "contact us."
        })]
      })
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(ButtonsContainer/* OfficeButtonsContainer */.g, {
      children: [/*#__PURE__*/jsx_runtime_.jsx(Button/* default */.ZP, {
        onClick: async () => await updateMeasurementHasOffice(true),
        selected: hasOffice,
        loading: loading,
        disabled: loadingFalse,
        children: "Yes"
      }), /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.ZP, {
        onClick: async () => await updateMeasurementHasOffice(false),
        selected: !hasOffice,
        loading: loadingFalse,
        disabled: loading,
        children: "No"
      })]
    })]
  });
};

/* harmony default export */ const offices_HasOffice = (HasOffice);

/***/ }),

/***/ 76420:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _button_Button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(59067);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(87491);
/* harmony import */ var _common_ButtonsContainer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(30495);
/* harmony import */ var _MeasurementSection__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(28067);
/* harmony import */ var _utils_applicationMap__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(40516);
/* harmony import */ var _contexts_auth__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(58368);
/* harmony import */ var _contexts_measurements__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(85238);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(72994);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(11098);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }












var NotifyIcon = function NotifyIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("path", {
      d: "M10.01 0C15.453-.04 20.053 4.48 20 10.09c-.052 5.348-4.374 9.902-10 9.902-5.648 0-10.05-4.6-10-10.087C.052 4.307 4.655-.043 10.01.001zm0 2.022c-4.322-.01-7.804 3.425-7.974 7.637-.183 4.51 3.372 8.232 7.82 8.303 4.559.075 8.005-3.571 8.116-7.756.114-4.396-3.417-8.183-7.964-8.184h.002z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("path", {
      d: "M11.014 8.49v2.6c0 .594-.451 1.06-1.013 1.053-.574-.009-1.018-.464-1.018-1.055-.002-1.74-.002-3.48 0-5.219 0-.58.446-1.035 1.01-1.04.573-.005 1.021.45 1.022 1.042v2.62zM11.015 14.074c.013.424-.167.747-.532.954-.342.195-.689.17-1.026-.033-.39-.235-.577-.785-.437-1.28a1.018 1.018 0 0 1 .996-.745c.476.012.858.324.977.794.026.104.018.206.022.31z"
    })]
  }));
};

NotifyIcon.defaultProps = {
  width: "20",
  height: "20",
  viewBox: "0 0 20 20",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};





const NoUtilityBillsContainer = styled_components__WEBPACK_IMPORTED_MODULE_11___default().div.withConfig({
  displayName: "HasUtilityBills__NoUtilityBillsContainer",
  componentId: "b46plr-0"
})(["background:", ";", " padding:0.75rem;display:flex;justify-content:flex-start;align-items:center;padding-right:2rem;margin-top:0.5rem;& > svg{fill:", ";margin-right:0.5rem;}"], p => p.theme.colors.backgroundYellow, _styles__WEBPACK_IMPORTED_MODULE_9__/* .borderRadius */ .E, p => p.theme.colors.black);

const HasUtilityBills = ({
  hasUtilityBills,
  setHasUtilityBills,
  sectionDisabled
}) => {
  const {
    user
  } = (0,_contexts_auth__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)();
  const {
    selectedMeasurement,
    setSelectedMeasurement
  } = (0,_contexts_measurements__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
  const {
    0: close,
    1: setClose
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    0: loading,
    1: setLoading
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    0: loadingFalse,
    1: setLoadingFalse
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const id = "has_utility_bills";

  const updateMeasurementUtilityBills = async value => {
    try {
      value ? setLoading(true) : setLoadingFalse(true);
      const {
        data: measurement
      } = await axios__WEBPACK_IMPORTED_MODULE_1___default().patch(`/api/organisations/${user.organisation_id}/measurements/${selectedMeasurement.id}`, _objectSpread({
        has_utility_bills: value
      }, (0,_utils_applicationMap__WEBPACK_IMPORTED_MODULE_12__/* .shouldUpdateLastCompletedStep */ ._Z)({
        step: id,
        measurement: selectedMeasurement
      }) ? {
        last_completed_step: id
      } : {}));
      setSelectedMeasurement(measurement);
      setHasUtilityBills(!!measurement.has_utility_bills);
      setClose(!close);
    } catch (error) {
      (0,_utils_logger__WEBPACK_IMPORTED_MODULE_10__/* .logError */ .H)(error);
    }

    value ? setLoading(false) : setLoadingFalse(false);
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_MeasurementSection__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
    id: id,
    title: "Do you have access to utility bills?",
    value: hasUtilityBills ? "Yes" : "No",
    sectionDisabled: sectionDisabled,
    closedContent: !sectionDisabled && selectedMeasurement.has_utility_bills === false && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(NoUtilityBillsContainer, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(NotifyIcon, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP, {
        size: "subtitleBold",
        align: "left",
        children: "Without utility bills, your calculations will be slightly less accurate but still very much acceptable."
      })]
    }),
    close: close,
    setClose: setClose,
    required: true,
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(_common_ButtonsContainer__WEBPACK_IMPORTED_MODULE_4__/* .OfficeButtonsContainer */ .g, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
        onClick: () => updateMeasurementUtilityBills(true),
        loading: loading,
        disabled: loadingFalse,
        children: "Yes"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
        onClick: () => updateMeasurementUtilityBills(false),
        loading: loadingFalse,
        disabled: loading,
        children: "No"
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HasUtilityBills);

/***/ }),

/***/ 74154:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61908);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(45641);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(87491);
/* harmony import */ var _form_Input__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(18183);
/* harmony import */ var _common_Form__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(79397);
/* harmony import */ var _common_FormGroup__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(13586);
/* harmony import */ var _MeasurementSection__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(28067);
/* harmony import */ var _contexts_auth__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(58368);
/* harmony import */ var _contexts_measurements__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(85238);
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(16170);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(75609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__, react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _form_Input__WEBPACK_IMPORTED_MODULE_4__]);
([_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__, react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _form_Input__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }















const schema = yup__WEBPACK_IMPORTED_MODULE_10__.object().shape({
  name: yup__WEBPACK_IMPORTED_MODULE_10__.string().required(),
  postcode: yup__WEBPACK_IMPORTED_MODULE_10__.string().required().matches(_utils_constants__WEBPACK_IMPORTED_MODULE_12__/* .POSTCODE_REGEX */ .C3, "Please enter a valid postcode"),
  size: yup__WEBPACK_IMPORTED_MODULE_10__.number().transform((currentValue, originalValue) => {
    return originalValue === "" ? null : currentValue;
  }).nullable(true).typeError("Please enter a valid number")
});

const OfficeDetails = ({
  setHasOffice,
  hasUtilityBills,
  sectionDisabled
}) => {
  var _selectedMeasurement$, _selectedMeasurement$2, _organisation$offices, _organisation$offices2, _selectedMeasurement$3, _selectedMeasurement$4, _organisation$offices3, _organisation$offices4, _selectedMeasurement$5, _selectedMeasurement$6, _organisation$offices5, _organisation$offices6;

  const {
    user,
    organisation
  } = (0,_contexts_auth__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
  const {
    selectedMeasurement,
    setSelectedMeasurement,
    updateLastCompletedStep
  } = (0,_contexts_measurements__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)();
  const id = "office_details";
  const methods = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_2__.useForm)({
    resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__.yupResolver)(schema),
    defaultValues: {
      name: ((_selectedMeasurement$ = selectedMeasurement.offices) === null || _selectedMeasurement$ === void 0 ? void 0 : (_selectedMeasurement$2 = _selectedMeasurement$[0]) === null || _selectedMeasurement$2 === void 0 ? void 0 : _selectedMeasurement$2.name) || ((_organisation$offices = organisation.offices) === null || _organisation$offices === void 0 ? void 0 : (_organisation$offices2 = _organisation$offices[0]) === null || _organisation$offices2 === void 0 ? void 0 : _organisation$offices2.name),
      postcode: ((_selectedMeasurement$3 = selectedMeasurement.offices) === null || _selectedMeasurement$3 === void 0 ? void 0 : (_selectedMeasurement$4 = _selectedMeasurement$3[0]) === null || _selectedMeasurement$4 === void 0 ? void 0 : _selectedMeasurement$4.postcode) || ((_organisation$offices3 = organisation.offices) === null || _organisation$offices3 === void 0 ? void 0 : (_organisation$offices4 = _organisation$offices3[0]) === null || _organisation$offices4 === void 0 ? void 0 : _organisation$offices4.postcode),
      size: ((_selectedMeasurement$5 = selectedMeasurement.offices) === null || _selectedMeasurement$5 === void 0 ? void 0 : (_selectedMeasurement$6 = _selectedMeasurement$5[0]) === null || _selectedMeasurement$6 === void 0 ? void 0 : _selectedMeasurement$6.size) || ((_organisation$offices5 = organisation.offices) === null || _organisation$offices5 === void 0 ? void 0 : (_organisation$offices6 = _organisation$offices5[0]) === null || _organisation$offices6 === void 0 ? void 0 : _organisation$offices6.size)
    }
  });

  const upsertOffice = async (values, cb) => {
    const office = selectedMeasurement.offices[0];

    if (!office) {
      var _measurement$offices, _measurement$offices$, _measurement$offices2, _measurement$offices3, _measurement$offices4, _measurement$offices5;

      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_1___default().post(`/api/organisations/${user.organisation_id}/offices`, _objectSpread(_objectSpread({}, values), {}, {
        size: parseInt(values.size)
      }));
      const {
        data: measurement
      } = await axios__WEBPACK_IMPORTED_MODULE_1___default().post(`/api/organisations/${user.organisation_id}/measurements/${selectedMeasurement.id}/offices`, {
        office_id: data.id
      });
      setHasOffice(!!measurement.offices.length);
      methods.reset({
        name: (_measurement$offices = measurement.offices) === null || _measurement$offices === void 0 ? void 0 : (_measurement$offices$ = _measurement$offices[0]) === null || _measurement$offices$ === void 0 ? void 0 : _measurement$offices$.name,
        postcode: (_measurement$offices2 = measurement.offices) === null || _measurement$offices2 === void 0 ? void 0 : (_measurement$offices3 = _measurement$offices2[0]) === null || _measurement$offices3 === void 0 ? void 0 : _measurement$offices3.postcode,
        size: (_measurement$offices4 = measurement.offices) === null || _measurement$offices4 === void 0 ? void 0 : (_measurement$offices5 = _measurement$offices4[0]) === null || _measurement$offices5 === void 0 ? void 0 : _measurement$offices5.size
      });
    } else {
      var _measurement$offices6, _measurement$offices7, _measurement$offices8, _measurement$offices9, _measurement$offices10, _measurement$offices11;

      const {
        data: measurement
      } = await axios__WEBPACK_IMPORTED_MODULE_1___default().patch(`/api/organisations/${user.organisation_id}/offices/${office.id}`, _objectSpread(_objectSpread({}, values), {}, {
        size: parseInt(values.size)
      }));
      methods.reset({
        name: (_measurement$offices6 = measurement.offices) === null || _measurement$offices6 === void 0 ? void 0 : (_measurement$offices7 = _measurement$offices6[0]) === null || _measurement$offices7 === void 0 ? void 0 : _measurement$offices7.name,
        postcode: (_measurement$offices8 = measurement.offices) === null || _measurement$offices8 === void 0 ? void 0 : (_measurement$offices9 = _measurement$offices8[0]) === null || _measurement$offices9 === void 0 ? void 0 : _measurement$offices9.postcode,
        size: (_measurement$offices10 = measurement.offices) === null || _measurement$offices10 === void 0 ? void 0 : (_measurement$offices11 = _measurement$offices10[0]) === null || _measurement$offices11 === void 0 ? void 0 : _measurement$offices11.size
      });
    }

    await updateLastCompletedStep(id);
    cb();
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_MeasurementSection__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
    id: id,
    title: "Office Details",
    value: selectedMeasurement.offices[0] ? `${selectedMeasurement.offices[0].size} m²` : "",
    sectionDisabled: sectionDisabled,
    onNextClick: methods.handleSubmit(upsertOffice),
    required: true,
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_common_Form__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
      onSubmit: methods.handleSubmit(upsertOffice),
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.FormProvider, _objectSpread(_objectSpread({}, methods), {}, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_form_Input__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
          id: "name",
          name: "name",
          testId: "name",
          width: "30%",
          placeholder: "Office Name",
          isRequired: true
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_form_Input__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
          id: "postcode",
          name: "postcode",
          testId: "postcode",
          width: "30%",
          placeholder: "Office Postcode",
          isRequired: true
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_common_FormGroup__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_form_Input__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
            id: "size",
            name: "size",
            testId: "size",
            width: "30%",
            placeholder: "Size in m\xB2(optional)",
            type: "number"
          }), " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx("div", {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP, {
              children: "m\xB2"
            })
          })]
        })]
      }))
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (OfficeDetails);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 23603:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61908);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(45641);
/* harmony import */ var _common_Divider__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6459);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(87491);
/* harmony import */ var _form_Input__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(18183);
/* harmony import */ var _form_InputDropdown__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(51894);
/* harmony import */ var _common_DescriptionTextContainer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1069);
/* harmony import */ var _common_Form__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(79397);
/* harmony import */ var _common_FormGroup__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(13586);
/* harmony import */ var _MeasurementSection__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(28067);
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(19390);
/* harmony import */ var _contexts_auth__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(58368);
/* harmony import */ var _contexts_measurements__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(85238);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(75609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__, react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _form_Input__WEBPACK_IMPORTED_MODULE_5__, _form_InputDropdown__WEBPACK_IMPORTED_MODULE_6__]);
([_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__, react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _form_Input__WEBPACK_IMPORTED_MODULE_5__, _form_InputDropdown__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



















const schema = yup__WEBPACK_IMPORTED_MODULE_14__.object().shape({
  landfill_period: yup__WEBPACK_IMPORTED_MODULE_14__.object().shape({
    label: yup__WEBPACK_IMPORTED_MODULE_14__.string(),
    value: yup__WEBPACK_IMPORTED_MODULE_14__.string()
  }).required("Please select a time frame").typeError("Please select a time frame"),
  landfill_amount: yup__WEBPACK_IMPORTED_MODULE_14__.number().required().typeError("Please enter a valid number"),
  recycling_period: yup__WEBPACK_IMPORTED_MODULE_14__.object().shape({
    label: yup__WEBPACK_IMPORTED_MODULE_14__.string(),
    value: yup__WEBPACK_IMPORTED_MODULE_14__.string()
  }).required("Please select a time frame").typeError("Please select a time frame"),
  recycling_amount: yup__WEBPACK_IMPORTED_MODULE_14__.number().required().typeError("Please enter a valid number")
});
const wasteMetrics = [{
  label: "kg",
  value: "kg"
}, {
  label: "Bin Bags",
  value: "bin_bags"
}];

const Waste = ({
  sectionDisabled,
  hasUtilityBills
}) => {
  var _selectedMeasurement$, _selectedMeasurement$3, _wasteMetrics$find, _WASTE_PERIODS$find, _WASTE_PERIODS$find$l, _wasteMetrics$find2, _WASTE_PERIODS$find2, _WASTE_PERIODS$find2$;

  const {
    user
  } = (0,_contexts_auth__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z)();
  const {
    selectedMeasurement,
    setSelectedMeasurement,
    updateLastCompletedStep
  } = (0,_contexts_measurements__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z)();
  const id = "waste";
  const currentWaterUtility = selectedMeasurement.utilities.find(utility => utility.type === "water");
  const methods = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_2__.useForm)({
    resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__.yupResolver)(schema),
    defaultValues: {
      landfill_amount: (_selectedMeasurement$ = selectedMeasurement.waste.find(waste => waste.type === "landfill")) === null || _selectedMeasurement$ === void 0 ? void 0 : _selectedMeasurement$.amount,
      landfill_period: _utils_constants__WEBPACK_IMPORTED_MODULE_11__/* .WASTE_PERIODS.find */ .j3.find(period => {
        var _selectedMeasurement$2;

        return period.value === ((_selectedMeasurement$2 = selectedMeasurement.waste.find(waste => waste.type === "landfill")) === null || _selectedMeasurement$2 === void 0 ? void 0 : _selectedMeasurement$2.period);
      }),
      recycling_amount: (_selectedMeasurement$3 = selectedMeasurement.waste.find(waste => waste.type === "recycling")) === null || _selectedMeasurement$3 === void 0 ? void 0 : _selectedMeasurement$3.amount,
      recycling_period: _utils_constants__WEBPACK_IMPORTED_MODULE_11__/* .WASTE_PERIODS.find */ .j3.find(period => {
        var _selectedMeasurement$4;

        return period.value === ((_selectedMeasurement$4 = selectedMeasurement.waste.find(waste => waste.type === "recycling")) === null || _selectedMeasurement$4 === void 0 ? void 0 : _selectedMeasurement$4.period);
      })
    }
  });

  const updateMeasurementWaste = async (values, cb) => {
    try {
      const {
        landfill_metric,
        landfill_amount,
        landfill_period,
        recycling_metric,
        recycling_amount,
        recycling_period
      } = values;
      const landfill = selectedMeasurement.waste.find(waste => waste.type === "landfill");

      if (!landfill) {
        await axios__WEBPACK_IMPORTED_MODULE_1___default().post(`/api/organisations/${user.organisation_id}/measurements/${selectedMeasurement.id}/waste`, {
          type: "landfill",
          period: landfill_period.value,
          office_id: selectedMeasurement.offices[0].id,
          metric: landfill_metric.value,
          amount: parseInt(landfill_amount)
        });
      } else {
        await axios__WEBPACK_IMPORTED_MODULE_1___default().patch(`/api/organisations/${user.organisation_id}/measurements/${selectedMeasurement.id}/waste/${landfill.id}`, {
          period: landfill_period.value,
          metric: landfill_metric.value,
          amount: parseInt(landfill_amount)
        });
      }

      const recycling = selectedMeasurement.waste.find(waste => waste.type === "recycling");

      if (!recycling) {
        await axios__WEBPACK_IMPORTED_MODULE_1___default().post(`/api/organisations/${user.organisation_id}/measurements/${selectedMeasurement.id}/waste`, {
          type: "recycling",
          period: recycling_period.value,
          office_id: selectedMeasurement.offices[0].id,
          metric: recycling_metric.value,
          amount: parseInt(recycling_amount)
        });
      } else {
        await axios__WEBPACK_IMPORTED_MODULE_1___default().patch(`/api/organisations/${user.organisation_id}/measurements/${selectedMeasurement.id}/waste/${recycling.id}`, {
          period: recycling_period.value,
          metric: recycling_metric.value,
          amount: parseInt(recycling_amount)
        });
      }

      await updateLastCompletedStep(id);
      cb();
    } catch (error) {
      throw error;
    }
  };

  const landfillWaste = selectedMeasurement.waste.find(waste => waste.type === "landfill");
  const recyclingWaste = selectedMeasurement.waste.find(waste => waste.type === "recycling");
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_MeasurementSection__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
    id: id,
    title: "Waste",
    onNextClick: methods.handleSubmit(updateMeasurementWaste),
    sectionDisabled: sectionDisabled,
    value: !!selectedMeasurement.waste.length && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.Fragment, {
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxs)(_common_Text__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP, {
        size: "subtitle",
        color: "blue",
        children: ["Landfill: ", landfillWaste === null || landfillWaste === void 0 ? void 0 : landfillWaste.amount, " ", (_wasteMetrics$find = wasteMetrics.find(metric => metric.value === (landfillWaste === null || landfillWaste === void 0 ? void 0 : landfillWaste.metric))) === null || _wasteMetrics$find === void 0 ? void 0 : _wasteMetrics$find.label, " ", (_WASTE_PERIODS$find = _utils_constants__WEBPACK_IMPORTED_MODULE_11__/* .WASTE_PERIODS.find */ .j3.find(period => period.value === (landfillWaste === null || landfillWaste === void 0 ? void 0 : landfillWaste.period))) === null || _WASTE_PERIODS$find === void 0 ? void 0 : (_WASTE_PERIODS$find$l = _WASTE_PERIODS$find.label) === null || _WASTE_PERIODS$find$l === void 0 ? void 0 : _WASTE_PERIODS$find$l.toLowerCase()]
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx("br", {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxs)(_common_Text__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP, {
        size: "subtitle",
        color: "blue",
        children: ["Recycling: ", recyclingWaste === null || recyclingWaste === void 0 ? void 0 : recyclingWaste.amount, " ", (_wasteMetrics$find2 = wasteMetrics.find(metric => metric.value === (recyclingWaste === null || recyclingWaste === void 0 ? void 0 : recyclingWaste.metric))) === null || _wasteMetrics$find2 === void 0 ? void 0 : _wasteMetrics$find2.label, " ", (_WASTE_PERIODS$find2 = _utils_constants__WEBPACK_IMPORTED_MODULE_11__/* .WASTE_PERIODS.find */ .j3.find(period => period.value === (recyclingWaste === null || recyclingWaste === void 0 ? void 0 : recyclingWaste.period))) === null || _WASTE_PERIODS$find2 === void 0 ? void 0 : (_WASTE_PERIODS$find2$ = _WASTE_PERIODS$find2.label) === null || _WASTE_PERIODS$find2$ === void 0 ? void 0 : _WASTE_PERIODS$find2$.toLowerCase()]
      })]
    }),
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_common_Form__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
      onSubmit: methods.handleSubmit(updateMeasurementWaste),
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxs)(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.FormProvider, _objectSpread(_objectSpread({}, methods), {}, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_common_DescriptionTextContainer__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP, {
            children: "Estimations for waste are acceptable if no waste management report is available. E.g 2 bin bags / week"
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_common_DescriptionTextContainer__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP, {
            size: "cardTitle",
            children: "Landfill"
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_form_InputDropdown__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
          id: "landfill_period",
          hasDefaultValue: false,
          width: "50%",
          placeholder: "Please select time period...",
          optionArray: _utils_constants__WEBPACK_IMPORTED_MODULE_11__/* .WASTE_PERIODS */ .j3
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxs)(_common_FormGroup__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
          align: "flex-start",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_form_InputDropdown__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
            id: "landfill_metric",
            width: "18.5%",
            placeholder: "Select metric...",
            optionArray: wasteMetrics,
            defaultValue: wasteMetrics.find(metric => metric.value === (landfillWaste === null || landfillWaste === void 0 ? void 0 : landfillWaste.metric))
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_form_Input__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
            id: "landfill_amount",
            name: "landfill_amount",
            testId: "landfill_amount",
            width: "30%",
            placeholder: "Enter Value",
            type: "number",
            isRequired: true
          })]
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_common_Divider__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
          margin: "0.5rem 0 2rem",
          width: "50%"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_common_DescriptionTextContainer__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP, {
            size: "cardTitle",
            children: "Recycling"
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_form_InputDropdown__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
          id: "recycling_period",
          width: "50%",
          hasDefaultValue: false,
          placeholder: "Please select timeframe...",
          optionArray: _utils_constants__WEBPACK_IMPORTED_MODULE_11__/* .WASTE_PERIODS */ .j3
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxs)(_common_FormGroup__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
          align: "flex-start",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_form_InputDropdown__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
            id: "recycling_metric",
            width: "18.5%",
            placeholder: "Select metric...",
            optionArray: wasteMetrics,
            defaultValue: wasteMetrics.find(metric => metric.value === (recyclingWaste === null || recyclingWaste === void 0 ? void 0 : recyclingWaste.metric))
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_form_Input__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
            id: "recycling_amount",
            name: "recycling_amount",
            testId: "recycling_amount",
            width: "30%",
            placeholder: "Enter Value",
            type: "number",
            isRequired: true
          })]
        })]
      }))
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Waste);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 59502:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61908);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(45641);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(87491);
/* harmony import */ var _form_Input__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(18183);
/* harmony import */ var _form_InputDropdown__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(51894);
/* harmony import */ var _common_DescriptionTextContainer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1069);
/* harmony import */ var _common_Form__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(79397);
/* harmony import */ var _common_FormGroup__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(13586);
/* harmony import */ var _MeasurementSection__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(28067);
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(19390);
/* harmony import */ var _contexts_auth__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(58368);
/* harmony import */ var _contexts_measurements__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(85238);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(75609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__, react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _form_Input__WEBPACK_IMPORTED_MODULE_4__, _form_InputDropdown__WEBPACK_IMPORTED_MODULE_5__]);
([_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__, react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _form_Input__WEBPACK_IMPORTED_MODULE_4__, _form_InputDropdown__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

















const schema = yup__WEBPACK_IMPORTED_MODULE_13__.object().shape({
  usage: yup__WEBPACK_IMPORTED_MODULE_13__.number().required().typeError("Please enter a valid number"),
  period: yup__WEBPACK_IMPORTED_MODULE_13__.object().shape({
    label: yup__WEBPACK_IMPORTED_MODULE_13__.string(),
    value: yup__WEBPACK_IMPORTED_MODULE_13__.string()
  }).required("Please select a time frame").typeError("Please select a time frame")
});
const METRICS_ARRAY = [{
  label: "m3",
  value: "m3"
}, {
  label: "GBP",
  value: "gbp"
}];

const WaterUtility = ({
  sectionDisabled
}) => {
  var _METRICS_ARRAY$find;

  const {
    user
  } = (0,_contexts_auth__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z)();
  const {
    selectedMeasurement,
    updateLastCompletedStep
  } = (0,_contexts_measurements__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z)();
  const id = "water";
  const currentElectricityUtility = selectedMeasurement.utilities.find(utility => utility.type === "electricity");
  const currentWaterUtility = selectedMeasurement.utilities.find(utility => utility.type === "water");
  const methods = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_2__.useForm)({
    resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__.yupResolver)(schema),
    defaultValues: {
      usage: currentWaterUtility === null || currentWaterUtility === void 0 ? void 0 : currentWaterUtility.usage,
      metric: METRICS_ARRAY.find(metric => (currentWaterUtility === null || currentWaterUtility === void 0 ? void 0 : currentWaterUtility.metric) === metric.value),
      period: _utils_constants__WEBPACK_IMPORTED_MODULE_10__/* .PERIODS.find */ .z5.find(period => period.value === (currentWaterUtility === null || currentWaterUtility === void 0 ? void 0 : currentWaterUtility.period))
    }
  });

  const updateMeasurementWater = async ({
    period,
    metric,
    usage
  }, cb) => {
    try {
      const utility = currentWaterUtility;

      if (!utility) {
        await axios__WEBPACK_IMPORTED_MODULE_1___default().post(`/api/organisations/${user.organisation_id}/measurements/${selectedMeasurement.id}/utilities`, {
          type: "water",
          period: period.value,
          metric: metric.value,
          office_id: selectedMeasurement.offices[0].id,
          usage: parseInt(usage)
        });
      } else {
        await axios__WEBPACK_IMPORTED_MODULE_1___default().patch(`/api/organisations/${user.organisation_id}/measurements/${selectedMeasurement.id}/utilities/${utility.id}`, {
          period: period.value,
          metric: metric.value,
          usage: parseInt(usage)
        });
      }

      await updateLastCompletedStep(id);
      cb();
    } catch (error) {
      throw error;
    }
  };

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(_MeasurementSection__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
    id: id,
    title: "Water",
    onNextClick: methods.handleSubmit(updateMeasurementWater),
    sectionDisabled: sectionDisabled,
    value: selectedMeasurement.utilities && currentWaterUtility && `${currentWaterUtility === null || currentWaterUtility === void 0 ? void 0 : currentWaterUtility.usage} ${(_METRICS_ARRAY$find = METRICS_ARRAY.find(metric => (currentWaterUtility === null || currentWaterUtility === void 0 ? void 0 : currentWaterUtility.metric) === metric.value)) === null || _METRICS_ARRAY$find === void 0 ? void 0 : _METRICS_ARRAY$find.label} ${_utils_constants__WEBPACK_IMPORTED_MODULE_10__/* .PERIODS.find */ .z5.find(period => period.value === currentWaterUtility.period).label}`,
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_common_DescriptionTextContainer__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP, {
        children: "What was your water usage for the period?"
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_common_Form__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
      onSubmit: methods.handleSubmit(updateMeasurementWater),
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.FormProvider, _objectSpread(_objectSpread({}, methods), {}, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_form_InputDropdown__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
          id: "period",
          width: "50%",
          placeholder: "Please select timeframe...",
          optionArray: _utils_constants__WEBPACK_IMPORTED_MODULE_10__/* .PERIODS */ .z5,
          hasDefaultValue: false
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(_common_FormGroup__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
          align: "flex-start",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_form_InputDropdown__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
            id: "metric",
            width: "18.5%",
            placeholder: "Select metric...",
            optionArray: METRICS_ARRAY
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_form_Input__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
            id: "usage",
            name: "usage",
            testId: "usage",
            width: "30%",
            placeholder: "Enter Value",
            type: "number",
            isRequired: true
          })]
        })]
      }))
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WaterUtility);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;