"use strict";
exports.id = 2774;
exports.ids = [2774];
exports.modules = {

/***/ 82774:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61908);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(45641);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(87491);
/* harmony import */ var _form_Input__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(18183);
/* harmony import */ var _form_InputDropdown__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(51894);
/* harmony import */ var _common_DescriptionTextContainer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1069);
/* harmony import */ var _common_Form__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(79397);
/* harmony import */ var _common_FormGroup__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(13586);
/* harmony import */ var _MeasurementSection__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(28067);
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(19390);
/* harmony import */ var _contexts_auth__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(58368);
/* harmony import */ var _contexts_measurements__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(85238);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(75609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__, react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _form_Input__WEBPACK_IMPORTED_MODULE_4__, _form_InputDropdown__WEBPACK_IMPORTED_MODULE_5__]);
([_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__, react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _form_Input__WEBPACK_IMPORTED_MODULE_4__, _form_InputDropdown__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

















const schema = yup__WEBPACK_IMPORTED_MODULE_13__.object().shape({
  amount: yup__WEBPACK_IMPORTED_MODULE_13__.number().required().typeError("Please enter a valid number"),
  period: yup__WEBPACK_IMPORTED_MODULE_13__.object().shape({
    label: yup__WEBPACK_IMPORTED_MODULE_13__.string(),
    value: yup__WEBPACK_IMPORTED_MODULE_13__.string()
  }).required("Please select a time frame").typeError("Please select a time frame")
});

const Expenses = ({
  sectionDisabled,
  review
}) => {
  var _selectedMeasurement$, _selectedMeasurement$3, _selectedMeasurement$4, _PERIODS$find;

  const {
    user
  } = (0,_contexts_auth__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z)();
  const {
    selectedMeasurement,
    updateLastCompletedStep
  } = (0,_contexts_measurements__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z)();
  const id = "expenses";
  const methods = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_2__.useForm)({
    resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_0__.yupResolver)(schema),
    defaultValues: {
      amount: (_selectedMeasurement$ = selectedMeasurement.expenses) === null || _selectedMeasurement$ === void 0 ? void 0 : _selectedMeasurement$.amount,
      period: _utils_constants__WEBPACK_IMPORTED_MODULE_10__/* .PERIODS.find */ .z5.find(period => {
        var _selectedMeasurement$2;

        return period.value === ((_selectedMeasurement$2 = selectedMeasurement.expenses) === null || _selectedMeasurement$2 === void 0 ? void 0 : _selectedMeasurement$2.period);
      })
    }
  });

  const updateMeasurementExpenses = async ({
    period,
    amount
  }, cb) => {
    try {
      if (amount) {
        await axios__WEBPACK_IMPORTED_MODULE_1___default().post(`/api/organisations/${user.organisation_id}/measurements/${selectedMeasurement.id}/expenses?`, {
          period: period.value,
          amount: parseInt(amount)
        });
        await updateLastCompletedStep(id);
      }

      cb();
    } catch (error) {
      throw error;
    }
  };

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(_MeasurementSection__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
    id: id,
    title: "Total Expenses on products and services",
    onNextClick: methods.handleSubmit(updateMeasurementExpenses),
    sectionDisabled: sectionDisabled,
    value: ((_selectedMeasurement$3 = selectedMeasurement.expenses) === null || _selectedMeasurement$3 === void 0 ? void 0 : _selectedMeasurement$3.amount) && `£${(_selectedMeasurement$4 = selectedMeasurement.expenses) === null || _selectedMeasurement$4 === void 0 ? void 0 : _selectedMeasurement$4.amount} ${(_PERIODS$find = _utils_constants__WEBPACK_IMPORTED_MODULE_10__/* .PERIODS.find */ .z5.find(period => {
      var _selectedMeasurement$5;

      return period.value === ((_selectedMeasurement$5 = selectedMeasurement.expenses) === null || _selectedMeasurement$5 === void 0 ? void 0 : _selectedMeasurement$5.period);
    })) === null || _PERIODS$find === void 0 ? void 0 : _PERIODS$find.label}`,
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_common_DescriptionTextContainer__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP, {
        children: "This is the total spend on operational products and services; server costs, cloud hosting, paid services, marketing etc."
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_common_Form__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
      onSubmit: methods.handleSubmit(updateMeasurementExpenses),
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.FormProvider, _objectSpread(_objectSpread({}, methods), {}, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_form_InputDropdown__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
          id: "period",
          width: "50%",
          placeholder: "Please select timeframe...",
          optionArray: _utils_constants__WEBPACK_IMPORTED_MODULE_10__/* .PERIODS */ .z5,
          hasDefaultValue: false
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(_common_FormGroup__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
          align: "flex-start",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_form_InputDropdown__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
            id: "metric",
            width: "18.5%",
            placeholder: "Select metric...",
            optionArray: [{
              label: "£ (GBP)",
              value: "gbp"
            }]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_form_Input__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
            id: "amount",
            name: "amount",
            testId: "amount",
            width: "30%",
            placeholder: "Enter Value",
            type: "number",
            isRequired: true
          })]
        })]
      }))
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Expenses);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;