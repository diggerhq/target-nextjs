"use strict";
exports.id = 9067;
exports.ids = [9067];
exports.modules = {

/***/ 59067:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "iq": () => (/* binding */ commonStyles),
/* harmony export */   "BC": () => (/* binding */ smallStyles),
/* harmony export */   "$Y": () => (/* binding */ buttonStyles),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(41664);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _common_Spinner__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16114);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);
const _excluded = ["href", "as", "external"],
      _excluded2 = ["disabled", "loading", "href"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }









const createColor = ({
  secondary,
  color,
  small,
  theme
}) => theme.colors[color] || secondary || small ? theme.colors.blue : theme.colors.white;

const commonStyles = (0,styled_components__WEBPACK_IMPORTED_MODULE_4__.css)(["cursor:", ";padding:", ";", " max-height:", ";font-weight:", ";color:", ";text-decoration:none;margin:0;font-size:", ";border-width:", ";border-style:solid;box-sizing:unset;display:inline-block;min-width:", ";", ";text-align:center;border-radius:4px;transition:box-shadow 0.3s,transform 0.3s,background-color 0.3s,font-weight 0.3s,color 0.3s,opacity 0.3s;background-color:", ";border-color:", ";&:visited{color:", ";}&:focus{outline:none;}&:hover{opacity:0.8;}&:active{transform:translateY(1px);transition:transform 0.1s;}", ";& > a{text-decoration:inherit;font-weight:inherit;color:inherit;font-size:inherit;}"], p => !p.disabled && (p.cursor ? p.cursor : "pointer"), p => p.fullWidth ? "0.5rem 0rem" : p.padding ? p.padding : "0.5rem 0.5rem", p => p.fullWidth ? "width: 100%;" : "max-width: 14.5rem;", p => p.maxHeight || "2rem", p => p.theme.button.fontWeight, createColor, p => p.theme.button.size, p => p.borderWidth ? p.borderWidth : "0.03125rem", p => p.minWidth || "8.625rem", p => p.maxWidth && (0,styled_components__WEBPACK_IMPORTED_MODULE_4__.css)(["max-width:", ";"], p.maxWidth), p => p.backgroundColor ? p.theme.colors[p.backgroundColor] : p.theme.colors.blue, p => p.borderColor ? p.theme.colors[p.borderColor] : p.theme.colors.blue, p => p.theme.colors.white, _theme__WEBPACK_IMPORTED_MODULE_3__/* .media.tablet */ .BC.tablet`
    padding: ${p => p.width ? "0.5rem 0" : p.padding ? p.padding : "0.5rem 0"};
    ${p => p.fullWidth ? "width: unset;" : "max-width: 14.5rem;"}
      min-width: ${p => p.width || p.minWidth || "8.625rem"};
      width: ${p => p.width || p.minWidth || "8.625rem"};
    ${p => p.maxWidth && (0,styled_components__WEBPACK_IMPORTED_MODULE_4__.css)(["max-width:", ";"], p.maxWidth)};
  `);
const secondaryStyles = (0,styled_components__WEBPACK_IMPORTED_MODULE_4__.css)(["background-color:", ";border-color:", ";box-shadow:unset;&:hover{background-color:", ";}"], p => p.backgroundColor ? p.theme.colors[p.backgroundColor] : p.theme.colors.transparent, p => p.borderColor ? p.theme.colors[p.borderColor] : "#2e68f140", p => p.theme.colors.secondaryBlue);
const warningStyles = (0,styled_components__WEBPACK_IMPORTED_MODULE_4__.css)(["background-color:", ";color:", ";border-color:", ";&:hover{", "}"], p => p.backgroundColor ? p.theme.colors[p.backgroundColor] : p.secondary ? p.theme.colors.transparent : p.theme.colors.warning, p => p.color ? p.theme.colors[p.color] : p.secondary ? p.theme.colors.warning : p.theme.colors.white, p => p.borderColor ? p.theme.colors[p.borderColor] : `${p.theme.colors.warning}40`, p => !p.loading ? (0,styled_components__WEBPACK_IMPORTED_MODULE_4__.css)(["background-color:", ";color:", ";"], p => p.theme.colors.warning, p => p.color ? p.theme.colors[p.color] : p.theme.colors.white) : (0,styled_components__WEBPACK_IMPORTED_MODULE_4__.css)(["background-color:", ";"], p => p.theme.colors.transparent));
const smallStyles = (0,styled_components__WEBPACK_IMPORTED_MODULE_4__.css)(["background-color:", ";border-color:", ";padding:0;border-radius:15px;min-width:", ";color:", ";box-shadow:unset;border-width:", ";border-style:solid;&:hover{", "}", ";"], p => p.backgroundColor ? p.theme.colors[p.backgroundColor] : p.theme.colors.transparent, p => p.borderColor ? p.theme.colors[p.borderColor] : p.warning ? p.theme.colors.warning : p.theme.colors.blue, p => p.minWidth || "6.2rem", p => p.color ? createColor(p) : p.warning ? p.theme.colors.warning : p.theme.colors.blue, p => p.borderWidth ? p.borderWidth : "1px", p => !p.loading && (0,styled_components__WEBPACK_IMPORTED_MODULE_4__.css)(["background-color:", ";color:", ";"], p => p.warning ? p.theme.colors.warning : p.theme.colors.blue, p => p.theme.colors.white), _theme__WEBPACK_IMPORTED_MODULE_3__/* .media.tablet */ .BC.tablet`
      padding: 0;
  `);
const disabledStyles = (0,styled_components__WEBPACK_IMPORTED_MODULE_4__.css)(["padding:", ";color:", ";box-shadow:none;", " &:hover{transform:none;font-weight:", ";opacity:1;background:", ";color:", ";}", ";"], p => p.fullWidth ? "0.25rem 0rem" : p.padding ? p.padding : "0.5rem 0.5rem", p => p.theme.colors.placeholderGrey, p => !p.loading && (0,styled_components__WEBPACK_IMPORTED_MODULE_4__.css)(["background:", ";border-color:", ";"], p => p.theme.colors.white, p => p.borderColor ? p.theme.colors[p.borderColor] : p.theme.colors.placeholderGrey), p => p.theme.button.fontWeight, p => p.theme.colors.white, p => p.theme.colors.placeholderGrey, _theme__WEBPACK_IMPORTED_MODULE_3__/* .media.tablet */ .BC.tablet`
    padding: ${p => p.width ? "0.5rem 0" : p.padding ? p.padding : "0.5rem 0rem"};
    ${p => p.fullWidth ? "width: unset;" : "max-width: 14.5rem;"}
    ${p => p.width && `width: ${p.width};`}
    ${p => p.maxWidth && (0,styled_components__WEBPACK_IMPORTED_MODULE_4__.css)(["max-width:", ";"], p.maxWidth)};
  `);
const loadingStyles = (0,styled_components__WEBPACK_IMPORTED_MODULE_4__.css)(["padding:", ";", ";"], p => p.fullWidth ? "0.5rem 0rem" : p.padding ? p.padding : "0.5rem 0rem", _theme__WEBPACK_IMPORTED_MODULE_3__/* .media.tablet */ .BC.tablet`
    padding: ${p => p.small ? "0" : p.width ? "0.37rem 0" : p.padding ? p.padding : "0.37rem 0rem"};

  `);
const buttonStyles = (0,styled_components__WEBPACK_IMPORTED_MODULE_4__.css)(["", " ", " ", " ", " ", " ", ""], commonStyles, p => p.secondary && secondaryStyles, p => p.warning && warningStyles, p => p.small && smallStyles, p => p.disabled && !p.loading && disabledStyles, p => p.loading && loadingStyles);
const ActionButton = styled_components__WEBPACK_IMPORTED_MODULE_4___default().button.withConfig({
  displayName: "Button__ActionButton",
  componentId: "xnb1y6-0"
})(["", ""], buttonStyles);
const LinkButton = styled_components__WEBPACK_IMPORTED_MODULE_4___default().a.withConfig({
  displayName: "Button__LinkButton",
  componentId: "xnb1y6-1"
})(["", ""], buttonStyles);
const SpinnerContainer = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
  displayName: "Button__SpinnerContainer",
  componentId: "xnb1y6-2"
})(["display:flex;justify-content:center;align-items:center;width:fit-content;margin:1px auto;& > svg{", " ", " ", " ", "}& > ", "{", "}"], p => (p.secondary || p.small) && `stroke: ${p.theme.colors.blue};`, p => p.warning && `stroke: ${p.theme.colors.white};`, p => p.warning && p.secondary && `stroke: ${p.theme.colors.warning}40;`, p => p.small && "width: 1.25rem;", _common_Spinner__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, _theme__WEBPACK_IMPORTED_MODULE_3__/* .media.tablet */ .BC.tablet`
    margin: 0 auto;
  `);

const StyledButton = _ref => {
  let {
    href,
    as,
    external
  } = _ref,
      rest = _objectWithoutProperties(_ref, _excluded);

  return href && !rest.disabled ? !external ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(next_link__WEBPACK_IMPORTED_MODULE_0__["default"], {
    href: href,
    as: as,
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(LinkButton, _objectSpread({}, rest))
  }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(LinkButton, _objectSpread({
    href: href
  }, rest)) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(ActionButton, _objectSpread({}, rest));
};

class Button extends react__WEBPACK_IMPORTED_MODULE_1__.Component {
  render() {
    const _this$props = this.props,
          {
      disabled,
      loading,
      href
    } = _this$props,
          props = _objectWithoutProperties(_this$props, _excluded2);

    return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(StyledButton, _objectSpread(_objectSpread({
      disabled: disabled || loading,
      loading: loading,
      href: href
    }, props), {}, {
      children: [!loading && this.props.children, loading && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(SpinnerContainer, _objectSpread(_objectSpread({
        fullWidth: props.fullWidth
      }, props), {}, {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_common_Spinner__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
          width: "1rem"
        })
      }))]
    }));
  }

}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Button);

/***/ })

};
;