"use strict";
exports.id = 6067;
exports.ids = [6067];
exports.modules = {

/***/ 16067:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ContentContainer)
/* harmony export */ });
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16666);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_responsive__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _button_Button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(59067);
/* harmony import */ var _common_Text__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(87491);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__);









const Container = styled_components__WEBPACK_IMPORTED_MODULE_5___default().div.withConfig({
  displayName: "ContentContainer__Container",
  componentId: "bo1q2p-0"
})(["padding:0 1.25rem 3rem;position:relative;background-color:", ";border-radius:5px;min-height:97vh;", " ", " ", " ", " ", " ", ""], p => p.theme.colors.backgroundGrey, p => p.limit && (0,styled_components__WEBPACK_IMPORTED_MODULE_5__.css)(["max-height:90vh;overflow-y:scroll;"]), _theme__WEBPACK_IMPORTED_MODULE_4__/* .media.tablet */ .BC.tablet`
    padding: 1.25rem;
    ${p => p.limitWidth && (0,styled_components__WEBPACK_IMPORTED_MODULE_5__.css)(["overflow:hidden;max-width:86vw;"])}
    ${p => p.limit && (0,styled_components__WEBPACK_IMPORTED_MODULE_5__.css)(["max-height:88.5vh;overflow:hidden;"])}
    `, _theme__WEBPACK_IMPORTED_MODULE_4__/* .media.tabletLarge */ .BC.tabletLarge`
    padding: ${p => p.padding || "1.25rem 2rem"};
    ${p => p.limit && (0,styled_components__WEBPACK_IMPORTED_MODULE_5__.css)(["max-height:100vh;overflow:hidden;"])}   
  `, _theme__WEBPACK_IMPORTED_MODULE_4__/* .media.desktop */ .BC.desktop`
        max-width: 89vw;
    `, _theme__WEBPACK_IMPORTED_MODULE_4__/* .media.desktopLarge */ .BC.desktopLarge`
        padding: ${p => p.padding || "2.5rem 3rem"};
    `, _theme__WEBPACK_IMPORTED_MODULE_4__/* .media.wideScreen */ .BC.wideScreen`
        max-width: 92vw;
    `);
const TitleContainer = styled_components__WEBPACK_IMPORTED_MODULE_5___default().div.withConfig({
  displayName: "ContentContainer__TitleContainer",
  componentId: "bo1q2p-1"
})(["position:relative;", ""], _theme__WEBPACK_IMPORTED_MODULE_4__/* .media.tabletLarge */ .BC.tabletLarge`
    margin-bottom: 0.5rem;
    display:  flex;
    align-items: center;
    justify-content: ${p => !p.description ? "flex-end" : "space-between"};
     ${p => (p.description || p.hasCTAs) && "margin-bottom: 0"};
        ${p => !p.description && !p.hasCTAs && "margin-bottom: 0"};
  `);
const TextContainer = styled_components__WEBPACK_IMPORTED_MODULE_5___default().div.withConfig({
  displayName: "ContentContainer__TextContainer",
  componentId: "bo1q2p-2"
})(["", ""], _theme__WEBPACK_IMPORTED_MODULE_4__/* .media.tablet */ .BC.tablet`
    margin-bottom: 0.625rem;
    line-height: normal;
  `);
const UserActionsContainer = styled_components__WEBPACK_IMPORTED_MODULE_5___default().div.withConfig({
  displayName: "ContentContainer__UserActionsContainer",
  componentId: "bo1q2p-3"
})(["display:none;justify-content:flex-end;", ""], _theme__WEBPACK_IMPORTED_MODULE_4__/* .media.tabletLarge */ .BC.tabletLarge`
    display: flex;
    align-items: center;
  `);
const TitleTextContainer = styled_components__WEBPACK_IMPORTED_MODULE_5___default()(TextContainer).withConfig({
  displayName: "ContentContainer__TitleTextContainer",
  componentId: "bo1q2p-4"
})(["justify-content:space-between;display:flex;", ";", ""], p => p.description || !p.cta ? "margin-bottom: 0.5rem" : "margin-bottom: 0", _theme__WEBPACK_IMPORTED_MODULE_4__/* .media.tabletLarge */ .BC.tabletLarge`
    ${p => p.description ? "margin-bottom: 0.25rem" : "margin-bottom: 0.75rem"};
  `);
const CTAButtonContainer = styled_components__WEBPACK_IMPORTED_MODULE_5___default().div.withConfig({
  displayName: "ContentContainer__CTAButtonContainer",
  componentId: "bo1q2p-5"
})(["margin-left:1rem;"]);
const DescriptionTextContainer = styled_components__WEBPACK_IMPORTED_MODULE_5___default()(TextContainer).withConfig({
  displayName: "ContentContainer__DescriptionTextContainer",
  componentId: "bo1q2p-6"
})(["line-height:1;margin-bottom:1rem;", ""], _theme__WEBPACK_IMPORTED_MODULE_4__/* .media.tabletLarge */ .BC.tabletLarge`
    max-width: 70%;
  `);
const BreadcrumbContainer = styled_components__WEBPACK_IMPORTED_MODULE_5___default()(TextContainer).withConfig({
  displayName: "ContentContainer__BreadcrumbContainer",
  componentId: "bo1q2p-7"
})(["margin:initial;"]);
const IconContainer = styled_components__WEBPACK_IMPORTED_MODULE_5___default().div.withConfig({
  displayName: "ContentContainer__IconContainer",
  componentId: "bo1q2p-8"
})(["margin-right:0.75rem;background:", ";", ";border-radius:10px;width:3rem;height:3rem;display:flex;align-items:center;justify-content:center;", " transition:box-shadow 0.3s;& > svg{fill:", ";width:1.5rem;height:1.75rem;}&:hover{", "}"], p => p.theme.colors.blue, p => p.iconBorder && `border: 0.5px solid ${p.theme.colors.tertiaryBlue}`, p => p.onClick && "cursor: pointer;", p => p.theme.colors.white, p => p.onClick && `
        background-color: ${p => p.theme.colors.secondaryBlue};
        box-shadow: ${p => `0 5px 5px 0 ${p.theme.colors.blue}40`};
      `);
const LinkIconContainer = styled_components__WEBPACK_IMPORTED_MODULE_5___default()(IconContainer).withConfig({
  displayName: "ContentContainer__LinkIconContainer",
  componentId: "bo1q2p-9"
})(["margin-left:0.75rem;background:", ";border:0.5px solid ", ";& > svg{fill:", ";}"], p => p.theme.colors.backgroundGrey, p => p.theme.colors.secondaryBlue, p => p.theme.colors.blue);
const TitleInnerContainer = styled_components__WEBPACK_IMPORTED_MODULE_5___default().div.withConfig({
  displayName: "ContentContainer__TitleInnerContainer",
  componentId: "bo1q2p-10"
})(["display:flex;align-items:center;"]);
const MobileCTAs = styled_components__WEBPACK_IMPORTED_MODULE_5___default().div.withConfig({
  displayName: "ContentContainer__MobileCTAs",
  componentId: "bo1q2p-11"
})(["display:flex;justify-content:space-between;margin-top:1rem;margin-bottom:1.75rem;& > div{margin-left:initial;}"]);
const DesktopCTAs = styled_components__WEBPACK_IMPORTED_MODULE_5___default().div.withConfig({
  displayName: "ContentContainer__DesktopCTAs",
  componentId: "bo1q2p-12"
})(["display:flex;align-items:flex-end;justify-content:flex-end;margin-bottom:0.75rem;"]);
const Anchor = styled_components__WEBPACK_IMPORTED_MODULE_5___default().a.withConfig({
  displayName: "ContentContainer__Anchor",
  componentId: "bo1q2p-13"
})(["text-decoration:none;cursor:pointer;"]);
function ContentContainer({
  title,
  breadcrumb,
  description,
  children,
  cta,
  onClick,
  href,
  as,
  loading,
  limit,
  limitWidth,
  icon,
  iconBorder,
  onIconClick,
  iconLink,
  iconHref,
  secondaryCta,
  onSecondaryClick
}) {
  const isTabletLarge = (0,react_responsive__WEBPACK_IMPORTED_MODULE_1__.useMediaQuery)({
    query: `(min-width: ${_theme__WEBPACK_IMPORTED_MODULE_4__/* .sizes.tabletLarge */ .J7.tabletLarge}px)`
  });
  const isTablet = (0,react_responsive__WEBPACK_IMPORTED_MODULE_1__.useMediaQuery)({
    query: `(min-width: ${_theme__WEBPACK_IMPORTED_MODULE_4__/* .sizes.tablet */ .J7.tablet}px)`
  });
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_0__.useRouter)();
  const hasCTAs = !!cta || !!secondaryCta;
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.Fragment, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(Container, {
      limit: limit,
      limitWidth: limitWidth,
      children: [breadcrumb && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(BreadcrumbContainer, {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP, {
          size: "breadcrumb",
          align: "left",
          color: "black",
          children: breadcrumb
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(TitleTextContainer, {
        cta: hasCTAs,
        description: description,
        breadcrumb: breadcrumb,
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(TitleInnerContainer, {
          children: [icon && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(IconContainer, {
            iconBorder: iconBorder,
            onClick: onIconClick,
            children: icon
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP, {
            size: "contentTitle",
            align: "left",
            children: title
          }), iconLink && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(LinkIconContainer, {
            onClick: () => router.push(iconHref),
            children: iconLink
          })]
        })
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(TitleContainer, {
        description: !!description,
        hasCTAs: hasCTAs,
        children: [description && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(DescriptionTextContainer, {
          align: "center",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_common_Text__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP, {
            size: isTabletLarge ? "body" : "tiny",
            children: description
          })
        }), isTablet && hasCTAs && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(DesktopCTAs, {
          children: [secondaryCta && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(CTAButtonContainer, {
            children: typeof secondaryCta === "function" ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
              secondary: true,
              href: href,
              as: as,
              onClick: onSecondaryClick,
              children: secondaryCta
            }) : secondaryCta
          }), cta && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(CTAButtonContainer, {
            children: typeof cta === "string" ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
              href: href,
              as: as,
              onClick: onClick,
              children: cta
            }) : cta
          })]
        }), !isTablet && hasCTAs && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(MobileCTAs, {
          children: [secondaryCta && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(CTAButtonContainer, {
            children: typeof secondaryCta === "string" ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
              secondary: true,
              type: "button",
              href: href,
              as: as,
              onClick: onSecondaryClick,
              children: secondaryCta
            }) : secondaryCta
          }), cta && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(CTAButtonContainer, {
            children: typeof cta === "string" ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
              href: href,
              as: as,
              onClick: onClick,
              loading: loading,
              children: cta
            }) : cta
          })]
        })]
      }), children]
    })
  });
}

/***/ })

};
;