"use strict";
exports.id = 1593;
exports.ids = [1593];
exports.modules = {

/***/ 41593:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1187);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(91073);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);




const StyledToastContainer = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(react_toastify__WEBPACK_IMPORTED_MODULE_0__.ToastContainer).attrs({
  autoClose: false,
  enableMultiContainer: true
}).withConfig({
  displayName: "FormToastContainer__StyledToastContainer",
  componentId: "sc-5ow6rl-0"
})(["&.Toastify__toast-container{position:static;width:100%;color:", ";padding:0;", "}.Toastify__toast{border-radius:4px;min-height:3rem;display:flex;align-items:center;padding:0.75rem 1.5rem;}.Toastify__toast--error{background-color:", ";}.Toastify__toast--info{background-color:", ";}.Toastify__toast--warning{background-color:#f5c223;}.Toastify__toast--success{background-color:", ";}.Toastify__toast-body{font-weight:500;}.Toastify__progress-bar{}.Toastify__close-button > svg{height:30px;width:30px;}"], p => p.theme.colors.white, _theme__WEBPACK_IMPORTED_MODULE_1__/* .media.tablet */ .BC.tablet`
        max-width: ${p => p.maxWidth || "100%"};
    `, p => p.theme.colors.red, p => p.theme.colors.blue, p => p.theme.colors.green);

const FormToastContainer = ({
  containerId,
  maxWidth
}) => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(StyledToastContainer, {
    containerId: containerId,
    transition: react_toastify__WEBPACK_IMPORTED_MODULE_0__.Zoom,
    limit: 1,
    maxWidth: maxWidth
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FormToastContainer);

/***/ })

};
;